### vue-ts-h5 基于常竣提供的模板升级而来
- vue-cli-3脚手架， vant前端框架  typeScript为编程语言的H5项目模板

### 更新日志 
#### 2019-11-15 发布1.0版本。
#### 2019-12-11 发布2.0版本。
- 模块化开发
- 各组件抽离，适应模块化
- 根据域名参数（target,暂定，例如?target=demo1）适配路由,跳转目标页面

### 体验地址 
http://129.204.9.145/home

####注意：
- 开发前请进企业微信：文件盘>[华南]华南战略中心材料>技术类>技术规范>前端 阅读前端开发规范
- 为了保证项目样式统一：字体大小、字体颜色、背景颜色、圆角、页面边距统一，所有基础样式使用src/assets/styles/global/theme.less下面的样式
- 所有组件优先使用Vant有的，没有的再自行定义,避免全局样式不统一



### 文件和文件夹说明 
#####框架本身的文件和文件夹 不允许进行修改, 有更好的建议可以提出来
#### 1.文件夹
- api 后端请求地址统一放这里
- assets 静态文件 包括图片 样式 js文件
- components 自定义组件统一放这里
- config 项目配置统一在这里
- https http请求封装
- global 全局变量挂载
- mixins 全局混合器
- model 定义Object时必须定义model
- plugins 插件
- router 路由
- store 状态管理
- types 用于vue
- utils 工具类，需要统一挂载在vue
- views 所有页面都写在这里

#### 2.文件
- package.json 项目目前所有依赖 添加插件需要经过允许
- tslint.json 代码格式限制 不允许修改
- vue.config.js vue项目配置
