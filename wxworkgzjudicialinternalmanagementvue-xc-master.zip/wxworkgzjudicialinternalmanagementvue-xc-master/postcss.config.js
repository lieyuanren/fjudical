/**
 * @Author: tangzhicheng
 * @Date: 2020-03-31 10:04:12
 * @LastEditors: tangzhicheng
 * @LastEditTime: 2020-04-01 15:07:45
 * @Description: file content
 */
module.exports = ({ file }) => {
  // 第三方组件库的基准值是 37.5
  let rootValue = file && file.dirname && file.dirname.indexOf('vant') > -1 ? 37.5 : 75;
  return {
    plugins: {
      'postcss-pxtorem': {
        rootValue: rootValue, // 750px 分辨率设计稿
        propList: ['*', '!border'],
        selectorBlackList: ['downwarp'],
        minPixelValue: 3

      }
    }
  };
};
// module.exports = {
//   plugins: {
//     autoprefixer: {}
//   }
// }
