<!--
 * @Author: tangzhicheng
 * @Date: 2020-03-09 09:17:18
 * @LastEditors: tangzhicheng
 * @LastEditTime: 2021-03-30 14:17:13
 * @Description: file content
 -->
<template>
  <div style="height: 100%;">
    <!--region 遮罩层-->
    <div class="weui-mask transparent"
         v-show="showMasking || loading.show"></div>
    <!--endregion-->
    <!--region 全局loading-->
    <v-loading :loading="loading"></v-loading>
    <!--endregion-->
    <transition :css="!!direction"
                :name="transitionName"
                @after-enter="afterEnter"
                mode="out-in">
      <keep-alive exclude="AssessmentDetails,InstitutionDetail,PersonDetail,Login,Home,AuthenticActList,TaskList,CaseHandle,AddMediator,Details,DisputeList,DisputeDetails,MediatorDetails,MediatorUpdata,ProjectDeclaration,Schedule,CarManager,Registered,OA">
        <router-view :key="$route.path"
                     class="router-view"></router-view>
      </keep-alive>
    </transition>
  </div>
</template>
<script lang='ts'>
import { Vue, Component } from 'vue-property-decorator';
import { Getter, Mutation } from 'vuex-class';
import VLoading from '@/components/common/v-loading/index.vue';

@Component({
  components: { VLoading }
})
export default class App extends Vue {
  @Getter('showMasking')
  public showMasking!: boolean;
  @Getter('loading')
  public loading!: object;
  @Getter('direction')
  public direction!: string;
  @Mutation('SET_SHOW_MASKING')
  public setShowMasking!: any;

  public created() {
    if (this.$utils.Common.getParam('debug')) {
      const script = document.createElement('script');
      script.src = '//cdn.jsdelivr.net/npm/erud';
      document.body.appendChild(script);
      script.onload = () => {
        window.eruda.init();
      };
    }
  }

  public mounted() {
    console.log('i am app mounted');
  }

  get transitionName(): string {
    return 'van-pop-' + (this.direction === 'forward' ? 'in' : 'out');
  }

  public afterEnter() {
    this.setShowMasking(false);
  }
}
</script>
<style lang='less'>
@import "./assets/styles/global/close";
@import "./assets/styles/app/common";
@import "./assets/styles/app/custom";
@import "./assets/styles/app/publicStyle";
</style>
