/**
 * @Author : yeqinhua
 * @Date : 2019-11-13
 * @Version : 1.0
 * @Content : Api抽离 作为独立文件夹
 */
import SYSTEM from './modules/system'; // 系统
import CAR from './modules/car-manager'; // 停车
import NOTARIZATION from './modules/notarization'; // 公证
import JUDICIALEXPERTISE from './modules/judicial-expertise'; // 司法鉴定
import LEGALAID from './modules/legal-aid'; // 法律援助
import MEDIATION from './modules/mediation'; // 调解
import TMANAGER from './modules/tmanager'; // 任务管理
import BASESERVICE from './modules/base-service'; // 基层法律服务
import INTERNALCONTROL from './modules/internal-control'; // 基层法律服务
import ATTENDANCEMANAGE from './modules/attendance-manage'; // 考勤管理
import PersonalManager from './modules/personal-manager'; // 人事考核
import AccessManager from './modules/access-manager'; // 门禁
import PatrolManage from './modules/patrol-manage'; // 巡更管理
import PoliceCar from './modules/police-car'; // 警务用车
import AccessControlManage from './modules/access-contron-manage';
import DEMO from './modules/demo';


const API = {
  system: SYSTEM,
  car: CAR,
  notarization: NOTARIZATION,
  judicialExpertise: JUDICIALEXPERTISE,
  legalAid: LEGALAID,
  mediation: MEDIATION,
  tManager: TMANAGER,
  baseService: BASESERVICE,
  internalControl: INTERNALCONTROL,
  attendanceManage: ATTENDANCEMANAGE,
  personalManager: PersonalManager,
  patrolManage: PatrolManage,
  accessManager: AccessManager,
  policeCar: PoliceCar,
  demo: DEMO,
  accessControlManage: AccessControlManage
};

export default  API;

