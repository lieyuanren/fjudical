/**
 * @Author : lilili
 * @Date : 2020-07-21
 * 考勤管理
 */
const AccessControlManage = {
  dataList: '/api/access/listLibs', // 权限组信息列表
  accessList: '/api/access/listOrg',
  controlDetail: '/api/access/getLibInfo',
  recordList: '/api/access/listRecord',
  personList: '/api/access/listPerson',
  deviceList: '/api/access/listDevice',
  equipmentList: '/api/access/getEquipmentList'
};

export default  AccessControlManage;
