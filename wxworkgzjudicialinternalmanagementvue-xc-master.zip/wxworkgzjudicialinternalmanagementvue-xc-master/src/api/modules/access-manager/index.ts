/**
 * @Author : yuanhongbao
 * @Date : 2021/03/26
 * 门禁
 */
const accessManager = {
  checkAuth: '/api/intelligence/checkin/department' // 权限校验
};
export default  accessManager;
