/**
 * @Author : lilili
 * @Date : 2020-07-21
 * 考勤管理
 */
const AttendanceManage = {
  department: '/api/intelligence/checkin/department', // 部门列表
  attendance: '/api/intelligence/checkin/attendance', // 考勤数据列表
  checkin: '/api/intelligence/checkin/checkin', // 打卡记录列表
  static: '/api/intelligence/checkin/static', // 考勤统计数据
  exception: '/api/intelligence/checkin/attendance_detail' // 考勤异常
};
export default  AttendanceManage;
