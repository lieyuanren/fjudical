/**
 * 基层法律服务
 */
const BaseService = {
  person: '/api/basic_law/select_person'
};
export default  BaseService;
