/**
 * 停车管理
 */
const Car = {
  index: '/api/car/listCar',
  parkSize: '/api/car/parkSize',
  updateCar: '/api/car/addOrUpdate',
  itemInfo: '/api/car/listSlot?carNo=',
  deleteCar: '/api/car/delete?carNo='
};
export default  Car;
