const DEMO = {
  // demo api start
  login: '/demo/api/users/login',
  user: '/demo/api/users',
  area: {
    province: '/demo/api/province',
    city: '/demo/api/city'
  },
  sex: '/demo/api/sex'
  // demo api end
};
export default  DEMO;
