/**
 * 内控管理系统
 */
const INTERNALCONTROL = {

  /**
   * 首页
   */
  index: {
    // todo
  },

  /**
   * 个人办公
   */
  person: {
    list: {
      dbsx: '/api/work/will', // 待办事项
      blls: '/api/work/done', // 办理历史
      sqls: '/api/work/applyed' // 申请历史
    },
    detail: '/api/work/detail'// 待办事项、办理历史、申请历史
  },

  /**
   * 内控
   */
  conproject: {
    list: {
      jsxmsb: '/api/conproject/apply', // 建设项目申报列表接口
      jsxmbg: '/api/conproject/change', // 建设项目变更列表接口
      jsxmys: '/api/conproject/finish', // 建设项目变更列表验收,
      ysbz: '/api/budget/order', // 预算编制管理
      ystzgl: '/api/budget/change', // 预算调整管理
      jfsqgl: '/api/expenses/apply', // 经费申请管理
      jksqgl: '/api/expenses/borrow', // 借款申请管理
      bzsqgl: '/api/expenses/account', // 报账申请管理
      cgsqgl: '/api/purchase/purchase', // 采购申请管理
      zbgl: '/api/purchase/tenders', // 招标管理
      zbbggl: '/api/purchase/change', // 招标变更管理
      dylygl: '/api/purchase/single', // 单一来源管理
      htsqgl: '/api/contract/audit', // 合同审签管理
      htbggl: '/api/contract/change', // 合同变更管理
      htjcgl: '/api/contract/relieve', // 合同解除管理
      zcpzgl: '/api/asset_manage/configuration_list', // 资产配置管理
      cgjhgl: '/api/asset_manage/purchase_list', // 采购计划管理
      zcczgl: '/api/asset_manage/handler_list', // 资产处置管理
      czcjgl: '/api/asset_manage/rent_list', // 出租出借管理
      zcdbgl: '/api/asset_manage/allot_list', // 资产调拨管理
      zclygl: '/api/asset_manage/receive_list', // 资产领用管理
      zcyjgl: '/api/asset_manage/transfer_list', // 资产移交管理
      jxglxmzc: '/api/performance/project', //绩效管理项目支出
      jxglbmzc: '/api/performance/dept_list' // 绩效管理部门支出
    },
    detail: {
      jsxmsb: '/api/conproject/applyDetail', // 建设项目申报详情
      jsxmbg: '/api/conproject/changeDetail', // 建设项目变更详情
      jsxmys: '/api/conproject/finishDetail', // 建设项目变更详情
      ysbzgl: '/api/budget/orderDetail', // 预算编制管理
      ystzgl: '/api/budget/changeDetail', // 预算调整管理
      jfsqgl: '/api/expenses/applyDetail', // 经费申请管理
      jksqgl: '/api/expenses/borrowDetail', // 借款申请管理
      bzsqgl: '/api/expenses/accountDetail', // 报账申请管理
      cgsqgl: '/api/purchase/purchaseDetail', // 采购申请管理
      zbgl: '/api/purchase/tendersDetail', // 招标管理
      zbbggl: '/api/purchase/changeDetail', // 招标变更管理
      dylygl: '/api/purchase/singleDetail', // 单一来源管理
      htsqgl: '/api/contract/auditDetail', // 合同审签管理
      htbggl: '/api/contract/changeDetail', // 合同变更管理
      htjcgl: '/api/contract/relieveDetail', // 合同解除管理
      zcpzgl: '/api/asset_manage/configuration_detail', // 资产配置管理
      cgjhgl: '/api/asset_manage/purchase_detail', // 采购计划管理
      zcczgl: '/api/asset_manage/handler_detail', // 资产处置管理
      czcjgl: '/api/asset_manage/rent_detail', // 出租出借管理
      zcdbgl: '/api/asset_manage/allot_detail', // 资产调拨管理
      zclygl: '/api/asset_manage/receive_detail', // 资产领用管理
      zcyjgl: '/api/asset_manage/transfer_detail', // 资产移交管理
      jxglbmzc: '/api/performance/dept_detail', // 绩效管理部门支出详情
      xmzcjx: '/api/performance/projectDetail' // 绩效管理项目支出管理
    },
    audit: '/api/work/audit' // 审核
  },

  /**
   * 统计
   */
  static: {
    // todo
  }
};
export default  INTERNALCONTROL;

