/**
 * 司法确认
 * @type {{demo: string}}
 */
const JUDICIALEXPERTISE = {
  // demo api start
  demo: '/',
  index: {
    index: '/api/judicialexpertise/index/index'
  },
  case: {
    list: '/api/judicialexpertise/case/list',
    count: '/api/judicialexpertise/case/count',
    detail: '/api/judicialexpertise/case/detail'
  },
  organization: {
    count: '/api/judicialexpertise/organization/count',
    list: '/api/judicialexpertise/organization/list',
    orgPersonDetail: '/api/judicialexpertise/organization/org_person_detail',
    orgAppraiserDetail: '/api/judicialexpertise/organization/org_appraiser_detail',
    orgAbilityDetail: '/api/judicialexpertise/organization/org_ability_detail'
  },
  appraiser: {
    count: '/api/judicialexpertise/appraiser/count',
    list: '/api/judicialexpertise/appraiser/list',
    detail: '/api/judicialexpertise/appraiser/detail',
    creditDetail: '/api/judicialexpertise/appraiser/credit_detail'
  },
  static: '/api/judicialexpertise/static'
};
export default  JUDICIALEXPERTISE;

