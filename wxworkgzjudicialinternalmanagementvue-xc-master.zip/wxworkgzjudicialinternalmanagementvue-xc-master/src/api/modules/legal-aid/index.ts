const LEGALAID = {
  index: {
    indexInfo: '/api/legalaid/index/indexInfo'
  },
  organization: {
    list: '/api/legalaid/organization/list'
  },
  case: {
    list: '/api/legalaid/case/list',
    count: '/api/legalaid/case/count'
  },
  dataStatistics: {
    // 案件/咨询数
    caseAndConsultCount: '/api/legalaid/dataStatistics/caseAndConsultCount',
    // 案件分布
    caseDistribution: '/api/legalaid/dataStatistics/caseDistribution',
    // 结案情况
    caseFinishCondition: '/api/legalaid/dataStatistics/caseFinishCondition',
    // 咨询案件类型
    consultTypeCase: '/api/legalaid/dataStatistics/consultTypeCase',
    // 群体案件
    groupCaseCondition: '/api/legalaid/dataStatistics/groupCaseCondition'
  }
};
export default  LEGALAID;
