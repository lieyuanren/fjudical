const MEDIATION = {
  login: {
    loginByAccount: 'admin/api/wechat/loginByAccount', // 账号密码登录
    loginByWXWorkCode: 'admin/api/wechat/loginByWXWorkCode', // 企业微信授权码登录
    getUserInfo: 'admin/api/user/token', // token换用户信息
  },
  lookup: {
    town: 'admin/intelligentmediation/wechat/town/lookup', // 查询区县数据-越秀区、天河区等
    street: 'admin/intelligentmediation/wechat/street/lookup', // 查询街道数据-白云街道、白云街道等
    committees: 'admin/intelligentmediation/wechat/institution/committees', // 查询街道下的调委会数据
    institutionType: 'admin/api/common/institution_type', // 获取机构类型
    committeeType: 'admin/api/common/committee_type', // 获取调委会类型
    hzCommitteeType: 'admin/api/common/hz_committee_type', // 调委会行专类型列表
  },
  organization: {
    disputeCommittee: 'admin/api/institutions/disputeCommittee', // 查询调委会数据
    judicialOffice: 'admin/api/institutions/judicialOffice', // 查询司法局/所数据
    findJudicialById: 'admin/api/institutions/judicialOffice', // 查询司法所详情
    findCommitteeById: 'admin/api/institutions/disputeCommittee', // 查询调委会详情
  },
  mediator: {
    mediators: 'admin/api/mediators', // 查询get、添加post 、更新put调解员
    detail: 'admin/api/mediators/findByCode',
    analysis: 'admin/api/mediators/analysis', // 调解员能力分析 - 暂定
    updateMediators: 'api/mediators/updateMediator',  //更新调解员 POST方式
    addMediators: 'api/mediators', //POST方式， 新增级别，特长，账号密码添加
    listMediators :'api/mediators' //Get 方式 新增级别 特长
  },
  enterCase:{ //案件录入
    firstEnter:'admin/api/mediate/written/saveCaseInfo', // 案件录入初步保存 POST
    saveShengQing:'admin/api/mediate/written/saveNatural', //书面调解保存当事人 POST type=1
    saveBeiShengQing:'admin/api/mediate/written/saveNatural', //书面调解保存当事人 POST type=2
    finalSaveEnter:'admin/api/mediate/written/saveResult' //Post 保存结果
  },
  check: { // 纠纷排查
    list: 'admin/api/checkInfo/queryForPage',
    detail: 'admin/api/checkInfo/queryForDetail',
    add: 'admin/api/checkInfo/save',
    upload: 'admin/api/checkInfo/upload_attachment' // 附件上传
  },
  case: {
    // 案件api
    getDisputeType: 'admin/api/case_manager/dispute_type_list', // 纠纷类型列表
    list: '/admin/api/case_manager/list'
  },
  analysis: {
    // 统计分析
  },
  file_upload: 'admin/api/common/file_upload', // 文件上传
};
export default  MEDIATION;
