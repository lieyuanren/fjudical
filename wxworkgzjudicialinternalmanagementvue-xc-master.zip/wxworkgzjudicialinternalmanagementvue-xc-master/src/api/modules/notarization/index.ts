/**
 * 公证
 */
const Notarization = {
  annualAssessment: {
    list: '/api/notarization/gzAnnualAssessment/list',
    findByOrgCode: '/api/notarization/gzAnnualAssessment/findByOrgCode'
  },
  organization: {
    list: '/api/notarization/gzOrganization/list',
    detail: '/api/notarization/gzOrganization/findByCode',
    allList: '/api/notarization/gzOrganization/allList',
  },
  rewardPunishment: {
    findByOrgCode: '/api/notarization/gzRewardPunishment/findByOrgCode'
  },
  personnel: {
    list: '/api/notarization/gzPersonnel/list',
    findByCode: '/api/notarization/gzPersonnel/findByCode'
  },
  authenticAct: {
    findWithdrawn: '/api/notarization/gzAuthenticAct/findWithdrawn',
    list: '/api/notarization/gzAuthenticAct/list',
    count: '/api/notarization/gzAuthenticAct/count',
    findByCode: '/api/notarization/gzAuthenticAct/findByCode',
  },
  index: {
    caseView: '/api/notarization/gzNotarizationCase/caseView',
    charge: '/api/notarization/gzChargeCase/charge',
    notaryCase: '/api/notarization/gzPersonnel/notaryCase'
  },
  dataStatistics: {
    caseView: '/api/notarization/gzNotarizationCase/caseView',
    caseContrast: '/api/notarization/gzNotarizationCase/caseContrast',
    charge: '/api/notarization/gzChargeCase/charge',
    majorCase: '/api/notarization/gzNotarizationCase/majorCase',
    notaryCase: '/api/notarization/gzPersonnel/notaryCase',
    personCase: '/api/notarization/gzPersonnel/personCase'
  }
};
export default  Notarization;
