/**
 * 任务管理
 */
const PatrolManage = {
  // 考勤
  attendance: {
    cardList: '/api/inspection_card/list'
  },
  // 打卡记录
  record: {
    inspectionRoutes: '/api/inspection_route/list',
    inspectionAddress: '/api/inspection_address/list',
    inspectionPerson: '/api/inspection_person/list',
    inspectionDetail: '/api/inspection_detail/list'
  }
};
export default  PatrolManage;
