/**
 * 巡更
 */
const PatrolManager = {
  address: {
    list: '/api/inspection_address/list'
  },
  card: {
    list: '/api/inspection_card/list'
  },
  detail: {
    list: '/api/inspection_detail/list'
  },
  person:{
    list: '/api/inspection_person/list'
  },
  route:{
    list: '/api/inspection_route/list'
  }

};
export default  PatrolManager;
