/**
 * 人事考核
 */
const PersonalManager = {
  person: {
    listOrgs: '/api/personnel/person/orgs',
    listStaff:'/api/personnel/person/staff',
    listPeople:'/api/personnel/person',
    listFamily:'/api/personnel/person/family',
    listRp:'/api/personnel/person/rp'
  },
  union: {
    listunion: '/api/personnel/laborUnion'
  },
  train: {
    listtrain: '/api/personnel/train'
  },
  statistical:{
    list: '/api/personnel/statistics'
  },
  checks:{
    annual: '/api/personnel/annual',
    ordinary: '/api/personnel/ordinary/check',
    OrdinaryTimeById: '/api/personnel/ordinary/byid',
    AnnualById: '/api/personnel/annual/byid'
  }

};
export default  PersonalManager;
