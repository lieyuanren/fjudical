/**
 * @Author : lilili
 * @Date : 2021-03-29
 * 考勤管理
 */
const PoliceCar = {
  carUseList:'/api/policeCarUse/car_use_status', // 车辆使用列表
  carUseDetail:'/api/policeCarUse/details/', // 车辆使用详情
  orgList:'/api/policeOrganization/list', // 单位列表
  orgDetail:'/api/policeOrganization/', // 单位列表
  carList:'/api/policeCar/list', // 车辆列表
  carDetails:'/api/policeCar/details/', // 车辆详情
  carDetail:'/api/policeCar/', // 车辆详情
  driverList:'/api/policeDriver/list', // 驾驶员列表
  driverDetails:'/api/policeDriver/details/', // 驾驶员详情
  driverDetail:'/api/policeDriver/', // 驾驶员详情
  getOrgList:'/api/policeOrganization/get_org', // 单位机构
};
export default  PoliceCar;
