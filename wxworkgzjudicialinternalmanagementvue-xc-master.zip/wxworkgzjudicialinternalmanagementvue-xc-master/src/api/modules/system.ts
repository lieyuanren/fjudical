/**
 * 系统相关
 * @type {{wxwork: {getJSSDKConfig: string}, login: string}}
 */
const SYSTEM =  {
  login: '/api/system/login',
  moduleUser: '/api/system/module_user/',
  module: {
    list: '/api/module/list'
  },
  msg: {
    send: '/api/msg/send'
  },
  wxwork: { // 企业微信
    getJSSDKConfig: '/api/wechat_jssdk/config'
  }
};
export default  SYSTEM;
