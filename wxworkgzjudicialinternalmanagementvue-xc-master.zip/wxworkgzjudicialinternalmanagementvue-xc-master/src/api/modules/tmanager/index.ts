/**
 * 任务管理
 */
const TManager = {
  message: {
    list: '/api/message/list_by_user',
    read: '/api/message/update_status',
    delete: '/api/message/delete'
  },
  task: {
    taskList: '/api/tmanager/task_list',
    detail: '/api/tmanager/task_detail', //任务详情
    progress:'/api/tmanager/addProgress', //添加进度
    apply:'/api/tmanager/apply', //申请办结
    saveTimes:'/api/tmanager/autoTimes', //修改提醒时间
    applyTask:'/api/tmanager/finish', //修改提醒时间
    staticTask:'/api/tmanager/task_statistics', //统计任务
    addTask:'/api/tmanager/insert' ,//添加任务
    department:'/api/tmanager/department', //部门
    taskFrom:'/api/tmanager/taskFrom', //统计任务
    deptUser:'/api/tmanager/deptUser', //根据部门id获取用户
    deptAndUser:'/api/dept/dept_cascade', //根据部门id获取用户
    infoByTime: '/api/tmanager/infoByTime' // 通过时间段统计任务
  }
};
export default  TManager;
