<!--
* @Author : yeqinhua
* @Date :  2019-12-10
* @Version : 1.0
* @Content : 信息组件
-->
<template functional>
  <div class="van-toast van-toast--middle">
  </div>
</template>

<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator';

@Component
export default class Info extends Vue {
  @Prop()
  public mapKey: string = '';
}
</script>

<style lang="less">
</style>
