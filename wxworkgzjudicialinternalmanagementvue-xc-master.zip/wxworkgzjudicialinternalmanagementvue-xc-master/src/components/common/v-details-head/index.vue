<template>
  <div class="details-head">
    <div class="details-info">
      <div class="head-left">
        <div :key="index" v-for="(item ,index) in infoList">
          <p
            class="text4"
            v-if="item.label!=='公证处'&&item.label!=='机构简介'"
          >{{ item.label }}：{{ item.value }}</p>
          <p class="text1" v-else-if="item.label==='公证处'">{{ item.value }}</p>
          <p v-else-if="item.label ==='电话'"></p>
        </div>
      </div>
      <div class="head-right">
        <img :src="imgUrl"/>
      </div>
    </div>
    <div class="details-brief" v-if="isShow">
      <p class="text1">{{ briefObj.label }}</p>
      <p class="text4 content">{{ briefObj.value }}</p>
    </div>
  </div>
</template>

<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator';

// 详情头部组件
@Component
export default class DetailsHead extends Vue {
  @Prop({
    type: Array,
    default: []
  })
  // 基本信息数据
  public infoList!: any[];
  // 图片地址
  @Prop({
    type: String,
    default: ''
  })
  public imgUrl!: string;
  // 是否需要显示机构显示
  public isShow: boolean = false;
  // 机构简介
  public briefObj: any = {};

  // 判断是否有机构简介
  public created(): void {
    this.isShow = this.infoList.some((item: any) => {
      if (item.label === '机构简介') {
        this.briefObj = item;
        return true;
      }
    });
  }
}
</script>

<style lang="less">
.details-head {
  padding: 30px;
  background-color: #ffffff;

  .text1 {
    font-weight: 500 !important;
    margin-bottom: 20px;
  }
  .details-info {
    display: flex;

    .head-left {
      flex: 1;
    }

    .head-right {
      width: 190px;
      height: 190px;
      background: rgba(255, 255, 255, 1);
      border: 1px solid rgba(237, 237, 237, 1);
      border-radius: 6px;
    }
  }

  .details-brief {
    margin-top: 60px;
    .content {
      padding-top: 30px;
      border-top: 1px solid rgb(238, 238, 238);
    }
  }
}
</style>