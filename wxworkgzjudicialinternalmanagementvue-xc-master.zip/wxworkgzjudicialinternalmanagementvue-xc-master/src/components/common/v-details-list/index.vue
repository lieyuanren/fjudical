<template>
  <div class="details-list">
    <p class="text1">{{ item.title }}</p>
    <div class="content text4">
      <div class="span-box" v-if="item.span">
        <p :key="index" v-for="(spanArr,index) in  item.span">
          <span :key="span" v-for="span in spanArr">{{ span }}</span>
        </p>
      </div>
      <div class="text-box" v-else>
        <p
          :key="index"
          class="text4"
          v-for="(textObj ,index) in item.text"
        >{{ textObj.label }}：{{ textObj.value }}</p>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator';

// 详情列表组件
@Component
export default class DetailsList extends Vue {
  @Prop({
    type: Object,
    default: {}
  })
  public item!: any;
}
</script>

<style lang="less">
.details-list {
  padding: 30px;
  background-color: #ffffff;
  margin-top: 20px;

  .text1 {
    font-weight: 500 !important;
    margin-bottom: 20px;
  }
  .content {
    padding-top: 30px;
    border-top: 1px solid rgb(238, 238, 238);

    .span-box {
      p {
        display: flex;
        padding: 12px 0;
        justify-content: space-between;
      }
    }

    .text-box {
      p {
        padding: 10px 0;
      }
    }
  }
}
</style>