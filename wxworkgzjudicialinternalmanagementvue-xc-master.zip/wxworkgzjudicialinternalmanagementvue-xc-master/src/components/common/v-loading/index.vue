<!--
* @Author : ChangJun
* @Date :  2019-06-21
* @Version : 1.0
* @Content : loading组件
-->
<template functional>
  <div class="van-toast van-toast--middle" style="z-index: 2005;" v-show="props.loading.show">
    <div class="van-loading van-loading--circular van-toast__loading">
        <span class="van-loading__spinner van-loading__spinner--circular" style="color: white;">
        <svg class="van-loading__circular" viewBox="25 25 50 50">
          <circle cx="50" cy="50" fill="none" r="20"></circle>
        </svg>
        </span>
    </div>
    <div class="van-toast__text">{{props.loading.msg || '加载中'}}</div>
  </div>
</template>

<script lang="ts">
export default {
  props: {
    loading: {
      type: Object
    }
  }
};
</script>

<style lang="less">
.van-toast {
  position: fixed;
  top: 50%;
  left: 50%;
  display: flex;
  -webkit-box-orient: vertical;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  box-sizing: content-box;
  width: 90px;
  max-width: 70%;
  min-height: 90px;
  padding: 15px;
  color: #fff;
  font-size: 14px;
  line-height: 20px;
  white-space: pre-wrap;
  text-align: center;
  word-break: break-all;
  background-color: rgba(50, 50, 51, .88);
  border-radius: 4px;
  transform: translate3d(-50%, -50%, 0);
}
</style>
