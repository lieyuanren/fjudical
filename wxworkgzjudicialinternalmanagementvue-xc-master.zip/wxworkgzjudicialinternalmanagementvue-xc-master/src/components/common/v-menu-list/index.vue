<!-- 菜单入口列表组件 -->
<template>
  <van-cell-group class="panel">
    <van-cell @click="handleClick" class="panel-list" is-link>
      <span class="panel-list-title" slot="title">{{item.name}}</span>
      <img :src="item.icon" class="panel-list-icon" slot="icon"/>
      <van-icon
        class="panel-list-right"
        name="arrow"
        slot="right-icon"
        style="line-height: inherit;"
      />
    </van-cell>
  </van-cell-group>
</template>

<script lang="ts">
// @ts-ignore
import MenuData from '@/model/modules/notarization/integrityRecord/MenuData';
// @ts-ignore
import { Component, Prop, Vue } from 'vue-property-decorator';

@Component
export default class MenuList extends Vue {
  @Prop(Object)
  public item!: MenuData;

  // 完成路由跳转
  public handleClick(): void {
    if (this.item.type !== undefined) {
      // @ts-ignore
      this.$router.push({
        path: this.item.toUrl,
        query: {
          type: this.item.type
        }
      });
    } else {
      // @ts-ignore
      this.$router.push(this.item.toUrl);
    }
  }
}
</script>

<style lang="less">
.panel {
  margin-top: 20px;
  border-radius: 6px !important;
  &-list {
    border-radius: 6px !important;
    line-height: 136px !important;
    padding: 0 32px;
    &-icon {
      height: 66px;
      width: 66px;
      margin: auto;
      margin-right: 15px;
      vertical-align: middle;
    }
    &-title {
      font-size: 36px !important;
      color: #333333;
      vertical-align: middle;
    }
    &-right {
      line-height: 136px !important;
      color: #333333;
      vertical-align: middle;
    }
  }
}
</style>
