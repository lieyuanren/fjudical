<!-- 菜单入口列表组件 -->
<template>
  <div class="nodata">
    <img src="@/assets/images/nodata.png"/>
    <div class="nodata-text">暂无相关数据</div>
  </div>
</template>
<script lang="ts">
// @ts-ignore
import { Component, Vue } from 'vue-property-decorator';

@Component
export default class Nodata extends Vue {
}
</script>
<style lang="less">
.nodata {
  margin-top: 20%;
  img {
    margin: 0 auto;
    display: table-cell;
    height: 310px;
    width: 430px;
  }
  &-text {
    text-align: center;
    font-size: 30px;
    color: #666666;
  }
}
</style>
