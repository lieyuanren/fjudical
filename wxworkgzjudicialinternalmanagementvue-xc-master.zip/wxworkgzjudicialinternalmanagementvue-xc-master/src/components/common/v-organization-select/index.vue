<template>
  <div class="v-organization-select">
    <div @click="show = true">
      <span>{{ organization }}</span>
      <van-icon name="play" />
    </div>

    <van-popup v-model="show"
               round
               position="bottom">
      <van-picker show-toolbar
                  title="机构选择"
                  :columns="list"
                  @cancel="onCancel"
                  @confirm="onConfirm" />
    </van-popup>
  </div>
</template>

<script lang='ts'>
import { Component, Vue, Prop } from 'vue-property-decorator';

@Component({})
export default class extends Vue {
  @Prop() private readonly list: any;
  private organization: string = '请选择机构';
  private show: boolean = false;

  private onCancel(): void {
    this.show = false;
  }

  private onConfirm(arr: string[]): void {
    const str = arr.toString().replace(/,/g, '');
    this.show = false;
    this.organization = str;
    this.$emit('onConfirm', str);
  }
}
</script>

<style lang='less' scoped>
.v-organization-select {
  font-size: 32px;
  span,
  i {
    vertical-align: middle;
  }

  i {
    transform: rotateZ(90deg);
    margin-left: 6px;
  }
}
</style>