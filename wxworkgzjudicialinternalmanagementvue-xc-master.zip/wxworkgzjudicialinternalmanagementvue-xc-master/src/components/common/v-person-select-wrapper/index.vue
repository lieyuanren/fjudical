<!--
 * @Author: tangzhicheng
 * @Date: 2021-03-30 09:16:32
 * @LastEditors: tangzhicheng
 * @LastEditTime: 2021-03-30 14:03:46
 * @Description: file content
-->

<template>
  <div class="person-select">
    <div class="head">
      <span>{{ title }}</span>
      <van-icon class="add-icon"
                name="add-o"
                @click="open" />
    </div>
    <div class="content">
      <div class="item"
           v-for="item in personList"
           :key="item.id">
        <span>{{ item.name }}</span>
        <div class="del"
             @click="del(item.id)">
          <van-icon name="cross" />
        </div>
      </div>
    </div>

    <VPersonnelSelect ref="selector"
                      @confirm="onConfirm" />
  </div>
</template>

<script lang='ts'>
import { Component, Prop, Vue } from 'vue-property-decorator';
import VPersonnelSelect from '@/components/common/v-personnel-selector/index.vue';
import { PersonItem } from '@/model/modules/oa';

@Component({
  components: {
    VPersonnelSelect
  }
})
export default class PersonSelectWrapper extends Vue {
  @Prop() private title: string;
  private personList: PersonItem[] = [];

  private open() {
    (this.$refs.selector as VPersonnelSelect).open();
  }

  private del(id: number) {
    (this.$refs.selector as VPersonnelSelect).deselect(id);
    const index = this.personList.findIndex((it) => it.id === id);
    this.personList.splice(index, 1);
  }

  private onConfirm(data: any) {
    this.personList = data;
    this.$emit('confirm', data);
  }
}
</script>

<style lang='less' scoped>
.person-select {
  padding: 30px;
  background-color: #ffffff;
  margin: 20px 0;

  .head {
    padding-bottom: 20px;
    border-bottom: 1px solid #eeeeee;
    display: flex;
    justify-content: space-between;

    span {
      font-size: 32px;
      color: #333333;
    }

    .add-icon {
      font-size: 50px;
      color: #0a5ffe;
      font-weight: bold;
    }
  }

  .content {
    padding-top: 36px;
    display: flex;
    flex-wrap: wrap;

    .item {
      padding: 20px 40px;
      background: #fafafa;
      border: 1px solid #e4e4e4;
      border-radius: 8px;
      flex-shrink: 1;
      margin-right: 40px;
      margin-bottom: 20px;
      font-size: 28px;
      color: #666666;
      position: relative;

      .del {
        position: absolute;
        top: -17px;
        right: -17px;
        width: 34px;
        height: 34px;
        border-radius: 50%;
        background-color: #ff5659;
        color: #ffffff;
        text-align: center;
        font-size: 20px;
        line-height: 34px;
      }
    }
  }
}
</style>

