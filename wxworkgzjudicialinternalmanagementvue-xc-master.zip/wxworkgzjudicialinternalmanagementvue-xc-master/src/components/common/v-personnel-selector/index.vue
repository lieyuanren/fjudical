<!--
 * @Author: tangzhicheng
 * @Date: 2021-03-25 16:09:03
 * @LastEditors: tangzhicheng
 * @LastEditTime: 2021-03-30 14:00:40
 * @Description: file content
-->

<template>
  <van-popup v-model="show"
             get-container="body"
             closeable>
    <div class="personnel-selector">
      <p class="department-seletc">
        <span>政治部</span>
        <svg t="1616721768481"
             class="icon"
             viewBox="0 0 1024 1024"
             version="1.1"
             xmlns="http://www.w3.org/2000/svg"
             p-id="1706"
             width="12"
             height="12">
          <path d="M573.056 752l308.8-404.608A76.8 76.8 0 0 0 820.736 224H203.232a76.8 76.8 0 0 0-61.056 123.392l308.8 404.608a76.8 76.8 0 0 0 122.08 0z"
                p-id="1707"></path>
        </svg>
      </p>
      <van-search v-model="keyword"
                  placeholder="请输入搜索关键词"
                  @search="filterPerson"
                  @input="onInput" />
      <div class="list">
        <div class="person-item"
             v-for="item in currentData"
             :key="item.id"
             @click="onCheck(item)">
          <div :class="['content', item.checked && 'checked']">
            <img class="check-icon"
                 src="../../../assets/images/modules/mediation/cleck.png">
          </div>
          <p class="name">{{ item.name }}</p>
        </div>
      </div>
      <div class="action-bar">
        <div class="left">
          <van-checkbox v-model="checkedAll">
            <span class="check-label">全选</span>
          </van-checkbox>
        </div>
        <div class="center">
          <span>已选：</span>
          <span>{{ selectedCount }}</span>
        </div>
        <div class="btn"
             @click="onConfirm">确认</div>
      </div>
    </div>
  </van-popup>
</template>

<script lang='ts'>
import { Component, Vue } from 'vue-property-decorator';
import { PersonItem } from '@/model/modules/oa';

@Component
export default class VPersonnelSelect extends Vue {
  get selectedList() {
    return this.currentData.filter((item) => item.checked);
  }

  get selectedCount() {
    return this.currentData.reduce((total: number, target: any) => {
      return total + (target.checked ? 1 : 0);
    }, 0);
  }

  get checkedAll() {
    if (this.currentData.length === 0) {
      return false;
    }
    return this.currentData.every((item) => item.checked);
  }

  set checkedAll(newVal: boolean) {
    this.currentData.forEach((item) => (item.checked = newVal));
  }
  private show = false;
  private keyword = '';
  private personData: any[] = [
    {
      id: 1,
      name: '网老王',
      checked: false
    },
    {
      id: 2,
      name: '网老刘',
      checked: false
    },
    {
      id: 4,
      name: '张三丰',
      checked: false
    },
    {
      id: 6,
      name: '张三t',
      checked: false
    }
  ];
  private timer = -1;
  private currentData: PersonItem[] = [];
  private selectedIds: number[] = [];

  public open() {
    this.show = true;
  }

  public close() {
    this.show = false;
  }

  public deselect(id: number) {
    this.currentData.find((it) => {
      if (it.id === id) {
        it.checked = false;
        return true;
      }
    });
  }

  private created() {
    this.currentData = this.personData;
  }

  private filterPerson() {
    this.currentData = this.personData.filter((item) =>
      item.name.includes(this.keyword)
    );
  }

  private onInput() {
    clearTimeout(this.timer);
    this.timer = setTimeout(() => {
      this.filterPerson();
    }, 700);
  }

  private onConfirm() {
    this.close();
    this.$emit('confirm', this.selectedList);
  }

  private onCheck(target: any) {
    target.checked = !target.checked;
  }
}
</script>

<style lang='less' scoped>
.personnel-selector {
  width: 572px;
  background-color: #fff;
  padding-top: 74px;

  .department-seletc {
    padding: 10px 30px;
    font-size: 28px;
    color: #333333;
    display: flex;
    align-items: center;
    span {
      padding-right: 10px;
    }
  }

  .list {
    display: flex;
    padding: 0 30px;
    height: 600px;
    flex-wrap: wrap;
    overflow-y: auto;
    margin-bottom: 20px;
    .person-item {
      width: 33.3333%;
      min-height: 184px;
      flex-shrink: 0;
      .content {
        position: relative;
        margin: 0 auto;
        width: 124px;
        height: 124px;
        background-image: url("../../../assets/images/modules/judicial-expertise/avtor.png");
        background-size: 100% 100%;

        .check-icon {
          position: absolute;
          width: 46px;
          height: 46px;
          right: 0;
          bottom: 0;
          opacity: 0;
        }
      }

      .checked {
        .check-icon {
          opacity: 1;
        }
      }

      .name {
        text-align: center;
        padding: 0 8px;
        padding-top: 10px;
        font-size: 28px;
      }
    }
  }

  .action-bar {
    height: 96px;
    background-color: #eeeeee;
    padding: 0 30px;
    display: flex;
    font-size: 28px;
    align-items: center;
    justify-content: space-between;

    .center {
      span {
        &:nth-child(2) {
          color: #0a5ffe;
        }
      }
    }

    .btn {
      width: 140px;
      height: 64px;
      background-color: #0a5ffe;
      text-align: center;
      line-height: 64px;
      font-size: 32px;
      color: #ffffff;
    }
  }
}
</style>
 
