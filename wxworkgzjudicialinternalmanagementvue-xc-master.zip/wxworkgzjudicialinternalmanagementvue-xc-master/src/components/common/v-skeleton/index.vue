<!--
 * @Author: tangzhicheng
 * @Date: 2021-03-24 14:50:06
 * @LastEditors: tangzhicheng
 * @LastEditTime: 2021-03-24 14:57:32
 * @Description: file content
-->

<template>
  <div class="skeleton"
       v-if="loading">
    <div class="skeleton-item"
         v-for="n in count"
         :key="n">
      <van-skeleton title
                    :row="row" />
    </div>
  </div>
</template>

<script lang='ts'>
import { Component, Prop, Vue } from 'vue-property-decorator';

@Component
export default class VSkeleton extends Vue {
  @Prop({ default: 3 }) private row: number;
  @Prop({ default: 1 }) private count: number;
  @Prop({ default: false }) private loading: boolean;
}
</script>

<style lang='less' scoped>
.skeleton-item {
  padding: 30px 0;
  background-color: #ffffff;
  margin-bottom: 20px;
}
</style>

