<!--
 * @Author: 陈毛毛
 * @Date: 2021-03-26 11:49:52
 * @LastEditors: 陈毛毛
 * @LastEditTime: 2021-04-07 16:57:53
 * @Description: file content
-->
<template>
  <div class="tree">
    <van-tree-select
      :items="data"
      :active-id.sync="activeId"
      :main-active-index.sync="activeIndex"
      @click-item="sendData"
    />
  </div>
</template>

<script lang='ts'>
import { Component, Vue, Prop, Watch, Emit } from 'vue-property-decorator';
@Component
export default class AuthorityTree extends Vue {
  @Prop({
    type: Array,
    default: []
  })
  // 部门数据
  private data!: any[];

  @Prop({
    type: Boolean,
    default: true
  })
  // 弹窗显隐，默认显示
  private isShow!: boolean;
  private items: any[] = [
  {
    // 导航名称
    text: '所有城市',
    badge: 3,
    className: 'my-class',
    children: [
      {
        text: '温州',
        id: 1
      },
      {
        text: '杭州',
        id: 2
      }
    ]
  },
  {
    // 导航名称
    text: '所有城市1',
    badge: 3,
    className: 'my-class',
    children: [
      {
        text: '温州',
        id: 3
      },
      {
        text: '杭州',
        id: 4
      }
    ]
  }
];
  private activeId: number = 1;
  private activeIndex: number = 0;
  private sendData(val: any) {
    console.log(val);
    this.activeId = val.id;
    this.$emit('bindSend', val.id, val.text);
  }

}
</script>

<style lang='less' scoped>

.van-sidebar-item--select {
  border-color: #3770EB !important;
  // background: #e1e6f0;
}
.van-tree-select__item--active {
  color: #3770EB;
}
</style>
