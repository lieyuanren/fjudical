<template>
  <div class="department-tree">
    <div class="department-tree-header">
      <h3>权限组根目录</h3>
    </div>
    <!-- 已选部门 -->
    <div class="department-tree-select">
      <span v-if="selectedItems.length === 0">请选择：</span>
      <div v-else>
        <span v-for="(item, index) in selectedItems"
              @click="switchItems(item, index)"
              :key="'selected_'+index">{{ item.name }}</span>
      </div>
    </div>
    <!-- 树结构 -->
    <div class="department-tree-main">
      <!-- 左侧 -->
      <div class="department-tree-main-flex">
        <ul>
          <li v-for="(item, index) in leftTreeData"
              :key="index"
              @click="treeNodeClick(item, 'left')">
            <p :class="{'selected': selectedId === item.id}">{{ item.name }}</p>
          </li>
        </ul>
      </div>
      <!-- 右侧 -->
      <div class="department-tree-main-flex">
        <ul>
          <li v-for="(item, index) in rightTreeData"
              @click="treeNodeClick(item, 'right')"
              :key="'child_'+index">
            <p :class="{'selected': selectedId === item.id}">{{ item.name }}</p>
          </li>
        </ul>
      </div>
    </div>
  </div>
</template>

<script lang='ts'>
import { Component, Vue, Prop, Watch, Emit } from 'vue-property-decorator';
@Component
export default class AuthorityTree extends Vue {
  @Prop({
    type: Array,
    default: []
  })
  // 部门数据
  private data!: any[];

  @Prop({
    type: Boolean,
    default: true
  })
  // 弹窗显隐，默认显示
  private isShow!: boolean;

  private leftTreeData: any[] = [];
  private rightTreeData: any[] = [];
  private selectedItems: any[] = [];

  private selectedId: any = null;
  private selectedName: string = '';
  @Emit('bindSend') public send(
    selectedId: any,
    selectedName: string,
    isShow: boolean
  ) {
    // todo
  }

  @Watch('data')
  private watchData(): void {
    const storageSelectedData = window.sessionStorage.getItem(
      'selectedDepartment'
    );
    if (storageSelectedData) {
      // 有缓存时，取缓存
      const storage = JSON.parse(storageSelectedData);
      this.leftTreeData = storage.leftTreeData;
      this.rightTreeData = storage.rightTreeData;
      this.selectedItems = storage.selectedItems;
      this.selectedId = storage.selectedId;
      this.selectedName = storage.selectedName;
    } else {
      this.leftTreeData = this.data;
      this.rightTreeData = [];
      this.selectedItems = [];
      this.selectedId = null;
      this.selectedName = '';
    }
  }

  @Watch('isShow')
  private watchIsShow(): void {
    if (!this.isShow) {
      // 弹窗关闭时，存储
      const selectedDepartment = {
        leftTreeData: this.leftTreeData,
        rightTreeData: this.rightTreeData,
        selectedItems: this.selectedItems,
        selectedId: this.selectedId,
        selectedName: this.selectedName
      };
      window.sessionStorage.setItem(
        'selectedDepartment',
        JSON.stringify(selectedDepartment)
      );
    }
  }

  /**
   * 树节点点击事件
   */
  private treeNodeClick(item: any, type: string): void {
    let isLastNode = false; // 是否最后一级
    // 更新当前选中部门id、name
    this.selectedId = item.id;
    this.selectedName = item.name;
    // 更新左右两侧树结构
    if (type === 'left') {
      this.rightTreeData = item.child;
      if (!item.child || item.child === [] || item.child.length === 0) {
        isLastNode = true;
      }
    } else {
      if (item.child && item.child !== []) {
        this.leftTreeData = this.rightTreeData;
        this.rightTreeData = item.child;
      } else {
        isLastNode = true;
      }
    }
    // 更新已选部门信息
    const obj = {
      ...item,
      leftTreeData: this.leftTreeData,
      rightTreeData: this.rightTreeData
    };
    if (this.selectedItems.length === 0) {
      this.selectedItems.push(obj);
    } else {
      // 判断当前已选部门是否有同一层级(是否有相同的parent),有则替换,无则添加
      const i = this.isHasSameLevel(item.parent);
      if (i === null) {
        // 没有同一层级，直接添加
        this.selectedItems.push(obj);
      } else {
        // 有同一层级，根据返回的索引i进行替换
        this.selectedItems[i] = obj;
        this.selectedItems = this.selectedItems.slice(0, i + 1);
      }
    }
    // 向父组件传递选中id和name, isLastNode最后一级时通知父组件关闭弹窗
    this.send(this.selectedId, this.selectedName, !isLastNode);
  }

  // 查找已选部门是否有同级选项
  private isHasSameLevel(parentId: number) {
    let index: any = null;
    this.selectedItems.forEach((v, i) => {
      if (v.parent === parentId) {
        index = i;
      }
    });
    return index;
  }

  /**
   * 根据选中id切换部门
   */
  private switchItems(item: any, index: number): void {
    if (item.child && item.child !== []) {
      if (index >= 1) {
        this.leftTreeData = this.selectedItems[index - 1].leftTreeData;
        this.rightTreeData = this.selectedItems[index - 1].rightTreeData;
        this.selectedItems = this.selectedItems.slice(0, index);
      } else {
        this.leftTreeData = this.selectedItems[index].leftTreeData;
        this.rightTreeData = this.selectedItems[index].rightTreeData;
      }
    }
    this.selectedId = this.selectedItems[index - 1].id;
    this.selectedName = this.selectedItems[index - 1].name;
    // 向父节点传递选中id和name，不关闭弹窗
    this.send(this.selectedId, this.selectedName, true);
  }
}
</script>

<style lang='less' scoped>
.department-tree {
  height: 100%;
  overflow: hidden;
  &-header {
    h3 {
      font-size: 32px;
      font-weight: normal;
      text-align: center;
    }
    padding: 20px;
    border-bottom: 1px solid #eee;
  }
  &-select {
    padding: 20px 0;
    width: calc(100% - 40px);
    margin: 0 auto;
    overflow-x: auto;
    white-space: nowrap;
    span + span {
      margin-left: 20px;
    }
  }
  &-main {
    height: calc(100% - 46px - 39px - 40px);
    overflow: hidden;
    padding: 20px;
    display: flex;
    flex-direction: row;
    &-flex {
      flex: 1;
      height: 100%;
      overflow-y: auto;
    }
    ul li {
      p {
        font-size: 28px;
        padding: 10px 0;
      }
      p.selected {
        color: #0a5ffe;
      }
    }
  }
}
</style>
