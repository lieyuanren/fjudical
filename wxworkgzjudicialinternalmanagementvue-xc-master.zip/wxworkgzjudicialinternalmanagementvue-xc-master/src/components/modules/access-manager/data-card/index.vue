<template>
  <div class="data-card">
    <div class="data-card-item" @click="goRouter(item.id)">
      <div class="top">
        <div>{{item.name}}</div><div :class="{'btn' : true,'success' : item.distribute_status === 0}">{{item.distribute_status === 1 ? '下发中' : '下发成功'}}</div>
      </div>
      <div class="bottom">
        <div>
          <img class="data-card-abnormal-icon"
               src="../../../../assets/images/modules/access-manager/person.png"
               alt="">
          <span>{{item.size}}</span>
        </div>
        <div>
          <img class="data-card-abnormal-icon"
               src="../../../../assets/images/modules/access-manager/chat.png"
               alt="">
          <span>{{item.device_count}}</span>
        </div>
      </div>
    </div>
  </div>
</template>

<script lang='ts'>
  import { Component, Prop, Vue } from 'vue-property-decorator';

  @Component({
    filters: {
      textLimit(value: string): string {
        if (value.length > 14) {
          return value.substring(0, 13) + '…';
        }
        return value;
      }
    }
  })
  export default class DataCard extends Vue {
    @Prop({
      type: Object,
      default: () => ({})
    })
    private readonly item!: any;



    private goRouter(ID: any): void {
      this.$router.push({
        path: '/accessDetail',
        query: {
          id: ID
        }
      });
    }
  }
</script>

<style lang='less' scoped>
  .data-card {
    &-item {
      width: 95%;
      margin: 0 auto;
      margin-top: 24px;
      background: #fff;
      padding: 30px 30px 36px 30px;
      border-radius: 16px;
      box-sizing: border-box;
      .top {
        display: flex;
        justify-content: space-between;
        font-size: 32px;
        color: #363740;
        line-height: 44px;
        margin-bottom: 10px;
        .btn {
          font-size: 22px;
          color: #FFFFFF;
          background: #FB833A;
          border-radius: 12px 0 12px 0;
          padding: 8px 12px;
        }
        .success {
          background: #0AD795;
        }
      }
      .bottom {
        display: flex;
        div {
          margin-right: 94px;
          display: flex;
          font-size: 30px;
          color: #B4B8BE;
          align-items: center;
          img {
            width: 32px;
            height: 32px;
            margin-right: 8px;
          }
        }
      }
    }
  }

  // 重置样式
  .van-tag {
    position: absolute;
    top: 30px;
    right: 30px;
  }
</style>
