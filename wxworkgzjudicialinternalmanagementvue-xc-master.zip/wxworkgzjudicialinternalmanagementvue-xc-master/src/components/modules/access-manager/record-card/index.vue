<!--
 * @Author: 陈毛毛
 * @Date: 2021-03-23 11:27:41
 * @LastEditors: 陈毛毛
 * @LastEditTime: 2021-04-07 15:52:44
 * @Description: file content
-->
<template>
  <div class="record">
    <div class="item">
      <div class="img-wrap">
        <img :src="item.photo_path_view"
              alt="">
      </div>
      <div class="info">
        <div class="top">
          <div>{{item.display_name}}</div>
          <div>{{item.open_time | textLimit }}</div>
        </div>
        <div class="btm">
          <img src="../../../../assets/images/modules/access-manager/locate.png"
               alt="">
          <span>{{item.device_name}}</span>
        </div>
      </div>
    </div>
  </div>
</template>

<script lang='ts'>
import { Component, Prop, Vue } from 'vue-property-decorator';
import AttendanceCardModel from '@/model/modules/attendance-manage/attendance/AttendanceCardModel';
// @ts-ignore
import Common from '@/utils/common/common';

@Component({
  filters: {
    textLimit(value: string): any {
      return Common.dateFmt('yyyy-MM-dd hh:mm', new Date(value));
    }
  }
})
export default class RecordCard extends Vue {
  @Prop({
    type: Object,
    default: () => ({})
  })
  private readonly item!: AttendanceCardModel;

  private departments: any = [];

  private goRouter(errorDetail: any): void {
    this.$router.push({
      path: '/attendanceDetail'
    });
    window.sessionStorage.setItem('errorDetail', JSON.stringify(errorDetail));
  }
}
</script>

<style lang='less' scoped>
.record:nth-of-type(1) {
    border-radius: 48px 48px 0px 0px;
}

.record {
  width: 100%;
  background: #fff;
  .item {
    display: flex;
    padding: 30px;
    .img-wrap {
      margin-right: 24px;
      img {
        width: 84px;
        height: 84px;
        border-radius: 16px;
      }
    }

    .info {
      flex: 1;
      .top {
        display: flex;
        justify-content: space-between;
        font-size: 24px;
        color: #959BA6;
        line-height: 32px;
        margin-bottom: 8px;
        :first-child {
          font-size: 32px;
          font-weight: 600;
          color: #363740;
          line-height: 44px;
        }
      }

      .btm {
        display: flex;
        align-items: center;
        img {
          width: 32px;
          height: 32px;
          margin-right: 2px;
        }
      }
    }
  }
}

// 重置样式
.van-tag {
  position: absolute;
  top: 30px;
  right: 30px;
}
</style>
