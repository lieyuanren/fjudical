<template>
  <div class="member-data-card">
    <div class="member-data-card-info">
      <b class="text3">{{ item.name }}</b>
      <div class="text5">
        <span v-for="(v, index) in item.orgs"
              :key="index">
          {{ v.name }}
          <i v-show="index !== item.orgs.length - 1">、</i>
        </span>
      </div>
    </div>
    <div class="member-data-card-content">
      <ul>
        <li>
          <p class="text5">标准天数</p>
          <p class="text3">{{ item.standardDay }}</p>
        </li>
        <li>
          <p class="text5">应出勤</p>
          <p class="text3">{{ item.shouldDay }}</p>
        </li>
        <li>
          <p class="text5">正常打卡</p>
          <p class="text3">{{ item.normalDay }}</p>
        </li>
        <li>
          <p class="text5">缺勤天数</p>
          <p class="text3">{{ item.noDutyDay }}</p>
        </li>
        <li>
          <p class="text5">迟到天数</p>
          <p class="text3">{{ item.lateDay }}</p>
        </li>
        <li>
          <p class="text5">早退天数</p>
          <p class="text3">{{ item.leaveDay }}</p>
        </li>
      </ul>
    </div>
    <div class="member-data-card-abnormal"
         @click="goRouter(item)">
      <div class="member-data-card-abnormal-title">
        <img class="member-data-card-abnormal-icon"
             src="../../../../assets/images/modules/attendance-manage/light.png"
             alt="">
        <span>异常明细</span>
      </div>
      <img class="member-data-card-abnormal-arrow"
           src="../../../../assets/images/modules/attendance-manage/arrows.png"
           alt="">
    </div>
  </div>
</template>

<script lang='ts'>
import { Component, Prop, Vue } from 'vue-property-decorator';
import AttendanceCardModel from '@/model/modules/attendance-manage/attendance/AttendanceCardModel';

@Component({
  filters: {
    textLimit(value: string): string {
      if (value.length > 14) {
        return value.substring(0, 13) + '…';
      }
      return value;
    }
  }
})
export default class DataCard extends Vue {
  @Prop({
    type: Object,
    default: () => ({})
  })
  private readonly item!: AttendanceCardModel;

  private departments: any = [];

  // private judge(item: any): void {
  //   if (item.state === '注销') {
  //     this.type = 'danger';
  //   } else if (item.state === '暂停') {
  //     this.type = 'warning';
  //   }
  // }

  private  async  goRouter(item: any) {
    let params = {
      time: item.time,
      personId: item.id
    };
    const { code, data } = await this.$api.xHttp.post(
      this.$interface.attendanceManage.exception,
      params
    );
    if (code === 0) {
      this.$router.push({
        path: '/attendanceDetail'
      });
      window.sessionStorage.setItem('errorDetail', JSON.stringify(data));
    }

  }
}
</script>

<style lang='less' scoped>
.member-data-card {
  position: relative;
  padding: 0 30px;
  background-color: #ffffff;
  margin-top: 20px;
  &:last-child {
    margin-bottom: 20px;
  }
  &-info {
    display: flex;
    justify-content: space-between;
    padding: 20px 0;
    border-bottom: 1px solid #eee;
  }
  &-content {
    padding: 0 20px;
    ul {
      display: flex;
      flex-wrap: wrap;
      li {
        width: calc(100% / 3);
        padding: 15px 0;
        .text3 {
          font-size: 30px;
          font-weight: normal !important;
        }
      }
    }
    border-bottom: 1px solid #eee;
  }
  &-abnormal {
    display: flex;
    justify-content: space-between;
    padding: 20px 0;
    &-title {
      display: flex;
      justify-content: center;
      align-items: center;
    }
    &-icon {
      width: 40px;
      height: 40px;
      margin-right: 15px;
    }
    &-arrow {
      width: 14px;
      height: 26px;
      margin-top: 5px;
    }
  }
}

// 重置样式
.van-tag {
  position: absolute;
  top: 30px;
  right: 30px;
}
</style>
