<template>
  <div class="member-record-card">
    <div class="member-record-card-info">
      <b class="text3">{{ item.name }}</b>
      <span class="text5">
        {{ item.signTime }}
      </span>
    </div>
    <div class="member-record-card-remark text5">
      <span class="member-record-card-remark-icon">
        <img src="../../../../assets/images/modules/attendance-manage/mark.png"
             alt="">
        {{ item.originId }}
      </span>
      <p>
        <span v-for="(v, index) in item.orgs"
              :key="index">
          {{ v.name }}
        </span>
      </p>
    </div>
  </div>
</template>

<script lang='ts'>
import { Component, Prop, Vue } from 'vue-property-decorator';
import AttendanceCardModel from '@/model/modules/attendance-manage/attendance/AttendanceCardModel';

@Component({
  filters: {
    textLimit(value: string): string {
      if (value.length > 14) {
        return value.substring(0, 13) + '…';
      }
      return value;
    }
  }
})
export default class RecordCard extends Vue {
  @Prop({
    type: Object,
    default: () => ({})
  })
  private readonly item!: AttendanceCardModel;

  private departments: any = [];

  private goRouter(errorDetail: any): void {
    this.$router.push({
      path: '/attendanceDetail'
    });
    window.sessionStorage.setItem('errorDetail', JSON.stringify(errorDetail));
  }
}
</script>

<style lang='less' scoped>
.member-record-card {
  position: relative;
  padding: 0 30px;
  background-color: #ffffff;
  &:last-child {
    margin-bottom: 20px;
  }
  &-info {
    display: flex;
    justify-content: space-between;
    padding: 20px 0;
  }
  &-remark {
    display: flex;
    justify-content: space-between;
    padding-bottom: 20px;
    &-icon {
      display: flex;
      justify-content: center;
      align-items: center;
      img {
        width: 25px;
        height: 25px;
        margin-right: 10px;
      }
    }
  }
}
.member-record-card + .member-record-card {
  border-top: 1px solid #eee;
}

// 重置样式
.van-tag {
  position: absolute;
  top: 30px;
  right: 30px;
}
</style>
