<template>
  <div class="StatisticsChart">
    <div class="StatisticsChart-content">
      <div class="StatisticsChart-content-title">
        <img class="StatisticsChart-content-icon"
             src="../../../../assets/images/modules/attendance-manage/icon.png"
             alt="">
        考勤管理
      </div>
      <div class="StatisticsChart-content-chart">
        <canvas id="myChart"
                style="width: 100%; height: 100%;"></canvas>
      </div>
      <div class="StatisticsChart-content-data">
        <div>
          <p class="name">缺勤</p>
          <p>{{ lackNum }}</p>
        </div>
        <div>
          <p class="name">迟到</p>
          <p>{{ lateNum }}</p>
        </div>
      </div>
    </div>
  </div>
</template>

<script lang='ts'>
import { Component, Prop, Vue, Watch } from 'vue-property-decorator';
import pie from '@/plugins/antv-f2/pie';
import PieType from '@/model/common/f2/PieType';
// @ts-ignore
import pieInfo from '@/plugins/antv-f2/pieInFo';
@Component
export default class StatisticsChart extends Vue {
  @Prop({
    type: Object,
    default: () => ({})
  })
  private readonly data!: any;
  // 饼图
  private dataList: any[] = [];
  private totalNum: number = 0;
  private lackNum: number = 0;
  private lateNum: number = 0;
  /**
   * 绘制图表
   */
  private initChart(): void {
    const p = new PieType();
    p.type = '正常人次';
    if (this.totalNum === 0) {
      p.precent = 0;
    } else {
      p.precent = parseFloat(
        ((this.data.normalDay / this.totalNum) * 100).toFixed(1)
      );
    }
    p.num = this.data.normalDay;
    const p1 = new PieType();
    p1.type = '异常人次';
    if (this.totalNum === 0) {
      p1.precent = 0;
    } else {
      p1.precent = parseFloat(
        ((this.data.exceptionDay / this.totalNum) * 100).toFixed(1)
      );
    }
    p1.num = this.data.exceptionDay;
    this.dataList = [];
    this.dataList.push(p1);
    this.dataList.push(p);
    // 调用antv/f2组件
    pieInfo('myChart', this.dataList, ['#00B67D', '#1F80F1'], '人');
  }

  @Watch('data')
  private watchData(): void {
    console.log('this.data', this.data);
    this.totalNum = this.data.countDay;
    this.lackNum = this.data.noDutyDay;
    this.lateNum = this.data.lateDay;
    this.initChart();
  }
}
</script>
<style lang="less">
.StatisticsChart {
  padding: 40px;
  &-content {
    background: #fff;
    border-radius: 12px;
    &-title {
      font-size: 32px;
      font-weight: bold;
      padding: 40px;
      img {
        width: 45px;
        height: 45px;
        margin-right: 10px;
      }
    }
    &-chart {
      height: 400px;
      width: 100%;
    }
    &-data {
      display: flex;
      flex-direction: row;
      border-top: 1px solid #eeee;
      padding: 20px 0;
      margin-top: 30px;
      div {
        flex: 1;
        p {
          padding: 5px 0;
          text-align: center;
          font-size: 32px;
        }
        p.name {
          color: #999;
          font-size: 16px;
        }
      }
      div + div {
        border-left: 1px solid #eee;
      }
    }
  }
}
</style>
