<template>
  <div class="card-container">
    <div class="card-container-title">
      <div class="card-container-title-icon"></div>
      <div class="card-container-title-label">{{item.name}}</div>
      <div class="card-container-title-num">{{item.count}}人</div>
    </div>
    <div class="card-container-content"
         v-for="(card, idx) in item.cards"
         :key="idx">
      <div class="card-container-content-label">{{card.name}}</div>
      <div class="card-container-content-num">{{card.count}}人</div>
    </div>
  </div>
</template>

<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator';
import BCard from '../../../model/modules/baseservice/BCard';

@Component({})
export default class CCard extends Vue {
  @Prop() private item: BCard;
}
</script>

<style lang="less" scoped>
.card-container {
  margin: 30px;
  background: rgba(255, 255, 255, 1);
  border: 1px solid rgba(224, 224, 224, 0.2);
  border-radius: 12px;
  &-title {
    display: flex;
    padding: 0 30px;
    margin-top: 40px;
    justify-content: space-between;
    align-items: center;

    &-icon {
      width: 10px;
      height: 33px;
      background: rgba(10, 95, 254, 1);
      border-radius: 5px;
    }
    &-label {
      font-size: 36px;
      font-weight: bold;
      margin-left: 16px;
      margin-right: auto;
      color: rgba(51, 51, 51, 1);
    }
    &-num {
      font-size: 36px;
      font-weight: bold;
      color: rgba(51, 51, 51, 1);
    }
  }
  &-content {
    display: flex;
    padding-left: 55px;
    padding-right: 30px;
    font-size: 32px;
    color: rgba(102, 102, 102, 1);
    margin: 36px 0;
    justify-content: space-between;

    &:nth-last-child(1) {
      margin-bottom: 40px;
    }
  }
}
</style>
