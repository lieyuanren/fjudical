<!--
 * @Author: tangzhicheng
 * @Date: 2020-03-17 09:13:53
 * @LastEditors: tangzhicheng
 * @LastEditTime: 2020-04-01 16:13:29
 * @Description: 预算显示组件
 -->

<template>
  <div class="container">
    <info-list :infoList="moneyInfoList"></info-list>
  </div>
</template>

<script lang='ts'>
import MoneyInfo from '@/model/modules/internal-control/analysis/MoneyInfo';
import { Component, Prop, Vue, Watch } from 'vue-property-decorator';
import InfoList from '../v-info-list/index.vue';

@Component({
  components: {
    InfoList
  }
})
export default class BudgetPanel extends Vue {
  private moneyInfoList: MoneyInfo[] = [];
  @Prop() private statics: string;
  @Prop() private year: string;
  @Prop() private type: string;

  @Watch('statics')
  private async getStatics(): Promise<void> {
    await this.getData();
  }

  @Watch('year')
  private async getYear(): Promise<void> {
    await this.getData();
  }

  @Watch('type')
  private async getType(): Promise<void> {
    await this.getData();
  }

  private async mounted() {
    await this.getData();
  }

  /**
   * 数据请求
   */
  private async getData(): Promise<void> {
    console.log(this.type, this.statics, this.year);
    // 数据请求
    // const body = {
    //   type: this.type,
    //   statics: this.statics,
    //   year: this.year
    // };
    // const res = await this.$api.xHttp.post(this.$interface.tManager.task.taskList, body);
    // if (res.code === 0) {
    //   console.log(res.data);
    //   this.moneyInfoList = res.data;
    // }
    this.moneyInfoList = [
      {
        name: '办公室',
        budgetMoney: '3000000/45%',
        accountMoney: '2000000',
        expenditureMoney: '1500000'
      },
      {
        name: '机关党委',
        budgetMoney: '3000000/45%',
        accountMoney: '2000000',
        expenditureMoney: '1500000'
      },
      {
        name: '立法一处',
        budgetMoney: '3000000/45%',
        accountMoney: '2000000',
        expenditureMoney: '1500000'
      },
      {
        name: '综合保障中心',
        budgetMoney: '3000000/45%',
        accountMoney: '2000000',
        expenditureMoney: '1500000'
      },
      {
        name: '综合保障中心',
        budgetMoney: '3000000/45%',
        accountMoney: '2000000',
        expenditureMoney: '1500000'
      },
      {
        name: '综合保障中心',
        budgetMoney: '3000000/45%',
        accountMoney: '2000000',
        expenditureMoney: '1500000'
      },
      {
        name: '综合保障中心',
        budgetMoney: '3000000/45%',
        accountMoney: '2000000',
        expenditureMoney: '1500000'
      },
      {
        name: '综合保障中心',
        budgetMoney: '3000000/45%',
        accountMoney: '2000000',
        expenditureMoney: '1500000'
      },
      {
        name: '综合保障中心',
        budgetMoney: '3000000/45%',
        accountMoney: '2000000',
        expenditureMoney: '1500000'
      },
      {
        name: '综合保障中心',
        budgetMoney: '3000000/45%',
        accountMoney: '2000000',
        expenditureMoney: '1500000'
      }
    ];
    this.moneyInfoList.map((item: any, index: number) => {
      if (index === 0) {
        item.icon =
          'http://a3.att.hudong.com/68/61/300000839764127060614318218_950.jpg';
      } else if (index === 1) {
        item.icon =
          'http://a3.att.hudong.com/68/61/300000839764127060614318218_950.jpg';
      } else if (index === 2) {
        item.icon =
          'http://a3.att.hudong.com/68/61/300000839764127060614318218_950.jpg';
      } else {
        item.icon = index;
      }
    });
  }
}
</script>

<style lang='less' scoped>
.container {
  margin: 30px;

  &-img {
    width: 42px;
    height: 42px;
    margin-right: 25px;
  }

  &-span {
    font-size: 32px;
    font-weight: bold;
    color: rgba(153, 153, 153, 1);
    margin-right: 25px;
  }

  &-content {
    display: flex;
    flex-direction: column;
    font-size: 32px;
    font-weight: 500;
    color: rgba(153, 153, 153, 1);

    &-item {
      display: flex;
      justify-content: space-between;
      margin-bottom: 30px;
    }

    &-end {
      display: flex;
      justify-content: space-between;
    }
  }
}

// /deep/.van-cell {
//   position: relative;
//   display: flex;
//   box-sizing: border-box;
//   width: 100%;
//   padding: 30px 40px;
//   overflow: hidden;
//   color: #333333;
//   font-size: 32px;
//   line-height: 50px;
//   background-color: #fff;
//   height: 110px;
// }

// /deep/.van-cell__right-icon {
//   min-width: 1em;
//   height: 0.64rem;
//   font-size: 45px;
//   line-height: 0.64rem;
//   color: #bdbdbd;
// }

// /deep/.van-cell__name {
//   -webkit-box-flex: 1;
//   flex: 1;
//   font-size: 32px;
//   color: #333333;
//   font-weight: 500;
// }

// /deep/.van-collapse-item__content {
//   padding: 30px 40px 30px 120px;
//   line-height: 1.5;
//   background-color: #fff;
// }
</style>
 
