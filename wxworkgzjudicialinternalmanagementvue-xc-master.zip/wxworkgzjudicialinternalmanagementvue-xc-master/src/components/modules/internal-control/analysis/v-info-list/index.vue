<!--
 * @Author: suntaozhang
 * @Date: 2020-03-25
 * @LastEditors: tangzhicheng
 * @LastEditTime: 2020-05-06 15:16:01
 * @Description: 首页和统计页面列表
 -->
<template >
  <div class="info-list">
    <van-collapse accordion
                  v-for="(item, index) in infoList"
                  v-model="activeName"
                  :key="index">
      <van-collapse-item :name="index">
        <div slot="title">
          <span v-if="item.icon === index"
                class="container-span">{{ addZero(index + 1) }}</span>
          <img v-else
               class="container-img"
               :src="checkImg(index)">
          {{ item.name }}
        </div>
        <div class="container-content">
          <div class="container-content-item">
            <span>预算总额</span><span>{{ item.budgetMoney }}</span>
          </div>
          <div class="container-content-item">
            <span>到账金额</span><span>{{ item.accountMoney }}</span>
          </div>
          <div class="container-content-end">
            <span>预算支出</span><span>{{ item.expenditureMoney }}</span>
          </div>
        </div>
      </van-collapse-item>
    </van-collapse>
  </div>
</template>

<script lang='ts'>
import { Component, Vue, Prop } from 'vue-property-decorator';

@Component
export default class InfoList extends Vue {
  private activeName: number = -1;
  @Prop() private infoList: any;

  /**
   * 补0
   */
  private addZero(index: number): string {
    if (index < 10) {
      return '0' + index;
    } else {
      return index + '';
    }
  }

  /**
   * 选择排名图片
   */
  private checkImg(index: number): string {
    let imgUrl: string = require(`@/assets/images/modules/notarization/index/top-0${index +
      1}.png`);
    return imgUrl;
  }
}
</script>

<style lang='less' scoped>
.container {
  margin: 30px;

  &-img {
    width: 42px;
    height: 42px;
    margin-right: 25px;
  }

  &-span {
    font-size: 32px;
    font-weight: bold;
    color: rgba(153, 153, 153, 1);
    margin-right: 25px;
  }

  &-content {
    display: flex;
    flex-direction: column;
    font-size: 32px;
    font-weight: 500;
    color: rgba(153, 153, 153, 1);

    &-item {
      display: flex;
      justify-content: space-between;
      margin-bottom: 30px;
    }

    &-end {
      display: flex;
      justify-content: space-between;
    }
  }
}
</style>
<style lang="less">
.info-list {
  .van-cell {
    position: relative;
    display: flex;
    box-sizing: border-box;
    width: 100%;
    padding: 30px 40px;
    overflow: hidden;
    color: #333333;
    font-size: 32px;
    line-height: 50px;
    background-color: #fff;
    height: 110px;
  }

  .van-cell__right-icon {
    min-width: 1em;
    height: 0.64rem;
    font-size: 45px;
    line-height: 0.64rem;
    color: #bdbdbd;
  }

  .van-cell__name {
    -webkit-box-flex: 1;
    flex: 1;
    font-size: 32px;
    color: #333333;
    font-weight: 500;
  }

  .van-collapse-item__content {
    padding: 30px 40px 30px 120px;
    line-height: 1.5;
    background-color: #fff;
  }
}
</style>

 
