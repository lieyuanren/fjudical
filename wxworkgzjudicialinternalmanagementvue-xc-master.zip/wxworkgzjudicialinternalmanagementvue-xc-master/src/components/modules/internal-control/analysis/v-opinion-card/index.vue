<!--
 * @Author: tangzhicheng
 * @Date: 2020-03-18 09:13:18
 * @LastEditors: tangzhicheng
 * @LastEditTime: 2020-03-18 09:43:53
 * @Description: file content
 -->

 <template functional>
  <div class="opinion-card">
    <p class="row">
      <span class="name">{{ props.item.handler }}</span>
      <span class="state">（{{ props.auditStatus[props.item.status] }}）</span>
      <span class="date">{{ props.item.handleTime }}</span>
    </p>
    <p class="content">{{ props.item.content }}</p>
  </div>
</template>
 
 <script lang='ts'>
import Vue from 'vue';

export default Vue.extend({});
</script>
 
 <style lang='less' scoped>
.opinion-card {
  margin: 0 30px;
  border-bottom: 1px solid #eeeeee;
  height: 130px;
  padding: 15px 0;
  box-sizing: border-box;
  display: flex;
  flex-direction: column;
  justify-content: space-between;

  .row {
    font-size: 28px;
    color: #999999;
    display: flex;
    justify-content: space-between;

    .state {
      margin-right: auto;
      margin-left: 10px;
    }
  }

  .content {
    font-size: 28px;
  }
}
</style>
 
