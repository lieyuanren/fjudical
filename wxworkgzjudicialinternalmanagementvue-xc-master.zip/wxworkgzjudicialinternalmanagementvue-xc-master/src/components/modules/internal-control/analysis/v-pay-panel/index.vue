<!--
 * @Author: tangzhicheng
 * @Date: 2020-03-17 09:14:43
 * @LastEditors: tangzhicheng
 * @LastEditTime: 2020-03-18 10:19:02
 * @Description: 支出显示组件
 -->

 <template>
  <div class="pay-panel">
    <div class="pay-panel-content">
      <p class="title">
        本年度支出TOP3
      </p>
      <top-list :list="topList"></top-list>
    </div>
    <div class="pay-panel-content">
      <p class="title">
        其他
      </p>
      <progress-list :list="topList"></progress-list>
    </div>
  </div>
</template>
 
 <script lang='ts'>
import { Component, Vue, Watch, Prop } from 'vue-property-decorator';
import TopPayType from '@/model/modules/internal-control/analysis/TopPayType';
import OtherPayType from '@/model/modules/internal-control/analysis/OtherPayType';
import TopList from '@/components/modules/internal-control/analysis/v-top-list/index.vue';
import ProgressList from '@/components/modules/internal-control/analysis/v-progress-list/index.vue';

@Component({
  components: {
    TopList,
    ProgressList
  }
})
export default class PayPanel extends Vue {
  @Prop() private statics: string;
  @Prop() private year: string;
  @Prop() private type: string;

  private topList: TopPayType[] = [
    {
      payType: '人员支出',
      proportion: 56,
      money: 453423424
    },
    {
      payType: '人员支出',
      proportion: 56,
      money: 453423424
    },
    {
      payType: '人员支出',
      proportion: 56,
      money: 453423424
    }
  ];
  private otherList: OtherPayType[] = [];

  public created() {
    this.getData();
  }

  @Watch('year')
  private watchYear(): void {
    this.getData();
  }

  @Watch('type')
  private watchType(): void {
    this.getData();
  }

  /**
   * @description: 根据三个props请求数据
   * @param {type}
   * @return:Promsie<void>
   */
  private async getData(): Promise<void> {
    console.log('获取数据');
  }
}
</script>
 
 <style lang='less' scoped>
.pay-panel {
  &-content {
    margin: 0 30px;
    background-color: #ffffff;
    padding: 30px;
    border-radius: 12px;
    margin-top: 30px;
    &:nth-child(1) {
      margin-top: 0;
    }

    .title {
      font-size: 32px;
      font-weight: bold;
      color: #000000;
    }
  }
}
</style>
 
