<!--
 * @Author: tangzhicheng
 * @Date: 2020-03-17 15:12:33
 * @LastEditors: tangzhicheng
 * @LastEditTime: 2020-03-17 15:23:05
 * @Description: 数据统计其他列（函数组件）
 -->

 <template functional>
  <div class="progress-list">
    <div class="progress-list-item"
         v-for="(item, index) in props.list"
         :key="index">
      <p class="data">
        <span class="name">{{ item.payType }}</span>
        <span class="proportion">{{ item.proportion }}%</span>
        <span class="money">{{ item.money }}</span>
      </p>
      <van-progress :percentage="item.proportion"
                    :show-pivot="false"
                    stroke-width="8" />
    </div>
  </div>
</template>
 
 <script lang='ts'>
import Vue from 'vue';

export default Vue.extend({});
</script>
 
 <style lang='less' scoped>
.progress-list {
  &-item {
    font-size: 28px;
    .data {
      display: flex;
      justify-content: space-between;
      padding: 20px 0;

      .proportion {
        margin-left: auto;
        margin-right: 20px;
      }
    }
  }
}
</style>
 


