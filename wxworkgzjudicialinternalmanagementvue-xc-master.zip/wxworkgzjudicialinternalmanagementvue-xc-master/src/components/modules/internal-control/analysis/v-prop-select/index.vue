<!--
 * @Author: tangzhicheng
 * @Date: 2020-03-17 09:25:40
 * @LastEditors: tangzhicheng
 * @LastEditTime: 2020-03-17 10:22:20
 * @Description: 数据分析头部选择组件
 -->

 <template>
  <div class="prop-select">
    <van-divider>
      <div class="statistics"
           @click="handleShow(1)">
        <span>{{ statics }}</span>
        <van-icon name="play" />
      </div>
    </van-divider>
    <div class="prop-select-bottom">
      <div class="date"
           @click="handleShow(2)">
        <span>{{ year }}</span>
        <van-icon name="play" />
      </div>
      <div class="types"
           @click="handleShow(3)">
        <span>{{ type }}</span>
        <van-icon name="play" />
      </div>
    </div>
    <van-popup v-model="show"
               position="bottom">
      <van-picker :columns="columns"
                  show-toolbar
                  @confirm="onConfirm"
                  @cancel="onCancel" />
    </van-popup>
  </div>
</template>

 <script lang='ts'>
import { Component, Vue } from 'vue-property-decorator';

@Component
export default class PropSelect extends Vue {
  private show: boolean = false;
  private active: number = 0;
  private columns: string[] = [];
  /**
   * 三个参数
   */
  private statics: string = '年度预算汇总分析';
  private year: string = `${new Date().getFullYear()}`;
  private type: string = '部门';

  // 统计类型
  private statistics: string[] = ['年度预算汇总分析', '年度支出构成分析'];
  // 年份
  private years: string[] = [];
  // 类别
  private types1: string[] = [
    '部门',
    '项目',
    '预算支出功能'
  ];
  private types2: string[] = [
    '部门',
    '项目',
    '预算支出功能'
  ];

  public created() {
    this.initYear();
  }

  private initYear(): void {
    let year = new Date().getFullYear();
    for (let i = 0; i < 10; i++) {
      this.years.push(`${year--}`);
    }
  }

  private handleShow(index: number): void {
    this.show = true;
    this.active = index;

    if (index === 1) {
      this.columns = this.statistics;
    } else if (index === 2) {
      this.columns = this.years;
    } else if (index === 3) {
      if (this.statics === '年度预算汇总分析') {
        this.columns = this.types1;
      } else {
        this.columns = this.types2;
      }
    }
  }

  private onConfirm(str: string): void {
    this.show = false;
    if (this.active === 1) {
      this.statics = str;
    } else if (this.active === 2) {
      this.year = str;
    } else {
      this.type = str;
    }
    this.$emit('onConfirm', this.active, str);
  }

  private onCancel(str: string): void {
    this.show = false;
    this.$emit('onCancel', this.active, str);
  }
}
</script>

 <style lang='less' scoped>
.prop-select {
  height: 204px;
  background-image: url(../../../../../assets/images/modules/baseservice/bg.png);
  background-size: cover;
  overflow: hidden;
  font-size: 32px;

  .statistics {
    width: 370px;
    height: 60px;
    box-sizing: border-box;
    border: 1px solid #efffff;
    border-radius: 30px;
    color: #ffffff;
    font-size: 32px;
    display: flex;
    justify-content: center;
    align-items: center;
  }

  &-bottom {
    padding: 0 52px;
    display: flex;
    justify-content: space-between;

    .date,
    .types {
      color: #ffffff;
      display: flex;
      justify-content: center;
      align-items: center;
    }
  }
}

.van-icon {
  transform: rotateZ(90deg);
  margin-left: 10px;
}
</style>

