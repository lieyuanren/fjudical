<!--
 * @Author: tangzhicheng
 * @Date: 2020-03-17 11:01:11
 * @LastEditors: tangzhicheng
 * @LastEditTime: 2020-03-17 15:12:26
 * @Description: 数据统计前三项
 -->
<template >
  <div class="top-list">
    <div class="top-list-item"
         v-for="(item, index) in list"
         :key="index">
      <van-circle v-model="item.proportion"
                  :rate="item.proportion"
                  layer-color="#F3F3F5"
                  :stroke-width="80"
                  :clockwise="false"
                  :color="initColor(index)"
                  :text="`${item.proportion}%`" />
      <p class="name">{{ item.payType }}</p>
      <p class="money">{{ item.money }}</p>
    </div>
  </div>
</template>

<script lang='ts'>
import { Component, Vue, Prop } from 'vue-property-decorator';
import TopPayLisr from '@/model/modules/internal-control/analysis/TopPayType';

@Component
export default class TopList extends Vue {
  @Prop() private readonly list: TopPayLisr[];

  private initColor(index: number): string {
    let color = '';
    if (index === 1) {
      color = '#1E83E5';
    } else if (index === 2) {
      color = '#03B57B';
    } else {
      color = '#F3B13F';
    }

    return color;
  }
}
</script>

<style lang='less' scoped>
.top-list {
  display: flex;

  &-item {
    width: 33.33333%;
    height: 320px;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    padding-top: 20px;

    .name {
      margin-top: 30px;
    }
  }
}

.van-circle {
  width: 180px !important;
  height: 180px !important;
}
</style>

 
