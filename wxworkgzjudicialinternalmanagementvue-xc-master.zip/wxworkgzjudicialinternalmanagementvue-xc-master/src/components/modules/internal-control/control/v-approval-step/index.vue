<!--
 * @Author: tangzhicheng
 * @Date: 2020-03-16 16:40:39
 * @LastEditors: tangzhicheng
 * @LastEditTime: 2020-03-18 09:49:06
 * @Description: 审批流程
 -->
 
<template functional>
  <div class="approval-step">
    <div class="approval-step-title">
      <div class="point"></div>
      <div class="text">{{ props.item.name }}</div>
    </div>

    <div class="approval-step-content">
      <div class="item"
           v-for="(item, index) in props.item.handles"
           :key="index">
        <div class="state">

          <img :src="props.icon[item.status]">
        </div>
        <span class="name">{{ item.person }}</span>
        <span class="date">{{ item.handleTime }}</span>
      </div>
    </div>
  </div>
</template>

<script lang='ts'>
import Vue from 'vue';

export default Vue.extend({});
</script>

<style lang='less' scoped>
.approval-step {
  font-size: 28px;
  margin-top: 30px;
  &-title {
    display: flex;
    align-items: center;

    .point {
      width: 14px;
      height: 14px;
      background-color: #0a5ffe;
      border-radius: 50%;
    }

    .text {
      color: #666666;
      padding-left: 20px;
      font-weight: bold;
    }
  }

  &-content {
    background-color: #fafafa;
    padding: 0 20px;
    margin-top: 20px;
    margin-left: 30px;
    overflow: hidden;
    color: #666666;

    .item {
      display: flex;
      margin: 24px 0;
      justify-content: space-between;

      .state {
        width: 32px;
        height: 32px;

        img {
          width: 100%;
          height: 100%;
        }
      }

      .name {
        margin-right: auto;
        margin-left: 20px;
      }
    }
  }
}
</style>

