<!--
 * @Author: tangzhicheng
 * @Date: 2020-03-16 15:47:11
 * @LastEditors: tangzhicheng
 * @LastEditTime: 2020-03-16 16:18:25
 * @Description: 详情页 (函数式组件)
 -->

<template functional>
  <div class="cell-row">
    <span class="cell-row-label">{{ props.label }}</span>
    <span class="cell-row-value">{{ props.value }}</span>
  </div>
</template>

<script lang='ts'>
import Vue from 'vue';

/**
 * @props :item
 */
export default Vue.extend({});
</script>

<style lang='less' scoped>
.cell-row {
  font-size: 28px;
  display: flex;
  margin: 30px 0;

  &-label {
    color: #999999;
    width: 400px;
  }

  &-value {
    width: 290px;
    word-wrap:break-word
  }
}
</style>

