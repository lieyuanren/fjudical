<!--
 * @Author: tangzhicheng
 * @Date: 2020-03-16 10:44:00
 * @LastEditors: tangzhicheng
 * @LastEditTime: 2020-03-16 14:41:53
 * @Description: 内控管理单个选项
 -->

 <template>
  <div :class="{'manage-item':true,'manage-item-down':touch}"
       @touchstart="handleStart"
       @touchend="handleEnd"
       role="button">
    <div class="manage-item-image">
      <img :src="icon"
           v-if="icon">
    </div>
    <span class="manage-item-name">
      {{ name }}
    </span>
  </div>
</template>
 
 <script lang='ts'>
import { Component, Vue, Prop } from 'vue-property-decorator';

@Component
export default class ManageItem extends Vue {
  @Prop() private icon: string;
  @Prop() private name: string;
  @Prop({ default: '' }) private url: string;
  // 针对部分要传参跳转的需要
  @Prop({
    type: Object,
    default: () => ({})
  })
  private data: any;

  private touch: boolean = false;

  private handleStart(): void {
    this.touch = true;
  }

  private handleEnd(): void {
    this.touch = false;
    if (this.url) {
      this.$router.push({
        path: this.url,
        query: this.data
      });
    }
  }
}
</script>
 
 <style lang='less' scoped>
.manage-item {
  width: 33.333333%;
  height: 160px;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;

  &-image {
    width: 58px;
    height: 58px;
    img {
      width: 100%;
    }
  }

  &-name {
    font-size: 26px;
    margin-top: 20px;
  }
}

.manage-item-down {
  background-color: #eeeeee;
}
</style>
 
