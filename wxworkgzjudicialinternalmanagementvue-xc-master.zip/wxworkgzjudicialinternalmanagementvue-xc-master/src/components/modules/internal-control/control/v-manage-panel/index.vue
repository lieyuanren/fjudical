<!--
 * @Author: tangzhicheng
 * @Date: 2020-03-16 10:07:52
 * @LastEditors: tangzhicheng
 * @LastEditTime: 2020-03-16 14:38:08
 * @Description: 内控管理选项面板
 -->

<template>
  <div class="manage-panel"
       @click="handleClick">
    <p class="title">{{ title }}</p>
    <div class="manage-panel-body">
      <slot></slot>
    </div>
  </div>
</template>

<script lang='ts'>
import { Component, Vue, Prop } from 'vue-property-decorator';

@Component
export default class ManagePanel extends Vue {
  @Prop({ default: '管理' }) private readonly title: string;

  private handleClick(): void {
    this.$emit('onClick');
  }
}
</script>

<style lang='less' scoped>
.manage-panel {
  padding: 30px;
  color: #333333;
  background-color: #ffffff;
  border-bottom: 1px solid #eeeeee;

  .title {
    font-size: 32px;
    font-weight: bold;
  }

  &-body {
    flex-wrap: wrap;
    display: flex;
    margin-top: 20px;
  }
}
</style>

