<!--
 * @Author: suntaozhang
 * @Date: 2020-03-16
 * @LastEditTime: 2020-03-17 08:42:14
 * @Description: project content
 -->

<template>
  <div class="container-body"
       :item="item"
       @click="onClick">
    <div class="container-body-title">{{ item[module['name']] }}<span style="float: right; font-size: 14px; line-height: 22px;">{{ item['createTime'] }}</span></div>
    <div v-for="(itm, idx) in numArr"
         class="container-body-content"
         :key="idx">
      {{module[`label${itm + 1}`]}}：{{item[module[`field${itm + 1}`]]}}
    </div>
  </div>
</template>

<script lang='ts'>
  import {Component, Prop, Vue} from 'vue-property-decorator';

  @Component
  export default class ProjectContent extends Vue {
    @Prop() private item: any;
    @Prop() private module: any;

    private numArr: number[] = [];

    public mounted() {
      let keys = Object.keys(this.module);
      let numArr: number[] = [];
      let i = 0;
      keys.forEach((it: any) => {
        if (it.indexOf('field') !== -1) {
          numArr.push(i++);
        }
      });
      this.numArr = numArr;
    }

    private onClick() {
      this.$emit('click');
    }
  }
</script>

<style lang='less' scoped>
  .container {
    height: 100%;

    &-body {
      margin-top: 20px;
      min-height: 50px;
      background-color: #ffffff;
      padding: 40px 30px;

      &-title {
        font-size: 36px;
        font-weight: 500;
        color: rgba(51, 51, 51, 1);
      }

      &-content {
        font-size: 28px;
        font-weight: 500;
        color: rgba(153, 153, 153, 1);
        overflow: hidden;
        text-overflow: ellipsis;
        display: -webkit-box;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
      }
    }
  }
</style>
 
