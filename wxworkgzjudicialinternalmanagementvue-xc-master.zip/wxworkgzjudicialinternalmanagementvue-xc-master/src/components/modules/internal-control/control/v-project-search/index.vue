<!--
 * @Author: suntaozhang
 * @Date: 2020-03-16
 * @LastEditTime: 2020-05-06 10:49:37
 * @Description: project search
 -->

 <template>
  <div class="project-search">
    <van-search v-model="key"
                :placeholder="placeholder"
                @input="search" />
  </div>
</template>

 <script lang='ts'>
import { Component, Vue, Prop } from 'vue-property-decorator';

@Component
export default class ProjectSearch extends Vue {
  @Prop() private searchKey: string;
  @Prop() private placeholder: string;

  private key: string = this.searchKey;

  public search(): void {
    this.$emit('search', this.key);
  }
}
</script>

 <style lang='less'>
.project-search {
  .van-search {
    -webkit-box-align: center;
    align-items: center;
    box-sizing: border-box;
    padding: 30px;
  }

  .van-search__content {
    -webkit-box-flex: 1;
    flex: 1;
    padding-left: 0.21333rem;
    background-color: #f2f2f2;
    border-radius: 6px;
    height: 72px;
  }

  .van-field__control {
    display: block;
    box-sizing: border-box;
    width: 100%;
    min-width: 0;
    margin: 0;
    padding: 0;
    color: #666666;
    text-align: left;
    background-color: transparent;
    border: 0;
    resize: none;
    font-size: 28px;
    font-weight: 500;
  }
}
</style>
 
