<!--
 * @Author: tangzhicheng
 * @Date: 2020-03-24 10:17:58
 * @LastEditors: tangzhicheng
 * @LastEditTime: 2020-03-24 11:07:18
 * @Description: file content
 -->

<template>
  <div class="tab-list">
    <img :src="imgUrl" />
    <div :class="active === index?'tab-list-item active':'tab-list-item'"
         v-for="(value,index) in tabs"
         :key="index"
         @touchstart="handleClick(index)">
      {{ value }}
    </div>
  </div>
</template>

<script lang='ts'>
import { Component, Vue, Prop } from 'vue-property-decorator';

@Component
export default class TabList extends Vue {
  @Prop() private readonly tabs: string[];
  private active: number = 0;
  private imgUrl: string = require('@/assets/images/modules/notarization/index/bg@2x.png');

  private handleClick(index: number): void {
    this.active = index;
    this.$emit('onClick', this.active);
  }
}
</script>

<style lang='less' scoped>
.tab-list {
  position: relative;
  height: 238px;
  display: flex;
  justify-content: space-around;
  align-items: center;

  img {
    position: absolute;
    width: 100%;
    height: 100%;
  }

  &-item {
    position: relative;
    width: 214px;
    height: 90px;
    border-radius: 8px;
    background-color: #ffffff;
    font-size: 32px;
    color: #666666;
    text-align: center;
    line-height: 90px;
  }

  .active {
    background-color: #0a5ffe;
    color: #ffffff;
  }
}
</style>

 
