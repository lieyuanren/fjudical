<template>
  <div class="certificate-card">
    <div class="title">
      <span class="text2">{{ item.title }}</span>
      <van-tag :plain="state">{{ item.state }}</van-tag>
    </div>
    <p :key="index" class="text4" v-for="(obj,index) in item.dataList">
      <span>{{ obj.label }}</span>：
      <span>{{ obj.value }}</span>
    </p>
  </div>
</template>

<script lang='ts'>
import { Component, Prop, Vue } from 'vue-property-decorator';
import CertificateCardModel from '@/model/modules/judicial-expertise/appraisal-institution/CertificateCardModel';

@Component
export default class CertificateCard extends Vue {
  @Prop({
    type: Object,
    default: () => ({})
  })
  private readonly item!: CertificateCardModel;

  private state: string = '';

  public created(): void {
    this.setState();
  }

  private setState(): void {
    if (this.item.state === '未审核') {
      this.state = 'success';
    }
  }
}
</script>

<style lang='less' scoped>
.certificate-card {
  border: 1px solid rgba(223, 223, 223, 1);
  box-shadow: 0px 1px 16px 0px rgba(183, 183, 183, 0.63);
  border-radius: 12px;
  padding: 40px;
  margin-top: 30px;

  .title {
    display: flex;
    padding: 10px 0px;
    justify-content: space-between;

    .text2 {
      font-weight: normal !important;
    }
  }
}
</style>
