<template>
  <div class="credit-info">
    <div @click="handleClick" class="timer-select">
      <div class="timer">
        <span class="year">{{ year }}</span>
        <span>
          <van-icon name="arrow-down"/>
        </span>
      </div>
    </div>
    <div class="credit-list">
      <div>
        表彰奖励次数：
        <span :class="{'red':creditList[0]}">{{ creditList[0] }}次</span>
      </div>
      <div>
        违法犯罪次数：
        <span :class="{'red':creditList[1]}">{{ creditList[1] }}次</span>
      </div>
    </div>
    <div class="credit-list">
      <div>
        行政处理次数：
        <span :class="{'red':creditList[2]}">{{ creditList[2] }}次</span>
      </div>
      <div>
        行政处罚次数：
        <span :class="{'red':creditList[3]}">{{ creditList[3] }}次</span>
      </div>
    </div>
    <div class="credit-list">
      <div>
        行业处分次数：
        <span :class="{'red':creditList[4]}">{{ creditList[4] }}次</span>
      </div>
      <div>
        被投诉次数：
        <span :class="{'red':creditList[5]}">{{ creditList[5] }}次</span>
      </div>
    </div>
    <div class="credit-list">
      <div>
        有效投诉次数：
        <span :class="{'red':creditList[6]}">{{ creditList[6] }}次</span>
      </div>
    </div>
    <van-popup position="bottom" v-model="show">
      <van-picker :columns="yearArr" @cancel="onCancel" @confirm="onConfirm" show-toolbar/>
    </van-popup>
  </div>
</template>

<script lang='ts'>
import { Component, Prop, Vue } from 'vue-property-decorator';

@Component
export default class CreditInfo extends Vue {
  @Prop({
    type: Array,
    default: () => []
  })
  private readonly creditList!: number[];

  private show: boolean = false;
  private year: number = new Date().getFullYear();
  private yearArr: number[] = [];

  public async created(): Promise<void> {
    await this.getYear();
  }

  private onCancel(): void {
    this.show = !this.show;
  }

  private onConfirm(year: number): void {
    this.show = !this.show;
    this.year = year;
    // TODO:这里执行父级传递的数据请求方法
    this.$emit('getCreditList', year);
  }

  private handleClick(): void {
    this.show = !this.show;
  }

  private getYear(): void {
    if (this.yearArr.length !== 0) {
      return;
    }
    const curYear = new Date().getFullYear();
    this.year = curYear;
    for (let i = 0; i < 5; i++) {
      this.yearArr.push(curYear - i);
    }
  }
}
</script>

<style lang='less' scoped>
.timer-select {
  .timer {
    width: 184px;
    height: 56px;
    background: rgba(247, 247, 247, 1);
    border: 1px solid rgba(230, 230, 230, 1);
    border-radius: 28px;
    text-align: center;
    line-height: 56px;
    font-size: 24px;
    color: #666666;

    .year {
      padding-right: 12px;
    }

    span {
      vertical-align: middle;
    }
  }
}

.credit-list {
  display: flex;
  padding: 0 30px;
  justify-content: space-between;
  font-size: 28px;
  color: #333333;
  margin: 30px 0;

  span {
    color: #999999;
  }

  .red {
    color: #f84242;
  }
}
</style>
