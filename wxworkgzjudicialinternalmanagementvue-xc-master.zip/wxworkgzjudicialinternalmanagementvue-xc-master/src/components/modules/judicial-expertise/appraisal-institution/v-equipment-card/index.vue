<template>
  <div class="equipment-card">
    <p class="text4 head">
      <span>设备名称：</span>
      <span class="name">{{ item.name | checkEmpty }}</span>
      <van-tag :color="color" plain>{{ item.state | checkEmpty }}</van-tag>
    </p>
    <p class="text4">
      <span>型号：</span>
      <span>{{ item.type | checkEmpty }}</span>
    </p>
    <p class="text4">
      <span>数量及单位：</span>
      <span>{{ item.count | checkEmpty }}</span>
    </p>
    <p class="text4">
      <span>购入时间：</span>
      <span>{{ item.payTime | checkEmpty }}</span>
    </p>
    <p class="text4">
      <span>发票或（所有权凭证）编号：</span>
      <span>{{ item.serialNumber | checkEmpty}}</span>
    </p>
  </div>
</template>

<script lang='ts'>
import { Component, Prop, Vue } from 'vue-property-decorator';
import EquipmentCardModel from '@/model/modules/judicial-expertise/appraisal-institution/EquipmentCardModel';

@Component({
  filters: {
    checkEmpty(value: any) {
      if (!value) {
        return '/';
      }
      return value;
    }
  }
})
export default class EquipmentCard extends Vue {
  @Prop({
    type: Object,
    default: () => ({})
  })
  private readonly item!: EquipmentCardModel;
  private color: string = '#999999';

  private created() {
    this.setState();
  }

  private setState(): void {
    if (this.item.state === '未审核') {
      this.color = '#19BDCF';
    }
  }
}
</script>

<style lang='less' scoped>
.equipment-card {
  padding: 30px;
  background-color: #ffffff;
  margin: 24px 0;

  .head {
    display: flex;
    justify-content: space-between;

    .name {
      margin-right: auto;
    }
  }
}
</style>
