<template>
  <div @click="goRouter" class="institution-card">
    <div class="institution-card-body">
      <div class="institution-card-img"><img class="img" src="../../../../../assets/images/modules/judicial-expertise/org.png"></div>
      <div class="institution-card-content">
        <p class="text1">{{ item. organizationName | limitText(11) }}</p>
        <p class="text4">负责人：{{ item. person | limitText(11)}}</p>
        <p class="text4">地址：{{ item. address | limitText(17) }}</p>
        <div class="text4">
          <img :src="iconUrl"/>
          <span>{{ item.phoneNum| limitText(15) }}</span>
        </div>
      </div>
    </div>
    <van-tag :type="type" plain>{{ item.state }}</van-tag>
  </div>
</template>

<script lang='ts'>
import { Component, Prop, Vue } from 'vue-property-decorator';
import InstitutionCardModel from '@/model/modules/judicial-expertise/appraisal-institution/InstitutionCardModel';

@Component({
  // 限制标题名称，不超过13个字
  filters: {
    limitText(value: string, index: number): string {
      if (!value) {
        return '暂无';
      }
      if (value.length > index) {
        return value.substring(0, index - 2) + '…';
      }
      return value;
    }
  }
})
export default class InstitutionCard extends Vue {
  public type: string = 'primary';
  @Prop({
    type: Object,
    default: () => ({})
  })
  private readonly item!: InstitutionCardModel;
  private iconUrl: string = require('@/assets/images/modules/notarization/index/phone.png');

  public judge(item: any): void {
    if (item.state === '注销') {
      this.type = 'danger';
    } else if (item.state === '暂停') {
      this.type = 'warning';
    }
  }

  private created(): void {
    this.judge(this.item);
  }

  private goRouter(): void {
    this.$router.push({
      path: '/institutionDetails',
      query: {
        id: this.item.organizationId
      }
    });
  }
}
</script>

<style lang='less' scoped>

.img {
  width: 76px;
  height: 76px;
}
.institution-card {
  position: relative;
  padding: 30px;
  background-color: #ffffff;
  margin-bottom: 22px;

  .text1 {
    font-weight: normal !important;
  }

  &-body {
    display: flex;
  }

  &-img {
    width: 120px;
    height: 120px;
    border: 1px solid #eeeeee;
    text-align: center;
    margin-right: 30px;
    line-height: 120px;
  }

  &-content {
    padding-left: 24px;

    .text4 {
      img {
        width: 34px;
        height: 34px;
      }

      span {
        vertical-align: middle;
        padding-left: 10px;
        color: #0a5ffe;
      }
    }
  }

  // 重置样式
  .van-tag {
    position: absolute;
    top: 30px;
    right: 30px;
  }
}
</style>
