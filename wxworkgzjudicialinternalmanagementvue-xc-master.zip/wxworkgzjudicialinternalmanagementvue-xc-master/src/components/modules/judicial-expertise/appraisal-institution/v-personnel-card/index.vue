<template>
  <div class="personnel-card">
    <div class="img-box">
      <img src="../../../../../assets/images/modules/judicial-expertise/avtor.png"/>
    </div>
    <div class="content">
      <p class="head">
        <span class="text2">{{ item.title1 | checkEmpty }}</span>
        <span class="text3" v-if="item.title2">{{ item.title2 }}</span>
      </p>
      <div :key="index" class="text-list" v-for="(obj,index) in item.dataList">
        <p v-if="obj.label !=='电话'">
          <span>{{ obj.label}}</span>：
          <span>{{ obj.value | checkEmpty }}</span>
        </p>
        <div class="phone" v-else>
          <img :src="iconUrl"/>
          <span>{{ obj.value | checkEmpty }}</span>
        </div>
      </div>
    </div>
  </div>
</template>

<script lang='ts'>
import { Component, Prop, Vue } from 'vue-property-decorator';

// 鉴定机构 人员信息 展示卡
@Component({
  filters: {
    checkEmpty(value: any): string {
      if (!value) {
        return '/';
      }
      return value;
    }
  }
})
export default class PersonnelCard extends Vue {
  @Prop({
    type: Object,
    default: () => ({})
  })
  private readonly item!: any;
  private iconUrl: string = require('@/assets/images/modules/notarization/index/phone.png');
}
</script>

<style lang='less' scoped>
.personnel-card {
  padding: 24px 0;
  border-bottom: 1px solid #eeeeee;
  display: flex;
  overflow: hidden;
  .img-box {
    width: 190px;
    height: 190px;
    background-color: #eeeeee;
  }

  .content {
    flex: 1;
    padding-left: 24px;

    .text2,
    .text3 {
      font-weight: normal !important;
    }

    .head {
      span {
        padding-right: 30px;
      }
    }

    .text-list {
      margin: 6px 0;
      .phone {
        img {
          width: 34px;
          height: 34px;
          vertical-align: middle;
        }
        span {
          vertical-align: middle;
          font-size: 28px;
          padding-left: 12px;
          color: rgba(10, 95, 254, 1);
        }
      }
    }
  }
}
</style>
