<!--
 * @Author: tangzhicheng
 * @Date: 2021-03-23 10:44:30
 * @LastEditors: tangzhicheng
 * @LastEditTime: 2021-05-27 15:53:54
 * @Description: file content
-->
<template>
  <div @click="goRouter"
       class="appraiser-card">
    <div class="appraiser-card-body">
      <div class="appraiser-card-img">
        <img v-if="!item.imgUrl"
             :src="Photo">
        <img v-else
             :src="item.imgUrl">
      </div>
      <div class="appraiser-card-content">
        <p class="text1">{{ item.name }}</p>
        <p class="text4">所在机构：{{ item.organization | textLimit }}</p>
        <p class="text4">鉴定类别：{{ item.category | textLimit }}</p>
      </div>
    </div>
    <van-tag :type="type"
             plain>{{ item.state }}</van-tag>
  </div>
</template>

<script lang='ts'>
import { Component, Prop, Vue } from 'vue-property-decorator';
import AppraiserCardModel from '@/model/modules/judicial-expertise/appraiser/AppraiserCardModel';
// @ts-ignore
import Photo from '@/assets/images/modules/judicial-expertise/avtor.png';

@Component({
  filters: {
    textLimit(value: string): string {
      if (value && value.length > 14) {
        return value.substring(0, 13) + '…';
      }
      return value;
    }
  }
})
export default class AppraiserCard extends Vue {
  private type: string = 'primary';
  @Prop({
    type: Object,
    default: () => ({})
  })
  private readonly item!: AppraiserCardModel;

  private Photo: string = Photo;

  private judge(item: any): void {
    if (item.state === '注销') {
      this.type = 'danger';
    } else if (item.state === '暂停') {
      this.type = 'warning';
    }
  }

  private created(): void {
    this.judge(this.item);
  }

  private goRouter(): void {
    this.$router.push({
      path: '/appraiserDetails',
      query: {
        id: this.item.id
      }
    });
  }
}
</script>

<style lang='less' scoped>
.appraiser-card {
  position: relative;
  padding: 30px;
  background-color: #ffffff;
  margin-bottom: 20px;

  .text1 {
    font-weight: normal !important;
  }

  &-body {
    display: flex;
  }

  &-img {
    width: 120px;
    height: 120px;
  }

  &-content {
    padding-left: 24px;
  }
}

// 重置样式
.van-tag {
  position: absolute;
  top: 30px;
  right: 30px;
}
</style>
