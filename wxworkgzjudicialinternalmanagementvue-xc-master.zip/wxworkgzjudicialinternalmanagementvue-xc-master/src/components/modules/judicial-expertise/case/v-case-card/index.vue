<!--
 * @Author: tangzhicheng
 * @Date: 2021-03-23 10:44:30
 * @LastEditors: tangzhicheng
 * @LastEditTime: 2021-05-27 14:58:47
 * @Description: file content
-->
<template>
  <div @click="handleClick"
       class="case-card">
    <p class="text1">统一案号：{{ item.caseID }}</p>
    <p class="text4">机构名称：{{ item.organizationName }}</p>
    <p class="text4">委托人：{{ item.client }}</p>
    <p class="text4">结案时间：{{ item.overTime }}</p>
  </div>
</template>

<script lang='ts'>
import { Component, Prop, Vue } from 'vue-property-decorator';
import CaseCardModel from '@/model/modules/judicial-expertise/case/CaseCardModel';

@Component
export default class CaseCard extends Vue {
  @Prop({
    type: Object,
    default: {}
  })
  private readonly item!: CaseCardModel;

  // 跳转至详情页
  private handleClick(): void {
    this.$router.push({
      path: 'CaseDetails',
      query: {
        caseID: this.item.caseID
      }
    });
  }
}
</script>

<style lang='less' scoped>
.case-card {
  padding: 30px;
  background-color: #ffffff;
  margin-bottom: 22px;

  .text1 {
    margin-bottom: 6px;
    font-weight: normal !important;
  }

  .text4 {
    color: #999999;
  }
}
</style>
