<!--
 * @Author: tangzhicheng
 * @Date: 2020-03-09 09:17:18
 * @LastEditors: tangzhicheng
 * @LastEditTime: 2020-05-06 16:41:50
 * @Description: file content
 -->
<template>
  <div class="home-card">
    <span class="home-card-data">{{ item.data }}</span>
    <span class="home-card-prop">{{ item.prop }}</span>
    <img :src="item.imgUrl" />
  </div>
</template>

<script lang='ts'>
import { Component, Prop, Vue } from 'vue-property-decorator';
import HomeCardModel from '@/model/modules/judicial-expertise/home/HomeCardModel';

// 首页展示卡组件
@Component
export default class HomeCard extends Vue {
  @Prop({
    type: Object,
    default: 0
  })
  private readonly item!: HomeCardModel;
}
</script>

<style lang='less' scoped>
.home-card {
  position: relative;
  width: 100%;
  height: 220px;
  border-radius: 12px;
  margin-bottom: 40px;
  color: #ffffff;
  background-size: cover;

  &-data {
    position: absolute;
    font-size: 48px;
    left: 50px;
    font-weight: bold;
    top: 40px;
  }

  &-prop {
    position: absolute;
    left: 50px;
    top: 120px;
    font-size: 32px;
    opacity: 0.6;
  }

  img {
    width: 150px;
    height: 150px;
    position: absolute;
    top: 34px;
    right: 50px;
  }

  &:nth-child(2) {
    background-image: url(../../../../../assets/images/modules/judicial-expertise/bg-01.png);
  }

  &:nth-child(3) {
    background-image: url(../../../../../assets/images/modules/judicial-expertise/bg-02.png);
  }

  &:nth-child(4) {
    background-image: url(../../../../../assets/images/modules/judicial-expertise/bg-03.png);
  }
}
</style>
