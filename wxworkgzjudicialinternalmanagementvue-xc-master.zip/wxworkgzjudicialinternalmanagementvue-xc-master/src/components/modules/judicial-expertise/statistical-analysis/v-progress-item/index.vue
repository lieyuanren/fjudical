<template>
  <div class="progress-item">
    <div class="progress-item-head">
      <span>{{ item.organizationName }}</span>
      <span>{{ item.proportion }}%</span>
    </div>
    <div class="progress-item-progress">
      <van-progress :percentage="item.proportion" :show-pivot="false" stroke-width="8px"/>
    </div>
  </div>
</template>

<script lang='ts'>
import { Component, Prop, Vue } from 'vue-property-decorator';
import ProgressItemModel from '@/model/modules/judicial-expertise/statistical-analysis/ProgressItemModel';

@Component
export default class ProgressItem extends Vue {
  @Prop({
    type: Object,
    default: () => ({})
  })
  private item!: ProgressItemModel;
}
</script>

<style lang='less' scoped>
.progress-item {
  margin-bottom: 34px;
  &-head {
    display: flex;
    justify-content: space-between;
    color: #333333;
    font-size: 28px;
    padding-bottom: 10px;
  }
}
</style>
