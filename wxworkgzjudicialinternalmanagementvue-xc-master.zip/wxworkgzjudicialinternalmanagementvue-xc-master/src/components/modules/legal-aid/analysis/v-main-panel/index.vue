<template>
  <div class="main-panel">
    <div class="main-panel-head">
      <div class="item">
        <p class="text5">案件数量（件）</p>
        <p class="text1">{{caseCount}}</p>
      </div>
      <div class="item">
        <p class="text5">咨询数量（次）</p>
        <p class="text1">{{consultNumber}}</p>
      </div>
    </div>
    <div class="main-panel-content">
      <p class="text2">案件主体分布</p>
      <div class="canvas-box">
        <canvas id="myChart"></canvas>
      </div>
    </div>
    <div class="main-panel-content">
      <p class="text2">案件结案情况</p>
      <div class="canvas-box">
        <canvas id="container"></canvas>
      </div>
    </div>
  </div>
</template>

<script lang='ts'>
import { Component, Prop, Vue, Watch } from 'vue-property-decorator';
import f2 from '@/plugins/antv-f2/f2';
// const f2 = require('@/plugins/antv-f2/f2');
import columnar from '@/plugins/antv-f2/columnar';
import CaseOverModel from '@/model/modules/legal-aid/analysis/CaseOverModel';
import CaseMainModel from '@/model/modules/legal-aid/analysis/CaseMainModel';

@Component({})
export default class MainPanel extends Vue {
  @Prop() private readonly caseMain: CaseMainModel[];
  @Prop() private readonly caseOver: CaseOverModel[];
  @Prop() private readonly caseCount: number;
  @Prop() private readonly consultNumber: number;

  private data1: any[] = [];
  private data2: any[] = [];

  public created(): void {
    this.handleData();
  }

  // 挂着dom时 渲染f2控件
  public mounted(): void {
    f2(this.data1, ['#F6B043', '#00B67D', '#1F80F1']);
    columnar(this.data2);
  }

  // TODO:解决未在视图层出现的数据 未被监听的问题
  @Watch('caseMain')
  private watchCaseMian(): void {
    this.handleData();
    f2(this.data1, ['#F6B043', '#00B67D', '#1F80F1']);
  }

  @Watch('caseOver')
  private watchCaseOver(): void {
    this.handleData();
    columnar(this.data2);
  }

  // 处理数据
  private handleData(): void {
    this.data1 = [];
    this.data2 = [];
    if (this.caseMain) {
      this.data1 = this.handleValue(this.caseMain);
      this.data1.reverse();
    }
    if (this.caseOver) {
      this.data2 = this.handleValue(this.caseOver);
      this.data2.reverse();
    }
  }

  private handleValue(va: any): any[] {
    if (va instanceof Array) {
      return [...va];
    } else {
      return [va];
    }
  }
}
</script>

<style lang='less' scoped>
.main-panel {
  padding: 0 30px;

  &-head {
    background-color: #ffffff;
    height: 156px;
    border-radius: 12px;
    display: flex;
    justify-content: space-around;
    align-items: center;

    .item {
      .text1 {
        font-weight: 400 !important;
        margin-top: 6px;
      }
    }
  }

  &-content {
    padding: 30px 0;
    background-color: #ffffff;
    border-radius: 12px;
    margin: 30px 0;

    .text2 {
      padding: 0 30px;
      font-weight: bold;
    }

    .canvas-box {
      width: 100%;
      height: 400px;

      #myChart,
      #container {
        width: 100%;
        height: 100%;
      }
    }
  }
}
</style>
