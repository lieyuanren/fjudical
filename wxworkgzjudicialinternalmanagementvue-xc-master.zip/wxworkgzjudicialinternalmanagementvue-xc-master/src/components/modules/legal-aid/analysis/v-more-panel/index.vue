<template>
  <div class="more-panel">
    <div class="more-panel-content">
      <p class="text2">群体案件情况</p>
      <div class="canvas-box">
        <canvas id="myChart"></canvas>
      </div>
    </div>
    <div class="more-panel-content">
      <p class="text2">
        法律咨询案件类型情况</p>
      <div :key="index"
           class="item"
           v-for="(item,index) in legalAdvice">
        <p class="tips">
          <span>{{item.type}}</span>
          <span>{{item.num}}%</span>
        </p>
        <van-progress :percentage="item.num"
                      :show-pivot="false"
                      stroke-width="8" />
      </div>
    </div>
  </div>
</template>

<script lang='ts'>
import CaseGroupModel from '@/model/modules/legal-aid/analysis/CaseGroupModel';
import { Component, Prop, Vue, Watch } from 'vue-property-decorator';
import LegalAdviceModel from '@/model/modules/legal-aid/analysis/LegalAdviceModel';
import f2 from '@/plugins/antv-f2/f2';

@Component({})
export default class MorePanel extends Vue {
  @Prop() private readonly caseGroup: CaseGroupModel;
  @Prop() private readonly legalAdvice: LegalAdviceModel;

  private data1: any = [];

  public created(): void {
    this.handleData();
  }

  public mounted(): void {
    f2(this.data1, ['#00B67D', '#1F80F1']);
  }
  // TODO:解决未在视图层出现的数据 未被监听的问题
  @Watch('caseGroup')
  private watchCaseMian(): void {
    this.handleData();
    f2(this.data1, ['#00B67D', '#1F80F1']);
  }

  private handleData(): void {
    this.data1 = this.caseGroup;
  }
}
</script>

<style lang='less' scoped>
.more-panel {
  padding: 0 30px;
  &-content {
    padding: 30px 0;
    background-color: #ffffff;
    border-radius: 12px;
    margin-bottom: 30px;

    .text2 {
      padding: 0 30px;
      font-weight: 400 !important;
    }

    .canvas-box {
      width: 100%;
      height: 400px;

      #myChart {
        width: 100%;
        height: 100%;
      }
    }

    .item {
      padding: 0 30px;
      margin: 20px 0;
      .tips {
        font-size: 28px;
        display: flex;
        justify-content: space-between;
        margin-bottom: 20px;
      }
    }
  }
}
</style>
