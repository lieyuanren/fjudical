<!--
 * @Author: tangzhicheng
 * @Date: 2020-03-09 09:17:18
 * @LastEditors: tangzhicheng
 * @LastEditTime: 2020-05-06 14:39:52
 * @Description: file content
 -->
<template>
  <div class="data-card">
    <span class="number">{{ value }}</span>
    <span class="prop">{{ tips | changeText }}</span>
    <van-image :src="iconArr[index]" />
  </div>
</template>

<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator';

@Component({
  filters: {
    changeText(text: string): string {
      let newText = '';
      switch (text) {
        case 'organization':
          newText = '法律援助机构（家）';
          break;
        case 'lawyer':
          newText = '法律援助律师（人）';
          break;
        case 'case':
          newText = '本年度法律援助案件（件）';
          break;
        case 'consultation':
          newText = '本年度法律援助咨询（次）';

          break;
      }
      return newText;
    }
  }
})
export default class DataCard extends Vue {
  @Prop() private readonly value: number;
  @Prop() private readonly tips: string;
  @Prop() private readonly index: number;

  private iconArr: string[] = [
    require('@/assets/images/modules/legalAid/icon-01.png'),
    require('@/assets/images/modules/legalAid/icon-02.png'),
    require('@/assets/images/modules/legalAid/icon-03.png'),
    require('@/assets/images/modules/legalAid/icon-04.png')
  ];
}
</script>

<style lang="less" scoped>
.data-card {
  position: relative;
  margin: 40px;
  height: 170px;
  border-radius: 12px;
  color: #ffffff;

  .number {
    position: absolute;
    font-size: 48px;
    line-height: 48px;
    top: 35px;
    left: 50px;
  }

  .prop {
    position: absolute;
    font-size: 32px;
    top: 94px;
    left: 50px;
  }

  .van-image {
    position: absolute;
    top: 36px;
    right: 36px;
    width: 100px !important;
    height: 100px !important;
  }
}
</style>
