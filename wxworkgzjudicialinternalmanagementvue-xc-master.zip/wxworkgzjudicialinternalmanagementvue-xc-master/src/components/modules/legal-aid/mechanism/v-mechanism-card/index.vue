<!--
 * @Author: tangzhicheng
 * @Date: 2020-03-09 09:17:18
 * @LastEditors: tangzhicheng
 * @LastEditTime: 2020-05-06 14:55:32
 * @Description: file content
 -->
<template>
  <div class="mechanism-card">
    <div class="mechanism-card-img">
      <img :src="imgUrl" />
    </div>
    <div class="mechanism-card-content">
      <p class="text1 name">{{ item.name }}</p>
      <p class="text5 address">地址：{{ item.address }}</p>
      <p class="text4 phone">
        <img :src="iconUrl" />
        <span>{{ item.mobile }}</span>
      </p>
    </div>
  </div>
</template>


<script lang='ts'>
import { Component, Prop, Vue } from 'vue-property-decorator';
import MechanismModel from '@/model/modules/legal-aid/mechanism/MechanismModel';

@Component({})
export default class MechanismCard extends Vue {
  @Prop() private readonly item: MechanismModel;

  private iconUrl: string = require('@/assets/images/modules/notarization/index/phone.png');

  private imgUrl: string = require('@/assets/images/modules/notarization/index/institution-head.png');

  public created() {
    console.log(this.imgUrl);
  }
}
</script>

<style lang='less' scoped>
.mechanism-card {
  margin: 26px 0;
  background-color: #ffffff;
  padding: 30px 30px 30px 30px;
  display: flex;

  &-img {
    width: 140px;
    height: 140px;
  }

  &-content {
    flex: 1;
    padding-left: 30px;

    .name {
      font-weight: 400 !important;
    }
    .phone {
      display: flex;
      align-items: center;
      color: #0a5ffe;
      img {
        width: 34px;
        height: 34px;
      }
      span {
        padding-left: 10px;
      }
    }
  }
}
</style>
