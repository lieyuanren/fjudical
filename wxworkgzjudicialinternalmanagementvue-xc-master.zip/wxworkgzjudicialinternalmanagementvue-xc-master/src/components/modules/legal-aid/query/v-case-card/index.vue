<template>
  <div class="case-card">
    <p class="text1">案件号:{{ item.code }}</p>
    <p class="text4">登记时间:{{ item.registerTime }}</p>
    <p class="text4">受援人:{{ item.receivePerson }}</p>
    <p class="text4">受理机构:{{ item.receiveOrg }}</p>
    <p class="text4">承办人:{{ item.undertakePerson }}</p>
  </div>
</template>

<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator';
import CaseModel from '@/model/modules/legal-aid/query/CaseModel';

@Component({})
export default class CaseCard extends Vue {
  @Prop() private readonly item: CaseModel;
}
</script>


<style lang="less" scoped>
.case-card {
  padding: 30px;
  background-color: #ffffff;
  margin-bottom: 20px;

  .text1 {
    font-weight: 400 !important;
  }
}
</style>
