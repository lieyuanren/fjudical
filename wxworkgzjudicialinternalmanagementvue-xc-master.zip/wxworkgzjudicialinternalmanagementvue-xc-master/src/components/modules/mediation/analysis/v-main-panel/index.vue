<template>
  <div class="main-panel">
    <div class="main-panel-content content1">
      <div class="item">
        <span class="label">{{ date.getMonth()+1 }}月调解</span>
        <span class="label">案件总数</span>
        <span class="value">{{ caseObj.caseTotal }}</span>
      </div>
      <div class="item">
        <span class="label">{{ date.getMonth()+1 }}月调解中</span>
        <span class="label">案件数量</span>
        <span class="value">{{ caseObj.mediationCase }}</span>
      </div>
      <div class="item">
        <span class="label">{{ date.getMonth()+1 }}月调解</span>
        <span class="label">成功率</span>
        <span class="value">{{ caseObj.successCase }}</span>
      </div>
    </div>
    <div class="main-panel-content content2">
      <div class="item">
        <span class="label">1月-11月调解案件总数</span>
        <span class="value">{{ caseObj.allCase }}</span>
      </div>
      <div class="item">
        <span class="label">1月-11月调解成功率</span>
        <span class="value">{{ caseObj.allSuccessCase }}</span>
      </div>
    </div>
    <div class="main-panel-content content3">
      <div class="title">{{ date.getMonth()+1 }}月各类纠纷类别分布</div>
      <div class="tab-box">
        <div class="tab-item">
          <img :src="active === 0?icon1:icon3">
        </div>
        <div class="tab-item">
          <img :src="active === 1?icon2:icon4">
        </div>
        <div class="type-select"
             v-if="active === 1"
             @click="show = true">
          <span>{{ types }}</span>
          <van-icon name="play" />
        </div>
      </div>
      <van-swipe class="my-swipe"
                 :show-indicators="false"
                 @change="onChange">
        <van-swipe-item>
          <div class="canvas-box">
            <canvas id="myChart1"></canvas>
          </div>
        </van-swipe-item>
        <van-swipe-item>
          <div class="bar-box">
            <van-progress :percentage="disputeData.progress"
                          stroke-width="14"
                          :show-pivot="false" />
            <div class="item-list">
              <div class="item">
                <span class="label">排名</span>
                <span class="value">NO.{{ disputeData.ranking }}</span>
              </div>
              <div class="item">
                <span class="label">案件数量</span>
                <span class="value">{{ disputeData.caseCount }}</span>
              </div>
              <div class="item">
                <span class="label">案件占比</span>
                <span class="value">{{ disputeData.proportion }}</span>
              </div>
              <div class="item">
                <span class="label">环比上月</span>
                <span class="value">{{ disputeData.compare }}</span>
              </div>
            </div>
          </div>
        </van-swipe-item>
      </van-swipe>

    </div>
    <div class="main-panel-content content4">
      <div class="title">{{ date.getMonth()+1 }}月案件来源分布</div>
      <div class="canvas-box">
        <canvas id="myChart2"></canvas>
      </div>
    </div>
    <div class="main-panel-content content5">
      <div class="title">{{ date.getMonth()+1 }}月接受委托移送调解分布</div>
      <div class="canvas-box">
        <canvas id="myChart3"></canvas>
      </div>
    </div>
    <van-popup v-model="show"
               round
               position="bottom">
      <van-picker show-toolbar
                  title="纠纷类型"
                  :columns="columns"
                  @cancel="onCancel"
                  @confirm="onConfirm" />
    </van-popup>
  </div>
</template>

<script lang='ts'>
import { Component, Vue, Prop, Watch } from 'vue-property-decorator';
import pie from '@/plugins/antv-f2/pie';
import CaseTypes from '@/model/modules/mediation/analysis/CaseTypes';
import PieType from '@/model/common/f2/PieType';
import DisputeType from '@/model/modules/mediation/analysis/DisputeType';

@Component({})
export default class MainPanel extends Vue {
  @Prop() private readonly date: Date;
  @Prop() private readonly organization: string;
  private icon1: string = require('@/assets/images/modules/mediation/icon-bt.png');
  private icon2: string = require('@/assets/images/modules/mediation/icon-tx.png');
  private icon3: string = require('@/assets/images/modules/mediation/icon-bt-sel.png');
  private icon4: string = require('@/assets/images/modules/mediation/icon-tx-sel.png');

  private active: number = 0;

  private columns: string[] = [
    '领里纠纷',
    '其他纠纷',
    '损害赔偿纠纷',
    '劳动争议纠纷',
    '合同纠纷',
    '婚姻家庭纠纷',
    '物业管理纠纷',
    '道路交通事故纠纷',
    '房屋宅基地纠纷',
    '生产经营纠纷',
    '山林土地纠纷',
    '征地拆迁纠纷',
    '环境污染纠纷',
    '医疗纠纷',
    '消费纠纷',
    '旅游纠纷',
    '知识产权纠纷',
    '互联网纠纷'
  ];

  private show: boolean = false;

  private types: string = '领里纠纷';

  // 饼图1
  private dataList1: PieType[] = [];

  // 饼图2
  private dataList2: PieType[] = [];

  // 饼图3
  private dataList3: PieType[] = [];

  // 案件数值数据
  private caseObj: CaseTypes = new CaseTypes();

  // 纠纷数值数据
  private disputeData: DisputeType = new DisputeType();

  // 组件创建请求数据
  public async created() {
    this.getData();
  }

  // dom挂在完毕 初始化图表
  public mounted() {
    this.initChart();
  }

  // 时间，机构变化重新获取数据并初始化图表
  @Watch('organization')
  private watchOrganization(): void {
    this.getData();
    this.initChart();
  }
  @Watch('date')
  private watchDaten(): void {
    this.getData();
    this.initChart();
  }

  // 监听纠纷类型的变化并获取当前纠纷类型的相关数据
  @Watch('types')
  private watchTypes(): void {
    // ... getDisputeData
    console.log('获取纠纷类型数据');
  }

  /**
   * 绘制图表
   */
  private initChart(): void {
    pie('myChart1', this.dataList1, [
      '#F6B043',
      '#E55857',
      '#6E52D0',
      '#3436C7',
      '#1F80F1',
      '#00B67D'
    ]);
    pie('myChart2', this.dataList2, ['#F6B144', '#01B67B', '#1E80F1']);
    pie('myChart3', this.dataList3, [
      '#F6B043',
      '#E55857',
      '#6E52D0',
      '#1F80F1',
      '#00B67D'
    ]);
  }

  /**
   * 请求数据
   */
  private async getData(): Promise<void> {
    console.log('获取数据');
    this.caseObj = {
      caseTotal: 100,
      mediationCase: 89,
      successCase: '89%',
      allCase: 10023,
      allSuccessCase: '87.7%'
    };
    this.dataList2 = [
      {
        const: 'const',
        type: '主动调解',
        num: 123
      },
      {
        const: 'const',
        type: '依申请调解',
        num: 123
      },
      {
        const: 'const',
        type: '接受委托移送调解',
        num: 123
      }
    ];
    this.dataList3 = this.dataList1 = this.dataList2;
  }

  private onChange(active: number): void {
    this.active = active;
  }

  private onCancel(): void {
    this.show = false;
  }

  private onConfirm(str: string): void {
    this.show = false;
    this.types = str;
  }
}
</script>

<style lang='less' scoped>
.main-panel {
  padding: 0 30px;

  &-content {
    border-radius: 12px;
    background-color: #ffffff;
    margin-bottom: 28px;

    .label {
      font-size: 26px;
      color: #999999;
    }

    .value {
      font-size: 36px;
      font-weight: bold;
    }
  }

  .content1 {
    display: flex;
    height: 182px;

    .item {
      flex: 1;
      height: 100%;
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
    }
  }

  .content2 {
    display: flex;
    height: 150px;
    .item {
      flex: 1;
      display: flex;
      flex-direction: column;
      justify-content: center;

      .label {
        align-self: center;
      }

      .value {
        margin-left: 60px;
      }
    }
  }

  .content3 {
    height: 590px;
    display: flex;
    flex-direction: column;

    .tab-box {
      padding: 30px;
      padding-bottom: 0;
      display: flex;
      .tab-item {
        width: 80px;
        height: 60px;
        border: 1px solid #cccccc;
        box-sizing: border-box;
        display: flex;
        justify-content: center;
        align-items: center;

        img {
          width: 35px;
          height: 35px;
        }

        &:nth-child(1) {
          border-radius: 30px 0 0 30px;
        }

        &:nth-child(2) {
          border-radius: 0 30px 30px 0;
          border-left: none;
        }
      }

      .type-select {
        padding: 0 20px;
        height: 60px;
        border: 1px solid #cccccc;
        box-sizing: border-box;
        display: flex;
        justify-content: center;
        align-items: center;
        color: #cccccc;
        border-radius: 30px;
        margin-left: 30px;
        font-size: 28px;

        i {
          transform: rotateZ(90deg);
          font-size: 24px;
          margin-left: 6px;
        }
      }
    }

    .canvas-box {
      width: 690px;
      height: 100%;
      padding-bottom: 20px;
      box-sizing: border-box;

      #myChart1 {
        width: 100% !important;
        height: 380px !important;
      }
    }

    .bar-box {
      height: 100%;
      padding: 60px 40px 30px;
      box-sizing: border-box;

      .item-list {
        display: flex;
        justify-content: space-between;
        flex-wrap: wrap;
        margin-top: 30px;

        .item {
          width: 280px;
          height: 76px;
          background-color: #e7f3ff;
          margin: 20px 0;
          color: #2284f6;
          display: flex;
          align-items: center;

          .label {
            font-size: 24px;
            margin-left: 20px;
          }

          .value {
            font-size: 32px;
            font-weight: bold;
            margin-left: 10px;
          }
        }
      }
    }
  }

  .content4 {
    .canvas-box {
      height: 380px;
      padding-bottom: 20px;

      #myChart2 {
        width: 100%;
        height: 380px !important;
      }
    }
  }

  .content5 {
    .canvas-box {
      height: 380px;
      padding-bottom: 20px;

      #myChart3 {
        width: 100%;
        height: 380px !important;
      }
    }
  }

  .title {
    font-size: 28px;
    color: #000000;
    padding: 40px;
    padding-bottom: 0;
    font-weight: bold;
  }
}

.van-swipe {
  flex: 1;
}
</style>