<template>
  <div class="other-panel">
    <div class="other-panel-content content1">
      <div class="row">
        <div class="item">
          <span class="label">全市调解组织数</span>
          <span class="value">{{ mediationObj.organizationCount }}</span>
        </div>
        <div class="item">
          <span class="label">全市调解人员数量</span>
          <span class="value">{{ mediationObj.wholeCity }}</span>
        </div>
      </div>
      <div class="row">
        <div class="item">
          <span class="label">行专调解人员数量</span>
          <span class="value">{{ mediationObj.majorPerson }}</span>
        </div>
        <div class="item">
          <span class="label">12月行专调解案件数量</span>
          <span class="value">{{ mediationObj.majorCase }}</span>
        </div>
      </div>
    </div>
    <div class="other-panel-content content2">
      <div class="title">全市人民调解案件数量</div>
      <div class="canvas-box">
        <canvas id="myChart1"></canvas>
      </div>
    </div>

    <div class="other-panel-content content3">
      <div class="title">上月纠纷排查预警情况</div>
      <div class="canvas-box">
        <canvas id="myChart2"></canvas>
      </div>
    </div>
  </div>
</template>

<script lang='ts'>
import { Component, Vue, Prop, Watch } from 'vue-property-decorator';
import borKenLine from '@/plugins/antv-f2/borkenLine';
import BorkenLineType from '@/model/common/f2/BrokenLineType';
import barRow from '@/plugins/antv-f2/barRow';
import BarRowType from '@/model/common/f2/BarRowType';
import MediationType from '@/model/modules/mediation/analysis/MediationType';

@Component({})
export default class OtherPanel extends Vue {
  @Prop() private readonly date: Date;
  @Prop() private readonly organization: string;

  private mediationObj: MediationType = new MediationType();

  private dataList1: BorkenLineType[] = [];

  private dataList2: BarRowType[] = [];

  // 组件创建请求数据
  public created() {
    this.getData();
  }

  // dom挂载 初始化图表
  public mounted() {
    this.initChart();
  }

  // 时间，机构变化重新获取数据并初始化图表
  @Watch('organization')
  private watchOrganization(): void {
    this.getData();
    this.initChart();
  }
  @Watch('date')
  private watchDaten(): void {
    this.getData();
    this.initChart();
  }

  private initChart(): void {
    borKenLine('myChart1', this.dataList1);
    barRow(this.dataList2, 'myChart2');
  }

  /**
   * 请求数据
   */
  private async getData(): Promise<void> {
    this.dataList1 = [
      {
        xAxis: '1月',
        value: 10
      },
      {
        xAxis: '2月',
        value: 123
      },
      {
        xAxis: '3月',
        value: 56
      },
      {
        xAxis: '4月',
        value: 67
      },
      {
        xAxis: '5月',
        value: 89
      },
      {
        xAxis: '6月',
        value: 77
      }
    ];

    this.dataList2 = [
      {
        name: 'London',
        type: 'Jan.',
        num: 18.9
      },
      {
        name: 'London',
        type: 'Feb.',
        num: 28.8
      },
      {
        name: 'London',
        type: 'Mar.',
        num: 39.3
      },
      {
        name: 'London',
        type: 'Apr.',
        num: 81.4
      },
      {
        name: 'London',
        type: 'May.',
        num: 47
      },
      {
        name: 'London',
        type: 'Jun.',
        num: 20.3
      },
      {
        name: 'London',
        type: 'Jul.',
        num: 24
      },
      {
        name: 'London',
        type: 'Aug.',
        num: 35.6
      },
      {
        name: 'Berlin',
        type: 'Jan.',
        num: 12.4
      },
      {
        name: 'Berlin',
        type: 'Feb.',
        num: 23.2
      },
      {
        name: 'Berlin',
        type: 'Mar.',
        num: 34.5
      },
      {
        name: 'Berlin',
        type: 'Apr.',
        num: 99.7
      },
      {
        name: 'Berlin',
        type: 'May.',
        num: 52.6
      },
      {
        name: 'Berlin',
        type: 'Jun.',
        num: 35.5
      },
      {
        name: 'Berlin',
        type: 'Jul.',
        num: 37.4
      },
      {
        name: 'Berlin',
        type: 'Aug.',
        num: 42.4
      }
    ];
  }
}
</script>

<style lang='less' scoped>
.other-panel {
  padding: 0 30px;

  &-content {
    border-radius: 12px;
    background-color: #ffffff;
    .title {
      font-size: 28px;
      padding: 40px 30px;
      font-weight: bold;
      padding-bottom: 0;
    }
  }

  .content1 {
    .row {
      display: flex;
      width: 100%;
      height: 150px;
    }
    .item {
      height: 100%;
      flex: 1;
      display: flex;
      flex-direction: column;
      justify-content: center;

      .label {
        font-size: 26px;
        color: #999999;
        align-self: center;
      }

      .value {
        font-size: 36px;
        padding-top: 8px;
        margin-left: 80px;
      }
    }
  }

  .content2 {
    .canvas-box {
      width: 100%;
      height: 350px;

      #myChart1 {
        width: 100%;
        height: 100%;
      }
    }
  }

  .content3 {
    .canvas-box {
      width: 100%;
      height: 660px;

      #myChart2 {
        width: 100%;
        height: 100%;
      }
    }
  }
}
</style>