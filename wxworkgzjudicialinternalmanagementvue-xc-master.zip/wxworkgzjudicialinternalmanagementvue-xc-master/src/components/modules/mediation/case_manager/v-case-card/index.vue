<template>
  <div class="case-card"
       @click="goRoute">
    <div class="title">
      <span>{{ item.caseId }}</span>
      <van-tag plain
               :type="type">{{ item.state }}</van-tag>
    </div>
    <p class="case-card-prop">
      <span>纠纷类型：</span>
      <span>{{ item.type }}</span>
    </p>
    <p class="case-card-prop">
      <span>纠纷描述：</span>
      <span>{{ item.describe | textLimit}}</span>
    </p>
    <p class="case-card-prop">
      <span>调解日期：</span>
      <span>{{ item.mediationDate }}</span>
    </p>
    <p class="case-card-prop">
      <span>处案调委会：</span>
      <span>{{ item.committee }}</span>
    </p>
    <p class="case-card-prop">
      <span>处案调解员：</span>
      <span>{{ item.mediator }}</span>
    </p>
    <p class="case-card-prop">
      <span>其他调解员：</span>
      <span>{{ item.otherMediator }}</span>
    </p>
  </div>
</template>

<script lang='ts'>
import { Component, Vue, Prop } from 'vue-property-decorator';
import CaseCardType from '@/model/modules/mediation/case_manager/CaseCardType';

@Component({
  filters: {
    textLimit(str: string): string {
      if (str.length) {
        return str.substring(0, 43) + '…';
      }
      return str;
    }
  }
})
export default class CaseCard extends Vue {
  @Prop() private readonly item: CaseCardType;
  private type: string = 'default';

  public created(): void {
    this.initType();
  }

  private goRoute(): void {
    if (this.item.state === '已结案') {
      this.$router.push({
        path: '/details',
        query: {
          caseId: this.item.caseId,
          state: this.item.state
        }
      });
    } else if (this.item.state === '调解中') {
      this.$router.push({
        path: '/caseHandle',
        query: {
          id: this.item.caseId
        }
      });
    } else if (this.item.state === '待处理') {
      this.$router.push({
        path: '/details',
        query: {
          caseId: this.item.caseId,
          state: this.item.state
        }
      });
    } else if (this.item.state === '待接单') {
      this.$router.push({
        path: '/details',
        query: {
          caseId: this.item.caseId,
          state: this.item.state
        }
      });
    }
  }

  private initType(): void {
    const state = this.item.state;
    if (state === '待处理') {
      this.type = 'warning';
    } else if (state === '调解中') {
      this.type = 'primary';
    } else if (state === '已结案') {
      this.type = 'success';
    } else if (state === '已归档') {
      this.type = 'default';
    } else if (state === '待接单') {
      this.type = 'danger';
    }
  }
}
</script>

<style lang='less' scoped>
.case-card {
  padding: 30px;
  background-color: #ffffff;
  margin-bottom: 20px;

  .title {
    font-size: 32px;

    .van-tag {
      float: right;
    }
  }
  &-prop {
    font-size: 28px;
    color: #666666;
    padding: 8px 0;
  }
}
</style>