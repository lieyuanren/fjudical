<!--
 * @Author: your name
 * @Date: 2020-03-09 10:10:10
 * @LastEditTime: 2020-03-13 12:42:20
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \wxworkgzjudicialinternalmanagementsystemvue\src\components\modules\mediation\case_manager\v-case-panel\index.vue
 -->


<template>
  <div class="case-panel">
    <van-cell-group>
      <van-cell :title="casePanelObj.caseId" />
      <van-cell is-link
                :value="casePanelObj.caseFrom"
                @click="handleTextShow(1)">
        <template slot="title">
          <span class="label">*</span>
          <span class="custom-title">案件来源</span>
        </template>
      </van-cell>
      <van-cell is-link
                :value="casePanelObj.disputeType"
                @click="handleTextShow(2)">
        <template slot="title">
          <span class="label">*</span>
          <span class="custom-title">纠纷类别</span>
        </template>
      </van-cell>
      <van-cell is-link
                :value="casePanelObj.accpetDate"
                @click="handleTimeShow(1)">
        <template slot="title">
          <span class="label">*</span>
          <span class="custom-title">受理日期</span>
        </template>
      </van-cell>
      <van-field v-model="casePanelObj.disputeFact"
                 input-align="right"
                 required
                 placeholder="请输入"
                 label="纠纷事实" />
      <van-cell is-link
                :value="casePanelObj.caseForecast"
                @click="handleTextShow(3)">
        <template slot="title">
          <span class="label">*</span>
          <span class="custom-title">案件预测</span>
        </template>
      </van-cell>
      <van-cell is-link
                :value="casePanelObj.caseLevel"
                @click="handleTextShow(4)">
        <template slot="title">
          <span class="label">*</span>
          <span class="custom-title">案件难度级别</span>
        </template>
      </van-cell>
      <van-field v-model="casePanelObj.mediaOrga"
                 input-align="right"
                 placeholder="请输入"
                 required
                 label="调节组织" />
      <van-field v-model="casePanelObj.mediator"
                 input-align="right"
                 required
                 placeholder="请输入"
                 label="调解员" />
      <van-cell is-link
                value="请添加"
                @click="handleShow">
        <template slot="title">
          <span class="custom-title">参与调解员</span>
        </template>
      </van-cell>
      <div class="mediator-list">
        <NameCard v-for="(item, index) in sureList"
                  :item="item"
                  :key="index"
                  @del="delMediator" />
      </div>
      <van-cell is-link
                :value="casePanelObj.disputeDate"
                @click="handleTimeShow(2)">
        <template slot="title">
          <span class="label">*</span>
          <span class="custom-title">纠纷日期</span>
        </template>
      </van-cell>
      <van-field v-model="casePanelObj.caseId"
                 input-align="right"
                 label="案件编号" />
    </van-cell-group>
    <div class="btn-box">
      <div class="btn"
           @click="next">
        下一步
      </div>
    </div>
    <van-popup v-model="show"
               position="bottom">
      <van-datetime-picker v-model="currentDate"
                           type="date"
                           @cancel="onCancel"
                           @confirm="onConfirm" />
    </van-popup>
    <van-popup v-model="show1"
               position="bottom">
      <van-picker :columns="columns"
                  show-toolbar
                  @cancel="onCancel1"
                  @confirm="onConfirm1" />
    </van-popup>
    <van-popup v-model="show2"
               closeable
               round>
      <div class="mediator-panel">
        <div class="cell">
          <span class="level">{{ organizationLevel }}</span>
          <span class="select"
                @click="handleTextShow(5)">选择</span>
        </div>
        <div class="cell"
             @click="handleTextShow(6)">
          <span class="level">{{ organization }}</span>
          <van-icon name="play" />
        </div>
        <van-search v-model="searchKey"
                    placeholder="请输入搜索关键词" />
        <div class="mediator-box">
          <MediatorCard v-for="(item,index) in mediatorList"
                        :key="item.mediatorId"
                        :item="item"
                        @changeChecked="changeChecked(index)" />
        </div>
        <div class="mediator-btn">
          <van-checkbox v-model="isChecked">全选</van-checkbox>
          <div class="isSelect">
            <span>已选：</span>
            <span>{{ checkedCount }}</span>
          </div>
          <div class="btn"
               @click="onSure">
            确认
          </div>
        </div>
      </div>
    </van-popup>
  </div>
</template>

<script lang='ts'>
import { Component, Vue, Watch } from 'vue-property-decorator';
import CasePanelType from '@/model/modules/mediation/case_manager/CasePanelType';
import NameCard from '@/components/modules/mediation/case_manager/v-name-card/index.vue';
import MediatorCard from '@/components/modules/mediation/case_manager/v-mediator-card/index.vue';
import Mediator from '@/model/modules/mediation/case_manager/Mediator';

@Component({
  components: {
    NameCard,
    MediatorCard
  }
})
export default class CasePanel extends Vue {
  private casePanelObj: CasePanelType = new CasePanelType();
  private currentDate: Date = new Date();
  private show: boolean = false;
  private show1: boolean = false;
  private show2: boolean = false;
  private timeActive: number = 1;
  private columns: string[] = [];
  private textActive: number = 0;
  private searchKey: string = '';
  private isChecked: boolean = false;
  private organizationLevel: string = '请选择调委会级别';
  private organization: string = '全选择调委会';
  private timeLimit: any = null;
  private mediatorLimit: boolean = true;
  // 已选中调解员
  private sureList: Mediator[] = [];

  // 案件来源选择列表
  private caseFromList: string[] = ['案件来源1', '案件来源2', '案件来源3'];
  // 纠纷类型选择列表
  private disputeList: string[] = ['纠纷类型1', '纠纷类型2', '纠纷类型1'];
  // 案件预测选择列表
  private caseForecastList: string[] = ['预测1', '预测11', '预测11'];
  // 案件难度级别选择列表
  private caseLevelList: string[] = ['简单纠纷', '中级纠纷', '高级纠纷'];
  // 参与调解员选择列表
  private mediatorList: Mediator[] = [];

  // 各级调委会列表
  private levelList: string[] = [
    '街镇级及以下调委会',
    '行业性专业性调委会',
    '市属调委会'
  ];
  // 机构信息列表
  private organizationList: any = [
    {
      text: '浙江',
      children: [
        {
          text: '杭州',
          children: [{ text: '西湖区' }, { text: '余杭区' }]
        },
        {
          text: '温州',
          children: [{ text: '鹿城区' }, { text: '瓯海区' }]
        }
      ]
    },
    {
      text: '福建',
      children: [
        {
          text: '福州',
          children: [{ text: '鼓楼区' }, { text: '台江区' }]
        },
        {
          text: '厦门',
          children: [{ text: '思明区' }, { text: '海沧区' }]
        }
      ]
    }
  ];

  private get checkedCount(): number {
    let count = 0;
    const isTrue = this.mediatorList.every((item: Mediator): boolean => {
      if (item.isChecked) {
        count += 1;
        return true;
      } else {
        return false;
      }
    });
    this.isChecked = isTrue;
    return count;
  }

  /**
   * 请求调解员数据
   * @params : organizationLevel <string> 调委会级别范围
   * @params : organization <string> 当前调委会
   * @params : searchKey <string> 搜索字符
   */
  private async getMediatorList(): Promise<void> {
    console.log('获取数据');
    // 模拟数据
    this.mediatorList = [
      {
        mediatorId: '3123d',
        mediatorName: '张三丰',
        mediatorUrl: '',
        isChecked: false
      },
      {
        mediatorId: '3ew123d',
        mediatorName: '周杰伦',
        mediatorUrl: '',
        isChecked: false
      }
    ];
  }

  @Watch('searchKey')
  private watchSearchKey(): void {
    clearTimeout(this.timeLimit);
    this.timeLimit = setTimeout(() => {
      this.getMediatorList();
    }, 700);
  }

  @Watch('isChecked')
  private watchIsChecked(): void {
    if (this.isChecked) {
      this.checkedAll();
    }
  }

  private next(): void {
    console.log(this.casePanelObj);
    if (this.checkInfo()) {
      this.$emit('nextStep', 1);
    }
  }

  private handleTimeShow(index: number): void {
    this.show = true;
    this.timeActive = index;
  }

  private handleTextShow(index: number): void {
    this.textActive = index;
    this.show1 = true;
    if (index === 1) {
      this.columns = this.caseFromList;
    } else if (index === 2) {
      this.columns = this.disputeList;
    } else if (index === 3) {
      this.columns = this.caseForecastList;
    } else if (index === 4) {
      this.columns = this.caseLevelList;
    } else if (index === 5) {
      this.columns = this.levelList;
    } else if (index === 6) {
      this.columns = this.organizationList;
    }
  }

  private onCancel(): void {
    this.show = false;
  }

  private onCancel1(): void {
    this.show1 = false;
  }

  private onConfirm1(str: string | string[]): void {
    console.log(this.textActive);
    if (this.textActive === 1) {
      this.casePanelObj.caseFrom = str as string;
    } else if (this.textActive === 2) {
      this.casePanelObj.disputeType = str as string;
    } else if (this.textActive === 3) {
      this.casePanelObj.caseForecast = str as string;
    } else if (this.textActive === 4) {
      this.casePanelObj.caseLevel = str as string;
    } else if (this.textActive === 5) {
      this.organizationLevel = str as string;
    } else if (this.textActive === 6) {
      this.organization = str.toString().replace(/,/g, '');
    }
    this.show1 = false;
  }

  private onConfirm(date: Date): void {
    this.show = false;
    if (this.timeActive === 1) {
      this.casePanelObj.accpetDate = this.$utils.Common.dateFmt(
        'yyyy-MM-dd',
        date
      );
    } else {
      this.casePanelObj.disputeDate = this.$utils.Common.dateFmt(
        'yyyy-MM-dd',
        date
      );
    }
  }

  private handleShow(): void {
    this.show2 = true;
    if (this.mediatorLimit) {
      this.getMediatorList();
      this.mediatorLimit = false;
    }
  }

  // 检测填写信息
  private checkInfo(): boolean {
    for (const key in this.casePanelObj) {
      if (key === 'mediatorList' || key === 'caseId') {
        continue;
      }
      // @ts-ignore
      if (!this.casePanelObj[key]) {
        this.$toast({
          message: '请填写必要信息',
          icon: 'fail'
        });
        return false;
      }
    }

    return true;
  }

  // 全选操作
  private checkedAll(): void {
    this.mediatorList.forEach((item: Mediator): void => {
      item.isChecked = true;
    });
  }

  // 改变状态
  private changeChecked(index: number): void {
    this.mediatorList[index].isChecked = !this.mediatorList[index].isChecked;
  }

  /**
   * 取消选中调解员
   * 1.删除sureList中的调解员
   * 2.改变对应id调解员的checked
   */
  private delMediator(id: string): void {
    this.sureList.some((item: Mediator, index: number): boolean => {
      if (item.mediatorId === id) {
        item.isChecked = false;
        this.sureList.splice(index, 1);
        return true;
      } else {
        return false;
      }
    });
  }

  /**
   * 确认操作
   * 1.拿到所有被选中的调解员
   */
  private onSure(): void {
    const tempList: Mediator[] = [];
    this.show2 = false;
    this.mediatorList.forEach((item: Mediator): boolean => {
      if (item.isChecked) {
        tempList.push(item);
        return true;
      } else {
        return false;
      }
    });

    this.sureList = tempList;
  }
}
</script>

<style lang='less' scoped>
.case-panel {
  .label {
    color: #f25968;
    margin-left: -16px;
  }

  .btn-box {
    margin-top: 20px;
    padding: 40px;
    background-color: #ffffff;
    .btn {
      height: 96px;
      border-radius: 12px;
      font-size: 36px;
      color: #ffffff;
      background-color: #0a5ffe;
      text-align: center;
      line-height: 96px;
    }
  }

  .mediator-list {
    padding: 20px;
    // display: flex;
  }

  .mediator-panel {
    width: 600px;
    padding: 30px 0 0 0;
    margin-top: 50px;
    box-sizing: border-box;

    .cell {
      font-size: 28px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 30px;
      border-bottom: 1px solid #eeeeee;

      .select {
        color: #0a5ffe;
      }

      .van-icon {
        margin-right: auto;
        margin-left: 20px;
        transform: rotateZ(90deg);
      }
    }

    .mediator-box {
      padding: 0 30px;
      max-height: 600px;
      overflow-y: auto;
      display: flex;
      flex-wrap: wrap;
    }

    .mediator-btn {
      height: 96px;
      padding: 0 30px;
      display: flex;
      align-items: center;
      box-sizing: border-box;
      background-color: #fbf8f9;
      justify-content: space-between;

      .btn {
        width: 140px;
        height: 64px;
        background-color: #0a5ffe;
        color: #ffffff;
        text-align: center;
        line-height: 64px;
        border-radius: 6px;
      }
    }
  }
}

.van-popup--round {
  border-radius: 6px;
}
</style>
