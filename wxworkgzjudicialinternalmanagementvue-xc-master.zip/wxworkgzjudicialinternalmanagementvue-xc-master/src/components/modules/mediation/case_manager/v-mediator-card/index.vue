<template>
  <div class="mediator-card"
       @click="handleClick">
    <van-image width="1.65333rem"
               height="1.65333rem"
               :src="item.mediatorUrl" />
    <img :src="icon"
         v-if="item.isChecked"
         class="cleck">
    <p class="name">{{ item.mediatorName }}</p>
  </div>
</template>

<script lang='ts'>
import { Component, Vue, Prop } from 'vue-property-decorator';
import Mediator from '@/model/modules/mediation/case_manager/Mediator';

@Component
export default class MediatorCard extends Vue {
  @Prop() private readonly item: Mediator;
  private icon: string = require('@/assets/images/modules/mediation/cleck.png');
  private isChecked: boolean = false;

  private handleClick(): void {
    this.$emit('changeChecked');
    if (this.item.isChecked) {
      this.$emit('addMediator', this.item);
    } else {
      this.$emit('delMediator', this.item.mediatorId);
    }
  }
}
</script>

<style lang='less' scoped>
.mediator-card {
  position: relative;
  width: 124px;
  border-radius: 6px;
  margin: 20px 0;
  margin-right: 80px;

  &:nth-child(3n) {
    margin-right: 0px;
  }

  .cleck {
    position: absolute;
    width: 46px;
    height: 46px;
    top: 78px;
    right: 0;
  }

  .name {
    font-size: 28px;
    text-align: center;
  }
}
</style>
