<template>
  <div class="name-card"
       @click="handleDel">
    <span>{{ item.mediatorName }}</span>
    <div class="del">
      <van-icon name="cross" />
    </div>
  </div>
</template>

<script lang='ts'>
import { Component, Vue, Prop } from 'vue-property-decorator';
import Mediator from '@/model/modules/mediation/case_manager/Mediator';

@Component
export default class NameCard extends Vue {
  @Prop() private readonly item: Mediator;

  private handleDel(): void {
    this.$emit('del', this.item.mediatorId);
  }
}
</script>

<style lang='less' scoped>
.name-card {
  position: relative;
  padding: 20px 30px;
  background-color: #fcfbfc;
  border-radius: 8px;
  font-size: 28px;
  margin-right: 30px;
  display: inline-block;
  min-width: 160px;
  text-align: center;
  box-sizing: border-box;
  margin-top: 20px;

  .del {
    width: 34px;
    height: 34px;
    color: #ffffff;
    display: flex;
    background-color: #fc5859;
    justify-content: center;
    align-items: center;
    line-height: 34px;
    position: absolute;
    top: -10px;
    right: -10px;
    border-radius: 50%;
  }
}
</style>
