<template>
  <div class="party-card">
    <div class="party-card-content">
      <span class="name">苏浙</span>
      <span class="phone">12378012389</span>
    </div>
    <div class="party-card-btns">
      <div class="btn btn1">编辑</div>
      <div class="btn btn2">删除</div>
    </div>
  </div>
</template>

<script lang='ts'>
import { Component, Vue } from 'vue-property-decorator';

@Component
export default class PartyCard extends Vue {}
</script>

<style lang='less' scoped>
.party-card {
  padding: 20px 0;
  background-color: #ffffff;
  display: flex;
  height: 120px;
  box-sizing: border-box;
  justify-content: space-between;

  &-content {
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    color: #666666;

    .name {
      font-size: 28px;
    }

    .phone {
      font-size: 24px;
    }
  }

  &-btns {
    display: flex;
    align-items: center;

    .btn {
      width: 100px;
      height: 40px;
      border-radius: 6px;
      box-sizing: border-box;
      text-align: center;
      line-height: 40px;
      margin-right: 20px;
    }

    .btn1 {
      color: #5869fd;
      border: 1px solid #5869fd;
    }
    .btn2 {
      color: #ff536a;
      border: 1px solid #ff536a;
    }
  }
}
</style>
