<template>
  <div class="proposer-panel">
    <van-cell-group>
      <van-cell :title="proposerPanelObj.caseId" />
      <van-cell is-link
                :value="proposerPanelObj.proposerType"
                @click="handleShow(1)">
        <template slot="title">
          <span class="label">*</span>
          <span class="custom-title">申请人类型</span>
        </template>
      </van-cell>
      <van-field v-model="proposerPanelObj.name"
                 input-align="right"
                 required
                 placeholder="请输入"
                 label="姓名" />
      <van-cell is-link
                :value="proposerPanelObj.sex"
                @click="handleShow(2)">
        <template slot="title">
          <span class="custom-title">性别</span>
        </template>
      </van-cell>
      <van-cell is-link
                :value="proposerPanelObj.cardType"
                @click="handleShow(3)">
        <template slot="title">
          <span class="custom-title">证件类型</span>
        </template>
      </van-cell>
      <van-field v-model="proposerPanelObj.cardNum"
                 input-align="right"
                 required
                 placeholder="请输入"
                 label="证件号码" />
      <van-field v-model="proposerPanelObj.address"
                 input-align="right"
                 placeholder="请输入"
                 label="联系地址" />
      <van-cell is-link
                :value="proposerPanelObj.nation"
                @click="handleShow(4)">
        <template slot="title">
          <span class="custom-title">民族</span>
        </template>
      </van-cell>
      <van-field v-model="proposerPanelObj.partyCount"
                 input-align="right"
                 required
                 placeholder="请输入"
                 label="本方当事人数量" />
      <van-field v-model="proposerPanelObj.occupation"
                 input-align="right"
                 placeholder="请输入"
                 label="职业" />
      <van-field v-model="proposerPanelObj.age"
                 input-align="right"
                 placeholder="请输入"
                 label="年龄" />
      <van-field v-model="proposerPanelObj.phoneNum"
                 input-align="right"
                 required
                 label="联系电话" />
    </van-cell-group>
    <div class="add-person">
      <span>添加更多当事人</span>
    </div>
    <div class="party-list">
      <PartyCard />
    </div>
    <div class="btn-box">
      <div class="btn"
           @click="next">
        下一步
      </div>
    </div>

    <van-popup v-model="show"
               position="bottom">
      <van-picker :columns="columns"
                  show-toolbar
                  @cancel="onCancel"
                  @confirm="onConfirm" />
    </van-popup>
  </div>
</template>

<script lang='ts'>
import { Component, Vue } from 'vue-property-decorator';
import ProposerPanelType from '@/model/modules/mediation/case_manager/ProposerPanelType';
import PartyCard from '@/components/modules/mediation/case_manager/v-party-crad/index.vue';

@Component({
  components: {
    PartyCard
  }
})
export default class ProposerPanel extends Vue {
  // 申请人数据
  private proposerPanelObj: ProposerPanelType = new ProposerPanelType();
  // 当事人列表
  // private

  private columns: string[] = [];
  // 申请人类型1
  private proposerList: string[] = ['a', 'b', 'c'];
  // 性别列表2
  private sexList: string[] = ['男', '女', '其他'];
  // 证件类型3
  private cardTypeList: string[] = ['居民身份证'];
  // 民族4
  private nationList: string[] = ['汉族', '藏族'];

  private show: boolean = false;
  private activeIndex: number = 0;

  public created() {
    this.getList();
  }

  /**
   * 请求列表数据
   */
  private async getList(): Promise<void> {
    console.log('获取选择列表的数据');
  }

  // 下一步
  private next(): void {
    console.log(this.proposerPanelObj);
    if (this.checkInfo()) {
      this.$emit('nextStep', 2);
    }
  }

  // 检测填写信息
  private checkInfo(): boolean {
    for (const key in this.proposerPanelObj) {
      if (
        key === 'sex' ||
        key === 'cardType' ||
        key === 'address' ||
        key === 'nation' ||
        key === 'occupation' ||
        key === 'age'
      ) {
        continue;
      }
      // @ts-ignore
      if (!this.proposerPanelObj[key]) {
        this.$toast({
          message: '请填写必要信息',
          icon: 'fail'
        });
        return false;
      }
    }

    return true;
  }

  private handleShow(index: number): void {
    this.activeIndex = index;
    this.show = true;
    if (this.activeIndex === 1) {
      this.columns = this.proposerList;
    } else if (this.activeIndex === 2) {
      this.columns = this.sexList;
    } else if (this.activeIndex === 3) {
      this.columns = this.cardTypeList;
    } else if (this.activeIndex === 4) {
      this.columns = this.nationList;
    }
  }

  private onCancel(): void {
    this.show = false;
  }

  private onConfirm(str: string): void {
    this.show = false;
    if (this.activeIndex === 1) {
      this.proposerPanelObj.proposerType = str;
    } else if (this.activeIndex === 2) {
      this.proposerPanelObj.sex = str;
    } else if (this.activeIndex === 3) {
      this.proposerPanelObj.cardType = str;
    } else if (this.activeIndex === 4) {
      this.proposerPanelObj.nation = str;
    }
  }
}
</script>

<style lang='less' scoped>
.proposer-panel {
  .label {
    color: #f25968;
    margin-left: -16px;
  }

  .btn-box {
    padding: 40px;
    background-color: #ffffff;
    .btn {
      height: 96px;
      border-radius: 12px;
      font-size: 36px;
      color: #ffffff;
      background-color: #0a5ffe;
      text-align: center;
      line-height: 96px;
    }
  }
}

.add-person {
  padding: 20px;
  font-size: 28px;
  color: #1567fe;
  text-align: right;
}

.party-list {
  padding: 0 30px;
  background-color: #ffffff;
}
</style>
