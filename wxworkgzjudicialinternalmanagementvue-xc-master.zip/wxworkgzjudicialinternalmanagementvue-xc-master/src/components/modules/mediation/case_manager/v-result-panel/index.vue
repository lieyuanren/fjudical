<!--
 * @Author : tangzhicheng
 * @Date : 2020-03-09 10:13:02
 * @LastEditors  : tangzhicheng
 * @LastEditTime : 2020-03-13 15:00:28
 * @Description: file content
 -->


<template>
  <div class="result-panel">
    <van-cell-group>
      <van-cell title="案件结果" />

      <van-cell is-link
                :value="resultObj.result"
                @click="handleShow(1)">
        <template slot="title">
          <span class="label">*</span>
          <span class="custom-title">调查结果</span>
        </template>
      </van-cell>
      <van-field v-model="resultObj.agreementContent"
                 input-align="right"
                 placeholder="请输入"
                 required
                 label="协议内容" />
      <van-cell is-link
                :value="resultObj.carryOutWay"
                @click="handleShow(2)">
        <template slot="title">
          <span class="label">*</span>
          <span class="custom-title">履行方式</span>
        </template>
      </van-cell>
      <van-cell is-link
                :value="resultObj.agreementCase"
                @click="handleShow(3)">
        <template slot="title">
          <span class="label">*</span>
          <span class="custom-title">协议履行情况</span>
        </template>
      </van-cell>
      <van-cell is-link
                :value="resultObj.agreementDate"
                @click="show1 = true">
        <template slot="title">
          <span class="label">*</span>
          <span class="custom-title">协议日期</span>
        </template>
      </van-cell>
      <van-field v-model="resultObj.money"
                 input-align="right"
                 required
                 placeholder="请输入"
                 label="涉案金额" />
      <van-cell is-link
                :value="resultObj.evaluate"
                @click="handleShow(4)">
        <template slot="title">
          <span class="label">*</span>
          <span class="custom-title">是否满意</span>
        </template>
      </van-cell>
      <van-field v-model="resultObj.remark"
                 input-align="right"
                 placeholder="请输入"
                 required
                 label="备注" />
    </van-cell-group>
    <div class="btn-box">
      <div class="btn"
           @click="handleOver">
        完成
      </div>
    </div>
    <van-popup v-model="show"
               position="bottom">
      <van-picker :columns="columns"
                  show-toolbar
                  @cancel="show =false"
                  @confirm="onConfirm" />
    </van-popup>
    <van-popup v-model="show1"
               position="bottom">
      <van-datetime-picker type="date"
                           v-model="currentDate"
                           @cancel="show1= false"
                           @confirm="handleConfirm" />
    </van-popup>
  </div>
</template>


<script lang='ts'>
import { Component, Vue } from 'vue-property-decorator';
import ResultPanelType from '@/model/modules/mediation/case_manager/ResultPanelType';

@Component
export default class ResultPanel extends Vue {
  private resultObj: ResultPanelType = new ResultPanelType();
  private show: boolean = false;
  private show1: boolean = false;
  private columns: string[] = [];
  private activeIndex: number = 1;
  private currentDate: Date = new Date();

  // 调查结果
  private reslutList: string[] = ['1', '2'];
  // 履行方式
  private performMode: string[] = ['w', 'e'];
  // 协议履行情况
  private agreement: string[] = ['d', 'f'];
  // 是否满意
  private evaluate: string[] = ['满意', '不满意'];

  /**
   * 完成
   */
  private async onSubmit(): Promise<void> {
    console.log('提交数据');
  }

  // 完成整个案件处理操作
  private handleOver(): void {
    console.log(this.resultObj);
    if (this.checkInfo()) {
      this.onSubmit();
    }
  }

  // 检测信息
  private checkInfo(): boolean {
    for (const key in this.resultObj) {
      // @ts-ignore
      if (!this.resultObj[key]) {
        this.$toast({
          message: '请填写必要信息',
          icon: 'fail'
        });
        return false;
      }
    }
    return true;
  }
  /**
   * @description:
   * @param {type}
   * @return:
   */
  private handleShow(index: number): void {
    this.activeIndex = index;
    if (this.activeIndex === 1) {
      this.columns = this.reslutList;
    } else if (this.activeIndex === 2) {
      this.columns = this.performMode;
    } else if (this.activeIndex === 3) {
      this.columns = this.agreement;
    } else if (this.activeIndex === 4) {
      this.columns = this.evaluate;
    }
    this.show = true;
  }

  private handleConfirm(date: Date): void {
    this.show1 = false;
    this.resultObj.agreementDate = this.$utils.Common.dateFmt(
      'yyyy-MM-dd',
      date
    );
  }

  private onConfirm(str: string): void {
    this.show = false;
    if (this.activeIndex === 1) {
      this.resultObj.result = str;
    } else if (this.activeIndex === 2) {
      this.resultObj.carryOutWay = str;
    } else if (this.activeIndex === 3) {
      this.resultObj.agreementCase = str;
    } else if (this.activeIndex === 4) {
      this.resultObj.evaluate = str;
    }
  }
}
</script>

<style lang='less' scoped>
.label {
  color: #f25968;
  margin-left: -16px;
}
.btn-box {
  margin-top: 20px;
  padding: 40px;
  background-color: #ffffff;
  .btn {
    height: 96px;
    border-radius: 12px;
    font-size: 36px;
    color: #ffffff;
    background-color: #0a5ffe;
    text-align: center;
    line-height: 96px;
  }
}
</style>
