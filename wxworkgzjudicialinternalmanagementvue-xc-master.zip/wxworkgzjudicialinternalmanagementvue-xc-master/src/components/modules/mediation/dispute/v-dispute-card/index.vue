<template>
  <div class="dispute-card">
    <div class="dispute-card-content">
      <span class="title">{{ item.troubleshooting }}</span>
      <span class="text">{{ item.infoFrom }} {{ item.time }}</span>
    </div>
    <div class="dispute-card-state">
      <van-tag plain
               :type="type">{{ item.disputeLevel }}</van-tag>
    </div>
  </div>
</template>

<script lang='ts'>
import { Component, Vue, Prop } from 'vue-property-decorator';
import DisputeCardType from '@/model/modules/mediation/dispute/DisputeCardType';

@Component
export default class DisputeCard extends Vue {
  @Prop() private readonly item: DisputeCardType;
  private type: string = '';

  public created() {
    this.initType();
  }

  private initType(): void {
    const level = this.item.disputeLevel;
    if (level === '简单纠纷') {
      this.type = 'primary';
    } else if (level === '一般纠纷') {
      this.type = 'success';
    } else if (level === '疑难纠纷') {
      this.type = 'danger';
    }
  }
}
</script>

<style lang='less' scoped>
.dispute-card {
  padding: 30px;
  height: 148px;
  box-sizing: border-box;
  background-color: #ffffff;
  border-bottom: 1px solid #eeeeee;
  display: flex;
  justify-content: space-between;

  &-content {
    display: flex;
    flex-direction: column;
    justify-content: space-between;

    .title {
      font-size: 32px;
    }

    .text {
      font-size: 28px;
      color: #666666;
    }
  }
}
</style>
