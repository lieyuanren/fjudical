<template>
  <div class="mediation-card">
    <div class="mediation-card-head">
      <img class="line" src="@/assets/images/modules/mediation/1.png" v-if="name === '待接单'"/>
      <img class="line" src="@/assets/images/modules/mediation/2.png" v-else/>
      <span class="id">{{name}}</span>
      <div class="details">
        <span>共{{items.length}}个</span>
        <img src="@/assets/images/modules/mediation/sort.png">
      </div>
    </div>
    <div class="mediation-card-prop">
      <div class="mediation-card-items" v-for="(item,index) in items">
        <div class="index">{{index+1}}</div>
        <div>{{item.caseId}}</div>
        <div class="handle">
          <span v-if="name === '待接单'">督办</span>
          <span v-if="name !== '待接单'" style="color: white">隐藏</span>
        </div>
        <div>{{item.time}}</div>
      </div>
    </div>
  </div>
</template>

<script lang='ts'>
import {Component, Vue, Prop} from 'vue-property-decorator';
import CaseCardType from '@/model/modules/mediation/home/CaseCardType';

@Component({})
export default class CaseCard extends Vue {

  @Prop() private readonly items: CaseCardType[];
  @Prop() private readonly name: string;

  private goRoute (): void {
    // // TODO:
    // this.$router.push({
    //   path: '/caseHandle',
    //   query: {
    //     id: this.item.caseId
    //   }
    // });
  }

}
</script>

<style lang='less' scoped>
.mediation-card {
  padding: 40px;
  background-color: #ffffff;
  box-shadow: 0px 4px 21px 0px rgba(221, 221, 221, 0.48);
  border-radius: 12px;
  margin: 30px 0;

  .handle {
    color: #0A5FFE;
  }


  .index {
    color: #666666;
    background: #f5f7fb;
    border-radius: 50%;
    width: 45px;
    text-align: center
  }

  &-head {
    display: flex;
    justify-content: space-between;
    align-items: center;

    .line {
      width: 50px;
      margin: auto 0;
    }

    .id {
      font-size: 32px;
      margin-right: auto;
      margin-left: 20px;
    }

    .details {
      font-size: 26px;
      color: #666666;
      span{
        margin-right: 6px;
        text-align: center;
      }
      img {
        width: 30px;
        margin-top: -6px;
      }
    }
  }

  &-items {
    display: flex;
    justify-content: space-between;
    margin-top: 22px;
  }

  &-prop {
    color: #666666;
    margin: 16px 0;
    font-size: 27px;
  }
}
</style>
