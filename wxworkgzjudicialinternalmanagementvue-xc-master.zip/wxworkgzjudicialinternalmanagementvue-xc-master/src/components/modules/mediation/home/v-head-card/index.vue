<template>
  <div class="head-card"
       @click="goRoute">
    <div class="head-card-content">
      <div class="title">
        <span class="name">{{ item.name }}</span>
        <van-tag plain
                 type="danger">{{ item.state }}</van-tag>
      </div>
      <div class="text">
        {{ item.type }},{{ item.dispute | textLimit }}
      </div>
      <div class="text">
        {{ item.committee }}
      </div>
      <div class="text">
        {{ item.mediationDate }}
      </div>
      <div class="text">
        {{ item.phoneNum }}
      </div>
    </div>
  </div>
</template>

<script lang='ts'>
import { Component, Vue, Prop } from 'vue-property-decorator';
import HeadCardType from '@/model/modules/mediation/home/HeadCardType';

@Component({
  filters: {
    textLimit(str: string) {
      if (str.length > 15) {
        return str.substring(0, 14) + '…';
      }
      return str;
    }
  }
})
export default class HeadCard extends Vue {
  @Prop() private readonly item: HeadCardType;

  private goRoute(): void {
    this.$router.push({
      path: '/details',
      query: {
        caseId: this.item.caseId,
        state: this.item.state
      }
    });
  }
}
</script>

<style lang='less' scoped>
.head-card {
  padding: 0 30px;
  height: 340px;

  &-content {
    border-radius: 12px;
    background-color: #ffffff;
    width: 100%;
    height: 100%;
    padding: 30px 50px;
    box-sizing: border-box;

    .title {
      .name {
        font-size: 38px;
        font-weight: bold;
        vertical-align: middle;
        padding-right: 20px;
      }

      .van-tag {
        vertical-align: middle;
      }
    }

    .text {
      font-size: 28px;
      color: #666666;
      margin: 15px 0;
    }
  }
}
</style>
