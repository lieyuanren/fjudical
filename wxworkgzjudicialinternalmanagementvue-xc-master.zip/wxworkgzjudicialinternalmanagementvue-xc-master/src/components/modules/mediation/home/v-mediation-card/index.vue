<template>
  <div class="mediation-card"
       @click="goRoute">
    <div class="mediation-card-head">
      <span class="line"></span>
      <span class="id">{{ item.caseId }}</span>
      <div class="details">
        <span>详情</span>
        <van-icon name="arrow" />
      </div>
    </div>
    <p class="mediation-card-prop">
      <span>纠纷类型：</span>
      <span>{{ item.type }}</span>
    </p>
    <p class="mediation-card-prop">
      <span>调解日期：</span>
      <span>{{ item.mediationDate }}</span>
    </p>
    <p class="mediation-card-prop">
      <span>处案调委会：</span>
      <span>{{ item.committee }}</span>
    </p>
    <p class="mediation-card-prop">
      <span>处案调解员：</span>
      <span>{{ item.mediator }}</span>
    </p>
    <p class="mediation-card-prop">
      <span>其他调解员：</span>
      <span>{{ item.otherMediator }}</span>
    </p>
  </div>
</template>

<script lang='ts'>
import { Component, Vue, Prop } from 'vue-property-decorator';
import MediationCardType from '@/model/modules/mediation/home/MediationCardType';

@Component({})
export default class MediationCard extends Vue {
  @Prop() private readonly item: MediationCardType;

  private goRoute(): void {
    // TODO:
    this.$router.push({
      path: '/caseHandle',
      query: {
        id: this.item.caseId
      }
    });
  }
}
</script> 

<style lang='less' scoped>
.mediation-card {
  padding: 40px;
  background-color: #ffffff;
  box-shadow: 0px 4px 21px 0px rgba(221, 221, 221, 0.48);
  border-radius: 12px;
  margin: 30px 0;

  &-head {
    display: flex;
    justify-content: space-between;
    align-items: center;
    .line {
      width: 8px;
      height: 34px;
      background-color: #0a5ffe;
      border-radius: 4px;
    }

    .id {
      font-size: 32px;
      margin-right: auto;
      margin-left: 20px;
    }

    .details {
      font-size: 26px;
      color: #666666;

      span,
      i {
        vertical-align: middle;
      }
    }
  }

  &-prop {
    color: #666666;
    margin: 16px 0;
    font-size: 28px;
  }
}
</style>