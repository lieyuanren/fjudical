<template>
  <div class="mechanism-card"
       @click="goRoute">
    <p class="title">{{ item.mechanismName }}</p>
    <p class="text">调委会类别：{{ item.category }}</p>
    <p class="text">负责人：{{ item.person }}</p>
    <p class="text">联系地址：{{ item.address }} </p>
    <p class="text">联系电话：{{ item.phoneNum }} </p>
    <div class="count">
      <p class="value">{{ item.count }}</p>
      <p class="prop">调解员</p>
    </div>
  </div>
</template>

<script lang='ts'>
import { Component, Vue, Prop } from 'vue-property-decorator';
import MechanismCardType from '@/model/modules/mediation/mechanismer/MechanismCardType';

@Component({})
export default class MechanismCard extends Vue {
  @Prop() private readonly item: MechanismCardType;

  private goRoute(): void {
    this.$router.push({
      path: '/mechanismInfo',
      query: {
        id: this.item.id
      }
    });
  }
}
</script>

<style lang='less' scoped>
.mechanism-card {
  position: relative;
  padding: 30px;
  background-color: #ffffff;
  margin-bottom: 20px;

  .title {
    font-size: 32px;
  }

  .text {
    font-size: 28px;
    color: #666666;
    margin: 26px 0;
  }

  .count {
    position: absolute;
    width: 100px;
    top: 30px;
    right: 30px;

    .value {
      text-align: center;
      font-size: 32px;
      color: #666666;
    }

    .prop {
      text-align: center;
      font-size: 24px;
      color: #999999;
    }
  }
}
</style>
