<template>
  <div class="mediator-card"
       @click="goRoute">
    <div class="imgbox">
      <img src="">
    </div>
    <div class="content">
      <div class="title">
        <span class="name">{{ item.mediatorName }}</span>
        <span class="level">{{ item.level }}</span>
        <van-tag plain
                 :type="item.state?'primary':'default'">{{ item.state }}</van-tag>
      </div>
      <div class="text">{{ item.organization }}</div>
      <div class="text">调解案件：{{ item.caseCount }}件</div>
      <div class="text">从事人民调解工作年限：{{ item.year }}年</div>
      <div class="text">
        <img :src="phoneIcon1">
        <span>{{ item.phoneNum }}</span>
      </div>

      <div class="icon-box icon1">
        <img :src="messageIcon">
      </div>
      <div class="icon-box icon2">
        <img :src="phoneIcon2">
      </div>
    </div>
  </div>
</template>

<script lang='ts'>
import { Component, Vue, Prop } from 'vue-property-decorator';
import MediatorCardType from '@/model/modules/mediation/mechanismer/MediatorCardType';

@Component({})
export default class MediatorCard extends Vue {
  private phoneIcon1: string = require('@/assets/images/modules/notarization/index/phone.png');
  private messageIcon: string = require('@/assets/images/modules/mediation/icon-02.png');
  private phoneIcon2: string = require('@/assets/images/modules/mediation/phone.png');

  @Prop() private readonly item: MediatorCardType;

  private goRoute(): void {
    this.$router.push({
      path: '/mediatorDetails',
      query: {
        id: this.item.mediatorId
      }
    });
  }
}
</script>

<style lang='less' scoped>
.mediator-card {
  position: relative;
  display: flex;
  padding: 30px;
  background-color: #ffffff;
  .imgbox {
    width: 126px;
    height: 132px;
  }
  .content {
    flex: 1;
    padding-left: 30px;
    height: 100%;

    .title {
      display: flex;
      justify-content: space-between;
      align-items: center;
      .name {
        font-size: 36px;
      }
      .level {
        font-size: 24px;
        color: #999999;
        margin-right: auto;
        margin-left: 30px;
      }

      .van-tag {
        float: right;
      }
    }

    .text {
      font-size: 28px;
      margin: 15px 0;
      color: #666666;
      img {
        width: 34px;
        height: 34px;
      }
    }
  }

  .icon-box {
    position: absolute;
    width: 76px;
    height: 76px;
    bottom: 24px;

    img {
      width: 100%;
      height: 100%;
    }
  }

  .icon1 {
    right: 133px;
  }

  .icon2 {
    right: 30px;
  }
}
</style>