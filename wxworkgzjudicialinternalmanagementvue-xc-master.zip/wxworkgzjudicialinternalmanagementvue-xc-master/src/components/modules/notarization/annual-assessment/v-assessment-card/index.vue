<template>
  <div class="assessment-card">
    <div class="assessment-top">
      <div class="assessment-top-lt">
        <span class="text1">{{ item.name?item.name:item.name }}</span>
        <van-tag :type="item.state === '待评' ? 'primary' : 'success'"
                 plain>{{ item.state }}</van-tag>
      </div>
      <div class="assessment-top-rt text4">{{ item.assessTime }}</div>
    </div>
    <div class="assessment-bottom">
      <span class="text4">年度：{{ item.assessYear }}</span>
      <span class="text4">评分：{{ item.grade? item.grade: '-' }}</span>
      <span class="text4"
            v-if="item.type != 'JG'">{{ item.belongOrgan }}</span>
    </div>
  </div>
</template>

<script lang="ts">
// @ts-ignore
import AssesmentData from '@/model/modules/notarization/annual-assessment/AssessmentData';
import { Component, Prop, Vue } from 'vue-property-decorator';

// 年度考核内容卡
@Component
export default class AssessmentCard extends Vue {
  @Prop({
    type: Object,
    default: {}
  })
  public item!: AssesmentData;
}
</script>


<style lang="less" scoped>
.assessment-card {
  padding: 40px;
  margin-top: 30px;
  background: rgba(255, 255, 255, 1);

  .assessment-top {
    display: flex;
    justify-content: space-between;
    margin-bottom: 30px;
    line-height: 36px;

    .text1 {
      margin-right: 26px;
      vertical-align: middle;
      text-overflow: ellipsis;
      white-space: nowrap;
      max-width: 4rem;
      overflow: hidden;
    }

    .van-tag {
      vertical-align: middle;
      white-space: nowrap;
    }
    &-lt {
      display: flex;
    }
    &-rt {
      width: 3.5rem;
      text-align: right;
    }
  }

  .assessment-bottom {
    display: flex;
    justify-content: space-between;
  }
}
</style>
