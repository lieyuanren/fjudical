<template>
  <div @click="goRoute" class="authentic-card">
    <p class="text1">{{ item.organizationName }}</p>
    <p class="text4">卷宗号：{{ item.dossierId }}</p>
    <p class="text4">公证编号：{{ item.notarizationCode }}</p>
    <p class="text4">公证用途：{{ item.notarizationPurpose }}</p>
    <p class="text4">公证事项：{{ item.notarizationMatter }}</p>
    <p class="text4">使用地：{{ item.place }}</p>
    <p class="text4">公证员：{{ item.notary }}</p>
    <p class="text4">状态：{{ item.state }}</p>
    <p class="text4">落款时间：{{ item.settlingTime }}</p>
  </div>
</template>


<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator';
// @ts-ignore
import AuthenticData from '@/model/modules/notarization/AuthenticAct/AuthenticData';

// 公证书卡片组件
@Component
export default class AuthenticCard extends Vue {
  @Prop({
    type: Object,
    default: {}
  })
  public item!: AuthenticData;

  public goRoute(): void {
    this.$router.push({
      path: 'authenticActDetails',
      query: {
        id: this.item.notarizationCode
      }
    });
  }
}
</script>


<style lang="less">
.authentic-card {
  padding: 30px;
  margin-top: 40px;
  background-color: rgb(255, 255, 255);

  .text1 {
    margin-bottom: 15px;
    font-weight: 500 !important;
  }
}
</style>