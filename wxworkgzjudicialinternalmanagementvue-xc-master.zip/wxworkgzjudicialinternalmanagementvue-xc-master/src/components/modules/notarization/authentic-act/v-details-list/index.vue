<template>
  <div class="details-list">
    <p class="text1">{{ title }}</p>
    <div class="content" v-if="!content">
      <p :key="index" class="text4" v-for="(obj,index) in itemList">{{ obj.label }}：{{ obj.value }}</p>
    </div>
    <div class="content" v-else>
      <p class="text4">{{ content }}</p>
    </div>
  </div>
</template>

<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator';

// 详情页卡片组件
@Component
export default class DetailsList extends Vue {
  @Prop({
    type: String,
    default: ''
  })
  public title!: string;
  @Prop({
    type: Array,
    default: () => []
  })
  public itemList!: any[];

  @Prop({
    type: String,
    default: ''
  })
  public content!: string;
}
</script>

<style lang="less">
.details-list {
  background-color: #ffffff;
  padding: 30px;
  margin-top: 20px;
  margin-bottom: 20px;

  .text1 {
    font-weight: 500 !important;
  }
  .content {
    padding-top: 30px;
    margin-top: 20px;
    border-top: 1px solid rgb(238, 238, 238);

    .text4 {
      padding: 6px 0;
    }
  }
}
</style>