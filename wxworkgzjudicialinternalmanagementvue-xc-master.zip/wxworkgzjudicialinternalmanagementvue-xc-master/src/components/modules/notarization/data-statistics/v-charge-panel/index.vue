<template>
  <div class="contrast-panel">
    <ChargeSituation :chargeData="item" :key="index" v-for="(item,index) in chargetList"/>
  </div>
</template>

<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator';
// @ts-ignore
import ChargeSituation from '@/components/modules/notarization/home/v-charge-situation';
// @ts-ignore
import Charge from '@/model/modules/notarization/home/Charge';

@Component({
  components: {
    ChargeSituation
  }
})
export default class ChargePanel extends Vue {
  @Prop({
    type: Array,
    default: []
  })
  public chargetList!: Charge[];
}
</script>
