<template>
  <div class="main-panel">
    <div class="text2 title">
      <img :src="imgUrl4"/>
      <span>主要公证事项</span>
    </div>
    <div :key="data.index" class="data-list" v-for="data in statisticsList">
      <div class="data-content">
        <div class="img-box" v-if="data.index === 1">
          <img :src="imgUrl1"/>
        </div>
        <div class="img-box" v-else-if="data.index === 2">
          <img :src="imgUrl2"/>
        </div>
        <div class="img-box" v-else-if="data.index === 3">
          <img :src="imgUrl3"/>
        </div>
        <div class="img-box" v-else>0{{ data.index }}</div>
        <div class="types text2">{{ data.typeName }}</div>
        <div class="count text1">{{ data.count }}</div>
      </div>
      <p class="whole" v-if="data.whole">
        <span>全市</span>
        <span>{{data.whole}}</span>
      </p>
    </div>
  </div>
</template>

<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator';
// @ts-ignore
import StatisticsData from '@/model/modules/notarization/data-statistics/StatisticsData.ts';

@Component
export default class MainPanel extends Vue {
  // 数据列表
  @Prop({
    type: Array,
    default: []
  })
  public statisticsList!: StatisticsData[];

  public isWhole: boolean = false;
  public imgUrl1: string = require('@/assets/images/modules/notarization/index/top-01.png');
  public imgUrl2: string = require('@/assets/images/modules/notarization/index/top-02.png');
  public imgUrl3: string = require('@/assets/images/modules/notarization/index/top-03.png');
  public imgUrl4: string = require('@/assets/images/modules/notarization/index/icon-02@2x.png');
}
</script>

<style lang="less" scoped>
.main-panel {
  margin: 30px;
  padding: 30px;
  background: rgba(255, 255, 255, 1);
  border: 1px solid rgba(224, 224, 224, 0.2);
  border-radius: 12px;

  .title {
    img {
      width: 48px;
      height: 48px;
    }

    span {
      vertical-align: middle;
      padding-left: 20px;
    }
  }

  .data-list {
    position: relative;
    margin: 60px 0;

    .data-content {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 0 30px;
    }

    .text2 {
      font-weight: normal !important;
    }

    .img-box {
      width: 48px;
      height: 48px;
      text-align: center;
      color: #999999;
      font-size: 32px;
      font-weight: bold;
      line-height: 48px;
    }

    .types {
      margin-right: auto;
      margin-left: 66px;
    }

    .whole {
      position: absolute;
      width: 100%;
      text-align: right;
      font-size: 26px;
      color: #999999;

      span {
        padding-left: 20px;
      }
    }
  }
}
</style>