<template>
  <div class="notaries-all-show">
    <PersonnelCard :item="item" :key="index" v-for="(item,index) in notariesList"/>
  </div>
</template>


<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator';
// @ts-ignore
import PersonnelCard from '@/components/modules/notarization/data-statistics/v-personnel-card';
// @ts-ignore
import PersonnelCardData from '@/model/modules/notarization/data-statistics/PersonnelCardData.ts';

@Component({
  components: {
    PersonnelCard
  }
})
export default class NotariesAllShow extends Vue {
  @Prop({
    type: Array,
    default: []
  })
  public notariesList!: PersonnelCardData[];
}
</script>