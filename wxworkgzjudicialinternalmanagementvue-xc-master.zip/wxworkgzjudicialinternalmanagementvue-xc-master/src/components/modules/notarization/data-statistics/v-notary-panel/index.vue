<template>
  <div class="notary-panel">
    <Notaries :notariesData="notariesData"/>
  </div>
</template>

<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator';
// @ts-ignore
import Notaries from '@/components/modules/notarization/home/v-notaries';
// @ts-ignore
import NotariesModel from '@/model/modules/notarization/home/Notaries';

@Component({
  components: {
    Notaries
  }
})
export default class NotaryPanel extends Vue {
  @Prop({
    type: Object,
    default: {}
  })
  public notariesData!: NotariesModel;
}
</script>