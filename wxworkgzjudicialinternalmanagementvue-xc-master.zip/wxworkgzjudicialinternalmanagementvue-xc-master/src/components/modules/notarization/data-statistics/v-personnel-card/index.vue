<template>
  <div class="personnel-card">
    <div class="text2">
      <img :src="urlArr[iconIndex]"/>
      <span>{{ item.title }}</span>
    </div>
    <div class="flex-box">
      <div
        :key="index"
        class="param"
        v-for="(param,index) in item.paramData"
        v-if="param.value !== '-'"
      >
        <p class="text5">{{ param.label }}</p>
        <p class="text1">
          {{ param.value }}
          <span v-if="param.label == '占比'">%</span>
        </p>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator';
// @ts-ignore
import PersonnelCardData from '@/model/modules/notarization/data-statistics/PersonnelCardData';

@Component
export default class PersonnelCard extends Vue {
  @Prop({
    type: Object,
    default: {}
  })
  public item!: PersonnelCardData;

  public iconIndex: number = 0;
  // 图标数组
  public urlArr: string[] = [
    require('@/assets/images/modules/notarization/index/icon-15@2x.png'),
    require('@/assets/images/modules/notarization/index/icon-09@2x.png'),
    require('@/assets/images/modules/notarization/index/icon-10@2x.png'),
    require('@/assets/images/modules/notarization/index/icon-11@2x.png'),
    require('@/assets/images/modules/notarization/index/icon-12@2x.png'),
    require('@/assets/images/modules/notarization/index/icon-01@2x.png'),
    require('@/assets/images/modules/notarization/index/icon-05@2x.png'),
    require('@/assets/images/modules/notarization/index/icon-14@2x.png')
  ];

  public created(): void {
    if (this.item.title === '全市办证总数') {
      this.iconIndex = 0;
    } else if (this.item.title === '国内民事公证') {
      this.iconIndex = 1;
    } else if (this.item.title === '国内经济公证') {
      this.iconIndex = 3;
    } else if (this.item.title === '涉外民事公证') {
      this.iconIndex = 4;
    } else if (this.item.title === '涉外经济公证') {
      this.iconIndex = 5;
    } else if (this.item.title === '人员整体情况') {
      this.iconIndex = 6;
    } else if (this.item.title === '非公证员') {
      this.iconIndex = 7;
    }
  }
}
</script>

<style lang="less">
.personnel-card {
  border: 1px solid rgba(224, 224, 224, 0.2);
  padding: 30px;
  margin: 30px;
  background-color: #ffffff;
  border-radius: 12px;

  .text2 {
    img {
      width: 48px;
      height: 48px;
      vertical-align: middle;
    }
    span {
      vertical-align: middle;
      padding-left: 20px;
    }
  }

  .flex-box {
    display: flex;
    flex-wrap: wrap;
    margin-top: 20px;
    .param {
      width: 50%;
      flex-shrink: 0;
      margin-top: 10px;
      box-sizing: border-box;
      padding-left: 86px;
      &:nth-child(2n) {
        border-left: 1px solid rgba(224, 224, 224, 0.2);
      }
    }
  }
}
</style>
