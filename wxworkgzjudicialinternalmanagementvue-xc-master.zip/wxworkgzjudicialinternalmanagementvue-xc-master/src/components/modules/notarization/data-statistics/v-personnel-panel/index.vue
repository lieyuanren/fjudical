<template>
  <div class="personnel-panel">
    <PersonnelCard :item="item" :key="index" v-for="(item,index) in personnelList"/>
  </div>
</template>

<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator';
// @ts-ignore
import PersonnelCard from '@/components/modules/notarization/data-statistics/v-personnel-card';
// @ts-ignore
import PersonnelCardData from '@/model/modules/notarization/data-statistics/PersonnelCardData.ts';

@Component({
  components: {
    PersonnelCard
  }
})
export default class PersonnelPanel extends Vue {
  @Prop({
    type: Array,
    default: []
  })
  public personnelList!: PersonnelCardData[];
}
</script>