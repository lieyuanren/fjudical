<template>
  <div class="charge-situation">
    <h2 class="text2">
      <img :src="iconUrl"/>
      <span>{{ chargeData.title }}</span>
    </h2>
    <div class="sameMonth">
      <p class="text5">当前</p>
      <p class="text1">{{ chargeData.sameMonth }}</p>
    </div>
    <div class="flex-box">
      <div class="annualCumulative">
        <p class="text5">年累计</p>
        <p class="text1">{{ chargeData.annualCumulative }}</p>
      </div>
      <div class="lastYaer">
        <p class="text5">去年同期</p>
        <p class="text1">{{ chargeData.lastYear }}</p>
      </div>
      <div class="contrast">
        <p class="text5">对比</p>
        <p class="text1">{{ chargeData.contrast }}%</p>
      </div>
    </div>
  </div>
</template>
<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator';
// @ts-ignore
import ChargeModel from '@model/modules/notarization/home/Charge';

@Component
export default class ChargeSituation extends Vue {
  public iconUrl: string = require('@/assets/images/modules/notarization/index/icon-01@2x.png');

  @Prop({
    type: Object,
    default: {}
  })
  public chargeData!: ChargeModel;
}
</script>

<style lang="less" scoped>
.charge-situation {
  padding: 30px;
  margin: 30px;
  background: rgba(255, 255, 255, 1);
  border: 1px solid rgba(224, 224, 224, 0.2);
  border-radius: 12px;

  h2 {
    padding: 0 36px;
    img {
      width: 48px;
      height: 48px;
      vertical-align: middle;
    }

    span {
      vertical-align: middle;
      padding-left: 20px;
    }
  }

  .sameMonth {
    text-align: center;
    margin-top: 40px;
  }

  .flex-box {
    display: flex;
    margin-top: 52px;

    div {
      flex: 1;
      text-align: center;
    }
  }
}
</style>
