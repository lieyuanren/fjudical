<template>
  <div class="details-card">
    <h2 class="text2">
      <img :src="urlArr[iconIndex]" />
      <span>{{ item.notarizationType }}</span>
    </h2>
    <div class="content">
      <div class="sameMonth">
        <p class="text5">当月</p>
        <p class="text1">{{ item.sameMonth }}</p>
        <p class="text5"
           v-if="item.monthProportion">占比</p>
        <p class="text1"
           v-if="item.monthProportion">{{ item.monthProportion }}%</p>
      </div>
      <div class="cumulative">
        <p class="text5">累计</p>
        <p class="text1">{{ item.cumulative }}</p>
        <p class="text5"
           v-if="item.cumulativeProportion">占比</p>
        <p class="text1"
           v-if="item.cumulativeProportion">{{ item.cumulativeProportion }}%</p>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator';
// @ts-ignore
import NotarizationData from '@/model/modules/notarization/home/Notarization';

@Component
export default class DetailsCard extends Vue {
  @Prop(Object) public item!: NotarizationData;

  // 图标数组
  public urlArr: string[] = [
    require('@/assets/images/modules/notarization/index/icon-15@2x.png'),
    require('@/assets/images/modules/notarization/index/icon-09@2x.png'),
    require('@/assets/images/modules/notarization/index/icon-10@2x.png'),
    require('@/assets/images/modules/notarization/index/icon-11@2x.png'),
    require('@/assets/images/modules/notarization/index/icon-12@2x.png'),
    require('@/assets/images/modules/notarization/index/icon-01@2x.png')
  ];

  public iconIndex: number = 0;

  public created(): void {
    if (this.item.notarizationType === '全市办证总数') {
      this.iconIndex = 0;
    } else if (this.item.notarizationType === '国内民事公证') {
      this.iconIndex = 1;
    } else if (this.item.notarizationType === '国内经济公证') {
      this.iconIndex = 3;
    } else if (this.item.notarizationType === '涉外民事公证') {
      this.iconIndex = 4;
    } else if (this.item.notarizationType === '涉外经济公证') {
      this.iconIndex = 5;
    }
  }
}
</script>

<style lang="less" scoped>
.details-card {
  margin: 30px;
  padding: 30px;
  background: rgba(255, 255, 255, 1);
  border: 1px solid rgba(224, 224, 224, 0.2);
  border-radius: 12px;

  h2 {
    img {
      width: 48px;
      height: 48px;
      vertical-align: middle;
    }
    span {
      vertical-align: middle;
      padding-left: 20px;
    }
  }

  .content {
    width: 100%;
    display: flex;
    margin-top: 22px;
    flex-wrap: wrap;

    .sameMonth,
    .cumulative {
      width: 50%;
      padding-left: 70px;
      box-sizing: border-box;
      flex-shrink: 0;
      box-sizing: border-box;
    }

    div:nth-child(2n) {
      border-left: 1px solid rgba(238, 238, 238, 1);
    }
  }
}
</style>
