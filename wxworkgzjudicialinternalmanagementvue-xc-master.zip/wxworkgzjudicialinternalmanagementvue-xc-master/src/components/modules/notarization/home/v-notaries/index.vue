<template>
  <div class="notaries">
    <h2 class="text2">
      <img :src="iconUrl" />
      <span>{{ notariesData.title }}</span>
    </h2>
    <div class="flex-box">
      <div class="inEditing">
        <p class="text5">在编</p>
        <p class="text1">{{ notariesData.inEditing }}</p>
      </div>
      <div class="nonEditing">
        <p class="text5">非编</p>
        <p class="text1">{{ notariesData.nonEditing }}</p>
      </div>
      <div class="subtotal">
        <p class="text5">小计</p>
        <p class="text1">{{ notariesData.subtotal }}</p>
      </div>
    </div>
    <h3 class="text3">公证员级别</h3>
    <canvas id="myChart2"
            style="width:100%;height:240px;"></canvas>
  </div>
</template>
<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator';
// @ts-ignore
import NotariesModel from '@/model/modules/notarization/home/Notaries';

import f3 from '@/plugins/antv-f2/f3';


@Component
export default class Notaries extends Vue {
  @Prop({
    type: Object,
    default: {}
  })
  public notariesData!: NotariesModel;

  public iconUrl: string = require('@/assets/images/modules/notarization/index/icon-15@2x.png');

  public mounted(): void {
    // 调用antv/f2组件
    f3(this.notariesData.viewData, [
      '#F6B043',
      '#E55857',
      '#6E52D0',
      '#1F80F1',
      '#00B67D'
    ]);
  }

  public updated() {
    f3(this.notariesData.viewData, [
      '#F6B043',
      '#E55857',
      '#6E52D0',
      '#1F80F1',
      '#00B67D'
    ]);
  }
}
</script>

<style lang="less" scoped>
.notaries {
  padding: 30px;
  margin: 30px;
  background: rgba(255, 255, 255, 1);
  border: 1px solid rgba(224, 224, 224, 0.2);
  border-radius: 12px;

  h2 {
    padding: 0 34px;
    img {
      width: 48px;
      height: 48px;
      vertical-align: middle;
    }

    span {
      vertical-align: middle;
      padding-left: 20px;
    }
  }

  h3 {
    padding: 0 34px;
    margin-top: 90px;
  }

  .flex-box {
    display: flex;
    margin-top: 52px;

    div {
      flex: 1;
      text-align: center;
    }
  }
}
</style>
