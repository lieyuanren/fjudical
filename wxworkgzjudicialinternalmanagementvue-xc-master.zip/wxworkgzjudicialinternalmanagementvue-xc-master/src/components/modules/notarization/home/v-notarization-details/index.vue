<template>
  <div class="notarization-details">
    <DetailsCard :item="item" :key="i" v-for="(item,i) in notarizationArr"/>
  </div>
</template>
<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator';
// @ts-ignore
import DetailsCard from '@/components/modules/notarization/home/v-details-card';
// @ts-ignore
import NotarizationModel from '@model/modules/notarization/home/Notarization';

@Component({
  components: {
    DetailsCard
  }
})
export default class NotarizationDetails extends Vue {
  // 公证情况数据
  @Prop({
    type: Array,
    default: []
  })
  public notarizationArr!: NotarizationModel[];
}
</script>