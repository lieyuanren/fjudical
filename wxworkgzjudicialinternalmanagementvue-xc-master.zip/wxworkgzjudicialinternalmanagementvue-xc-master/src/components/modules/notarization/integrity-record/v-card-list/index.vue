<!-- 卡片列表组件 -->
<template>
  <van-cell-group class="panel">
    <van-card @click="handleClick"
              class="card">
      <div class="card-title"
           slot="title">
        {{item.name?item.name: '-'}}
        <!--<span v-show="item.showTab && !item.ifNotary"-->
        <!--class="card-btn card-btn-blue">非公证员</span>-->
        <!--<span v-show="item.showTab && item.ifNotary"-->
        <!--class="card-btn card-btn-green">公证员</span>-->
      </div>
      <div class="card-thumb"
           slot="thumb">
        <img :src="item.headImg" />
      </div>
      <div class="card-desc"
           slot="desc">{{labelArr[0]}}：{{item.position?item.position: '-'}}</div>
      <div class="card-desc"
           slot="desc">{{labelArr[1]}}：{{item.institution?item.institution: '-'}}</div>
      <div class="card-desc"
           slot="desc"
           v-show="types === 'person'">{{labelArr[2]}}：{{item.level?item.level: '-'}}
      </div>
      <div class="card-desc"
           slot="desc"
           v-show="types === 'institution'">
        <img class="card-icon"
             src="@/assets/images/modules/notarization/index/phone.png" />
        <span class="card-phone">{{item.phone?item.phone: '-'}}</span>
      </div>
    </van-card>
  </van-cell-group>
</template>

<script lang="ts">
// @ts-ignore
import IntegrityRecord from '@/model/global/IntegrityRecord';
import { Component, Prop, Vue } from 'vue-property-decorator';

@Component
export default class CaseList extends Vue {
  @Prop()
  public item: IntegrityRecord;
  @Prop()
  public labelArr: string[];
  @Prop()
  public toUrl: string;
  @Prop()
  public types: string;

  // 路由跳转
  public handleClick(): void {
    // @ts-ignore
    this.$router.push({
      path: this.toUrl,
      query: {
        code: this.item.code
      }
    });
  }
}
</script>

<style lang="less" scoped>
.panel {
  margin-top: 20px;
}

.card {
  height: 270px;
  background-color: #ffffff;
  .van-card__header {
    margin-top: 2.5%;
    .van-card__thumb {
      width: auto;
      height: auto;
      margin-right: 10px;
    }
  }
  &-thumb {
    width: 190px;
    height: 190px;
    margin-top: 5%;
  }
  &-title {
    font-size: 36px;
    padding-left: 26px;

    color: rgba(51, 51, 51, 1);
  }
  &-desc {
    font-size: 28px;
    color: rgba(153, 153, 153, 1);
    line-height: 48px;
    padding-left: 26px;
  }
  &-icon {
    width: 34px;
    height: 34px;
    margin-right: 10px;
    vertical-align: middle;
    padding-bottom: 1%;
  }
  &-phone {
    color: rgba(10, 95, 254, 1);
    vertical-align: middle;
  }
  &-btn {
    margin-top: 2.5%;
    float: right;
    border-radius: 19px;
    padding: 0 15px;
    height: 39px;
    line-height: 39px;
    font-size: 22px;
    color: rgba(255, 255, 255, 1);
    &-blue {
      background: rgba(53, 127, 250, 1);
    }
    &-green {
      background: #19bdcf;
    }
  }
}
</style>
