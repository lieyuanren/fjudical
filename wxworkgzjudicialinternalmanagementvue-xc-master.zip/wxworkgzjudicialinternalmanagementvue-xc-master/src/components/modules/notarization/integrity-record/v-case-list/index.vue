<!-- 卡片列表组件 -->
<template>
  <van-panel class="panel-case">
    <div class="panel-case-title" slot="header">{{title}}</div>
    <div class="panel-case-con">
      <div :key="index" class="panel-case-con-list" v-for="(item, index) in caseList">
        <span class="panel-case-con-list-year">{{item.year}}</span>
        <span class="panel-case-con-list-grade">{{item.grade}}</span>
        <span class="panel-case-con-list-content">{{item.content}}</span>
      </div>
      <div class="panel-case-con-null" v-if="caseList.length === 0">暂无数据</div>
    </div>
  </van-panel>
</template>

<script lang="ts">
// @ts-ignore
import Case from '@/model/global/Case';
// @ts-ignore
import { Component, Prop, Vue } from 'vue-property-decorator';

@Component
export default class CaseList extends Vue {
  @Prop({
    type: String,
    default: ''
  })
  public title!: string;
  @Prop({
    type: Array,
    default: []
  })
  public caseList!: Case[];
}
</script>

<style lang="less">
.panel-case {
  margin-top: 20px;
  &-title {
    margin: 0 30px;
    border-bottom: 1px solid #ebedf0;
    font-size: 36px;
    line-height: 90px;
    color: #333333;
  }
  &-con {
    padding: 30px;
    font-size: 28px;
    color: #666666;
    height: auto;
    line-height: 50px;
    &-null {
      text-align: center;
    }
    &-list {
      margin-bottom: 20px;
      display: compact;
      flex-direction: row;
      &-year {
        display: block;
        float: left;
        width: 25%;
      }
      &-grade {
        display: block;
        float: left;
        width: 25%;
      }
      &-content {
        max-width: 50%;
        padding-left: 26px;
        text-align: center;
      }
    }
  }
}
</style>
