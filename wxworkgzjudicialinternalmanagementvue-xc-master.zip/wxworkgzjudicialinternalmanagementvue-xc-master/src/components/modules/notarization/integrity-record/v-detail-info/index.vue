<!-- 基本信息组件 -->
<template>
  <div class="detail">
    <div class="con">
      <div class="info">
        <div class="info-left">
          <div class="info-left-title">{{detail.title}}</div>
          <div :key="index" class="info-left-desc" v-for="(item, index) in columns">
            <div v-if="item.label === 'phone'">
              <img
                class="info-left-desc-icon"
                src="@/assets/images/modules/notarization/index/phone.png"
              />
              <span class="info-left-desc-phone">{{item.value}}</span>
            </div>
            <div v-else>{{item.label}}：{{item.value}}</div>
          </div>
        </div>
        <div class="info-right">
          <img :src="detail.imgUrl"/>
        </div>
      </div>
    </div>
    <van-panel class="intro" v-if="detail.intro">
      <div class="intro-title" slot="header">机构简介</div>
      <div class="intro-con">{{detail.intro}}</div>
    </van-panel>
  </div>
</template>

<script lang="ts">
// @ts-ignore
import Detail from '@/model/global/DetailInfo';
// @ts-ignore
import DolumnInfo from '@/model/global/DolumnInfo';
// @ts-ignore
import { Component, Prop, Vue } from 'vue-property-decorator';

@Component
export default class Info extends Vue {
  @Prop()
  public detail: Detail;
  @Prop()
  public columns: DolumnInfo[];
}
</script>

<style lang="less">
.con {
  background: rgba(255, 255, 255, 1);
  padding: 20px 30px;
  overflow: auto;
  margin-top: 20px;
  .info {
    position: relative;
    top: 0;
    &-left {
      float: left;
      &-title {
        font-size: 36px;
        color: rgba(51, 51, 51, 1);
        line-height: 60px;
      }
      &-desc {
        font-size: 28px;
        color: rgba(153, 153, 153, 1);
        line-height: 50px;
        &-icon {
          width: 34px;
          height: 34px;
          margin-right: 10px;
          vertical-align: middle;
        }
        &-phone {
          color: rgba(10, 95, 254, 1);
          vertical-align: middle;
        }
      }
    }
    &-right {
      float: right;
      position: absolute;
      right: 30px;
      img {
        width: 190px;
        height: 190px;
        margin-top: 6%;
      }
    }
  }
}

.intro {
  &-title {
    margin: 0 30px;
    border-bottom: 1px solid #ebedf0;
    font-size: 36px;
    line-height: 90px;
    font-weight: 500;
    color: #333333;
  }
  &-con {
    padding: 30px;
    font-size: 30px;
    font-weight: 500;
    color: #666666;
    line-height: 50px;
  }
}

.van-hairline--top-bottom::after,
.van-hairline-unset--top-bottom::after {
  border: 0;
}
</style>
