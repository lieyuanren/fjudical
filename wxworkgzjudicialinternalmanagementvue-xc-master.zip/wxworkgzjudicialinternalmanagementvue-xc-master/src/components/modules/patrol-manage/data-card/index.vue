<template>
  <div class="member-data-card">
    <div class="member-data-card-content">
        <div class="text1">{{ item.name }}</div>
        <div class="text2">{{ item.code }}</div>
        <div class="text3 person" v-if="item.type === '人员卡'">人员卡</div>
        <div class="text3 address" v-if="item.type === '地址卡'">地址卡</div>
        <div class="text3 case" v-if="item.type === '事件卡'">事件卡</div>
    </div>
    <p>{{ item.remarks }}</p>
  </div>
</template>

<script lang='ts'>
import { Component, Prop, Vue } from 'vue-property-decorator';
import AttendanceCardModel from '@/model/modules/attendance-manage/attendance/AttendanceCardModel';

@Component({
  filters: {
    textLimit(value: string): string {
      if (value.length > 14) {
        return value.substring(0, 13) + '…';
      }
      return value;
    }
  }
})
export default class DataCard extends Vue {
  @Prop({
    type: Object,
    default: () => ({})
  })
  private readonly item: any;
}
</script>

<style lang='less' scoped>
.member-data-card {
  position: relative;
  padding: 30px;
  background-color: #ffffff;
  margin-top: 20px;

  &:last-child {
    margin-bottom: 20px;
  }

  &-content {
    display: flex;
    height: 32px;
    line-height: 32px;
    position: relative;
    padding: 0px 110px 25px 0;

    .text1 {
      font-size: 30px;
      font-weight: bold !important;
      min-width: 65px;
      margin-right: 65px;
    }
    .text2 {
      font-size: 28px;
      font-weight: 400 !important;
      color: #7F848B;
      line-height: 36px;
      height: 25px;
      position: relative;
      min-width: 120px;
      word-break: break-all;
      word-wrap: break-word;
      &:before {
        content: ' ';
        width: 36px;
        height: 36px;
        background-image: url("../../../../assets/images/modules/patrol-manage/phone.png");
        background-size: 100% 100%;
        background-repeat: no-repeat;
        position: absolute;
        left: -38px;
        top: 0;
      }
    }
    .text3 {
      font-size: 24px;
      font-weight: 600 !important;
      color: #FFFFFF;
      line-height: 32px;
      height: 32px;
      padding: 2px 16px;
      border-top-left-radius: 18px;
      border-bottom-right-radius: 18px;
      position: absolute;
      top: 0;
      right: 0;
    }
    .person {
      background-color: rgba(55, 112, 235);
    }
    .address{
      background-color: rgba(10, 215, 149);
    }
    .case{
      background-color: rgba(254, 145, 61);
    }
    img {
      display: inline-block;
      width: 36px;
      height: 36px;
    }
  }
  p {
    color: #B4B8BE;
    font-size: 26px;
    &:before {
      content: '备注：';
    }
  }
}
</style>
