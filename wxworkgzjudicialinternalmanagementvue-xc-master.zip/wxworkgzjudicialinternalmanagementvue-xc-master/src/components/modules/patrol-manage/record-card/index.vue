<template>
  <div class="member-record-card">
    <p class="member-record-card-title">{{ item.name }}</p>
    <div class="text3 address" v-if="item.result === '合格'">合格</div>
    <div class="text3 person" v-if="item.result === '漏检'">漏检</div>
    <div class="text3 case" v-if="item.result === '误点'">误点</div>
    <div class="content">线路名称：{{ item.route }}</div>
    <div class="content">地点名称：{{ item.address }}</div>
    <div class="content">巡检时间：{{ item.time }}</div>
    <div class="content">起止时间：{{ item.startTime }} - {{ item.endTime }}</div>
    <div class="names">
      <div class="names-item">计划：{{ item.planPerson }}</div>
      <div class="names-item">巡检：{{ item.person }}</div>
    </div>
  </div>
</template>

<script lang='ts'>
import { Component, Prop, Vue } from 'vue-property-decorator';

@Component({
  filters: {
    textLimit(value: string): string {
      if (value.length > 14) {
        return value.substring(0, 13) + '…';
      }
      return value;
    }
  }
})
export default class RecordCard extends Vue {
  @Prop({
    type: Object,
    default: () => ({})
  })
  private readonly item!: any;
}
</script>

<style lang='less' scoped>
.member-record-card {
  position: relative;
  padding: 30px;
  background-color: #ffffff;

  &-title {
    font-size: 30px;
    font-weight: bold;
  }
  .text3 {
    font-size: 24px;
    font-weight: 600 !important;
    color: #FFFFFF;
    line-height: 32px;
    height: 32px;
    padding: 2px 16px;
    border-top-left-radius: 18px;
    border-bottom-right-radius: 18px;
    position: absolute;
    top: 30px;
    right: 30px;
  }
  .person {
    background-color: rgba(180, 184, 190);
  }
  .address{
    background-color: rgba(10, 215, 149);
  }
  .case{
    background-color: rgba(254, 145, 61);
  }
  margin-bottom: 20px;
  .content {
    color: #B4B8BE;
    font-size: 26px;
    line-height: 46px;
    height: 46px;
  }
  .names {
    display: flex;
    color: #7F848B;
    font-size: 26px;
    margin-top: 42px;
    &-item {
      &:nth-child(2) {
        margin-left: 80px;
      }
    }
  }
}
</style>
