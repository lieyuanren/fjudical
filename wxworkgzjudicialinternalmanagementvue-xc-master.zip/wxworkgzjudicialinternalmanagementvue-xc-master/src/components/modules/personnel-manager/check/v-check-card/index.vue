<template>
  <div class="check-card">
    <div class="check-card-body">
      <div class="check-card-img">
        <img :src="item.photo" />
      </div>
      <div class="check-card-content">
        <p class="text1">{{ item.name }}</p>
        <p class="text4">出生日期：{{ item.birthday }}</p>
        <p class="text4">现任职务：{{ item.PriorWorkUnit }}</p>
        <p class="text4">参加工作时间：{{ item.workTime }}</p>
      </div>
    </div>
    <span class="split-line"></span>
    <div class="check-card-info">
      <div class="check-card-info-item">考核年度：{{ item.year }}</div>
      <div class="check-card-info-item">考核季度：{{ item.quarter }}</div>
    </div>
    <div class="check-card-info">
      <div class="check-card-info-item">考核结果：{{ item.constructionName }}</div>
      <div class="check-card-info-item" v-if="item.performance!=null">考核分数：{{ item.performance }}</div>
    </div>
    <div class="check-card-info">
      <div class="check-card-info-line">
        考核登记表：<img src="../../../../../assets/images/modules/personnel-manager/file.png" class="check-card-info-img">{{ item.registrationform }}
      </div>
    </div>
  </div>
</template>

<script lang='ts'>
import { Component, Prop, Vue } from 'vue-property-decorator';
import CheckCardModel from '@/model/modules/personnel-manager/check/CheckCardModel';

@Component({})
export default class CaseCard extends Vue {
  @Prop({
    type: Object,
    default: {}
  })
  private readonly item!: CheckCardModel;
}
</script>

<style lang='less' scoped>
  .check-card {
    min-height: 450px;
    background-color: #ffffff;
    margin-bottom: 26px;
    &-body {
      position: relative;
      padding: 30px;
      height: 160px;
      display: flex;
    }
    .text1 {
      font-weight: 500 !important;
      font-size: 36px;
      color: #333333;
    }

    .text4 {
      color: #999999;
    }

    .text2, .text3 {
      width: 167px;
      height: 27px;
      font-size: 28px;
      font-weight: 500;
    }

    &-img {
      margin-top: 12px;
      width: 140px;
      height: 140px;
    }

    &-content {
      padding-left: 34px;
    }
    &-info {
      display: flex;
      justify-content: space-around;
      color: #999999;
      font-size: 28px;
      &-item {
        width: 40%;
        text-align: left;
        line-height: 52px;
        height: 52px;
        &:nth-child(1) {
          margin-left: 32px;
        }
        &:nth-child(2) {
          margin-left: 45px;
        }
      }
      &-line {
        line-height: 52px;
        min-height: 52px;
        width: 100%;
        padding-left: 50px;
        box-sizing: border-box;
      }
      &-img {
        width: 26px;
        height: 26px;
        margin: -6px 8px 0px 5px;
      }
    }
  }
  .split-line {
    width: 690px;
    height: 1px;
    background-color: #EEEEEE;
    margin: 26px auto;
    display: block;
  }
</style>
