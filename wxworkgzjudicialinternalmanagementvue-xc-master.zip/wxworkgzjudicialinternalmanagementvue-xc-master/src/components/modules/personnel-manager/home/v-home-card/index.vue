<!--
 * @Author: tangzhicheng
 * @Date: 2020-03-09 09:17:18
 * @LastEditors: tangzhicheng
 * @LastEditTime: 2020-05-06 16:41:50
 * @Description: file content
 -->
<template>
  <div class="home-card" @click="$router.push(item.route)">
    <img :src="item.imgUrl" />
    <span class="home-card-data">{{ item.data }}</span>
    <span class="home-card-prop">{{ item.prop }}</span>
  </div>
</template>

<script lang='ts'>
import { Component, Prop, Vue } from 'vue-property-decorator';
import HomeCardModel from '@/model/modules/personnel-manager/home/HomeCardModel';

// 首页展示卡组件
@Component
export default class HomeCard extends Vue {
  @Prop({
    type: Object,
    default: 0
  })
  private readonly item!: HomeCardModel;
}
</script>

<style lang='less' scoped>
.home-card {
  position: relative;
  width: 690px;
  height: 180px;
  border-radius: 6px;
  margin-bottom: 30px;
  color: #ffffff;
  background-size: cover;

  &-data {
    position: absolute;
    font-size: 36px;
    left: 210px;
    top: 32px;
    font-weight: bold;
  }

  &-prop {
    position: absolute;
    left: 210px;
    top: 100px;
    font-size: 26px;
    opacity: 0.6;
  }

  img {
    width: 100px;
    height: 100px;
    position: absolute;
    left: 60px;
    top: 40px;
  }

  &:first-child {
    background-color: #6698E2;
  }

  &:nth-child(2) {
    background-color: #51AFFF;
  }

  &:nth-child(3) {
    background-color: #46BCD7;
  }

  &:nth-child(4) {
    background-color: #4AC28F;
  }

  &:nth-child(5) {
    background-color: #61CBC9;
  }

  &:nth-child(6) {
    background-color: #EDB44A;
  }
}
</style>
