<template>
  <div @click="goRouter" class="person-card">
    <div class="person-card-body">
      <div class="person-card-img">
        <img :src="item.photo" />
      </div>
      <div class="person-card-content">
        <p class="text1">{{ item.name }}</p>
        <p class="text4">职位：{{ item.priorWorkUnit | textLimit }}</p>
        <p class="text4">出生年月：{{ item.birthday | textLimit }}</p>
      </div>
    </div>
  </div>
</template>

<script lang='ts'>
import { Component, Prop, Vue } from 'vue-property-decorator';
import PersonCardModel from '@/model/modules/personnel-manager/person/personCardModel';

@Component({
  filters: {
    textLimit(value: string): string {
      if (value && value.length > 14) {
        return value.substring(0, 13) + '…';
      }
      return value;
    }
  }
})
export default class PersonCard extends Vue {
  @Prop({
    type: Object,
    default: () => ({})
  })
  private readonly item!: PersonCardModel;

  private goRouter(): void {
    this.$router.push({
      path: '/personnelManager/person/detail',
      query: {
        id: this.item.id
      }
    });
  }
}
</script>

<style lang='less' scoped>
.person-card {
  position: relative;
  padding: 30px;
  background-color: #ffffff;
  margin-bottom: 20px;

  .text1 {
    font-weight: 500 !important;
    font-size: 36px;
    color: #333333;
  }

  .text4 {
    color: #999999;
  }

  .text2, .text3 {
    width: 167px;
    height: 27px;
    font-size: 28px;
    font-weight: 500;
  }

  &-body {
    display: flex;
  }

  &-img {
    width: 140px;
    height: 140px;
  }

  &-content {
    padding-left: 34px;
  }
}

// 重置样式
.van-tag {
  position: absolute;
  top: 30px;
  right: 30px;
}
</style>
