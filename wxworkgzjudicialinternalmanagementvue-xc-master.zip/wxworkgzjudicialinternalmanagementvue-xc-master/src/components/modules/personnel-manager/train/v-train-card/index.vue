<template>
  <div class="person-card">
    <div class="person-card-body">
      <div class="person-card-content">
        <p class="text1">{{ item.name }}</p>
        <p class="text4">培训类型：{{ item.type }}</p>
        <p class="text4">培训年度：{{ item.year }}</p>
      </div>
    </div>
  </div>
</template>

<script lang='ts'>
import { Component, Prop, Vue } from 'vue-property-decorator';
import TrainCardModel from '@/model/modules/personnel-manager/train/TrainCardModel';

@Component({})
export default class PersonCard extends Vue {
  @Prop({
    type: Object,
    default: () => ({})
  })
  private readonly item!: TrainCardModel;
}
</script>

<style lang='less' scoped>
.person-card {
  position: relative;
  padding: 30px;
  background-color: #ffffff;
  margin-bottom: 20px;

  .text1 {
    font-weight: 500 !important;
    font-size: 36px;
    color: #333333;
  }

  .text4 {
    color: #999999;
  }

  .text2, .text3 {
    width: 167px;
    height: 27px;
    font-size: 28px;
    font-weight: 500;
  }

  &-body {
    display: flex;
  }
}

// 重置样式
.van-tag {
  position: absolute;
  top: 30px;
  right: 30px;
}
</style>
