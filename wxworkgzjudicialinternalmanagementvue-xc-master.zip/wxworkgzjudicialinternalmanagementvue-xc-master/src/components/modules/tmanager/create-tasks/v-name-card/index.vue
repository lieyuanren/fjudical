<template>
  <div class="name-card">
    {{ item.name }}
    <div @click="delItem"
         class="del">
      <van-icon name="cross"/>
    </div>
  </div>
</template>

<script lang='ts'>
import { Component, Prop, Vue } from 'vue-property-decorator';
import NameCardType from '@/model/modules/t_manager/NameCardType';
import { Mutation } from 'vuex-class';

@Component({})
export default class NameCard extends Vue {
  @Prop() private item: NameCardType;
  @Prop() private propName: string;
  @Mutation('delAll') private delCompany: any;

  // 删除当前项
  private delItem(): void {
    this.delCompany({
      propName: this.propName,
      arr: [this.item]
    });
  }
}
</script>

<style lang='less' scoped>
.name-card {
  position: relative;
  margin-top: 20px;
  border-radius: 8px;
  border: 1px solid #e4e4e4;
  padding: 18px;
  display: inline-block;
  margin-right: 44px;
  background-color: #fafafa;

  .del {
    width: 34px;
    height: 34px;
    position: absolute;
    right: -14px;
    top: -14px;
    background-color: #ff5659;
    border-radius: 50%;
    display: flex;
    justify-content: center;
    align-items: center;
    i {
      color: #ffffff;
    }
  }
}
</style>