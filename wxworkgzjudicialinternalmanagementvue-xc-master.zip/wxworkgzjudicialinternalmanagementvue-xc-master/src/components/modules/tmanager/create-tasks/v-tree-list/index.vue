<template>
  <div class="tree-list">
    <div class="tree-list-item"
         v-for="(item,index) in children"
         :key="item.id">
      <div class="tree-list-item-one"
           v-if="item.children">
        <van-checkbox v-model="item.isChecked"
                      shape="square"
                      @click="handelClick(index,item.id)">{{ item.name }}</van-checkbox>
        <van-icon name="arrow-up"
                  @click="toggelOpen(index)"
                  v-if="item.isOpen" />
        <van-icon name="arrow-down"
                  @click="toggelOpen(index)"
                  v-else />
      </div>
      <div class="tree-list-item-two"
           v-else>
        <van-checkbox v-model="item.isChecked"
                      shape="square"
                      @click="handelClick(index,item.id)">{{ item.name }}</van-checkbox>
      </div>
      <div class="tree-list-children"
           v-if="item.children && item.isOpen">
        <TreeList :children="item.children"
                  :parentCheck="item.isChecked"
                  :parentCheckIndex="index"
                  @changeParentCheck="changeParentCheck" />
      </div>
    </div>
  </div>
</template>

<script lang='ts'>
import { Component, Vue, Prop, Watch } from 'vue-property-decorator';
import { Getter, Mutation } from 'vuex-class';
import NameCardType from '../../../../../model/modules/t_manager/NameCardType';
import ListTreeType from '@/model/modules/t_manager/ListTreeType';

@Component({
  components: {
    TreeList
  }
})
export default class TreeList extends Vue {
  @Prop() private children: any;
  @Prop() private parentCheck: boolean;
  @Prop() private parentCheckIndex: number;
  @Mutation('addAll') private addAll: any;
  @Mutation('delAll') private delAll: any;

  private propName: string = '';
  // 临时存放的数组
  private temporaryArr: ListTreeType[] = [];

  public created() {
    this.propName = this.$route.query.propName as string;
    this.watchChildren();
  }

  // 监听父级的check状态
  @Watch('parentCheck')
  private watchParentCheck(): void {
    if (!this.children) {
      return;
    }
    if (this.parentCheck) {
      this.setBooleans(this.parentCheck);
    } else {
      const isTrue = this.children.every(
        (item: ListTreeType): boolean => item.isChecked as boolean
      );
      if (isTrue) {
        this.setBooleans(this.parentCheck);
      }
    }
  }

  // 监听子级的所有checked状态
  @Watch('children', { deep: true })
  private watchChildren(): void {
    if (!this.children) {
      return;
    }
    const isAllTrue = this.children.every(
      (item: ListTreeType): boolean => item.isChecked as boolean
    );
    if (isAllTrue === this.parentCheck) {
      return;
    }
    this.$emit('changeParentCheck', this.parentCheckIndex, isAllTrue);
  }
  private async toggelOpen(index: number): Promise<void> {
    this.children[index].isOpen = !this.children[index].isOpen;
  }

  private setBooleans(bol: boolean): void {
    for (const item of this.children) {
      item.isChecked = bol;
    }
  }

  private changeParentCheck(index: number, bol: boolean): void {
    this.children[index].isChecked = bol;
  }

  private handelClick(index: number, id: string): void {
    this.temporaryArr = [];
    // 根据id处理好一个数组传递给store
    this.handelArr(this.children[index]);
    if (this.children[index].isChecked) {
      this.delAll({
        propName: this.propName,
        arr: this.temporaryArr
      });
    } else {
      this.addAll({
        propName: this.propName,
        arr: this.temporaryArr
      });
    }
    console.log(this.temporaryArr);
  }

  // 递归处理数组
  private handelArr(ob: ListTreeType): void {
    // if (!ob.children) {
    //   this.temporaryArr.push({
    //     id: ob.id,
    //     name: ob.name,
    //     label:ob.name,
    //     text:ob.name
    //   });
    //   return;
    // } else {
    //   for (const item of ob.children) {
    //     this.handelArr(item);
    //   }
    // }
  }
}
</script>

<style lang='less' scoped>
.tree-list {
  width: 100%;
  background-color: #ffffff;
  &-item {
    &-one,
    &-two {
      display: flex;
      justify-content: space-between;
      align-items: center;
      height: 110px;
      padding: 0 20px;
      font-size: 32px;
    }
  }
  &-children {
    padding-left: 50px;
  }
}
</style>
