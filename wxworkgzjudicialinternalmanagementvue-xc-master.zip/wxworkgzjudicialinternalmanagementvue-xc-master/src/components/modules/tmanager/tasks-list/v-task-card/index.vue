<!--
 * @Author: tangzhicheng
 * @Date: 2021-03-23 10:44:30
 * @LastEditors: tangzhicheng
 * @LastEditTime: 2021-05-27 14:20:21
 * @Description: file content
-->
<template>
  <div @click="manageClick(item.taskId)"
       class="tasks-card">
    <p class="text2 title">
      <span>{{ item.title | textLimit }}</span>
      <van-tag :type="item.state==='已完成'?'success':'danger'"
               plain>{{ item.state }}
      </van-tag>

    </p>
    <p :key="index"
       class="item"
       v-for="(obj, index) in item.list">
      <span class="label">{{ obj.label }}:</span>
      <span class="value">{{ obj.value }}</span>
    </p>
  </div>
</template>

<script lang='ts'>
import { Component, Prop, Vue } from 'vue-property-decorator';
import TaskCardType from '@/model/modules/t_manager/TaskCardType';

@Component({
  filters: {
    textLimit(str: string): string {
      if (str.length > 16) {
        return str.substring(0, 15) + '…';
      }
      return str;
    }
  }
})
export default class TaskCard extends Vue {
  @Prop() private item: TaskCardType;

  /**
   * 任务点击
   */
  public manageClick(id: string): void {
    console.log('任务点击');
    this.$router.push({
      path: '/tmanager/detail',
      query: {
        id
      }
    });
  }
}
</script>

<style lang='less' scoped>
.tasks-card {
  background-color: #ffffff;
  padding: 30px 30px;
  border-bottom: 1px solid #eeeeee;

  .title {
    display: flex;
    justify-content: space-between;
    height: 42px;
  }

  .item {
    font-size: 28px;
    color: #999999;
    margin: 10px 0;

    .value {
      padding-left: 10px;
    }
  }

  .text2 {
    font-weight: normal !important;
  }
}
</style>
