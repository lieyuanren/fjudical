/**
 * @Author : ChangJun
 * @Date : 2019-06-19
 * @Version : 1.0
 * @Content : 全局配置
 */

const CONFIG = {
  // 接口
  // interfaces: require('../api/index'),
  // 代理
  proxy: {
    // 不同域名标识
    dev: ['demo', 'admin', 'api'], //
    // 接口域名配置
    // 192.168.50.218为测试服务器 仅用来保证前端正常运行
    domain: {
      demo: { // demo
        development: 'http://risktest.aegis-info.com/',
        pre: 'http://risktest.aegis-info.com/',
        production: 'http://risktest.aegis-info.com/'
      },
      admin: { // 调解
        development: 'http://localhost:8088/',
        pre: 'https://t-auth-dispute.aegis-info.com/',
        production: 'https://dispute.aegis-info.com/'
      },
      api: { // 混合项目
        development: 'https://wxgz.aegis-info.com/api',
        // development: 'http://192.168.50.143:8080/',
        pre: 'https://wxgz.aegis-info.com/',
        production: 'https://wxgz.aegis-info.com/'
      }
    }
  },
  name: 'WXWorkGZJudicialInternalManagementVue', // 项目名称
  version: 'V1.0', // 版本号
  channel: 'wxPage', // 渠道标识
  defaultTitle: '广州司法内部管理系统', // 页面标题
  // 错误编码
  http_code: {
    SUCCESS: 0,
    FAIL: -1
  }
};
module.exports = CONFIG;
