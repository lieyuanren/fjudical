/**
 * 全局变量
 *  this.$globals.global.data【name】 引用/赋值
 */
import Environment from '@/model/common/wxwork/Environment';

export default {
  data: {
    isDev: false, // 方便开发
    environment: new Environment(), // 运行环境
    deviceId: null, // 企业微信设备id
    userId: null  // 企业微信用户id
  },
  /**
   * 获取运行环境
   */
  getEnvironment (): Environment {
    if (this.data.environment) {
      return this.data.environment;
    }
    return new Environment();
  }
};
