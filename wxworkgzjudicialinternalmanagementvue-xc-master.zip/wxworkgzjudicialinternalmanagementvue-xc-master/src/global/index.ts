/**
 * @Author : yeqinhua
 * @Date : 2019/12/09
 * @Version : 1.0
 * @Content : 全局变量
 */
import Global from './global';
import {VueConstructor} from 'vue';

export default {
  install (Vue: VueConstructor): void {

    const globals = {Global};
    if (!Vue.prototype.$globals) {
      Vue.prototype.$globals = globals;
    } else {
      Vue.prototype.$api.$globals = globals;
    }
  }
};
