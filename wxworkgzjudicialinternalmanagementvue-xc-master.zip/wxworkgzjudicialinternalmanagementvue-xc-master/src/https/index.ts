/**
 * @Author : ChangJun
 * @Date : 2019/2/13
 * @Version : 1.0
 * @Content : 接口请求通用封装
 */
import xHttp from './x-https';

// const config = require('../config/index.js');
import interfaces from '../api/index';
import {VueConstructor} from 'vue';

export default {
  install (Vue: VueConstructor): void {
    Vue.prototype.$interface = interfaces;
    if (!Vue.prototype.$api) {
      Vue.prototype.$api = {
        xHttp
      };
    } else {
      Vue.prototype.$api.xHttp = xHttp;
    }
  }
};

