/**
 * @Author : ChangJun
 * @Date : 2019/2/13
 * @Version : 1.0
 * @Content : 接口请求通用封装
 */
// @ts-ignore
import qs from 'qs';
import { Dialog } from 'vant';
import axios from 'axios';
import store from '@/store/index';
import Log from '../utils/common/log';
import Localstorage from '../utils/common/local-storage';
import { router } from '@/router';

const config = require('../config/index.js');

/**
 * 请求拦截器
 */
axios.interceptors.request.use((config) => {
  // 在发送请求之前做些什么，例如加入token
  return config;
}, (error) => {
  // 对请求错误做些什么
  return Promise.reject(error);
});
/**
 * 响应拦截器
 */
axios.interceptors.response.use((response) => {
  // 在接收响应做些什么，例如跳转到登录页
  return response;
}, async (error) => {
  // 对响应错误做点什么
  const { status } = error.response;
  if (status && (status === 401 || status === 402)) {  // 统一拦截401
    error.response.data.msg = '重新登录';
    if (Localstorage.get('ACCESS_TOKEN') && Localstorage.get('ACCESS_TOKEN')) {
      Localstorage.clear('ACCESS_TOKEN');
      Localstorage.clear('USER');
      await router.replace('/login'); // 路由向到首页 进行授权
    }
  }
  if (status && status === 444) { // 操作频繁
    error.response.data.msg = '操作频繁';
  }
  return Promise.reject(error);
});

// 多种类型接口处理(根据各自项目进行修改)
const DEF = [
  {
    fail_handling: async (res: { code: number, msg: any }) => {
      let message = res.msg;
      if (res.code === -1) { // -1 是代码报错 屏蔽报错内容
        message = '系统问题，请稍后再试！';
      }
      await Dialog.alert({ title: '错误', message });
    }
  }
];

/**
 * 成功处理
 * @param res
 * @param load
 * @param defEx
 * @param defData
 */
function successParse(res: { data: { code: number, data: object, msg: any } }, load: boolean, defEx: boolean, defData: boolean) {
  return new Promise((resolve) => {
    if (load) {
      store.commit('SET_LOADING', { show: false });
    }
    try {
      const obj = res.data;
      if (obj.code === config.http_code.SUCCESS || obj.code === 200) {
        if (defData) {
          resolve(obj.data);
        } else {
          resolve(obj);
        }
      } else {
        // 通用业务失败处理
        if (defEx) {
          DEF[0].fail_handling(obj);
        } else {
          resolve(obj || {});
        }
      }
    } catch (ex) {
      if (defEx) {
        DEF[0].fail_handling({ code: -1, msg: '' });
      } else {
        resolve({});
      }
    }
  });
}

/**
 * 失败处理
 * @param ex
 * @param load
 * @param defFail
 * @returns {Promise.<*>|Promise<R>}
 */
function errorParse(ex: { status: number, data: { code: number, data: object, msg: any } }, load: boolean, defFail: boolean) {
  let resData = null;
  return new Promise((resolve, reject) => {
    if (load) {
      store.commit('SET_LOADING', { show: false });
    }
    const obj = ex ? ex.data : { msg: '' };
    if (defFail) {
      DEF[0].fail_handling({ code: ex.status || -1, msg: obj.msg });
    } else {
      resData = {
        code: ex.status,
        msg: obj.msg
      };
      reject(resData);
    }
  });
}

/**
 * Ajax请求方法
 * @param url 接口地址
 * @param method 请求方式
 * @param body 请求参数
 * @param options header参数
 * @param load 是否显示请求loading
 * @param loadMsg loading的提示
 * @param isForm content-type方式是否为 multipart/form-data
 * @param defFail 统一处理错误
 * @param defEx 统一逻辑错误处理
 * @param defData 统一数据处理
 * @param vailDator Api 校验规则
 * @returns {Promise<U>|*|Promise|Promise.<T>}
 */
function send(url: string, method: string, body: object, options: any, load: boolean, loadMsg: string, defFail: boolean, defEx: boolean, defData: boolean) {
  if (load) {
    store.commit('SET_LOADING', { show: true, msg: loadMsg });
  }
  // 生成请求的url
  // url = !url.startsWith('http') ? `${DOMAIN}${url}` : url
  const opts = { ...options };
  opts.headers = {
    'Accept': 'application/json',
    'Content-Type': options && options.isForm ? 'application/x-www-form-urlencoded' : 'application/json',
    'Authorization': (Localstorage.get('CurrentRouters') !== 'mediation' ? 'bearer ' : '') + Localstorage.get('ACCESS_TOKEN'), // 请求头
    'Module': Localstorage.get('CurrentRouters'), // 模块
    ...opts.headers
  };
  // post form-data请求将参数序列化成 form 参数
  if (options && options.isForm) {
    body = qs.stringify(body);
  }
  if ((body && method === 'get') || (body && method === 'delete')) {
    opts.params = body;
  }
  // 数据埋点
  const reqParamJson = body ? JSON.stringify(body) : '';
  Log.saveApiRequest(url, reqParamJson, '-2', '接口请求', 'apiReq');
  switch (method) {
    case 'get':
      return axios.get(url, opts)
        .then((res: any) => successParse(res, load, defEx, defData))
        .catch((ex: any) => errorParse(ex && ex.response, load, defFail));
    case 'post':
      return axios.post(url, body, opts)
        .then((res: any) => successParse(res, load, defEx, defData))
        .catch((ex: any) => errorParse(ex.response, load, defFail));
    case 'put':
      return axios.put(url, body, opts)
        .then((res: any) => successParse(res, load, defEx, defData))
        .catch((ex: any) => errorParse(ex.response, load, defFail));
    case 'delete':
      return axios.delete(url, opts)
        .then((res: any) => successParse(res, load, defEx, defData))
        .catch((ex: any) => errorParse(ex.response, load, defFail));
  }
}

export default {
  /**
   * Get / delete
   * @param url 请求链接
   * @param body 入参
   * @param options header 头信息
   * @param load loading
   * @param loadMsg loading信息
   * @param defFail 是否需要统一处理接口错误
   * @param defEx 是否统一处理业务逻辑错误
   * @param defData 是否只返回出参 data 内容
   * @returns {Promise<U>|*|Promise|Promise<T>}
   */
  get(url: string, body: object = {}, options: object = {}, { load = true, loadMsg = '加载中...', defFail = true, defEx = true, defData = false } = {}) {
    return send(url, 'get', body, options, load, loadMsg, defFail, defEx, defData);
  },
  delete(url: string, body: object = {}, options: object = {}, { load = true, loadMsg = '加载中...', defFail = true, defEx = true, defData = false } = {}) {
    return send(url, 'delete', body, options, load, loadMsg, defFail, defEx, defData);
  },
  /**
   * Post / Put
   * @param url 请求链接
   * @param body 入参
   * @param options header 头信息
   * @param load loading
   * @param loadMsg loading信息
   * @param defFail 是否需要统一处理接口错误
   * @param defEx 是否统一处理业务逻辑错误
   * @param defData 是否只返回出参 data 内容
   * @returns {Promise<U>|*|Promise|Promise<T>}
   */
  post(url: string, body: object = {}, options: object = {}, { load = true, loadMsg = '加载中...', defFail = true, defEx = true, defData = false } = {}) {
    return send(url, 'post', body, options, load, loadMsg, defFail, defEx, defData);
  },
  put(url: string, body: object = {}, options: object = {}, { load = true, loadMsg = '加载中...', defFail = true, defEx = true, defData = false } = {}) {
    return send(url, 'put', body, options, load, loadMsg, defFail, defEx, defData);
  },
  // 合并多次请求
  all(list: []) {
    return axios.all(list).then(axios.spread((...args: any) => {
      return args;
    }));
  }
};
