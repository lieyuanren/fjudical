import Vue from 'vue';
import '@/assets/flexible/flexible.min';
// @ts-ignore
import App from './App.vue';
import { router } from '@/router';
import { Route } from 'vue-router';
import store from './store/index';
import Common from './utils/common/common';
import Log from './utils/common/log';
import LocalStorage from '@/utils/common/local-storage';
import UtilsPlugin from './utils/index';
import HttpsPlugin from './https/index';
import GlobalDataPlugin from './global/index';
// @ts-ignore
import TipPlugin from './plugins/tip/index.js';
import { sync } from 'vuex-router-sync';

const config = require('./config/index.js');
Vue.config.productionTip = true;


// vant组件的引入
import './plugins/vant';
import { Commit } from 'vuex';

const commit: Commit = store.commit;
const history: Storage = window.sessionStorage;
const count = history.getItem('count') || 0;
history.clear();
let historyCount = (count as number) || 0;
history.setItem('/', '0');

// 手动滑动问题解决
let isPush: boolean = false;
let isTouchStart: boolean = false;
let endTime: any = Date.now();
const methods = ['push', 'go', 'replace', 'forward', 'back'];
document.addEventListener('touchend', () => {
  isTouchStart = false;
  endTime = Date.now();
});
document.addEventListener('touchstart', () => {
  isTouchStart = true;
});
methods.forEach((key: string) => {
  const method = (router as any)[key].bind(router);
  (router as any)[key] = (...args: any) => {
    isPush = true;
    method.apply(null, args);
  };
});

router.beforeEach((to: Route, from: Route, next: any) => {
  const token = LocalStorage.get('ACCESS_TOKEN'); // 权限判断
  if (!token && to.path !== '/login') {
    console.log('无登录状态，前往登录...');
    next({ path: '/login', replace: true });
    return;
  }
  // 全局遮罩
  commit('SET_SHOW_MASKING', true);
  // 离开上级页面埋点
  Log.saveRouteLeave(from, 'leave_page', '离开页面', 'leave');
  const toIndex = history.getItem(to.path);
  const fromIndex = history.getItem(from.path);
  let direction: string = '';
  if (toIndex) {
    // 前进动画
    if (!fromIndex || parseInt(toIndex, 10) > parseInt(fromIndex, 10) || (toIndex === '0' && fromIndex === '0')) {
      direction = 'forward';
    } else {
      direction = 'reverse';
    }
  } else {
    ++(historyCount as number);
    history.setItem('count', historyCount.toString());
    to.path !== '/' && history.setItem(to.path, historyCount.toString());
    direction = 'forward';
  }
  // 判断是否是ios左滑返回 或者 右滑前进
  if (toIndex && toIndex !== '0' && !isPush && (((Date.now() - endTime) < 377) || isTouchStart)) {
    commit('SET_DIRECTION', '');
  } else {
    commit('SET_DIRECTION', direction);
  }
  isTouchStart = false;
  // 记录进入时间
  commit('SET_ENTER_TIME', new Date().getTime());
  // 设置当前路由
  commit('SET_ROUTE', to);
  // 设置页面唯一标识
  commit('SET_PAGE_GUID', Common.guid());
  setTimeout(next, 0);
});
router.afterEach((to: Route) => {
  isPush = false;
  // 设置网页标题
  if (to.name || to.name !== config.defaultTitle) {
    Common.setTitle(to.name || config.defaultTitle);
  }
  // 路由进入埋点
  Log.saveEvent('into_page', '进入页面', 'init');
});
Vue.use(UtilsPlugin);
Vue.use(HttpsPlugin);
Vue.use(TipPlugin);
Vue.use(GlobalDataPlugin);
sync(store, router);
new Vue({
  router,
  store,
  render: (h) => h(App)
}).$mount('#app');

