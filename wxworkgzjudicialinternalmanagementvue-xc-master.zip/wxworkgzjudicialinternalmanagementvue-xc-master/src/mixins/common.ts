/**
 * 全局混入
 * @type {{data(): *, created(): void}}
 */
import { Vue, Component } from 'vue-property-decorator';
import Environment from '@/model/common/wxwork/Environment';
import BaseUser from '@/model/common/wxwork/BaseUser';
import LocalStorage from '@/utils/common/local-storage';

@Component
export default class Common extends Vue {
  public mapKey: string = 'HCNBZ-RQH6P-F7WDZ-VOTAV-JSMIO-33FAC';
  public environment = new Environment();
  public user: BaseUser = LocalStorage.get('USER');
}
