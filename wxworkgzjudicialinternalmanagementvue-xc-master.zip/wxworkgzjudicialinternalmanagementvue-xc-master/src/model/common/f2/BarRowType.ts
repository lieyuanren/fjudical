/**
 * @author : tangzhicheng
 * @Date : 2020-03-06
 * @Content : 层叠柱状图绘制数据类型
 */

export default class BarRowType {
    public name: string = '';
    public type: string = '';
    public num: number = 0;
}
