/**
 * @author : tangzhicheng
 * @Date : 2020-03-06
 * @Content : 折线图数据 类型
 */

export default class BorkenLineType {
    public xAxis: string = '';
    public value: number = 0;
}
