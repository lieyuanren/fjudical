/**
 * @author : tangzhicheng
 * @Date : 2020-03-05
 * @Content : 饼图数据类型
 */

export default class PieType {
    public const: string = 'const';
    public type: string = '';
    public num: number = 0;
    public precent?: number = 0;
}
