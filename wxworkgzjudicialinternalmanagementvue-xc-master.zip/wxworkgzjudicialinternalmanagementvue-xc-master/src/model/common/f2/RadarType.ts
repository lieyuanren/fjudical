/**
 * @author :tangzhicheng
 * @date :2020-3-11
 * @Content :数据分析 雷达图
 */

export default class RadarType {
    public name: string = '';
    public value: number = 0;
    public type: string = '';
}

