/**
 * @Author : ChangJun
 * @Date : 2019-06-18
 * @Version : 1.0
 * @Content : loading对象
 */

export default class Loading {
  public show?: boolean;
  public msg?: string;
}
