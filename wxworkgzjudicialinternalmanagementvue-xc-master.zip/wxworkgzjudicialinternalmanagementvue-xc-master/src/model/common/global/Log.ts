/**
 * @Author : ChangJun
 * @Date : 2019-06-25
 * @Version : 1.0
 * @Content : 数据埋点统计字段
 */

export default class Log {
  // 终端信息
  public ua?: string;

  // 用户信息
  public uId?: string; // 用户唯一标识
  public unionId?: string; // 微信下的唯一Id
  public openId?: string; // 微信的openId;
  public phone?: string; // 用户手机号
  // 项目
  public project?: string; // 平台名称
  public version?: string; // 平台版本
  public ip?: string; // 客户端IP
  public channelCode?: string; // 渠道编码
  public channel?: string; // 渠道：wxPage:微网页、wxProject:小程序
  public sourceCode?: string; // 来源：江苏高院、擎盾、广州司法局……

  public pageCode?: string; // 页面编码
  public pageGuid?: string; // 页面的闭环唯一标示，进入页面时创建新的
  public page?: string; // 页面
  public pageUrl?: string; // 页面路径

  public eventCode?: string; // 用户操作编码：用户触发行为的唯一事件标记
  public event?: string; // 用户操作释义：进入页面、点击【确认】按钮
  public activeCode?: string; // init：初始化， input：输入，click：点击，apiReq：接口请求，apiRes：接口返回，select：选择……

  public apiUrl?: string;
  public reqParam?: string; // 接口请求参数

  public enterTime?: string; // 页面进入时间
  public stayTime?: string; // 页面停留时间
  public time?: string; // 时间戳
}
