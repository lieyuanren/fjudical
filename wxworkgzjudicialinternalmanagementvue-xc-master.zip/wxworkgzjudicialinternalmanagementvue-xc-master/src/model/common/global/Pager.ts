/**
 * @Author : ChangJun
 * @Date : 2019-06-24
 * @Version : 1.0
 * @Content : 分页对象
 */

export default class Pager {
  public page: number;
  public pageSize: number;
  public total: number;
}
