/**
 * @Author : ChangJun
 * @Date : 2019-06-25
 * @Version : 1.0
 * @Content : API返回结果
 */

export default class ResponseApi {
  public code?: number;
  public data?: any;
  public msg?: string;
}
