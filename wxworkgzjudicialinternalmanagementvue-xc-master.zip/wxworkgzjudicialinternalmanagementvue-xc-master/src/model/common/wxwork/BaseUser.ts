/**
 * @Author : yeqinhua
 * @Date : 2019-06-25
 * @Version : 1.0
 * @Content : 检查运行环境
 */

export default class BaseUser {
  /**
   * 企业微信用户id
   */
  public id: number;

  /**
   * 登陆方式
   * 0 企业微信 code 登录
   * 1 账号密码登录
   * 2 短信验证码登录
   */
  public loginType: number;

  /**
   * 企业微信授权code 换取用户信息
   */
  public code: string;

  /**
   * 当前用户机构id
   */
  public organizationId: number;

  /** 级别 1-国家/部级单位、2-省/厅为，3-市/局、4-区、5-街镇 */
  public organizationGrade: number;

  /**
   * 当前用户机构code
   */
  public organizationCode: string;

  /**
   * 当前用户机构名称
   */
  public organizationName: string;

  /**
   * 当前用户机构下的子机构code
   */
  public organizationCodes: string[];

  /**
   * 企业微信用户id
   */
  public userId: string;
  /**
   * token
   */
  public token: string;
  /**
   * 用户名
   */
  public username: string;
  /**
   * 密码
   */
  public password: string;
  /**
   * 是否可用
   */
  /**
   * 用户所拥有的权限
   */
  public authority: string[];

  /**
   * 用户的账号是否过期;过期的账号无法通过授权验证. true 账号未过期
   */
  public accountNonExpired: boolean = true;

  /**
   * 用户的账户是否被锁定;被锁定的账户无法通过授权验证. true 账号未锁定
   */
  public accountNonLocked: boolean = false;

  /**
   * 用户的凭据(pasword) 是否过期;过期的凭据不能通过验证. true 没有过期;false 已过期
   */
  public credentialsNonExpired: boolean = false;
  /**
   * 是否启用
   */
  public enabled: boolean = false;

  // 业务系统用户
  public externalUser?: any;

}
