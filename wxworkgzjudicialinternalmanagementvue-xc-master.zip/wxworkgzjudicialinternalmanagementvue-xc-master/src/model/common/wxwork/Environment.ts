/**
 * @Author : yeqinhua
 * @Date : 2019-06-25
 * @Version : 1.0
 * @Content : 检查运行环境
 */

export default class Environment {
  public isWindowsPhone?: boolean; // windows phone
  public isSymbian?: boolean; // 塞班
  public isAndroid?: boolean; // 安卓
  public isFireFox?: boolean; // 火狐
  public isChrome?: boolean; // chrome
  public isTablet?: boolean; // 平板
  public isIPhone?: boolean; // 苹果
  public isAndroidTablet?: boolean; // 安卓平板
  public isPc?: boolean; // pc
  public isWeixin?: boolean; // 微信
  public isQYWeixin?: boolean; // 企业微信

  constructor() {
    const ua = navigator.userAgent;
    this.isWindowsPhone = /(?:Windows Phone)/.test(ua);
    this.isSymbian = /(?:SymbianOS)/.test(ua) || this.isWindowsPhone;
    this.isAndroid = /(?:Android)/.test(ua);
    this.isFireFox = /(?:Firefox)/.test(ua);
    this.isChrome = /(?:Chrome|CriOS)/.test(ua);
    this.isTablet = /(?:iPad|PlayBook)/.test(ua) || (this.isAndroid && !/(?:Mobile)/.test(ua)) || (this.isFireFox && /(?:Tablet)/.test(ua));
    this.isIPhone = /(?:iPhone)/.test(ua) && !this.isTablet;
    this.isAndroidTablet = /(?:Android)/.test(ua) && !this.isTablet;
    this.isPc = !this.isIPhone && !this.isAndroid && !this.isSymbian && !this.isTablet;
    const browser = ua.toLowerCase();
    this.isWeixin = browser.indexOf('micromessenger') !== -1;
    this.isQYWeixin = browser.indexOf('micromessenger') !== -1 && browser.indexOf('wxwork') !== -1;
  }
}
