/**
 * @author :lilili
 * @Date : 2020-07-21
 * @Content : 考勤数据卡数据对象
 */

export default class AttendanceCardModel {
  // 人员id
  // public id: string = '';
}


