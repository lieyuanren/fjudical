/**
 * @Author : 江振朗
 * @Date : 2020-03-10
 * @Version : 1.0
 * @Content :
 */

export default class BCard {
  public name?: string;
  public count?: number;
  public cards?: BCard[];
}

