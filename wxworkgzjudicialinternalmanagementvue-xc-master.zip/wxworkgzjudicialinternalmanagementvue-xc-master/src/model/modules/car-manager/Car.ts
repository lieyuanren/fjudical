/**
 * @Author : 廖天正
 * @Date : 2019-06-25
 * @Version : 1.0
 * @Content : 车辆信息
 */

export default class Car {
  public remark?: string;
  public carModel: string;
  // 终端信息
  public startTime?: string;
  // 用户信息
  public endTime?: string; // 用户唯一标识
  public telephone?: string; // 微信下的唯一Id
  public username?: string; // 微信的openId;
  public carType?: string; // 用户手机号
  // 项目
  public carNo: string; // 平台名称
  public carCode: string;
  public personCode: string;
}
