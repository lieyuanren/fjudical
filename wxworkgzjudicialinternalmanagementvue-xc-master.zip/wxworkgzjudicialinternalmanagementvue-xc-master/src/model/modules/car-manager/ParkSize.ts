/**
 * @Author : 廖天正
 * @Date : 2019-06-25
 * @Version : 1.0
 * @Content : 车辆信息
 */

export default class ParkSize {
  public total?: number = 0; // 用户唯一标识
  public remain?: number = 0; // 微信下的唯一Id
}
