/**
 * @author :suntaozhang
 * @date :2020-3-17
 * @Content :菜单信息
 */

export default class MoneyInfo {
  // 部门名称
  public name: string = '';
  // 预算总额
  public budgetMoney: string = '';
  // 到账金额
  public accountMoney: string = '';
  // 预算支出
  public expenditureMoney: string = '';
}

