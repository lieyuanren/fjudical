/**
 * @Author: tangzhicheng
 * @Date: 2020-03-18 09:14:15
 * @LastEditors: tangzhicheng
 * @LastEditTime: 2020-03-18 09:21:30
 * @Description: 详情页 信息卡
 */

export default class OpinionCardType {
    // 名字
    public handler: string = '';
    // 状态
    public status: string = '';
    // 时间
    public handleTime: string = '';
    // 内容
    public content: string = '';
}

