/**
 * @Author: tangzhicheng
 * @Date: 2020-03-17 10:47:38
 * @LastEditors: tangzhicheng
 * @LastEditTime: 2020-03-17 10:48:49
 * @Description: file content
 */

import TopPayType from '@/model/modules/internal-control/analysis/TopPayType';

export default class OtherPayType extends TopPayType {
}


