/**
 * @Author: tangzhicheng
 * @Date: 2020-03-17 10:41:11
 * @LastEditors: tangzhicheng
 * @LastEditTime: 2020-03-17 11:21:30
 * @Description: 数据分析
 */


export default class TopPayType {
    // 支出类型
    public payType: string = '';
    // 支付占比
    public proportion: number = 0;
    // 支出金额
    public money: string | number = '0';
}

