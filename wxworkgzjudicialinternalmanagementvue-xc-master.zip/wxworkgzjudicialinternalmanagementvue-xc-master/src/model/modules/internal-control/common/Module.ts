/**
 * 内控列表页面，详情页面模块统一实体类
 *
 * @author 江振朗 2020-03-18
 * @version 1.0.0
 */
export default class Module {
  public title: string = '';
  public label1: string = '';
  public field1: string = '';
  public label2: string = '';
  public field2: string = '';
  public label3: string = '';
  public field3: string = '';
  public urlName: string = '';
}
