/**
 * @Author: tangzhicheng
 * @Date: 2020-03-16 16:50:29
 * @LastEditors: tangzhicheng
 * @LastEditTime: 2020-03-16 16:55:29
 * @Description: 审批流程数据类型
 */

interface Person {
    person: string;
    handleTime: string;
    // 三个状态 0：待审批  1：同意 2：拒绝
    status: string;
}


export default class ApprovalStepType {
    // 审批历史节点
    public name: string = '';
    // 审批人对象
    public handles: Person[] = [];
}

