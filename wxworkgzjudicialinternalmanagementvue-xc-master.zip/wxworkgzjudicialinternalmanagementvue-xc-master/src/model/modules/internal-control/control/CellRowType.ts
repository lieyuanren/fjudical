/**
 * @Author: tangzhicheng
 * @Date: 2020-03-16 16:19:54
 * @LastEditors: tangzhicheng
 * @LastEditTime: 2020-03-16 16:21:17
 * @Description: 详情页 每一条展示信息的数据类型
 */

export default class CellRowType {
    // 字段名
    public label: string = '';
    // 字段值
    public value: string = '';
}

