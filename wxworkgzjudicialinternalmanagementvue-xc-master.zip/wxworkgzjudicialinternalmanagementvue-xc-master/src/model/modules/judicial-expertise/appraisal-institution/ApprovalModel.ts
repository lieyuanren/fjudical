/**
 * @author :tangzhicheng
 * @Date :2020-1-13
 * @Content :认证证书
 */

export default class ApprovalModel {
  // 认可范围
  public range: string;
  // 初次认可
  public firstTime: string;
  // 证书编号
  public certificateCode: string;
  // 发证机关
  public office: string;
  // 发证日期
  public sendTime: string;
}
