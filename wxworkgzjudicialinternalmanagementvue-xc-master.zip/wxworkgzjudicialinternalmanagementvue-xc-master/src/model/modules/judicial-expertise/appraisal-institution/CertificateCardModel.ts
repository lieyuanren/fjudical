/**
 * @author :tangzhicheng
 * @Date : 2020-1-14
 * @Content :资质质量展示卡
 */

export default class CertificateCardModel {
  public title: string = '';
  public state: string = '';
  public dataList: any[] = [];
}

