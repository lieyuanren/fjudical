/**
 * @author :tangzhicheng
 * @Date :2020-1-15
 * @Content :设备信息卡
 */

export default class EquipmentCardModel {
  // 设备名称
  public name: string = '';
  // 型号
  public type: string = '';
  // 数量及单位
  public count: number = 0;
  // 购入时间
  public payTime: string = '';
  // 发票或（所有权凭证）编号
  public serialNumber: string = '';
  // 状态
  public state: string = '';
}

