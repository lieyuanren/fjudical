/**
 * @author :tangzhicheng
 * @Date :2020-1-6
 * @Content :鉴定机构 展示卡 数据对象
 */


export default class InstitutionCardModel {
  // 机构id
  public organizationId: string = '';
  //  机构名称
  public organizationName: string = '';
  // 机构负责人
  public person: string = '';
  // 机构地址
  public address: string = '';
  // 联系电话
  public phoneNum: string = '';
  // 机构图片路径
  public imgUrl: string = '';
  // 执业状态
  public state: string = '';
}
