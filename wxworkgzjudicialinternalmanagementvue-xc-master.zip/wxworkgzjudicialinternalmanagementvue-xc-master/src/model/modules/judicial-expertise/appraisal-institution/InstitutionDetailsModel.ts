/**
 * @author :tangzhicheng
 * @Date :2020-1-13
 * @Content : 机构鉴定详情数据对象
 */

export default class InstitutionDetailsModel {
  //  机构名称
  public organizationName: string = '';
  // 状态
  public state: string = '';
  // 许可证号
  public licenseKey: string = '';
  // 有效期
  public termOfValidity: string = '';
  // 联系电话
  public phoneNum: string = '';
  // 机构地址
  public organizationAddress: string = '';
  // 统一社会信用代码
  public creditCode: string = '';
  // 司法鉴定类别
  public judicialCategory: string = '';
}
