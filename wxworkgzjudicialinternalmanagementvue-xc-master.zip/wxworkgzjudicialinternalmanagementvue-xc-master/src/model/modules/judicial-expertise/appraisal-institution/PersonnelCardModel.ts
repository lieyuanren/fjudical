/**
 * @author :tangzhicheng
 * @Date :2020-1-14
 * @Content :鉴定机构详情 信息卡 对象
 */

export default class PersonnelCardModel {
  public title1: string = '';
  public title2?: string = '';
  public dataList: any[] = [];
}

