/**
 * @author :tangzhicheng
 * @Date :2020-1-13
 * @Content :资质认定证书
 */


export default class QualificationsModel {
  // 实验室名称
  public laboratoryName: string;
  // 实验室地址
  public laboratoryAddress: string;
  // 证书编号
  public certificateCode: string;
  // 发证机关
  public office: string;
  // 发证日期
  public sendTime: string;
}
