/**
 * @author :tangzhicheng
 * @Date : 2020-16
 * @Content : 鉴定人展示卡数据对象
 */

export default class AppraiserCardModel {
  // 人员id
  public id: string = '';
  // 姓名
  public name: string = '';
  // 所在机构
  public organization: string = '';
  // 鉴定类别
  public category: string = '';
  // 状态
  public state: string = '';
  // 照片
  public imgUrl: string = '';
}


