/**
 * @author :tangzhicheng
 * @date :2020-1-17
 * @Content :鉴定人详情 数据对象
 */

export default class AppraiserDetailsModel {
  //  名字
  public name: string = '';
  // 性别
  public sex: string = '';
  // 状态
  public state: string = '';

  // 出生年月日
  public birthday: string = '';
  // 籍贯
  public nativePlace: string = '';
  // 所在单位
  public units: string = '';
  // 政治面貌
  public politicsStatusName: string = '';
  // 参加工作时间
  public workTime: string = '';
  // 身份号码
  public idCar: string = '';
  // 专业技术职务
  public post: string = '';
  // 现工作单位及职务简称
  public PriorWorkUnit: string = '';
  // 毕业学校
  public schoolOfGraduation: string = '';
  // 所学专业
  public major: string = '';
  // 毕业时间
  public Graduation: string = '';
  // 可能是奖罚情况
  public creditList: number[] = [];

  // 最高学历
  public officialAcademicCredentials: string = '';
  // 照片
  public photo: string = '';
  public mechanism: string = '';
  public certificateNumber: string = '';
  public category: string = '';
  public validity: string = '';
  public idCard: string = '';
  public practiceWay: string = '';
  public duty: string = '';
  public title: string = '';
  public phoneNumber: string = '';
  public address: string = '';
}
