/**
 * @author :tangzhicheng
 * @Date :2020-1-3
 * @Content :case案件卡数据对象
 */


export default class CaseCardModel {
  // 统一案号
  public caseID: string = '';
  // 机构名称
  public organizationName: string = '';
  // 委托人
  public client: string = '';
  // 结案时间
  public overTime: string = '';
}
