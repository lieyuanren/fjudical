/**
 * @author :tangzhicheng
 * @Date :2019-1-3
 * @Content :案件详情数据对象
 */


export default class CaseDetailsModel {
  // 统一案号
  public caseID: string = '无';
  // 结案时间
  public overTime: string = '无';
  // 机构名称
  public organizationName: string = '无';

  /**
   * 基本信息
   */
    // 委托人
  public client: string = '无';
  // 委托人类型/属地
  public clientTypes: string = '无';
  // 鉴定类别
  public appraisalType: string = '无';
  // 委托日期
  public entrustDate: string = '无';
  // 联系人
  public contacts: string = '无';
  // 联系地址
  public contactsAddress: string = '无';

  // 鉴定对象
  public appraiserObj: string = '无';
  // 鉴定对象类型
  public appraiserType: string = '无';
  // 委托鉴定事项
  public appraisalMatter: string = '无';

  // 鉴定用途
  public appraisalUse: string = '无';
  // 基本案情
  public basicCase: string = '无';

  /**
   * 更多案件信息
   */
    // 机构案号
  public organizationCaseID: string = '无';
  // 鉴定人
  public appraiser: string = '无';
  // 文书复核人
  public documentReviewer: string = '无';
  // 文书签发人
  public issuedby: string = '无';
  // 重大事项报告类型
  public importantMatters: string = '无';
  // 鉴定时限
  public appraisalTimeLimit: string = '无';
}
