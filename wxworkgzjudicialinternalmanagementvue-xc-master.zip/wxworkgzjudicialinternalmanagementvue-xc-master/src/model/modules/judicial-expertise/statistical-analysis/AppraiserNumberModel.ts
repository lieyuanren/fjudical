/**
 * @author :tangzhicheng
 * @date :2020-1-20
 * @Content :鉴定人详情
 */

export default class AppraiserNumberModel {
  // 机构名称
  public mechanism: string = '';
  // 数量
  public sales: number = 0;
}

