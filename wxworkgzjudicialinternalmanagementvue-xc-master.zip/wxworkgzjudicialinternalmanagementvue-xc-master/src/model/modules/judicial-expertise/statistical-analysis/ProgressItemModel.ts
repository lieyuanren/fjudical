/**
 * @author :tangzhicheng
 * @date :2020-1-17
 * @Content :鉴定机构占有率 数据对象
 */


export default class ProgressItemModel {
  //  机构名称
  public organizationName: string = '';
  // 占比
  public proportion: number = 0;
}
