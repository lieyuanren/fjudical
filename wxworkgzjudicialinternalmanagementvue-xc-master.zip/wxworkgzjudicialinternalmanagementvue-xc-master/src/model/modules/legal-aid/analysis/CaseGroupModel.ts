/**
 * @author ：tangzhicheng
 * @Date ；2020-2-7
 * @Content :群体案件情况
 */


export default class CaseGroupModel {
  // 群体案件
  public groupNumber: number = 0;
  // 非群体案件
  public unGroupNumber: number = 0;
}
