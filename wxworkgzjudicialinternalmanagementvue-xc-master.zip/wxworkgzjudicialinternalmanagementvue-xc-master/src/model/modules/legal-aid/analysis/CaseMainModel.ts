/**
 * @author :tangzhicheng
 * @Date :2020-2-6
 * @Content :案件主体分部
 */

export default class CaseMainModel {
  // 名称定义
  public const: string = '';
  // 类型
  public type: string = '';
  // 数值
  public num: number = 0;
}
