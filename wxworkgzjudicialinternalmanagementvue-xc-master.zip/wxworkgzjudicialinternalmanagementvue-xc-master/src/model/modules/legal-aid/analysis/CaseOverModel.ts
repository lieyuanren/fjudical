/**
 * @author ：tangzhicheng
 * @Date :2020-2-6
 * @Content ：案件结案情况
 */

export default class CaseOverModel {
  // 命名
  public name: string = '';
  // 类型
  public type: string = '';
  // 数值
  public count: number = 0;
}
