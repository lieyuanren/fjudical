/**
 * @author :tangzhicheng
 * @Date :2020-2-7
 * @Content : 法律咨询案件类型情况
 */

export default class LegalAdviceModel {
  // 民事案件
  public civil: number = 0;
  // 刑事案件
  public criminal: number = 0;
  // 行政案件
  public administrative: number = 0;
}
