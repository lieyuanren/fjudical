/**
 * @author :tangzhicheng
 * @Date :2020-2-5
 * @Content ：数据盘点
 */

export default class DataInventoryModel {
  // 法律援助机构
  public organization: number = 0;
  // 法律援助律师
  public lawyer: number = 0;
  // 法律援助案件
  public case: number = 0;
  // 法律援助咨询
  public consultation: number = 0;
}
