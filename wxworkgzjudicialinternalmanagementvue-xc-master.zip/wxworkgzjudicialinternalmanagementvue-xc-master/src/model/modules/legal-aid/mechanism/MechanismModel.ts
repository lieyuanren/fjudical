/**
 * @author :tangzhicheng
 * @Date :2020-2-5
 * @Content :机构列表项
 */

export default class MechanismModel {
  //  机构名称
  public name: string = '';
  // 地址
  public address: string = '';
  // 电话
  public mobile: string = '';
}
