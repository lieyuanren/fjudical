/**
 * @author : chenchunfei
 * @date : 2019/12/26 10:40
 * @version : 1.0
 * @content : 分页参数
 */
export default class PageParam {
  public currentPage: number;
  public pageSize: number;
}
