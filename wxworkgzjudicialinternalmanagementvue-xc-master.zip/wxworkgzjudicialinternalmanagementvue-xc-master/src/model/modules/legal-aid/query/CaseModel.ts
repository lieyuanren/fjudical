/**
 * @author :tangzhicheng
 * @Date :2020-2-5
 * @Content :案件列表项
 */

export default class CaseModel {
  // 案件号
  public code: string = '';
  // 登记时间
  public registerTime: string = '';
  // 授援人
  public receivePerson: string = '';
  // 受理机构
  public receiveOrg: string = '';
  // 承办人
  public undertakePerson: string = '';
}
