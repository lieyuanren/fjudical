/**
 * @author : tangzhicheng
 * @Date ：2020-03-05
 * @Content : 数据统计 第一块 案件相关数据
 */

export default class CaseTypes {
    // 当月总数
    public caseTotal: number = 0;
    // 当月调解中
    public mediationCase: number = 0;
    // 当月调解成功
    public successCase: string = '0%';
    // 总数
    public allCase: number = 0;
    // 总成功率
    public allSuccessCase: string = '0%';
}
