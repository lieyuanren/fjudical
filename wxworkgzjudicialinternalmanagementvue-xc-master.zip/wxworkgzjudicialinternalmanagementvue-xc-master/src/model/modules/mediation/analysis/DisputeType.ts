/**
 * @author : tangzhicheng
 * @Date ： 2020-03-06
 * @Content : 统计分析第一块 纠纷类型数据类型
 */

export default class DisputeType {
    // 进度条
    public progress: number = 0;
    // 排名
    public ranking: number = 0;
    // 案件数量
    public caseCount: number = 0;
    // 占比
    public proportion: string = '0%';
    // 环比上月
    public compare: string = '0%';
}
