/**
 * @author : tangzhicheng
 * @Date ： 2020-03-06
 * @Content : 统计分析第二块 调解信息的数据类型
 */

export default class MediationType {
    // 组织数
    public organizationCount: number = 0;
    // 全市人员数量
    public wholeCity: number = 0;
    // 行专调解员数量
    public majorPerson: number = 0;
    // 行专案件数量
    public majorCase: number = 0;
}
