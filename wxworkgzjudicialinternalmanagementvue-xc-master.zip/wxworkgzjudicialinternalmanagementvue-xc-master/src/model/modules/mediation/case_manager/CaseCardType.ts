/**
 * @author ：tangzhicheng
 * @Date :2020-03-03
 * @Content : 案件管理列表项组件的数据类型
 */
import MediationCardType from '@/model/modules/mediation/home/MediationCardType';

export default class CaseCardType extends MediationCardType {
    // 纠纷描述
    public describe: string = '';
}
