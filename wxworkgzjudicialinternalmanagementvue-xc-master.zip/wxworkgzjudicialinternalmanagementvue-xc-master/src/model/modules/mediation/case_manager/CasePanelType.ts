/**
 * @author : tangzhicheng
 * @Date : 2020-03-09
 * @Content : 案件处理（案件数据类型）
 */

import common from '@/utils/common/common';

export default class CasePanelType {
    // 案件来源
    public caseFrom: string = '';
    // 纠纷类别
    public disputeType: string = '';
    // 受理日期
    public accpetDate: string | Date = common.dateFmt('yyyy-MM-dd', new Date());
    // 纠纷事实
    public disputeFact: string = '';
    // 案件预测
    public caseForecast: string = '';
    // 案件难度级别
    public caseLevel: string = '';
    // 调解组织
    public mediaOrga: string = '';
    // 调解员
    public mediator: string = '';
    // 参与调解员
    public mediatorList: string[] = [];
    // 纠纷日期
    public disputeDate: string | Date = common.dateFmt('yyyy-MM-dd', new Date());
    // 案件编号
    public caseId: string = '';
}
