/**
 * @author : tangzhicheng
 * @Date : 2020-03-09
 * @Content : 调解员数据类型
 */

export default class Mediator {
    // 调解员id
    public mediatorId: string = '';
    // 调解员名字
    public mediatorName: string = '';
    // 调解员头像
    public mediatorUrl: string = '';
    // 是否被选中
    public isChecked: boolean = false;
}

