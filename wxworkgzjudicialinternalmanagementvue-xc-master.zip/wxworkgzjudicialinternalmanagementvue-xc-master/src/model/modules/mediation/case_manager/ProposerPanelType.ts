/**
 * @author : tangzhicheng
 * @Date : 2020-03-10
 * @Content :  （案件处理） 申请人数据类型
 */

export default class ProposerPanelType {
    // 案件编号
    public caseId: string = '0';
    // 申请人类型
    public proposerType: string = '';
    // 姓名
    public name: string = '';
    // 性别
    public sex: string = '';
    // 证件类型
    public cardType: string = '';
    // 证件号码
    public cardNum: string = '';
    // 联系地址
    public address: string = '';
    // 民族
    public nation: string = '';
    // 本方当事人数量
    public partyCount: string = '';
    // 职业
    public occupation: string = '';
    // 年龄
    public age: string = '';
    // 联系电话
    public phoneNum: string = '';
}


