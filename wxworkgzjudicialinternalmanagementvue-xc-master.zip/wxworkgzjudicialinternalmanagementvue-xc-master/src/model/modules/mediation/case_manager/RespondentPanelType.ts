

/**
 * @author : tangzhicheng
 * @Date : 2020-03-10
 * @Content : 被申请人数据类型
 */

import ProposerPanelType from '@/model/modules/mediation/case_manager/ProposerPanelType';


export default class RespondentPanelType extends ProposerPanelType {
}


