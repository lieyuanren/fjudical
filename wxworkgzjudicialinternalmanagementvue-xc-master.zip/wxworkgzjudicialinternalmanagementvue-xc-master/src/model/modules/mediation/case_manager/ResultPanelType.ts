/**
 * @author : tangzhicheng
 * @Date : 2020-03-10
 * @Content : 案件结果数据类型
 */

export default class ResultPanelType {
    // 调查结果*
    public result: string = '';
    // 协议内容*
    public agreementContent: string = '';
    // 履行方式*
    public carryOutWay: string = '';
    // 协议履行情况*
    public agreementCase: string = '';
    // 协议日期*
    public agreementDate: string = '';
    // 涉案金额*
    public money: string = '';
    // 是否满意*
    public evaluate: string = '';
    // 备注
    public remark: string = '';
}
