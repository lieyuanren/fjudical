/**
 * @author : tangzhicheng
 * @Date : 2020-03-11
 * @Content : 纠纷排查列表项的数据类型
 */

export default class DisputeCardType {
    // 排查情况
    public troubleshooting: string = '';
    // 信息来源
    public infoFrom: string = '';
    // 时间情况
    public time: string = '';
    // 纠纷级别
    public disputeLevel: string = '';
}
