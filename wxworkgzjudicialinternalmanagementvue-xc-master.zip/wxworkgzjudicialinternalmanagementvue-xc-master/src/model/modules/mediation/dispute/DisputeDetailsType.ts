/**
 * @author ： tangzhicheng
 * @Date : 2020-03-11
 * @Content : 纠纷排查详情的数据类型
 */

export default class DisputeDetailsType {
    // 地址
    public address: string = '';
    // 信息来源
    public infoFrom: string = '';
    // 纠纷级别
    public disputeLevel: string = '';
    // 时间
    public date: string = '';
    // 排查情况
    public situation: string = '';
}


