/**
 * @author :tianzheng
 * @Dare :2020-03-03
 * @Content :首页调解中列表项组件的数据类型
 */

export default class CaseCardType {
  // 案件id
  public caseId: string = '';
  // 日期
  public time: string = '';
  // 调委会
  public commitee ?: string;
}
