/**
 * @author :tangzhicheng
 * @Dare :2020-03-12
 * @Content :首页调解中列表项组件的数据类型
 */


export default class HeadCardType {
    // 案件编号
    public caseId: string = '';
    // 当事人名称
    public name: string = '';
    // 纠纷类型
    public type: string = '';
    // 纠纷详情
    public dispute: string = '';
    public mediationDate: string = '';
    public committee: string = '';
    public state: string = '待接单';
    public phoneNum: string = '';
}
