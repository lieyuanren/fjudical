/**
 * @author :tangzhicheng
 * @Dare :2020-03-03
 * @Content :首页调解中列表项组件的数据类型
 */

export default class MediationCardType {
    // 案件id
    public caseId: string = '';
    // 纠纷类型
    public type: string = '';
    // 调解日期
    public mediationDate: string = '';
    // 处案调委会
    public committee: string = '';
    // 处案调解员
    public mediator: string = '';
    // 其他调解员
    public otherMediator?: string = '';
    // 状态
    public state: string = '';
}
