/**
 * @author : tangzhicheng
 * @Date : 2020-03-10
 * @Content : 新增调解员的数据类型
 */

export default class AddMediatorType {
    // 图片地址
    public imgUrl: string = '';
    // 姓名
    public name: string = '';
    // 联系方式
    public phoneNum: string = '';
    // 身份证号码
    public IdCard: string = '';
    // 羊成慧调解账号
    public account: string = '';
    // 养成慧调解密码
    public password: string = '';
    // 所属调委会
    public organization: string[] = ['请选择'];
    // 调解员级别
    public mediatorLevel: string = '';
    // 兼备其他身份
    public ohterIdentity: string = '';
    // 职位
    public position: string = '';
    // 专兼职
    public mtcsol: string = '兼职';
    // 是否政府购买服务
    public isGovernment: string = '否';
    // 是否从事过相关方面工作或具备有关知识储备
    public isWorkOn: string = '否';
    // 政治面貌
    public politicsStatus: string = '';
    // 聘用日期
    public employDate: string = '';
    // 民族
    public nation: string = '';
    // 学历
    public education: string = '';
    // 所学专业
    public specialities: string = '';
    // 身份职业
    public occupation: string = '';
    // 资格职称
    public title: string = '';
    // 婚姻状况
    public maritalStatus: string = '';
    // 联系地址
    public address: string = '';
    // 个人简介
    public introduce: string = '';
}
