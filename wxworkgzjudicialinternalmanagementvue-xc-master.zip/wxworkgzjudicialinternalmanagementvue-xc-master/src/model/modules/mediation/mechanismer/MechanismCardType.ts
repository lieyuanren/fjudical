/**
 * @author : tangzhicheng
 * @Date : 2020-03-04
 * @Content : 机构人员列表项的数据类型
 */

export default class MechanismCardType {
    // 机构id
    public id: string = '';
    // 机构名称
    public mechanismName: string = '';
    //  调委会类别
    public category: string = '';
    // 负责人
    public person: string = '';
    // 联系地址
    public address: string = '';
    // 联系电话
    public phoneNum: string = '';
    // 调解员数量
    public count: number = 0;
}
