/**
 * @author ： tangzhicheng
 * @Date : 2020-03-06
 * @Content : 调解员列表卡 数据类型
 */

export default class MediatorCardType {
    // 调解员id
    public mediatorId: string = '';
    // 头像图片
    public imgUrl: string = '';
    // 调解员名称
    public mediatorName: string = '';
    // 调解员级别
    public level: string = '';
    // 所属调委会
    public organization: string = '';
    // 调解案件
    public caseCount: number = 0;
    // 从事工作年限
    public year: number = 0;
    // 电话
    public phoneNum: string = '';
    // 状态
    public state: string = '';
}
