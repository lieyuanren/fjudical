/**
 * @author : tangzhicheng
 * @Date ； 2020-03-11
 * @Content : 调解员详情
 */

export default class MediatorDetailsType {
    // 名字
    public name: string = '';
    // 所属调委会
    public organization: string = '';
    // 专兼职
    public mtcsol: string = '';
    // 从事法律职业类型
    public jobType: string = '';
    // 学历学位
    public education: string = '';
    // 调解擅长类型
    public beGoodAt: string = '';
    // 处罚
    public punishment: string = '';
    // 奖励
    public award: string = '';
}
