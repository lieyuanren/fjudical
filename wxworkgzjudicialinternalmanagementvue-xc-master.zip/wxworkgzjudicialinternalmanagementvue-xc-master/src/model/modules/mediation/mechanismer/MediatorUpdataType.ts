/**
 * @author : tangzhicheng
 * @Date : 2020-3-11
 * @Content : 修改调解员信息
 */

import AddMediatorType from '@/model/modules/mediation/mechanismer/AddMediatorType';

export default class MediatorUpdataType extends AddMediatorType {

}
