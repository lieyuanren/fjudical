/**
 * @author:tangzhicheng
 * @Date :2019-12-26
 * @Verison :1.0
 * @Content :公证书结果数据
 */

export default class AuthenticData {
  // 机构名称
  public organizationName: string;
  //  卷宗号
  public dossierId: string;
  // 公证编号
  public notarizationCode: string;
  // 公证用途
  public notarizationPurpose: string;
  // 公证事项
  public notarizationMatter: string;
  // 使用地
  public place: string;
  // 公证员
  public notary: string;
  // 状态
  public state: string;
  // 落款时间
  public settlingTime: string;
  // 正文内容(证词)
  public textContent: string;
  // 笔录文本
  public recordText: string;

}
