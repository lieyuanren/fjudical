/**
 * @author:tangzhicheng
 * @Date :2019-12-23
 * @Verison :1.0
 * @Content :公证书搜索对象
 */

export default class SearchData {
  // 公证处
  public notarialOffice: string;
  // 当事人
  public party: string;
  // 公证编号
  public notarizationId: string;
  // 证件号码
  public certificatesId: string;
}

