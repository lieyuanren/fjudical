/**
 * @Author : yeqinhua
 * @Date : 2019-06-25
 * @Version : 1.0
 * @Content : demo
 */

export default class Demo {
  public id: number;
}
