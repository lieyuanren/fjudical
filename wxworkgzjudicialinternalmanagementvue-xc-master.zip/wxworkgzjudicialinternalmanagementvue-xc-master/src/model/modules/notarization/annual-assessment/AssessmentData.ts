/**
 * @author：tangzhicheng
 * @Date :2019-12-24
 * @Content : 年度考核列表数据对象
 */


export default class AssesmentData {
  // 人员名称
  public name: string;
  // 所属机构
  public belongOrgan: string;
  // 考核时间
  public assessTime: string;
  // 评估状态
  public state: number;
  // 评分
  public grade: string;
  // 年度
  public assessYear: string;
  // 类别
  public type: string;
}
