/**
 * @author : chenchunfei
 * @date : 2019/12/26 10:36
 * @version : 1.0
 * @content : 考核参数
 */
export default class AssessParam {
  // 年度
  public assessYear: string;
  // 机构
  public belongOrganCode: string;
  // 评分
  public grade: string;
  // 名称
  public name: string;
  // 状态
  public state: string;
  // 类别
  public type: any;
}
