/**
 * @author :tangzhicheng
 * @Date ：2019-12-27
 * @Content :数据统计展示卡 数据对象
 */

interface Param {
  label: string;
  value: string;
}

export default class PersonnelCardData {
  // 标题
  public title: string;
  // 参数对象
  public paramData: Param[];
}

