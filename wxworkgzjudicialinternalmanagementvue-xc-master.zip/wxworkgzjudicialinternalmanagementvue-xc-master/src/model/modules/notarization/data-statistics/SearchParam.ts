/**
 * @author:tangzhicheng
 * @Date :2019-12-27
 * @Content ：数据统计查询参数对象
 */

export default class SearchParam {
  public situation: string;
  public condition: string;
  public timer: string;
}

