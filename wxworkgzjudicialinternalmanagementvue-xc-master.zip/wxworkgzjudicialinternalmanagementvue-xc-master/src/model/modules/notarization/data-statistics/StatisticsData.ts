/**
 * @author :tangzhicheng
 * @Date :2019-12-27
 * @Content :数据统计列表数据
 */

export default class StatisticsData {
  public index: number;
  public typeName: string;
  public count: number;
  public whole?: number;
}

