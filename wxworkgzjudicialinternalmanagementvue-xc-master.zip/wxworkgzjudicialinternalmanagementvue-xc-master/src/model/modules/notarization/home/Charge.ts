/**
 * @Author : tangzhicheng
 * @Date : 2019-12-20
 * @Version : 1.0
 * @Content : charge 收费情况数据
 */

export default class Charge {
  // 标题
  public title: string;
  // 当月
  public sameMonth: number;
  // 年累计
  public annualCumulative: number;
  // 去年同期
  public lastYear: number;
  // 对比
  public contrast: number|string;
}
