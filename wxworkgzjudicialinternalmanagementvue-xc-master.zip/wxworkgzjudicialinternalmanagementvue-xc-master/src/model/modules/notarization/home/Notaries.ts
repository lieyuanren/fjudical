/**
 * @Author : tangzhicheng
 * @Date : 2019-12-20
 * @Version : 1.0
 * @Content : Notaries 全市公证员情况数据
 */

export default class Notaries {
  // 标题
  public title: string;
  // 在编
  public inEditing: number;
  // 非编
  public nonEditing: number;
  // 小计
  public subtotal: number;
  // 环形图数据
  public viewData: any[] = [];
}


