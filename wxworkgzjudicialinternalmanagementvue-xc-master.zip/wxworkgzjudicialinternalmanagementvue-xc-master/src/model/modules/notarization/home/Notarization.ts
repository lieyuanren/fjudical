/**
 * @Author : tangzhicheng
 * @Date : 2019-12-20
 * @Version : 1.0
 * @Content : notarizationData 公证情况数据
 */

export default class Notarization {
  // 公证类型
  public notarizationType: string;
  // 当月
  public sameMonth: number;
  // 累计
  public cumulative: number;
  // 当月占比
  public monthProportion?: string|number;
  // 累计占比
  public cumulativeProportion?: string|number;
}

// 暂存问题：抛出的数据结构在其他文件中没有起到结构限制效果
