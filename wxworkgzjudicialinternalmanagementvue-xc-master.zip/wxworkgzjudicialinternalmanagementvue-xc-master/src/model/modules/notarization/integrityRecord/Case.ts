/**
 * @Author : chenchunfei
 * @Date : 2019-12-19
 * @Version : 1.0
 * @Content :
 */

export default class DetailInfo {
  // 年份
  public year: string;
  // 评分
  public grade: string;
  // 内容
  public content: string;
}
