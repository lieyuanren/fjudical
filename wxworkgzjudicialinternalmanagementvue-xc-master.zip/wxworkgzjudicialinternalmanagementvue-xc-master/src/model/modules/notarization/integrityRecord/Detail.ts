/**
 * @Author : chenchunfei
 * @Date : 2019-12-19
 * @Version : 1.0
 * @Content :
 */

export default class DetailInfo {
  // 标题
  public title: string;
  // 图片
  public imgUrl: string;
  // 简介
  public intro: string;
}
