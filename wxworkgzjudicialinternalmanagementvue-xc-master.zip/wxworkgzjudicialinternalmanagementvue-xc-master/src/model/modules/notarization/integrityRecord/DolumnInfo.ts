/**
 * @Author : chenchunfei
 * @Date : 2019-12-19
 * @Version : 1.0
 * @Content :
 */

export default class DolumnInfo {
  // 标签
  public label: string;
  // 值
  public value: string;
}
