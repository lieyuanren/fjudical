/**
 * @Author : chenchunfei
 * @Date : 2019-12-19
 * @Version : 1.0
 * @Content :
 */

export default class IntegrityRecord {
  // 名称
  public name: string;
  // 机制
  public position: string;
  // 机构
  public institution: string;
  // 电话
  public phone: string;
  // 头像
  public headImg: string;
  // 级别
  public level: string;
  // 编码
  public code: string;

}
