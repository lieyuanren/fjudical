/**
 * @Author : chenchunfei
 * @Date : 2019-12-19
 * @Version : 1.0
 * @Content :
 */

export default class MenuData {
  // 名称
  public name: string;
  // 图标
  public icon: string;
  // 跳转途径
  public toUrl: string;
  // 类别
  public type?: string;
}
