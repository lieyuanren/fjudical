/**
 * @Author: tangzhicheng
 * @Date: 2021-03-30 10:00:02
 * @LastEditors: tangzhicheng
 * @LastEditTime: 2021-03-30 10:01:03
 * @Description: file content
 */


export interface PersonItem {
  id: number;
  name: string;
  checked: boolean;
}
