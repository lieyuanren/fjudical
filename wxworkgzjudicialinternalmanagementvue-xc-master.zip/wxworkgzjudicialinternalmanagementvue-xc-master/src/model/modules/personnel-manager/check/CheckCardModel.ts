/**
 * @author :tangzhicheng
 * @Date :2020-1-3
 * @Content :case案件卡数据对象
 */
export default class CheckCardModel {
  public id?: string = '';
  // 姓名
  public name: string = '';
  // 出生年月
  public birthday: string = '';
  // 职位
  public PriorWorkUnit: string = '';
  // 工作时间
  public workTime: string = '';
  // 考核年度
  public year: string = '';
  // 考核季度
  public quarter: string = '';
  // 考核结果
  public constructionName: string = '';
  // 考核分数
  public performance: string = '';
  // 头像
  public photo: string = '';
  // 考核登記表路徑
  public registrationform: string = '';
}
