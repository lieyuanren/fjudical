/**
 * @author :tangzhicheng
 * @Date :2020-1-3
 * @Content : HomeCard组件的数据对象
 */


export default class HomeCardModel {
  // 数据值
  public data: string = '';
  // 属性
  public prop: string = '';
  // 图片地址
  public imgUrl: string = '';
  // 跳转路由
  public route: string = '';
}
