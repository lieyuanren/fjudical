/**
 * @author :李景恒
 * @Date : 2020-16
 * @Content : 鉴定人展示卡数据对象
 */

export default class Family {
  // 名字
  public name?: string = '';
  // 称谓
  public title?: string = '';
  // 政治面貌
  public politicsStatusName?: string = '';
  // 出生年月
  public birthday?: string = '';
// 工作单位及职务简称
  public units?: string = '';
}
