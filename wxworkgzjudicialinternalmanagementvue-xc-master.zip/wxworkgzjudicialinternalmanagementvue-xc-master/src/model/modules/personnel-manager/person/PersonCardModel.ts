/**
 * @author :tangzhicheng
 * @Date : 2020-16
 * @Content : 鉴定人展示卡数据对象
 */

export default class PersonCardModel {
  // 人员id
  public id?: string = '';
  // 姓名
  public name?: string = '';
  // 所在机构
  public position?: string = '';
  // 鉴定类别
  public birthDate?: string = '';
  // 照片
  public imgUrl?: string = '';
}


