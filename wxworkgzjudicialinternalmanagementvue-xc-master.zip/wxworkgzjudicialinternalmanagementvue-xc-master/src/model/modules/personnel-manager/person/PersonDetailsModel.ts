/**
 * @author :tangzhicheng
 * @date :2020-1-17
 * @Content :鉴定人详情 数据对象
 */

export default class PersonDetailsModel {
  //  名字
  public name?: string = '';
  // 性别
  public sex?: string = '';
  // 状态
  public state?: string = '';

  // 所属机构
  public mechanism?: string = '';
  // 执业证号
  public certificateNumber?: string = '';
  // 鉴定类别
  public category?: string = '';
  // 有效期
  public validity?: string = '';
  // 身份号码
  public idCard?: string = '';
  // 执业方式
  public practiceWay?: string = '';
  // 专业技术职务
  public duty?: string = '';
  // 职称等级
  public title?: string = '';
  // 手机号码
  public phoneNumber?: string = '';
  // 通讯地址
  public address?: string = '';
  // 信用信息
  public creditList?: number[] = [];
}
