/**
 * @author :李景恒
 * @Date : 2020-16
 * @Content : 鉴定人展示卡数据对象
 */

export default class  RewardAndPunish {
  // 名字
  public name: string = '';
  // 批准机构
  public officeName: string = '';
  // 批准时间
  public approvalTime: string = '';
  // 结束时间
  public endTime: string = '';
}
