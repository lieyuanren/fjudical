/**
 * @author :tangzhicheng
 * @Date : 2020-16
 * @Content : 鉴定人展示卡数据对象
 */

export default class TrainCardModel {
  // 姓名
  public name: string = '';
  // 培训类型
  public type: string = '';
  // 培训年度
  public year: string = '';
}
