/**
 * @Author : 廖天正
 * @Date : 2019-12-20
 * @Version : 1.0
 * @Content : 进度
 */

export default class Job {
  public id: number;

  public title: string;

  public time: number;
}
