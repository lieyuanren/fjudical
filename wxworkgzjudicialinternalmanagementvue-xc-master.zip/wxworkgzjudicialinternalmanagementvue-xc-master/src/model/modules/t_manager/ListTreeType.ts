/**
 * @author : tangzhicheng
 * @Date ；2020-2-25
 * @Content ；列表选择树数据类型
 */

export default class ListTreeType {
  public id: string = '';
  public name: string = '';
  public label: string = '';
  public icon: string = 'fa';
  public isChecked?: boolean = false;
  public isOpen?: boolean = true;
  public text: string = '';
  public selected?: boolean = false;
  public opened?: boolean = false;
  public children?: ListTreeType[];
}
