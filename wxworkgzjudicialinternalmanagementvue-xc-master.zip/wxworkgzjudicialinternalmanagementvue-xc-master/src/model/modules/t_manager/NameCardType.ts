/**
 * @author : tangzhicheng
 * @Date : 2020-2-25
 * @Content : 名字卡组件数据类型
 */

export default class NameCardType {
  public id: string;
  public name: string;
}
