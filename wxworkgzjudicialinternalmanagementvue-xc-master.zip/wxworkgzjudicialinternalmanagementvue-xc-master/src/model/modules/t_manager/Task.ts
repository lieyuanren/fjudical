/**
 * @Author : 廖天正
 * @Date : 2019-12-20
 * @Version : 1.0
 * @Content : 任务
 */

export default class Task {
  // 来源
  public taskFrom: string;
  // 任务名
  public taskTitle: string;
  // 描述
  public taskDesc: string;
  // 级别
  public taskLevel: string;
  // 类型
  public taskType: string;
  // 开始时间
  public createTime: number;
  // 计划开始时间
  public beginDate: number;
  // 计划结束时间
  public endDate: number;
  // 知否需要延长
  public isAcceptance: string = '1';
  // 预警天数
  public aewDay: number = 0;
  //  承办单位
  public orginizer: string;
  // 预警天数
  public taskState: string = '1';
  // 排序
  public orderSort: number = new Date().getTime();
  // 有效标识
  public validFlag: string = '1';
  // 反馈
  public feedbackFre: string = 'n';
  // 分管领导
  public leaderIds: string[];
  // 承办人员
  public undertakePersons: string[];
  // 接受人员
  public acceptPersons: string[];

  public jobs: any[];
}

