/**
 * @author :tangzhicheng
 * @Date :2020-02-27
 * @Content :任务列表项 数据类型
 */
interface Options {
  label: string;
  value: string;
}

export default class TaskCardType {
  // 任务标题
  public title: string = '';
  // 当前任务状态
  public state: string = '';
  // 属性列表
  public list: Options[] = [];
  // 任务id
  public taskId: string = '';
}
