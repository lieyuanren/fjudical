/**
 * @Author : 廖天正
 * @Date : 2019-12-20
 * @Version : 1.0
 * @Content : 任务
 */
import Job from '@/model/modules/t_manager/Job';

export default class TaskInfo {
  // 任务名
  public taskName: string;
  // 描述
  public taskDesc: string;
  // 级别
  public taskLevel: string;
  // 类型
  public taskType: string;
  // 创办人
  public taskCreator: string;
  // 开始时间
  public createTime: string;
  // 计划开始时间
  public startTime: string;
  // 计划结束时间
  public endTime: string;
  // 剩余时间
  public surplus: string;
  // 剩余时间
  public finish: string;
  // 建议
  public advise: TaskRecord[];

  public progress: TaskRecord[];

  public jobs: Job[];
}

interface TaskRecord {
  // 用户
  user: string;
  createTime: string;
  taskRecordContent: string;
}

