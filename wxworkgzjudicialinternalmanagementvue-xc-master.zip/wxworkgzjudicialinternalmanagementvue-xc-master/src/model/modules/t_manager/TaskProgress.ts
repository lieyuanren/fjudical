/**
 * @Author : 廖天正
 * @Date : 2019-12-20
 * @Version : 1.0
 * @Content : 进度
 */

export default class TaskProgress {
  // 任务名
  public taskId: string;
  // 描述
  public content: string;
  // 级别
  public type: number;
}
