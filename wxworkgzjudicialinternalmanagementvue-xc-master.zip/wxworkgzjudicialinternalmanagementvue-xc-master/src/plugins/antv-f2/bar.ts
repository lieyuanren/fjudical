/**
 * @Author       : tangzhicheng
 * @Date         : 2020-03-09 09:17:18
 * @LastEditors  : tangzhicheng
 * @LastEditTime : 2020-03-13 14:40:22
 * @Description  : file content
 */


// @ts-ignore
import F2 from '@antv/f2/lib/index-all';

/**
 * @param data：f2条形图渲染所需要的数据
 */

export default function bar(data: any, id: string = 'myChart') {
  const chart = new F2.Chart({
    id,
    pixelRatio: window.devicePixelRatio,
    padding: 'auto'
  });
  chart.source(data, {
    sales: {
      tickCount: 5
    }
  });
  chart.tooltip({
    showItemMarker: false,
    onShow: function onShow(ev: any) {
      const items = ev.items;
      items[0].name = null;
      items[0].name = items[0].title;
      items[0].value = ' ' + items[0].value;
    }
  });
  chart.interval().position('mechanism*sales');
  chart.render();
}
