/**
 * @author : tangzhicheng
 * @Date : 2020-03-06
 * @Content : 层叠柱状图绘制函数
 */

// @ts-ignore
import F2 from '@antv/f2/lib/index-all';
import BarRowType from '@/model/common/f2/BarRowType';


export default function barRow(data: BarRowType[], id: string = 'myChart') {

    const chart: any = new F2.Chart({
        id,
        pixelRatio: window.devicePixelRatio
    });
    chart.source(data, {
        num: {
            tickCount: 5
        }
    });
    chart.coord({
        transposed: true
    });
    chart.tooltip({
        custom: true, // 自定义 tooltip 内容框
        onChange: function onChange(obj: any) {
            const legend = chart.get('legendController').legends.top[0];
            const tooltipItems = obj.items;
            const legendItems = legend.items;
            const map = {} as any;
            legendItems.forEach((item: any) => {
                map[item.name] = _.clone(item);
            });
            tooltipItems.forEach((item: any) => {
                const name = item.name;
                const value = item.value;
                if (map[name]) {
                    map[name].value = value;
                }
            });
            legend.setItems(_.values(map));
        },
        onHide: function onHide() {
            const legend = chart.get('legendController').legends.top[0];
            legend.setItems(chart.getLegendItems().country);
        }
    });
    chart.interval()
        .position('type*num')
        .color('name')
        .adjust('stack');
    chart.render();

}
