/**
 * @author :tanzhicheng
 * @Date ； 2020-03-06
 * @Content : 直线图绘制函数
 */

// @ts-ignore
import F2 from '@antv/f2/lib/index-all';
import BorkenLine from '@/model/common/f2/BrokenLineType';

/**
 * @param data：f2折线图渲染所需要的数据
 */

export default function borkenLine(id: string, data: BorkenLine[]) {
    const chart = new F2.Chart({
        id,
        pixelRatio: window.devicePixelRatio
    });

    chart.source(data, {
        value: {
            tickCount: 5,
            min: 0
        },
        xAxis: {
            range: [0, 1],
            tickCount: 6
        }
    });
    chart.tooltip({
        custom: true,
        showXTip: true,
        showYTip: true,
        snap: true,
        crosshairsType: 'xy',
        crosshairsStyle: {
            lineDash: [2]
        }
    });
    chart.axis('xAxis', {
        label: function label(text: string, index: number, total: number) {
            const textCfg = {} as any;
            if (index === 0) {
                textCfg.textAlign = 'left';
            } else if (index === total - 1) {
                textCfg.textAlign = 'right';
            }
            return textCfg;
        }
    });
    chart.line().position('xAxis*value');
    chart.render();
}
