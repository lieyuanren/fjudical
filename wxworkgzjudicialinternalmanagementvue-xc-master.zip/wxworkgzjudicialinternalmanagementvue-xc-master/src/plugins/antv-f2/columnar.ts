/**
 * @author :tangzhicheng
 * @Date ；2020-2-12
 * @Content :f2柱状图绘制函数
 */

// @ts-ignore
import F2 from '@antv/f2/lib/index-all';
// @ts-ignore
import _ from 'lodash';

/**
 * @param data：f2柱状图渲染所需要的数据
 */

export default function columnar(data: any, id: string = 'container') {
  const chart: any = new F2.Chart({
    id,
    pixelRatio: window.devicePixelRatio
  });
  chart.source(data);
  chart.tooltip({
    custom: true, // 自定义 tooltip 内容框
    onChange: function onChange(obj: any) {
      const legend = chart.get('legendController').legends.top[0];
      const tooltipItems = obj.items;
      const legendItems = legend.items;
      const map: any = {};
      legendItems.forEach((item: any) => {
        map[item.name] = _.clone(item);
      });
      tooltipItems.forEach((item: any) => {
        const name = item.name;
        const value = item.value;
        if (map[name]) {
          map[name].value = value;
        }
      });
      legend.setItems(_.values(map));
    },
    onHide: function onHide() {
      const legend = chart.get('legendController').legends.top[0];
      legend.setItems(chart.getLegendItems().country);
    }
  });

  chart
    .interval()
    .position('type*count')
    .color('name')
    .adjust({
      type: 'dodge',
      marginRatio: 0.05 // 设置分组间柱子的间距
    });
  chart.render();
}
