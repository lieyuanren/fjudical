/**
 * @Author : tangzhicheng
 * @Date : 2019-12-22
 * @Content : antv/f2 环形图组件渲染函数的封装
 */

//  这里f2组件库的全部引入，后期可以考虑按需引入

// @ts-ignore
import F2 from '@antv/f2/lib/index-all';


function GetPercent(num: any, total: any) {
  /// <summary>
  /// 求百分比
  /// </summary>
  /// <param name="num">当前数</param>
  /// <param name="total">总数</param>
  num = parseFloat(num);
  total = parseFloat(total);
  if (isNaN(num) || isNaN(total)) {
    return '-';
  }
  return total <= 0 ? '0%' : (Math.round(num / total * 10000) / 100.00) + '%';
}
/**
 * @param data：f2环形图渲染所需要的数据 { const:'const',typs:<String>,num:<Number> }
 * @param colorList:根据业务需求定制的颜色数组
 */

export default function antvF2(data: any, colorList: any) {
  let sum = 0;
  if (data instanceof Array) {
    for (let item of data) {
      sum += item.num;
    }
    for (let item of data) {
      item.p = GetPercent(item.num, sum);
    }
  }
  const chart = new F2.Chart({
    id: 'myChart2',
    pixelRatio: window.devicePixelRatio
  });
  chart.source(data);
  chart.coord('polar', {
    transposed: true,
    radius: 0.8,
    innerRadius: 0.5
  });
  chart.axis(false);
  chart.legend(false);
  chart.tooltip(false);
  chart.guide().html({
    position: ['50%', '50%'],
    html:
      '<div style="text-align: center;width:150px;height: 50px;">\n      <p style="font-size: 12px;color: #999;margin: 0" id="title"></p>\n      <p style="font-size: 18px;color: #343434;margin: 0;font-weight: bold;" id="money"></p>\n      </div>'
  });
  chart
    .interval()
    .position('const*num')
    .adjust('stack')
    .color('type', colorList);
  chart.pieLabel({
    sidePadding: 30,
    activeShape: true,
    label1: function label1(data: any) {
      return {
        text:  data.p,
        fill: '#343434',
        fontWeight: 'bold'
      };
    },
    label2: function label2(data: any) {
      return {
        text: data.type === '五' ? '未评' : data.type,
        fill: '#999'
      };
    }
  });
  chart.render();
}
