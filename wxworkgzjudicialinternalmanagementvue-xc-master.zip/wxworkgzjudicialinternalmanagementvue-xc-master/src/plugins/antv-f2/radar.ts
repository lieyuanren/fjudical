/**
 * @author :tangzhicheng
 * @date :2020-3-11
 * @Content :数据分析 雷达图
 */

// @ts-ignore
import F2 from '@antv/f2/lib/index-all';
import RadarType from '@/model/common/f2/RadarType';

export default function radar(id: string, data: RadarType[]) {
    const chart: any = new F2.Chart({
        id,
        pixelRatio: window.devicePixelRatio
    });

    chart.coord('polar');
    chart.source(data, {
        score: {
            min: 0,
            nice: false,
            tickCount: 4
        }
    });
    chart.tooltip({
        custom: true, // 自定义 tooltip 内容框
        onChange: function onChange(obj: any) {
            const legend = chart.get('legendController').legends.top[0];
            const tooltipItems = obj.items;
            const legendItems = legend.items;
            const map = {} as any;
            legendItems.forEach((item: any) => {
                map[item.name] = _.clone(item);
            });
            tooltipItems.forEach((item: any) => {
                const name = item.name;
                const value = item.value;
                if (map[name]) {
                    map[name].value = value;
                }
            });
            legend.setItems(_.values(map));
        },
        onHide: function onHide() {
            const legend = chart.get('legendController').legends.top[0];
            legend.setItems(chart.getLegendItems().country);
        }
    });
    chart.axis('value', {
        label: function label(text: any, index: any, total: any) {
            if (index === total - 1) {
                return null;
            }
            return {
                top: true
            };
        },
        line: {
            top: false
        }
    });
    chart.area().position('type*value').color('name')
        .animate({
            appear: {
                animation: 'groupWaveIn'
            }
        });
    chart.line().position('type*value').color('name')
        .animate({
            appear: {
                animation: 'groupWaveIn'
            }
        });
    chart.point().position('type*value').color('name')
        .style({
            stroke: '#fff',
            lineWidth: 1
        })
        .animate({
            appear: {
                delay: 300
            }
        });

    chart.render();


}
