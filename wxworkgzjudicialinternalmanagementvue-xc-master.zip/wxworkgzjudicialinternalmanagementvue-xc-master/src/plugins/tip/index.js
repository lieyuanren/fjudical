/**
 * @Author : ChangJun
 * @Date : 2019-09-03
 * @Version : 1.0
 * @Content : toast 轻提示
 */
import TipDom from './index.vue';
import Common from '../../utils/common/common';

let $vm;
export default {
  install (Vue, options) {
    const Tip = Vue.extend(TipDom);
    if (!$vm) {
      $vm = new Tip({
        el: document.createElement('div')
      });
      document.body.appendChild($vm.$el);
    }
    const tip = {
      // 隐藏
      hide () {
        Common.removeClass($vm.$el, ['fadeInUp']);
        Common.addClass($vm.$el, ['animated', 'fadeOutUp']);
        // 500ms 后删除动画样式
        setTimeout(() => {
          $vm.show = false;
          Common.removeClass($vm.$el, ['animated', 'fadeOutUp']);
        }, 500);
      },
      // 显示
      show (option) {
        if (!$vm.show) {
          $vm.text = typeof option === 'string' ? option : option.text;
          // 计算提示框的宽度
          let _w = $vm.text.length * 14 + 12;
          // 判断长度是否 > body 的80%
          const BW = document.body.offsetWidth * .8;
          if (_w > BW) {
            $vm.$el.style.width = `${ BW }px`;
            _w = BW;
          }
          $vm.$el.style.left = `calc((100% - ${ _w }px) / 2)`;
          Common.addClass($vm.$el, ['animated', 'fadeInUp']);
          $vm.show = true;
          // 自动关闭
          setTimeout(() => {
            this.hide();
          }, option.duration || 2000);
        }
      }
    };
    if (!Vue.$tip) {
      Vue.$tip = {
        ...tip
      };
    } else {
      Vue.$tip = tip;
    }
    Vue.mixin({
      created: function () {
        this.$tip = Vue.$tip;
      }
    });
  }
};
