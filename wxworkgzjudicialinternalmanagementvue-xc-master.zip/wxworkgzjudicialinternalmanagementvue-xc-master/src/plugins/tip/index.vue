<template>
  <div class="tip-box" v-show="show">{{ text }}
    <div class="mask"></div>
  </div>
</template>

<script>
export default {
  name: 'TipPlugin',
  data () {
    return {
      show: false,
      text: ''
    };
  }
};
</script>

<style lang="less" scoped>
.tip-box {
  position: absolute;
  top: 70%;
  background-color: rgba(0, 0, 0, 0.6);
  color: #fff;
  padding: 8PX 12PX;
  box-sizing: border-box;
  font-size: 14PX;
  border-radius: 6px;
  text-align: center;
  overflow: hidden;
  .mask {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(255, 255, 255, 0);
  }
}

.animated {
  -webkit-animation-duration: .4s;
  animation-duration: .4s;
  -webkit-animation-fill-mode: both;
  animation-fill-mode: both;
}

@keyframes fadeInUp {
  from {
    opacity: 0;
    -webkit-transform: translate3d(0, 100%, 0);
    transform: translate3d(0, 100%, 0);
  }

  to {
    opacity: 1;
    -webkit-transform: translate3d(0, 0, 0);
    transform: translate3d(0, 0, 0);
  }
}

.fadeInUp {
  -webkit-animation-name: fadeInUp;
  animation-name: fadeInUp;
}

@keyframes fadeOutUp {
  from {
    opacity: 1;
  }

  to {
    opacity: 0;
    -webkit-transform: translate3d(0, -100%, 0);
    transform: translate3d(0, -100%, 0);
  }
}

.fadeOutUp {
  -webkit-animation-name: fadeOutUp;
  animation-name: fadeOutUp;
}
</style>
