/**
 * @Author : tangzhicheng
 * @Date : 2019-12-23
 * @Version : 1.0
 * @Content :vant组件的引入抽离
 */
import Vue from 'vue';
import {
  Button,
  Dialog,
  Toast,
  CellGroup,
  Cell,
  PullRefresh,
  List,
  Card,
  Icon,
  Search,
  DropdownMenu,
  DropdownItem,
  Collapse,
  CollapseItem,
  Panel
} from 'vant';
import {
  Field
} from 'vant';
import {
  Tag
} from 'vant';
import {
  Row,
  Col
} from 'vant';
import {
  Popup
} from 'vant';
import {
  Picker
} from 'vant';
import {
  DatetimePicker
} from 'vant';
import {
  Tabbar,
  TabbarItem
} from 'vant';
import {
  Circle
} from 'vant';
import {
  Progress
} from 'vant';
import {
  Image
} from 'vant';
import { Checkbox, CheckboxGroup } from 'vant';
import { Swipe, SwipeItem } from 'vant';
import { Step, Steps } from 'vant';
import { RadioGroup, Radio } from 'vant';
import { Tab, Tabs } from 'vant';
import { Uploader } from 'vant';
import { Switch } from 'vant';
import { Divider } from 'vant';
import { Skeleton } from 'vant';
import { TreeSelect } from 'vant';

Vue.use(Skeleton);
Vue.use(Divider);
Vue.use(Switch);
Vue.use(Uploader);
Vue.use(Tab);
Vue.use(Tabs);
Vue.use(Radio);
Vue.use(RadioGroup);
Vue.use(Step);
Vue.use(Steps);
Vue.use(Swipe);
Vue.use(SwipeItem);
Vue.use(Checkbox);
Vue.use(CheckboxGroup);
Vue.use(Image);
Vue.use(Progress);
Vue.use(Circle);
Vue.use(Tabbar).use(TabbarItem);

Vue.use(DatetimePicker);
Vue.use(Picker);
Vue.use(Popup);
Vue.use(Row).use(Col);
Vue.use(Tag);
Vue.use(Button)
  .use(Dialog)
  .use(Toast)
  .use(CellGroup)
  .use(Cell)
  .use(List)
  .use(Card)
  .use(Icon)
  .use(Search)
  .use(DropdownMenu)
  .use(DropdownItem)
  .use(Collapse)
  .use(CollapseItem)
  .use(Panel)
  .use(PullRefresh)
  .use(Field)
  .use(TreeSelect);
Dialog.setDefaultOptions({
  confirmButtonColor: '#1989fa',
  confirmButtonText: '确定'
});