/**
 * @Author: tangzhicheng
 * @Date: 2020-03-12 15:31:55
 * @LastEditors: tangzhicheng
 * @LastEditTime: 2021-03-24 10:36:24
 * @Description: file content
 */
import Vue from 'vue';
import Router, { RouteConfig } from 'vue-router';
import CommonUtil from '../utils/common/common';
import LocalStorageUtil from '../utils/common/local-storage';
import useDemo from './modules/use-demo'; // 框架使用 demo 路由
import car from './modules/car-manager'; // 停车管理
import notarization from './modules/notarization'; // 公证
import judicialExpertise from './modules/judicial-expertise'; // 司法鉴定
import legalAid from './modules/legal-aid'; // 法律援助
import mediation from './modules/mediation'; // 调解
import tmanager from './modules/tmanager'; // 任务管理
import baseService from './modules/baseservice'; // 任务管理
import internalControl from './modules/internal-control'; // 内控管理
import attendanceMange from './modules/attendance-manage'; // 考勤管理
import personnelManager from './modules/personnel-manager'; // 人事考核
import patrolManage from './modules/patrol-manage'; // 巡更系统
import accessMange from './modules/access-manager'; // 门禁系统
import policeCar from './modules/police-car'; // 警务用车系统
import oa from './modules/oa'; // OA办公系统

Vue.use(Router);
const IMPORT = (file: string) => (resolve: any) =>
  require([`@/views/${file}.vue`], resolve);

// 动态获取项目路由
const currentRouters = () => {
  // 清除缓存
  // LocalStorageUtil.clear('CurrentRouters');
  // LocalStorageUtil.clear('CurrentDestination');
  // 当前项目名称
  let target = CommonUtil.getParam('target');
  // 当前项目路由
  // let routers: RouteConfig[] = [];
  if (!target) {
    target = LocalStorageUtil.get('CurrentRouters');
  }
  if (target) {
    target!!.trim();
  }

  console.log('--------target-------', target);
  if (target === 'mediation') {
    // 调解
    setRouterData(target!!, mediation);
    router.addRoutes(mediation);
  } else {
    // 混合项目
    router.addRoutes(car);
    router.addRoutes(notarization);
    router.addRoutes(judicialExpertise);
    router.addRoutes(legalAid);
    router.addRoutes(tmanager);
    router.addRoutes(baseService);
    router.addRoutes(internalControl);
    router.addRoutes(attendanceMange);
    router.addRoutes(personnelManager);
    router.addRoutes(patrolManage);
    router.addRoutes(accessMange);
    router.addRoutes(policeCar);
    router.addRoutes(oa);
  }
  console.log('--------router-------', router);
};

function setRouterData(target: string, routers: RouteConfig[]) {
  LocalStorageUtil.set('CurrentRouters', target);
  LocalStorageUtil.set(
    'CurrentDestination',
    routers.length > 0 && routers[0].path
  );
}

export const router = new Router({
  mode: 'history',
  base: process.env.BASE_URL,
  routes: [
    {
      path: '*',
      redirect: '/notfound',
    },
    {
      path: '/',
      redirect: '/home',
    },
    {
      path: '/home',
      name: 'Home',
      component: IMPORT('Home'),
      meta: { pageCode: 1 },
    },
    {
      path: '/login',
      name: 'Login',
      component: IMPORT('Login'),
      meta: { pageCode: 2 },
    },
    {
      path: '/notfound',
      name: 'NotFound',
      component: IMPORT('NotFound'),
      meta: { pageCode: 3 },
    },
    {
      path: '/h5',
      name: 'H5',
      component: IMPORT('H5'),
      meta: { pageCode: 4 },
    },
  ] as RouteConfig[],
});
router.addRoutes(useDemo);
// 根据项目导入路由
currentRouters();
