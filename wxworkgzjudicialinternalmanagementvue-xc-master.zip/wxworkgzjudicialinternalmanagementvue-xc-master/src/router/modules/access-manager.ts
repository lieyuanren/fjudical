/**
 * @Author: 陈毛毛
 * @Date: 2021-03-23 10:14:40
 * @LastEditors: 陈毛毛
 * @LastEditTime: 2021-03-24 11:51:39
 * @Description: file content
 */
 import { RouteConfig } from 'vue-router';
 const IMPORT = (file: string) => (resolve: any) => require([`@/views/modules/${file}.vue`], resolve);

 export default [
     {
         path: '/accessManage',
         name: '首页',
         component: IMPORT('access-manager/index'),
         meta: { pageCode: 10 }
     },
     {
        path: '/accessDetail',
        name: ' 详情',
        component: IMPORT('access-manager/data/detail/index'),
        meta: { pageCode: 10 }
    }
 ] as RouteConfig[];
