/**
 * @Author: lilili
 * @Date: 2020-07-17 16:15:00
 * @LastEditors: lilili
 * @LastEditTime: 2020-07-17 16:15:00
 * @Description: file content
 */
import { RouteConfig } from 'vue-router';
const IMPORT = (file: string) => (resolve: any) => require([`@/views/modules/${file}.vue`], resolve);

export default [
    {
        path: '/attendanceManage',
        name: '首页',
        component: IMPORT('attendance-manage/index'),
        meta: { pageCode: 10 }
    },
    {
        path: '/attendanceDetail',
        name: '异常明细',
        component: IMPORT('attendance-manage/data/detail/index'),
        meta: { pageCode: 10 }
    }
] as RouteConfig[];
