import { RouteConfig } from 'vue-router';
const IMPORT = (file: string) => (resolve: any) => require([`@/views/modules/${file}.vue`], resolve);

export default [
    {
        path: '/baseservice',
        name: '基层法律服务',
        component: IMPORT('baseservice/index'),
        meta: { pageCode: 6 }
    }
] as RouteConfig[];
