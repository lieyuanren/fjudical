import { RouteConfig } from 'vue-router';

const IMPORT = (file: string) => (resolve: any) => require([`@/views/modules/${ file }.vue`], resolve);
export default [
  {
    path: '/car',
    name: '剩余车位',
    component: IMPORT('car-manager/index'),
    meta: { pageCode: 1 }
  },
  {
    path: '/register',
    name: '已登记车牌',
    component: IMPORT('car-manager/register-car/index'),
    meta: { pageCode: 1 }
  },
  {
    path: '/modify',
    name: '车辆编辑',
    component: IMPORT('car-manager/modify-car/index'),
    meta: { pageCode: 1 }
  },
  {
    path: '/add',
    name: '车辆添加',
    component: IMPORT('car-manager/add-car/index'),
    meta: { pageCode: 1 }
  }
] as RouteConfig[];
