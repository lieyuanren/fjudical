/**
 * @Author: tangzhicheng
 * @Date: 2020-03-16 09:34:09
 * @LastEditors: tangzhicheng
 * @LastEditTime: 2020-03-16 16:12:09
 * @Description: file content
 */

import { RouteConfig } from 'vue-router';

const IMPORT = (file: string) => (resolve: any) => require([`@/views/modules/${file}.vue`], resolve);

export default [
    {
        path: '/internalControl',
        name: '内控管理',
        component: IMPORT('internal-control/index'),
        meta: { pageCode: 9 }
    },
    {
        path: '/projectDeclaration',
        name: '建设项目申报',
        component: IMPORT('internal-control/control/project-declaration/index'),
        meta: { pageCode: 9 }
    },
    {
        path: '/details',
        name: '详情',
        component: IMPORT('internal-control/control/details/index'),
        meta: { pageCode: 9 }
    }
] as RouteConfig[];
