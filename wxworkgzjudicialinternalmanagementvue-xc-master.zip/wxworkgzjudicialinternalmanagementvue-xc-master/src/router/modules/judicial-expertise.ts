import { RouteConfig } from 'vue-router';

const IMPORT = (file: string) => (resolve: any) => require([`@/views/modules/${file}.vue`], resolve);
export default [
    {
        path: '/judicialExpertise',
        name: '司法鉴定',
        component: IMPORT('judicial-expertise/index'),
        meta: { pageCode: 6 }
    },
    {
        path: '/caseDetails',
        name: '详情',
        component: IMPORT('judicial-expertise/case/case-details/index'),
        meta: { pageCode: 6 }
    },
    {
        path: '/institutionDetails',
        name: '详情',
        component: IMPORT('judicial-expertise/appraisal-institution/institution-details/index'),
        meta: { pageCode: 6 }
    },
    {
        path: '/moreInfo',
        name: '详情',
        component: IMPORT('judicial-expertise/appraisal-institution/more-info/index'),
        meta: { pageCode: 6 }
    },
    {
        path: '/appraiserDetails',
        name: '详情',
        component: IMPORT('judicial-expertise/appraiser/appraiser-details/index'),
        meta: { pageCode: 6 }
    }
] as RouteConfig[];
