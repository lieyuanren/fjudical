import { RouteConfig } from 'vue-router';
const IMPORT = (file: string) => (resolve: any) => require([`@/views/modules/${file}.vue`], resolve);

export default [
    {
        path: '/legalAid',
        name: '法律援助',
        component: IMPORT('legal-aid/index'),
        meta: { pageCode: 6 }
    }
] as RouteConfig[];
