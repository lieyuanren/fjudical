import { RouteConfig } from 'vue-router';
const IMPORT = (file: string) => (resolve: any) => require([`@/views/modules/${file}.vue`], resolve);

export default [
    {
        path: '/mediation',
        name: '人民调解',
        component: IMPORT('mediation/index'),
        meta: { pageCode: 6 }
    },
    {
        path: '/details',
        name: '案件详情',
        component: IMPORT('mediation/case_manager/details/index'),
        meta: { pageCode: 6 }
    },
    {
        path: '/mechanismInfo',
        name: '机构信息',
        component: IMPORT('mediation/mechanismer/mechanism_info/index'),
        meta: { pageCode: 6 }
    },
    {
        path: '/mediatorList',
        name: '调解员',
        component: IMPORT('mediation/mechanismer/mediator_list/index'),
        meta: { pageCode: 6 }
    },
    {
        path: '/caseHandle',
        name: '案件处理',
        component: IMPORT('mediation/case_manager/case_handle/index'),
        meta: { pageCode: 6 }
    },
    {
        path: '/addMediator',
        name: '新增调解员',
        component: IMPORT('mediation/mechanismer/add_mediator/index'),
        meta: { pageCode: 6 }
    },
    {
        path: '/disputeList',
        name: '纠纷排查',
        component: IMPORT('mediation/dispute/dispute_list/index'),
        meta: { pageCode: 6 }
    },
    {
        path: '/disputeDetails',
        name: '纠纷排查',
        component: IMPORT('mediation/dispute/dispute_details/index'),
        meta: { pageCode: 6 }
    },
    {
        path: '/dossier',
        name: '卷宗材料',
        component: IMPORT('mediation/case_manager/dossier/index'),
        meta: { pageCode: 6 }
    },
    {
        path: '/mediatorDetails',
        name: '调解员',
        component: IMPORT('mediation/mechanismer/mediator_details/index'),
        meta: { pageCode: 6 }
    },
    {
        path: '/mediatorUpdata',
        name: '修改调解员信息',
        component: IMPORT('mediation/mechanismer/mediator_updata/index'),
        meta: { pageCode: 6 }
    },
    {
        path: '/track',
        name: '案件跟踪',
        component: IMPORT('mediation/track/index'),
        meta: { pageCode: 6 }
    },
    {
        path: '/trackDetail',
        name: '案件跟踪',
        component: IMPORT('mediation/track/detail/index'),
        meta: { pageCode: 6 }
    }
] as RouteConfig[];
