import { RouteConfig } from 'vue-router';

const IMPORT = (file: string) => (resolve: any) => require([`@/views/${ file }.vue`], resolve);
export default [
  {
    path: '/module1',
    name: 'Demo1',
    component: IMPORT('modules/demo/index'),
    meta: { pageCode: 21 }
  }
] as RouteConfig[];
