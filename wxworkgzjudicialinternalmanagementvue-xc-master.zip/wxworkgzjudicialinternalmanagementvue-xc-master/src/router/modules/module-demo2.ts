import { RouteConfig } from 'vue-router';

const IMPORT = (file: string) => (resolve: any) => require([`@/views/${ file }.vue`], resolve);
export default [
  {
    path: '/module2',
    name: 'Demo2',
    component: IMPORT('modules/demo2/index'),
    meta: { pageCode: 31 }
  }
] as RouteConfig[];
