import { RouteConfig } from 'vue-router';

const IMPORT = (file: string) => (resolve: any) => require([`@/views/${file}.vue`], resolve);
export default [
  {
    path: '/notarization',
    name: '公证',
    component: IMPORT('modules/notarization/index'),
    meta: { pageCode: 21 }
  },
  {
    path: '/institutionList',
    name: '机构诚信档案',
    component: IMPORT('modules/notarization/integrity-record/institution/index'),
    meta: { pageCode: 21 }
  },
  {
    path: '/personList',
    name: '人员诚信档案',
    component: IMPORT('modules/notarization/integrity-record/person/index'),
    meta: { pageCode: 21 }
  },
  {
    path: '/institutionDetail',
    name: '详情',
    component: IMPORT('modules/notarization/integrity-record/institution/detail/index'),
    meta: { pageCode: 21 }
  },
  {
    path: '/personDetail',
    name: '详情',
    component: IMPORT('modules/notarization/integrity-record/person/detail/index'),
    meta: { pageCode: 21 }
  },
  {
    path: '/assessmentDetails',
    name: '年度考核详情',
    component: IMPORT('modules/notarization/annual-assessment/asessment-details/index'),
    meta: { pageCode: 21 }
  },
  {
    path: '/authenticActList',
    name: '公证书查询结果',
    component: IMPORT('modules/notarization/authentic-act/authentic-act-list/index'),
    meta: { pageCode: 21 }
  },
  {
    path: '/authenticActDetails',
    name: 'AssessmentDetails',
    component: IMPORT('modules/notarization/authentic-act/authentic-act-details/index'),
    mate: { pageCode: 21 }
  }
] as RouteConfig[];
