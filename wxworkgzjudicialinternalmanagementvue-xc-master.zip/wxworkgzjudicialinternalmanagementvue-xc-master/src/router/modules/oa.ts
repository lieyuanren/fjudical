/**
 * @Author: tangzhicheng
 * @Date: 2021-03-24 10:21:09
 * @LastEditors: tangzhicheng
 * @LastEditTime: 2021-03-30 14:21:15
 * @Description: file content
 */


import { RouteConfig } from 'vue-router';

const IMPORT = (file: string) => (resolve: any) => require([`@/views/${file}.vue`], resolve);


const OARoutes: RouteConfig[] = [
  {
    path: '/oa',
    name: 'oa',
    redirect: '/oa/home',
    component: IMPORT('modules/oa/index'),
    meta: { pageCode: 6 },
    children: [
      {
        path: 'home',
        name: 'home',
        component: IMPORT('modules/oa/home/index')
      },
      {
        path: 'detail',
        name: 'detail',
        component: IMPORT('modules/oa/detail/index')
      },
      {
        path: 'received',
        name: 'received',
        component: IMPORT('modules/oa/received/index')
      },
      {
        path: 'post',
        name: 'post',
        component: IMPORT('modules/oa/post/index')
      }
    ]
  }
];


export default OARoutes;
