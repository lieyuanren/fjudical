/**
 * @Author: tangzhicheng
 * @Date: 2020-03-09 09:17:18
 * @LastEditors: tangzhicheng
 * @LastEditTime: 2020-04-29 14:34:38
 * @Description: file content
 */
import { RouteConfig } from 'vue-router';
const IMPORT = (file: string) => (resolve: any) => require([`@/views/modules/${file}.vue`], resolve);

export default [
    {
        path: '/patrol-manage',
        name: '卡号管理',
        component: IMPORT('patrol-manage/index'),
        meta: { pageCode: 6 }
    }
] as RouteConfig[];
