/**
 * @Author: jzl
 * @Date: 2021-01-26 09:17:18
 * @LastEditors: tangzhicheng
 * @LastEditTime: 2020-04-29 14:34:38
 * @Description: file content
 */
import { RouteConfig } from 'vue-router';
const IMPORT = (file: string) => (resolve: any) => require([`@/views/modules/${file}.vue`], resolve);

export default [
    {
        path: '/personnelManager',
        name: '人事考核',
        component: IMPORT('personnel-manager/index'),
        meta: { pageCode: 6 }
    },
    {
        path: '/personnelManager/person/list',
        name: '人员管理',
        component: IMPORT('personnel-manager/person/index'),
        meta: { pageCode: 6 }
    },
    {
        path: '/personnelManager/person/detail',
        name: '人员信息集',
        component: IMPORT('personnel-manager/person/person-details/index'),
        meta: { pageCode: 6 }
    },
    {
        path: '/personnelManager/check',
        name: '考核管理',
        component: IMPORT('personnel-manager/check/index'),
        meta: { pageCode: 6 }
    },
    {
        path: '/personnelManager/union',
        name: '工会群团',
        component: IMPORT('personnel-manager/union/index'),
        meta: { pageCode: 6 }
    },
    {
        path: '/personnelManager/train',
        name: '培训管理',
        component: IMPORT('personnel-manager/train/index'),
        meta: { pageCode: 6 }
    },
    {
        path: '/personnelManager/train',
        name: '培训管理',
        component: IMPORT('personnel-manager/train/index'),
        meta: { pageCode: 6 }
    },
    {
        path: '/personnelManager/statistical',
        name: '统计报表',
        component: IMPORT('personnel-manager/statistical-analysis/index'),
        meta: { pageCode: 6 }
    }
] as RouteConfig[];
