/**
 * @Author: lilili
 * @Date: 2021-03-23 09:17:18
 * @LastEditors: lilili
 * @LastEditTime: 2021-03-23 09:17:18
 * @Description: file content
 */
import { RouteConfig } from 'vue-router';
const IMPORT = (file: string) => (resolve: any) => require([`@/views/modules/${file}.vue`], resolve);

export default [
    {
        path: '/police-car',
        name: '警务用车系统',
        component: IMPORT('police-car/index'),
        meta: { pageCode: 6 }
    }, {
        path: '/car-detail/:carNumber',
        name: '车辆状态信息',
        component: IMPORT('police-car/data/detail/index'),
        meta: { pageCode: 6 }
    }, {
        path: '/company-list',
        name: '单位信息列表',
        component: IMPORT('police-car/info/companyList/index'),
        meta: { pageCode: 6 }
    }, {
        path: '/prison-detail/:organizationId',
        name: '单位详细信息',
        component: IMPORT('police-car/info/companyList/detail/index'),
        meta: { pageCode: 6 }
    }, {
        path: '/car-list',
        name: '车辆信息列表',
        component: IMPORT('police-car/info/carList/index'),
        meta: { pageCode: 6 }
    }, {
        path: '/car-info/:carId',
        name: '车辆详细信息',
        component: IMPORT('police-car/info/carList/detail/index'),
        meta: { pageCode: 6 }
    }, {
        path: '/driver-list',
        name: '车辆信息列表',
        component: IMPORT('police-car/info/driverList/index'),
        meta: { pageCode: 6 }
    }, {
        path: '/driver-info/:driverId',
        name: '车辆详细信息',
        component: IMPORT('police-car/info/driverList/detail/index'),
        meta: { pageCode: 6 }
    }
] as RouteConfig[];
