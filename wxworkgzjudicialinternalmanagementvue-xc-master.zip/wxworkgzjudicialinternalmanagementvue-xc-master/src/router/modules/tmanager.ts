/**
 * @Author: tangzhicheng
 * @Date: 2020-03-09 09:17:18
 * @LastEditors: tangzhicheng
 * @LastEditTime: 2020-04-29 14:34:38
 * @Description: file content
 */
import { RouteConfig } from 'vue-router';
const IMPORT = (file: string) => (resolve: any) => require([`@/views/modules/${file}.vue`], resolve);

export default [
    {
        path: '/tmanager',
        name: '首页',
        component: IMPORT('tmanager/index'),
        meta: { pageCode: 6 }
    },
    {
        path: '/tmanager/message_list',
        name: '消息管理',
        component: IMPORT('tmanager/message/index'),
        meta: { pageCode: 6 }
    },
    {
        path: '/tmanager/detail',
        name: '任务详情',
        component: IMPORT('tmanager/detail/index'),
        meta: { pageCode: 6 }
    },
    {
        path: '/tmanager/todo',
        name: '我的待办',
        component: IMPORT('tmanager/todo/index'),
        meta: { pageCode: 6 }
    },
    {
        path: '/tmanager/report',
        name: '统计报表',
        component: IMPORT('tmanager/report/index')
    },
    {
        path: '/tmanager/static',
        name: '任务统计',
        component: IMPORT('tmanager/static/index'),
        meta: { pageCode: 6 }
    },
    {
        path: '/tmanager/createTasks',
        name: '创建任务',
        component: IMPORT('tmanager/create-tasks/index'),
        meta: { pageCode: 6 }
    },
    {
        path: '/tmanager/copyGive',
        name: '添加选项',
        component: IMPORT('tmanager/copy-give/index'),
        meta: { pageCode: 6 }
    },
    {
        path: '/tmanager/tasksList',
        name: '任务',
        component: IMPORT('tmanager/tasks-list/index'),
        meta: { pageCode: 6 }
    }
] as RouteConfig[];
