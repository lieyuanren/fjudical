import { RouteConfig } from 'vue-router';

const IMPORT = (file: string) => (resolve: any) => require([`@/views/${ file }.vue`], resolve);
export default [
  {
    path: '/demo',
    name: 'Demo',
    component: IMPORT('demo/index'),
    meta: { pageCode: 11 }
  },
  {
    path: '/demo/button',
    name: '按钮',
    component: IMPORT('demo/button/index'),
    meta: { pageCode: 12 }
  },
  {
    path: '/demo/dialog',
    name: '弹窗',
    component: IMPORT('demo/dialog/index'),
    meta: { pageCode: 13 }
  },
  {
    path: '/demo/pull-and-push',
    name: '下拉刷新、上拉加载 - 基础',
    component: IMPORT('demo/pull-and-push/index'),
    meta: { pageCode: 14 }
  },
  {
    path: '/demo/pull-and-push/me-scroll',
    name: '下拉刷新、上拉加载 - me-scroll',
    component: IMPORT('demo/pull-and-push/me-scroll'),
    meta: { pageCode: 15 }
  },
  {
    path: '/demo/http/api',
    name: '接口请求',
    component: IMPORT('demo/api-http/index'),
    meta: { pageCode: 16 }
  }
] as RouteConfig[];
