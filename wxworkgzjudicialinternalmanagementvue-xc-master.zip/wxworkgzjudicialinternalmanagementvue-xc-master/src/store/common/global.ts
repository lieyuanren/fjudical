/**
 * @Author : ChangJun
 * @Date : 2019-06-18
 * @Version : 1.0
 * @Content : 全局持久化配置
 */
import Loading from '@/model/common/global/Loading';

const config = require('@/config/index.js');
const mutationTypes = {
  setLoading: 'SET_LOADING',
  setMasking: 'SET_SHOW_MASKING',
  setDirection: 'SET_DIRECTION', // 页面切换动画
  setChannel: 'SET_CHANNEL',
  setEnterTime: 'SET_ENTER_TIME',
  setRoute: 'SET_ROUTE'
};
const state = {
  loading: new Loading(), // loading加载
  showMasking: false, // 全局遮盖
  direction: '', // 页面切换动画
  channel: '', // 渠道编码
  enterTime: '', // 页面进入时间
  route: {} // 当前路由
};
const getters = {
  loading: (state: any) => {
    return state.loading;
  },
  showMasking: (state: any) => {
    return state.showMasking;
  },
  direction: (state: any) => {
    return state.direction;
  },
  channel: (state: any) => {
    return state.channel;
  },
  enterTime: (state: any) => {
    return state.enterTime;
  },
  route: (state: any) => {
    return state.route;
  }
};
const mutations = {
  [mutationTypes.setLoading] (state: any, val: Loading) {
    if (val && val.show) {
      state.loading = {
        show: val.show,
        msg: val.msg
      };
    } else {
      state.loading = {
        show: false,
        msg: ''
      };
    }
  },
  [mutationTypes.setMasking] (state: any, val: boolean) {
    state.showMasking = val || false;
  },
  [mutationTypes.setDirection] (state: any, val: string) {
    state.direction = val;
  },
  [mutationTypes.setChannel] (state: any, val: string) {
    if (!val) {
      val = config.channel;
    }
    state.channel = val;
  },
  [mutationTypes.setEnterTime] (state: any, val: string) {
    state.enterTime = val;
  },
  [mutationTypes.setRoute] (state: any, val: string) {
    state.route = val;
  }
};
export default {
  state,
  getters,
  mutations
};
