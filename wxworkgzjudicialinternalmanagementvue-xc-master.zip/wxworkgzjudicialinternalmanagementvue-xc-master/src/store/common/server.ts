/**
 * @Author : ChangJun
 * @Date : 2019-06-26
 * @Version : 1.0
 * @Content : 项目数据
 */

const state = {
  pageGuid: ''
};
const mutationTypes = {
  setPageGuid: 'SET_PAGE_GUID'
};
const getters = {
  pageGuid: (state: any) => {
    return state.pageGuid; // 页面唯一标识：进入页面创建新的唯一标识
  }
};
const mutations = {
  [mutationTypes.setPageGuid] (state: any, val: string) {
    state.pageGuid = val;
  }
};
export default {
  state,
  getters,
  mutations
};
