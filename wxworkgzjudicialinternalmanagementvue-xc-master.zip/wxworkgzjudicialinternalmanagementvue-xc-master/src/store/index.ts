/**
 * @Author : ChangJun
 * @Date : 2019-06-18
 * @Version : 1.0
 * @Content : vuex 持久化
 */

import Vue from 'vue';
import Vuex from 'vuex';
import createPersistedState from 'vuex-persistedstate';

import localStorage from '@/utils/common/local-storage';
// 模块
Vue.use(Vuex);
import global from './common/global';
import server from './common/server';
import car from './modules/car-manager';
import notarization from './modules/notarization';
import tmanager from './modules/tmanager';

export default new Vuex.Store({
  // 组合各个模块
  modules: {
    global,
    server,
    car,
    notarization,
    tmanager
  },
  // 插件
  plugins: [createPersistedState({
    key: require('../../package.json').name + 'vuex',
    paths: [''], // 只缓存service里的state
    getState: (key) => localStorage.get(key),
    setState: (key, state) => localStorage.set(key, state)
  })]
});
