/**
 * @Author : 停车管理
 * @Date : 2019-12-20
 * @Version : 1.0
 * @Content : 全局持久化配置
 */
const mutationTypes = {
  setCarList: 'SET_CARLIST',
  setCarNull: 'SET_CAR_NULL',
  setParkSize: 'SET_PARKSIZE'
};
const state = {
  carList: [],
  parkSize: { total: 0, remain: 0 }
};
const getters = {
  cars: (state: any) => {
    return state.carList;
  }
};
const mutations = {
  [mutationTypes.setCarList] (state: any, val: object[]) {
    state.carList = val;
  },
  [mutationTypes.setCarNull] (state: any, val: object[]) {
    state.carList = null;
  },
  [mutationTypes.setParkSize] (state: any, val: object) {
    state.parkSize = val;
  }
};
export default {
  state,
  getters,
  mutations
};
