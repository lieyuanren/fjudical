/**
 * @Author : yeqinhua
 * @Date : 2020-01-02
 * @Version : 1.0
 * @Content : 司法鉴定
 */

const state = {};
const mutationTypes = {};
const getters = {};
const mutations = {};
export default {
  state,
  getters,
  mutations
};
