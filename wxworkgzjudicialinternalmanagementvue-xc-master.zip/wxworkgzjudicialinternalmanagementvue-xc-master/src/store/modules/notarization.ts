/**
 * @Author : yeqinhua
 * @Date : 2019-06-26
 * @Version : 1.0
 * @Content : 公证
 */

// @ts-ignore
import AuthenticData from '@/model/modules/notarization/AuthenticAct/AuthenticData';

const state = {
  // 公证书查询数据
  authenticActData: null
};
const mutationTypes = {
  setAuthenticActData: 'setAuthenticActData'
};
const getters = {
  demo: (state: any) => {
    return state.demo; // 页面唯一标识：进入页面创建新的唯一标识
  },
  authenticActData: (state: any) => {
    return state.authenticActData;
  }
};
const mutations = {
  // 存放公证书查询数据
  [mutationTypes.setAuthenticActData](state: any, val: AuthenticData) {
    state.authenticActData = val;
  }
};
export default {
  state,
  getters,
  mutations
};
