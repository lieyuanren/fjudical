/**
 * @author : tangzhicheng
 * @Date ：2020-2-25
 * @Content ：任务管理数据仓库
 */

import NameCardType from '@/model/modules/t_manager/NameCardType';

interface StateType<T> {
  // 承办单位
  companyList: T[];
  // 分管领导
  leaderList: T[];
  // 承办人员
  personnelList: T[];
  // 接受消息人员
  messageList: T[];
  // 时间
  jobList: T[];

}

interface OptionType {
  propName: string;
  arr: NameCardType[];
}

const state: StateType<NameCardType> = {
  companyList: [],
  leaderList: [],
  personnelList: [],
  messageList: [],
  jobList: []
};

const getters = {
  companyList (state: any): NameCardType[] {
    return state.companyList;
  },
  leaderList (state: any): NameCardType[] {
    return state.leaderList;
  },
  personnelList (state: any): NameCardType[] {
    return state.personnelList;
  },
  messageList (state: any): NameCardType[] {
    return state.messageList;
  },
  jobList (state: any): NameCardType[] {
    return state.jobList;
  }
};

const mutations = {
  // 删除
  delAll (state: any, obj: OptionType): void {
    obj.arr.forEach((item: NameCardType): void => {
      state[obj.propName].some((company: NameCardType, index: number): boolean | undefined => {
        if (item.id === company.id) {
          state[obj.propName].splice(index, 1);
          return true;
        }
      });
    });
  },
  // 添加
  addAll (state: any, obj: OptionType): void {
    obj.arr.forEach((item: NameCardType): void => {
      const isTrue = state[obj.propName].some((company: NameCardType): boolean | undefined => {
        if (item.id === company.id) {
          return true;
        }
      });
      if (!isTrue) {
        state[obj.propName].push(item);
      }
    });
  },

  // 清空仓库
  clearStore (state: any) {
    state.companyList = [];
    state.leaderList = [];
    state.personnelList = [];
    state.messageList = [];
    state.jobList = [];
  }

};

export default {
  state,
  getters,
  mutations
};
