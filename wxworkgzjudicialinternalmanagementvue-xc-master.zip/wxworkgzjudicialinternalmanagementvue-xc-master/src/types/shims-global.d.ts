/**
 * @Author: tangzhicheng
 * @Date: 2021-03-23 10:44:30
 * @LastEditors: tangzhicheng
 * @LastEditTime: 2021-03-24 10:27:13
 * @Description: file content
 */
import Vue from "vue";

declare global {
  interface Window {
    eruda: any;
  }
}
declare global {
  // export const moment: typeof moment;
  export const wx: any; // 去掉wx jssdk 错误警告
  export const qq: any;
}

declare global {
  export const F2: any;
  export const _: any;
}
