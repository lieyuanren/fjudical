import Vue from 'vue';

declare module '*.vue' {
  import Vue from 'vue';
  export default Vue;
}
declare module 'vue/types/vue' {
  interface Vue {
    $api: any;
    $interface: any;
    $utils: any;
    $tip: any;
    $globals: any;
  }
}
