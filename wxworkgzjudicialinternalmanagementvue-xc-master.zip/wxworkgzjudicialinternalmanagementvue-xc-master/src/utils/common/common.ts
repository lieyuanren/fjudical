/**
 * @Author : ChangJun
 * @Date : 2019/2/18
 * @Version : 1.0
 * @Content : 常用方法工具类
 */

export default {
  /**
   * 取宽高
   */
  // 取宽高
  getWidthHeight() {
    const w = window;
    const d = document;
    const e = d.documentElement;
    const g = d.getElementsByTagName('body')[0];
    const x = w.innerWidth || e.clientWidth || g.clientWidth;
    const y = w.innerHeight || e.clientHeight || g.clientHeight;
    return { width: x, height: y };
  },
  /**
   * 手机号码脱敏
   * @param phone 手机号
   */
  hidePhone(phone: string) {
    if (!phone) {
      return '';
    }
    phone = phone.toString();
    if (phone.length !== 11) {
      return phone;
    }
    return phone.substring(0, 3) + '*****' + phone.substring(8);
  },
  /**
   * 取url参数
   * @param name 参数名称
   * @param url url地址
   */
  getParam(name: string, url?: string) {
    if (!url) {
      url = window.location.href;
    }
    name = name.replace(/[\[\]]/g, '\\$&');
    const regex = new RegExp('[?&]' + name + '(=([^&#]*)|&|#|$)');
    const results = regex.exec(url);
    if (!results) {
      return null;
    }
    if (!results[2]) {
      return '';
    }
    return decodeURIComponent(results[2].replace(/\+/g, ' '));
  },
  /**
   * 数字转大写
   * @param n 数字处理
   */
  numberToChinese(n: string) {
    if (!/^(0|[1-9]\d*)(\.\d+)?$/.test(n)) {
      return '';
    }
    let unit: string = '京亿万仟佰拾兆万仟佰拾亿仟佰拾万仟佰拾元角分';
    let str: string = '';
    n += '00';
    const p = n.indexOf('.');
    if (p >= 0) {
      n = n.substring(0, p) + n.substr(p + 1, 2);
      unit = unit.substr(unit.length - n.length);
      for (let i = 0; i < n.length; i++) {
        str += '零壹贰叁肆伍陆柒捌玖'.charAt(Number(n.charAt(i))) + unit.charAt(i);
      }
      return str.replace(/零(仟|佰|拾|角)/g, '零').replace(/(零)+/g, '零').replace(/零(兆|万|亿|元)/g, '$1').replace(/(兆|亿)万/g, '$1').replace(/(京|兆)亿/g, '$1').replace(/(京)兆/g, '$1').replace(/(京|兆|亿|仟|佰|拾)(万?)(.)仟/g, '$1$2零$3仟').replace(/^元零?|零分/g, '').replace(/(元|角)$/g, '$1整');
    }
  },
  /**
   * 设置网页标题
   * @param title
   */
  setTitle(title: string) {
    setTimeout(() => {
      // 利用iframe的onload事件刷新页面
      document.title = title;
      const iframe = document.createElement('iframe');
      iframe.style.visibility = 'hidden';
      iframe.style.width = '1px';
      iframe.style.height = '1px';
      iframe.onload = () => {
        setTimeout(() => {
          document.body.removeChild(iframe);
        }, 0);
      };
      document.body.appendChild(iframe);
    }, 0);
  },
  /**
   * 生成guid
   */
  guid() {
    let time: number = Date.now();
    if (typeof performance !== 'undefined' && typeof performance.now === 'function') {
      time += performance.now(); // use high-precision timer if available
    }
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (code: string) => {
      const rep = (time + Math.random() * 16) % 16 | 0;
      time = Math.floor(time / 16);
      return (code === 'x' ? rep : (rep & 0x3 | 0x8)).toString(16);
    });
  },
  hasClass(obj: any, cls: string) {
    return obj.className.match(new RegExp('(\\s|^)' + cls + '(\\s|$)'));
  },
  /**
   * 添加样式
   * @param obj
   * @param clsArr
   */
  addClass(obj: any, clsArr: string[]) {
    clsArr.map((cls) => {
      if (!this.hasClass(obj, cls)) {
        obj.className = obj.className.trimEnd();
        obj.className += ' ' + cls;
      }
    });
  },
  /**
   * 删除样式
   * @param obj
   * @param clsArr
   */
  removeClass(obj: any, clsArr: string[]) {
    clsArr.map((cls) => {
      if (this.hasClass(obj, cls)) {
        let reg = new RegExp('(\\s|^)' + cls + '(\\s|$)');
        obj.className = obj.className.replace(reg, ' ');
      }
    });
  },
  /**
   * 日期格式化
   */
  dateFmt(fmt: string | null, date: any, ampm = false) {
    if (fmt === null || fmt === '' || fmt === undefined) {
      fmt = 'yyyy-MM-dd hh:mm:ss';
    }
    const o: any = {
      'M+': date.getMonth() + 1,     // 月份
      'd+': date.getDate(),     // 日
      'h+': date.getHours(),     // 小时
      'm+': date.getMinutes(),     // 分
      's+': date.getSeconds(),     // 秒
      'q+': Math.floor((date.getMonth() + 3) / 3), // 季度
      'S': date.getMilliseconds()    // 毫秒
    };
    let suffix;
    if (ampm) {
      if (o['h+'] > 12) {
        o['h+'] -= 12;
        suffix = 'PM';
      } else {
        suffix = 'AM';
      }
    }
    if (/(y+)/.test(fmt)) {
      fmt = fmt.replace(RegExp.$1, (date.getFullYear() + '').substr(4 - RegExp.$1.length));
    }
    for (let k in o) {
      if (new RegExp('(' + k + ')').test(fmt)) {
        fmt = fmt.replace(RegExp.$1, (RegExp.$1.length === 1) ? (o[k]) : (('00' + o[k]).substr(('' + o[k]).length)));
      }
    }
    if (ampm) {
      fmt += suffix;
    }
    return fmt;
  }
};
