/**
 * @Author : ChangJun
 * @Date : 2019/2/15
 * @Version : 1.0
 * @Content : 本地缓存 + 加密工具
 */
const CryptoJS = require('crypto-js');
const storage = window.localStorage;
const key = CryptoJS.enc.Utf8.parse('7e^V9FLMatcyX0kA').toString();
const ivVal = CryptoJS.enc.Utf8.parse('kr6V%xV&tQj8kH13').toString();
const config = {
  iv: ivVal,
  mode: CryptoJS.mode.CBC,
  padding: CryptoJS.pad.Pkcs7
};

const enable = false; // 控制加解密

export default {
  /**
   * 设置缓存数据
   * @param name 缓存名称
   * @param value 需要缓存的数据
   */
  set(name: string, value: any) {
    if (typeof (value) === 'object') {
      value = JSON.stringify(value);
    } else {
      value = JSON.stringify({ myCacheValue: value });
    }
    if (enable) { // 控制加解密
      // DES加密
      value = CryptoJS.TripleDES.encrypt(value.toString(), key, config).toString();
    }
    storage.setItem(name, value);
  },
  /**
   * 取缓存数据
   * @param name 缓存名称
   */
  get(name: string) {
    try {
      const temp: any = storage.getItem(name);
      let value = temp;
      if (!temp) {
        return null;
      }
      if (enable) { // 控制加解密
        // DES解密
        let decValue = CryptoJS.TripleDES.decrypt(temp, key, config);
        // 转换为 UTF8 字符串
        value = CryptoJS.enc.Utf8.stringify(decValue) || temp;
      }
      let obj: any = { myCacheValue: '' };
      obj = JSON.parse(value);
      if (obj.myCacheValue) {
        return obj.myCacheValue;
      }
      return obj;
    } catch (e) {
      return null;
    }
  },
  /**
   * 清除缓存数据
   * @param name 缓存名称
   */
  clear(name?: string) {
    if (name) {
      storage.removeItem(name);
    } else {
      storage.clear();
    }
  }
};
