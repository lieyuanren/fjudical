/**
 * @Author : ChangJun
 * @Date : 2019-06-25
 * @Version : 1.0
 * @Content : 数据埋点业务
 */
import Log from '@/model/common/global/Log';
import store from '@/store';
import {Route} from 'vue-router';

const config = require('../../config/index.js');

/**
 * 数据埋点
 * @param pageName 页面名称
 * @param pageCode 页面编码
 * @param pageUrl 页面路径
 * @param pageGuid 页面唯一标示
 * @param eventCode 事件编码
 * @param eventName 事件释义
 * @param activeCode 行为名称
 * @param stayTime 停留时长
 * @param apiUrl 接口地址
 * @param reqParam 入参
 */

function saveLog (pageName: string, pageCode: string, pageUrl: string, pageGuid: string, eventCode: string, eventName: string, activeCode: string, stayTime: string = '', apiUrl: string = '', reqParam: string = '') {
  try {
    let log: Log = {};
    log.ua = navigator.userAgent;
    log.project = config.name;
    log.version = config.version;
    log.channel = config.channel;
    log.sourceCode = '';
    // @ts-ignore
    log.ip = ip || '127.0.0.1';
    log.page = pageName;
    log.pageCode = pageCode;
    log.pageUrl = pageUrl;
    log.pageGuid = pageGuid;
    // 操作信息
    log.eventCode = eventCode;
    log.event = eventName;
    log.activeCode = activeCode;
    // 页面进入事件、停留时长
    const getter = (store.getters as any);
    log.enterTime = getter && getter.enterTime;
    log.stayTime = stayTime;
    log.time = new Date().getTime().toString();
    // 用户信息
    log.uId = '';
    log.phone = '';
    log.unionId = '';
    log.openId = '';

    // 拼接参数串
    let args = '';
    // @ts-ignore
    for (let i of Object.keys(log)) {
      if (args !== '') {
        args += '&';
      }
      // @ts-ignore
      args += i + '=' + encodeURIComponent(log[i]);
    }
    let img = new Image(1, 1);
    img.src = `https://point.aegis-info.com/public/aegis/point/1.gif?${args}`;
  } catch (e) {
    console.log(' e:', e);
  }
}

export default {
  /**
   * 用户触发埋点
   * @param eventCode 事件编码
   * @param eventName 事件释义
   * @param activeCode 行为名称
   */
  saveEvent (eventCode: string, eventName: string, activeCode: string) {
    // 页面路由信息
    const getter = (store.getters as any);
    const route = getter.route;
    const pageGuid = getter.pageGuid;
    saveLog(route.meta.name || route.name, route.meta.pageCode, route.fullPath, pageGuid, eventCode, eventName, activeCode);
  },
  /**
   * 离开路由埋点
   * @param preRoute 离开路由
   * @param eventCode 事件编码
   * @param eventName 事件释义
   * @param activeCode 行为名称
   */
  saveRouteLeave (preRoute: Route, eventCode: string, eventName: string, activeCode: string) {
    // 记录停留时间
    const getter = (store.getters as any);
    const stay = new Date().getTime() - getter.enterTime;
    const pageGuid = getter.pageGuid;
    saveLog(preRoute.meta.name || preRoute.name, preRoute.meta.pageCode, preRoute.fullPath, pageGuid, eventCode, eventName, activeCode, stay.toString());
  },
  /**
   * 接口请求埋点
   * @param apiUrl 接口地址
   * @param reqParam 入参
   * @param eventCode 事件编码 入参：-2
   * @param eventName 事件释义
   * @param activeCode 行为名称
   */
  saveApiRequest (apiUrl: string, reqParam: string, eventCode: string, eventName: string, activeCode: string) {
    const getter = (store.getters as any);
    const route = getter.route;
    const pageGuid = getter.pageGuid;
    saveLog(route.meta.name || route.name, route.meta.pageCode, route.fullPath, pageGuid, eventCode, eventName, activeCode, '', apiUrl, reqParam);
  }
};
