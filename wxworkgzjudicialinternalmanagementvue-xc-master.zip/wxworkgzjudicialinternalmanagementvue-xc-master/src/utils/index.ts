/**
 * @Author : ChangJun
 * @Date : 2019/2/15
 * @Version : 1.0
 * @Content : 工具类文件
 */
import moment from 'moment';
import LocalStorage from './common/local-storage';
import Common from './common/common';
import Log from './common/log';
import JSSDK from './modules/wxwork/wxwork-js-sdk';
import Auth from './modules/wxwork/auth';
import {VueConstructor} from 'vue';

export default {
  install (Vue: VueConstructor): void {

    const utils = {Moment: moment, LocalStorage, Common, Log, JSSDK, Auth};
    if (!Vue.prototype.$utils) {
      Vue.prototype.$utils = utils;
    } else {
      Vue.prototype.$api.$utils = utils;
    }
  }
};
