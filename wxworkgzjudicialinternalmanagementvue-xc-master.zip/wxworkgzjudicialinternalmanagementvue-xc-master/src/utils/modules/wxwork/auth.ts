/**
 * 企业微信授权相关
 */
export default {
  /**
   * 检组装授权 url
   * @returns {*}
   */
  async generateAuthUrl () {
    const authUrl = 'http://45.40.236.20';
    const appid = 'ww133db7fb1965594d';
    // const authUrl = 'https://open.weixin.qq.com'
    // const appid = 'ww4783b5de3fda6acd'
    const state = 'test';
    const url = `${ window.location.href }`;
    const final = `${ authUrl }/connect/oauth2/authorize?appid=${ appid }&redirect_uri=${ url }&response_type=code&scope=snsapi_base&state=${ state }#wechat_redirect`;
    console.log('final', final);
    return final;
  }
};
