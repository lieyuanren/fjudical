// @ts-nocheck
/* eslint-disable */
import api from '../../../https/x-https';
const apiInterface = require('../../../api/index');
/**
 * 运行环境判断
 */
export default {
  /**
   * 注册企业微信 jssdk
   * @returns {Promise<void>}
   */
  async QYJSSDKConfig (jsApi, callBack) {
    const url = location.href.split('#')[0];
    const params = {
      url,
      isAgent: false
    };
    const config = await api.post(apiInterface.wxwork.getJSSDKConfig, params);
    console.log('QYJSSDKConfig res', config);
    config.jsApiList = jsApi;
    wx.config({
      beta: true, // 必须这么写，否则wx.invoke调用形式的jsapi会有问题
      debug: false, // 开启调试模式,调用的所有api的返回值会在客户端alert出来，若要查看传入的参数，可以在pc端打开，参数信息会通过log打出，仅在pc端时才会打印。
      appId: config.appId, // 必填，企业微信的corpID
      timestamp: config.timestamp, // 必填，生成签名的时间戳
      nonceStr: config.nonceStr, // 必填，生成签名的随机串
      signature: config.signature, // 必填，签名，见 附录-JS-SDK使用权限签名算法
      jsApiList: config.jsApiList // 必填，需要使用的JS接口列表，凡是要调用的接口都需要传进来
    });
    wx.error((res) => {
      console.log('=========================QYJSSDKConfig error=======================', res);
    });
    wx.ready(() => {
      console.log(`======================QYJSSDKConfig ready===========================`);
      // Environment.wxJSSDKAgentConfig(config.common,callBack)
      if (callBack) {
        callBack();
      }
    });
  },

  /**
   *
   * agentConfig的作用
   * config注入的是企业的身份与权限，而agentConfig注入的是应用的身份与权限。
   * 尤其是当调用者为第三方服务商时，通过config无法准确区分出调用者是哪个第三方应用，而在部分场景下，
   * 又必须严谨区分出第三方应用的身份，此时即需要通过agentConfig来注入应用的身份信息
   * @returns {Promise<void>}
   */
  async wxJSSDKAgentConfig (base, callBack) {
    const config = await api.wx.geJSSDKConfig(base.url, base.noncestr, base.timestamp, true);
    console.log('QYJSSDKConfig res', config);
    config.jsApiList = ['selectExternalContact', 'openUserProfile', 'thirdPartyOpenPage', 'getCurExternalContact'];
    // config.debug = false
    config.success = (res) => {
      console.log('=============================wxJSSDKAgentConfig success===========================', res);
      // 回调
      callBack(true);
    };
    config.fail = (res) => {
      console.log('===========================wxJSSDKAgentConfig fail===============================', res);
      if (res.errMsg.indexOf('function not exist') > -1) {
        alert('版本过低请升级');
      }
      callBack(false);
    };
    wx.config(config);
  }
};
