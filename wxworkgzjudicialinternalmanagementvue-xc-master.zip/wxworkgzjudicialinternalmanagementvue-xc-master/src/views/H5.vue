<!--
 * h5
 * @Author: yeqinhua
 * @Date: 2021-04-14 10:25:54
 * @Description: file content
-->

<template>
  <div class="h5">
    <iframe :src="h5" width="100%" height="100%"></iframe>
  </div>
</template>

<script lang='ts'>
import { Component, Vue } from 'vue-property-decorator';

const h5s: any = {
  'correction': 'https://t-h5correctionmanage.aegis-info.com',
  'canteen': 'http://food.sfj.gz.gov.cn/reserve/#/layout'
};

@Component
export default class OA extends Vue {
  get h5(): string {
    return h5s[this.$utils.LocalStorage.get('CurrentRouters')];
  }
}
</script>

<style lang='less' scoped>
.h5 {
  width: 100%;
  height: 100%;
}
</style>
