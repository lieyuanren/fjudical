<template>
  <div class="wrapper">
    <div class="grid-item"
         v-for="(item,index) in modules"
         :key="index"
         @click="to(item)">
      <img :src="item.icon"
           alt="icon">
      <span>
        {{ item.name }}
      </span>
    </div>
  </div>
</template>

<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';

const icons = {
  tmanager: require('@/assets/images/tmanager.png'),
  car: require('@/assets/images/car.png'),
  notarization: require('@/assets/images/notarization.png'),
  judicialExpertise: require('@/assets/images/judicialExpertise.png'),
  legalAid: require('@/assets/images/legalAid.png'),
  basicService: require('@/assets/images/basicService.png'),
  internalControl: require('@/assets/images/internalControl.png'),
  personnelManager: require('@/assets/images/personnelManager.png'),
  patrolManage: require('@/assets/images/patrolManage.png'),
  policeCar: require('@/assets/images/policeCar.png'),
  accessManage: require('@/assets/images/accessManage.png'),
  oa: require('@/assets/images/oa.png'),
  attendanceManage: require('@/assets/images/attendanceManage.png'),
  correction: require('@/assets/images/correction.png'),
  canteen: require('@/assets/images/canteen.png'),
};

type iconsKey = keyof typeof icons;

@Component({
  components: {}
})
export default class Home extends Vue {
  public modules: any = [
    // { name: '停车管理', value: 'car', route: '/car' },
    // { name: '公证管理', value: 'notarization', route: '/notarization' },
    // { name: '司法鉴定', value: 'judicialExpertise', route: '/judicialExpertise' },
    // { name: '法律援助', value: 'legalAid', route: '/legalAid' },
    // // { name: '人民调解', route: '/mediation' },
    // { name: '任务管理', login: true, value: 'tmanager', route: '/tmanager' },
    // { name: 'Demo', value: 'demo', route: '/demo' }
  ];

  public async created() {
    const res = await this.$api.xHttp.get(this.$interface.system.module.list);
    if (res.code === 0 && res.data.length !== 0) {
      const data = res.data;
      data.forEach((item: any) => {
        item.icon = icons[item.code as iconsKey];
      });
      this.modules = res.data;
    } else {
      this.$dialog
        .alert({
          title: '提示',
          message: '系统异常，请稍后重试!'
        })
        .then(() => {
          // wx.closeWindow(); // 关闭程序
        });
    }
  }
  public mounted() {
    console.log('i am home mounted');
    // 统一在这里解析url跳转到相应的系统
    const currentRouters = this.$utils.LocalStorage.get('CurrentRouters');
    const currentDestination = this.$utils.LocalStorage.get(
      'CurrentDestination'
    );
    // console.log('--------currentRouters----------', currentRouters);
    // console.log('--------currentDestination----------', currentDestination);
    if (currentRouters === 'mediation') {
      this.$router.replace(currentDestination); // 手动跳转
    }
    // if (currentDestination) {
    //   this.$router.replace(currentDestination); // 手动跳转
    // } else {
    //   console.error('-------------系统没有匹配到路由-------------');
    //   this.$dialog.alert({
    //     title: '提示',
    //     message: '系统异常，请稍后重试!'
    //   }).then(() => {
    //     wx.closeWindow(); // 关闭程序
    //   });
    // }
  }

  public async to(item: any) {
    let flag = true;
    if (item.login) {
      const res = await this.$api.xHttp.post(
        this.$interface.system.moduleUser + item.code
      );
      if (res.code !== 0 || !res.data.externalUser) {
        flag = false;
      } else {
        // 更新用户
        this.$utils.LocalStorage.set('USER', res.data);
      }
    }
    // if (flag) {
    if (true) {
      this.$utils.LocalStorage.set('CurrentRouters', item.code);
      this.$utils.LocalStorage.set('CurrentDestination', item.route);
      await this.$router.push(item.route);
    } else {
      this.$dialog
        .alert({
          title: '提示',
          message: '权限不足'
        })
        .then(() => {
          // wx.closeWindow(); // 关闭程序
        });
    }
  }
}
</script>
<style lang="less" scoped>
.wrapper {
  width: 100%;
  height: 100%;
  background-color: #ffffff;
  .grid-item {
    width: 33.333%;
    height: 240px;
    flex-shrink: 0;
    float: left;
    display: flex;
    flex-direction: column;
    justify-content: center;
    box-sizing: border-box;
    align-items: center;
    border-bottom: 1px solid #eeeeee;

    img {
      width: 84px;
      height: 84px;
      margin-top: 40px;
    }

    span {
      padding-top: 20px;
    }

    &:nth-child(2),
    &:nth-child(5),
    &:nth-child(8),
    &:nth-child(11),
    &:nth-child(14) {
      border-left: 1px solid #eeeeee;
      border-right: 1px solid #eeeeee;
    }

    &:nth-child(13),
    &:nth-child(14) {
      border-bottom: none;
    }
  }
}
</style>
