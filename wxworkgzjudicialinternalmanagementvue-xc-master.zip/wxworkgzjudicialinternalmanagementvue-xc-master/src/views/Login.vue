<template>
  <div class="login box">
    <div class="login-container-form"
         style="z-index: -100"
         v-show="showFormLogin">
      <div class="login-container-form-title">{{ loginTitle }}</div>
      <div class="login-container-form-item">{{ loginType === 0 ? '账号' : '手机' }}</div>
      <div class="login-container-form-input">
        <van-field :placeholder="loginType === 1 ? '请输入用户名' : '请输入手机号码'"
                   clearable
                   maxlength="28"
                   v-model="username" />
      </div>
      <template v-if="loginType === 1">
        <div class="login-container-form-item">密码</div>
        <div class="login-container-form-input">
          <van-field clearable
                     maxlength="28"
                     placeholder="请输入密码"
                     type="password"
                     v-model="password" />
        </div>
      </template>
      <template v-if="loginType === 2">
        <div class="login-container-form-item">验证码</div>
        <div class="login-container-form-input">
          <div class="login-container-form-input-left">
            <van-field clearable
                       maxlength="6"
                       placeholder="请输入验证码"
                       v-model="password" />
          </div>
          <div :class="{ disable: countInterval !== null }"
               @click="send"
               class="login-container-form-input-right">
            {{ countInterval === null ? '获取验证码' : `${'倒计时' + count + 's'}` }}
          </div>
        </div>
      </template>
      <div @click="changeLoginType"
           class="login-container-form-type">
        {{ loginType === 1 ? '验证码登录' : '密码登录' }}
      </div>
      <div @click="login"
           class="login-container-form-btn">
        登录
      </div>
    </div>
    <div class="login-container-qr"
         id="QYWXLogin"
         v-show="environment.isPc && showQYWXLoginCode">
    </div>
  </div>
</template>

<script lang="ts">
import { Component } from 'vue-property-decorator';
import { mixins } from 'vue-class-component';
// @ts-ignore
import Common from '@/mixins/common';
// @ts-ignore
import BaseUser from '@/model/common/wxwork/BaseUser';
import Localstorage from '../utils/common/local-storage';

@Component({
  components: {}
})
export default class Login extends mixins(Common) {
  public loginTitle = '用户登录';
  public showFormLogin = false; // 显示登陆容器
  public showQYWXLoginCode = false; // 显示扫码登陆容器
  public from = '';
  public loginType = 0; // 登录类型 0 code登录 默认；1 账号密码登录；2 短信验证码登录
  public username = 'admin';
  public password = '123456';
  public count = 60;
  public countInterval?: any = null;

  public async mounted() {
    const code = this.$route.query.code; // 授权后的code code不为空时 代表正在授权
    const state = this.$route.query.state; // 授权前携带参数
    const token = this.$utils.LocalStorage.get('ACCESS_TOKEN'); // 缓存
    if (this.$globals.Global.data.isDev) {
      // 绿色通道
      this.$utils.LocalStorage.set('ACCESS_TOKEN', '123456');
      await this.finalLogin();
      return;
    }
    // @ts-ignore
    if (this.environment.isQYWeixin) {
      // 只允许企业微信打开  暂时开放微信通道
      if (token) {
        // 有登录状态
        this.go(); // 正常访问
      } else {
        if (code) {
          await this.finalLogin(code as string);
        } else {
          window.location.href = await this.$utils.Auth.generateAuthUrl(); // 构造授权域名 开始授权
        }
      }
    } else {
      console.log(
        '---------------请在企业微信客户端或PC浏览器打开--------------------'
      );
      // 社工登录
      this.loginType = 1;
      this.showFormLogin = true;
      // this.$dialog.alert({
      //   title: '提示',
      //   message: '请在企业微信客户端或PC浏览器打开'
      // }).then(() => {
      //   // on close
      //   // @ts-ignore
      //   wx.closeWindow();
      // });
    }
  }

  public go() {
    // @ts-ignore
    this.$router.replace({ path: '/home', query: { fromLogin: true } });
  }

  public changeLoginType() {
    this.loginType = this.loginType === 1 ? 2 : 1;
    this.username = '';
    this.password = '';
  }

  // 登录表单
  public login() {
    if (!this.username || !this.password) {
      this.$toast.fail('请输入完整信息');
      return;
    }
    this.finalLogin();
  }

  public async finalLogin(code?: string) {
    // 执行code to userId 并自动登录
    const params = new BaseUser();
    params.loginType = this.loginType;
    if (code) {
      params.code = code;
    } else {
      params.username = this.username; // lukegdwang市局   wucaili区局  yuanhongbao所  103
      params.password = this.password;
    }
    const res = await this.$api.xHttp.post(this.getLoginAPI(), params, {
      isForm: Localstorage.get('CurrentRouters') === 'mediation'
    });
    if (res.code === 0 || res.code === 200) {
      let user = res.data;
      this.$utils.LocalStorage.set('ACCESS_TOKEN', res.data.token);
      if (Localstorage.get('CurrentRouters') === 'mediation') {
        this.$utils.LocalStorage.set('ACCESS_TOKEN', res.data);
        let userRes = await this.$api.xHttp.post(
          this.$interface.mediation.login.getUserInfo,
          params,
          { isForm: Localstorage.get('CurrentRouters') === 'mediation' }
        );
        if (userRes.code === 200) {
          user = userRes.data;
        } else {
          this.$dialog
            .alert({
              title: '提示',
              message: res.msg
            })
            .then(() => {
              // wx.closeWindow();
              this.$utils.LocalStorage.clear('ACCESS_TOKEN');
              return;
            });
        }
      }
      this.$utils.LocalStorage.set('USER', user);
      this.go();
    } else {
      this.$dialog
        .alert({
          title: '提示',
          message: res.msg
        })
        .then(() => {
          // on close
          // @ts-ignore
          // wx.closeWindow();
          return;
        });
    }
  }

  public getLoginAPI(): string {
    console.log('--------', Localstorage.get('CurrentRouters'));
    if (Localstorage.get('CurrentRouters') === 'mediation') {
      return this.$interface.mediation.login.loginByAccount;
    }
    return this.$interface.system.login;
  }

  public async send() {
    if (this.countInterval) {
      return;
    }
    if (!this.username) {
      this.$toast.fail('请输入手机号码');
      return;
    }
    this.count = 60;
    const res = await this.$api.xHttp.get(
      this.$interface.system.msg.send + `/${this.username}`
    );
    if (res.code === 0 || res.code === 200) {
      this.$toast.success(res.msg);
      this.count = 60;
      this.countInterval = setInterval(() => {
        if (this.count <= 0) {
          clearInterval(this.countInterval);
          this.countInterval = null;
        } else {
          this.count--;
        }
      }, 1000);
    }
  }
}
</script>
<style lang="less" scoped>
.login {
  background: #ffffff;
  width: 100%;
  height: 100%;
  max-height: 100%;
  overflow: scroll;
  &-container {
    &-qr {
      width: 100%;
      height: 100%;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    &-form {
      width: 100%;
      height: 100%;
      padding: 0 60px;
      box-sizing: border-box;
      &-title {
        height: 84px;
        font-size: 44px;
        font-weight: bold;
        color: #000000;
        margin-top: 10%;
        text-align: center;
      }
      &-item {
        margin-top: 80px;
        color: #333333;
        font-size: 28px;
        font-weight: bold;
      }
      &-input {
        width: 100%;
        margin-top: 10px;
        border-bottom: 1px solid #e0e0e0;
        padding: 20px 0;
        display: flex;
        flex-direction: row;
        &-left {
          flex: 1;
        }
        &-right {
          width: 160px;
          text-align: center;
          font-size: 24px;
          color: #0a5ffe;
          display: flex;
          align-items: center;
          justify-content: center;
        }
      }
      &-type {
        margin-top: 40px;
        width: fit-content;
        float: right;
        cursor: pointer;
        font-size: 32px;
        font-weight: 500;
        height: 64px;
        line-height: 64px;
        color: #333333;
      }
      &-btn {
        width: 100%;
        height: 100px;
        line-height: 100px;
        text-align: center;
        background: #0a5ffe;
        margin-top: 160px;
        font-size: 36px;
        color: #ffffff;
        border-radius: 12px;
      }
      // &-bg {
      //   position: fixed;
      //   width: 100%;
      //   max-width: 750px;
      //   height: 125px;
      //   bottom: 0;
      //   background-image: url("../assets/images/modules/login/login-bg.png");
      //   background-size: 100% 100%;
      //   z-index: 1;
      // }
    }
  }
}

.disable {
  color: #b2b2b2;
}

.van-cell {
  padding: unset;
}

.van-field__control {
  font-weight: 500;
  font-size: 32px;
}
</style>
