<template>
  <div class="notfound box">
    <div style="color: #1989fa;font-size: 22px">404 Not Found</div>
  </div>
</template>

<style lang="less" scoped>
.notfound {
  height: 100%;
  background-color: #ffffff;
  display: flex;
  align-items: center;
  justify-content: center;
}
</style>
