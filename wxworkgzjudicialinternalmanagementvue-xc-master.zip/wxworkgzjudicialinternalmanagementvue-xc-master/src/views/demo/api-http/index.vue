<!--
* @Author : ChangJun
* @Date :  2019-06-25
* @Version : 1.0
* @Content :
-->
<template>
  <div class="api-http-demo">
    <van-cell-group title="请求方式">
      <van-cell @click="handleGet" is-link title="Get"></van-cell>
      <van-cell @click="handlePost" is-link title="Post"></van-cell>
      <van-cell @click="handlePut" is-link title="Put"></van-cell>
      <van-cell @click="handleDelete" is-link title="Delete"></van-cell>
    </van-cell-group>
    <van-cell-group title="回调处理">
      <van-cell @click="handleApiError" is-link title="自定义接口失败"></van-cell>
      <van-cell @click="handleCodeError" is-link title="自定义业务失败"></van-cell>
      <van-cell @click="handleFormartData" is-link title="自定义出参格式"></van-cell>
    </van-cell-group>
    <van-cell-group title="多个调用">
      <van-cell @click="handleAll" is-link title="并发调用"></van-cell>
      <van-cell @click="handleContinue" is-link title="连续调用"></van-cell>
    </van-cell-group>
    <van-cell-group style="padding: 12px 12px;" title="按钮调用">
      <van-button :loading="btnLoading" :loading-text="loadingText" @click="handleSubmit" block plain type="info">下一步
      </van-button>
    </van-cell-group>
  </div>
</template>

<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';
import ResponseApi from '@/model/common/global/ResponseApi';

@Component({})
export default class Index extends Vue {
  public btnLoading: boolean = false;
  public loadingText: string = '请求中…';

  // get请求
  public async handleGet(): Promise<void> {
    const data = await this.$api.xHttp.get(this.$interface.demo.area.province, null, null);
    this.$tip.show(`${ data[0].provinceId }-${ data[0].provinceName }`);
  }

  // post请求
  public async handlePost(): Promise<void> {
    const res = await this.$api.xHttp.post(this.$interface.demo.login, { name: '123', psw: '123' }, { isForm: true });
    console.log(' res:', res);
  }

  // put请求
  public async handlePut(): Promise<void> {
    const res = await this.$api.xHttp.put(this.$interface.demo.user, { volunteers: {} }, { isForm: true });
    console.log(' res:', res);
  }

  // delete请求
  public async handleDelete(): Promise<void> {
    const res = await this.$api.xHttp.delete(`${ this.$interface.demo.user }/1`, null, null);
    console.log(' res:', res);
  }

  // 自定义接口错误
  public handleApiError(): void {
    this.$api.xHttp.post(this.$interface.demo.login,
      {
        name: '123',
        psw: '123'
      },
      { isForm: true },
      { defFail: false }
    )
      .then(() => {
        console.log('业务逻辑');
      })
      .catch((e: ResponseApi) => {
        this.$dialog.alert({
          title: '自定义错误',
          message: e.msg
        });
      });
  }

  // 自定义业务错误
  public handleCodeError(): void {
    this.$api.xHttp.get(this.$interface.demo.area.city, { provinceId: '1' }, { defEx: false }).then((data: []) => {
      if (!data || data.length < 1) {
        this.$dialog.alert({
          title: '自定义错误',
          message: '暂无数据'
        });
      }
    });
  }

  // 自定义出参格式
  public async handleFormartData(): Promise<void> {
    const res: ResponseApi = await this.$api.xHttp.get(this.$interface.demo.area.province, null, null, { defData: false });
    if (res && res.code === 200) {
      const data: any = res.data;
      this.$tip.show(`${ data[0].provinceId }-${ data[0].provinceName }`);
    }
  }

  // 并发调用
  public async handleAll(): Promise<void> {
    const pro = this.$api.xHttp.get(this.$interface.demo.area.province, null, null);
    const sex = this.$api.xHttp.get(this.$interface.demo.sex, null, null);

    const res = await this.$api.xHttp.all([pro, sex]);
    this.$tip.show('请求成功');
    console.log(' res:', res);
  }

  // 连续调用
  public async handleContinue(): Promise<void> {
    this.$api.xHttp.get(this.$interface.demo.area.province, null, null).then((res: any) => {
      this.$api.xHttp.get(this.$interface.demo.area.city, { provinceId: res[0].provinceId }).then((res1: any) => {
        this.$tip.show(`${ res1[0].cityId }-${ res1[0].cityName }`);
      });
    });
  }

  // get请求
  public handleSubmit(): void {
    this.btnLoading = true;
    setTimeout(() => {
      this.$api.xHttp.get(this.$interface.demo.area.province, null, null, { load: false }).then((data: any) => {
        this.$tip.show(`${ data[0].provinceId }-${ data[0].provinceName }`);
        this.btnLoading = false;
      });
    }, 2000);
  }
}
</script>

<style lang="less">
.api-http-demo {
}
</style>
