<!--
* @Author : ChangJun
* @Date :  2019-06-20
* @Version : 1.0
* @Content : button
-->
<template>
  <div class="button-demo box">
    <van-button @click="handleClick" size="large" type="info">默认按钮</van-button>
    <van-button hairline plain size="large" type="info">默认按钮</van-button>
    <van-button loading loading-text="加载中..." loading-type="spinner" size="large" type="danger"/>
    <van-button size="small" type="info">小按钮</van-button>
    <br/>
    <van-button size="mini" type="info">微型按钮</van-button>
  </div>
</template>

<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';

@Component({})
export default class ButtonDemo extends Vue {
  public handleClick(): void {
    this.$utils.Log.saveEvent('001', '按钮点击', 'button');
    this.$tip.show('触发数据埋点！');
  }
}
</script>

<style lang="less">
.button-demo {
  background-color: #ffffff;
  box-sizing: border-box;
  .van-button {
    margin-top: 15px;
  }
}
</style>
