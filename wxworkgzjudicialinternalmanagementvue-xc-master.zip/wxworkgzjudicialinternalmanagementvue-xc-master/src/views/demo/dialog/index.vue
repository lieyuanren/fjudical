<!--
* @Author : ChangJun
* @Date :  2019-06-21
* @Version : 1.0
* @Content :
-->
<template>
  <div class="dialog-index">
    <van-cell-group title="弹窗">
      <van-cell @click="handleLoading()" is-link title="加载 loading"></van-cell>
      <van-cell @click="handleToast()" is-link title="Tip" value="轻提示"></van-cell>
      <van-cell @click="handleAlert()" is-link title="Alert"></van-cell>
      <van-cell @click="handleConfirm()" is-link title="Confirm"></van-cell>
      <van-cell @click="showDialog = true" is-link title="Dialog"></van-cell>
    </van-cell-group>
    <van-dialog :closeOnClickOverlay="true"
                :showConfirmButton="false"
                v-model="showDialog">
      <div style="text-align: center;padding: 12px;">
        <p style="text-align: center;margin-bottom: 12px;">诉讼风险评估</p>
        <img src="../../../assets/images/logo.png" style=" width: 100px;"/>
      </div>
      <span @click="showDialog = false" class="van-close"></span>
    </van-dialog>
  </div>
</template>

<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';
import { Mutation } from 'vuex-class';

@Component({
  name: 'DialogIndex'
})
export default class DialogIndex extends Vue {
  @Mutation('SET_LOADING')
  public setLoading!: any;
  public showDialog: boolean = false;

  public handleLoading(): void {
    this.setLoading({ show: true, msg: '请求中' });
    setTimeout(() => {
      this.setLoading({ show: false });
    }, 2000);
  }

  public handleToast(): void {
    this.$tip.show('轻提示：南京擎盾南京擎盾南京擎盾南京擎盾南京擎盾南京擎盾');
  }

  public handleAlert(): void {
    this.$dialog.alert({
      title: '提示',
      message: '提示信息！'
    });
  }

  public handleConfirm(): void {
    this.$dialog.confirm({
      title: '确认',
      message: '确认信息！'
    }).then(() => {
      this.$tip.show('点击确认');
    }).catch(() => {
      this.$tip.show('点击取消');
    });
  }
}
</script>

<style lang="less" scoped>
.dialog-index {
  background-color: #ffffff;
}
</style>
