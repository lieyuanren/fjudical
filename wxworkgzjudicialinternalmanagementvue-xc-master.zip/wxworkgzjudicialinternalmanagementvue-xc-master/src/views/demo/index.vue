<template>
  <div class="demo">
    <van-cell-group title="基础组件">
      <van-cell is-link title="按钮" to="/demo/button"/>
      <van-cell is-link title="弹窗" to="/demo/dialog"/>
    </van-cell-group>
    <van-cell-group title="下拉刷新、上拉加载">
      <van-cell is-link title="基础" to="/demo/pull-and-push"></van-cell>
      <van-cell is-link title="me-scroll" to="/demo/pull-and-push/me-scroll"></van-cell>
    </van-cell-group>
    <van-cell-group title="接口">
      <van-cell is-link title="http-api" to="/demo/http/api"/>
    </van-cell-group>
  </div>
</template>

<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';

@Component({
  components: {}
})
export default class Demo extends Vue {
}
</script>
<style lang="less" scoped>
.demo {
  height: 100%;
  background-color: #ffffff;
}
</style>
