<!--
* @Author : ChangJun
* @Date :  2019-06-24
* @Version : 1.0
* @Content :
-->
<template>
  <div class="pull-and-push-page">
    <van-pull-refresh
      @refresh="onRefresh"
      v-model="refreshing">
      <van-list
        :finished="finished"
        :offset="offset"
        @load="loadMore"
        finished-text="没有更多了"
        v-model="loading">
        <van-cell
          :key="item"
          :title="item"
          v-for="item in list"/>
      </van-list>
    </van-pull-refresh>
  </div>
</template>

<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';
import Pager from '@/model/common/global/Pager';

@Component({})
export default class PullAndPush extends Vue {
  public list: number[] = [];
  public loading: boolean = false;
  public refreshing: boolean = false;
  public finished: boolean = false;
  public offset: number = 50;
  public pager: Pager = {
    page: 1,
    pageSize: 20,
    total: 100
  };

  public getData(page: number, pageSize: number = 20): any {
    const list: number[] = Array.from(new Array(100).keys());
    let data: number[] = list.slice((page - 1) * pageSize, page * pageSize);
    return new Promise((resolve) => {
      resolve(data);
    });
  }

  public async onRefresh(): Promise<void> {
    this.pager.page = 1;
    this.list = await this.getData(this.pager.page);
    this.refreshing = false;
    this.finished = false;
    this.loading = true;
  }

  public async loadMore(): Promise<void> {
    let res = await this.getData(this.pager.page);
    this.list = this.list.concat(res);
    this.loading = false;
    this.finished = this.list.length >= this.pager.total;
    this.pager.page += 1;
  }
}
</script>

<style lang="less">
.pull-and-push-page {
}
</style>
