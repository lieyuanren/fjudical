<!--
* @Author : ChangJun
* @Date :  2019-06-22
* @Version : 1.0
* @Content :
-->
<template>
  <div class="pull-and-push-page box">
    <me-scroll-vue :down="meScrollDown" :up="meScrollUp" @init="meScrollInit" ref="baseScroll">
      <van-cell :key="i" :title="i" v-for="i in dataList"></van-cell>
    </me-scroll-vue>
  </div>
</template>

<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';
// @ts-ignore
import MeScrollVue from 'mescroll.js/mescroll.vue';

@Component({
  components: { MeScrollVue }
})
export default class PullAndPushBase extends Vue {
  public meScroll: any = null;
  public pager = {
    num: 1,
    size: 20,
    total: 0
  };
  public meScrollDown: any = {
    auto: false,
    page: {
      num: 1,
      size: 20
    },
    htmlNodata: '<p class="upwarp-nodata">无数据</p>',
    empty: {
      tip: '无更多数据'
    },
    callback: this.pushRefresh
  };
  public dataList: number[] = [];
  public meScrollUp: any = {
    page: {
      num: 1,
      size: 20
    },
    callback: this.loadMore,
    inited: this.initData,
    htmlNodata: `<p class="upwarp-nodata">-- 没有更多了 --</p>`
    // htmlLoading: `<p class="upwarp-progress mescroll-rotate"></p><p class="upwarp-tip">加载更多中..</p>`
  };

  public meScrollInit(obj: any) {
    this.meScroll = obj;
  }

  public initData(scroll: any) {
    // console.log(' scroll:', scroll);
  }

  public getData(): any {
    const list = Array.from(new Array(100).keys());
    this.pager.total = list.length;
    return new Promise((resolve) => {
      setTimeout(() => {
        let data = list.slice((this.pager.num - 1) * this.pager.size, this.pager.num * this.pager.size);
        resolve(data);
      }, 1000);
    });
  }

  public async pushRefresh(scroll: any) {
    this.pager.num = 1;
    this.dataList = [];
    scroll.resetUpScroll();
    scroll.clearDataList();
  }

  public async loadMore(page: any, scroll: any) {
    let temp = await this.getData();
    this.dataList = this.dataList.concat(temp);
    this.$nextTick(() => {
      this.pager.num += 1;
      scroll.endBySize(this.pager.size, this.pager.total + this.pager.size);
    });
  }
}
</script>

<style lang="less">
.pull-and-push-page {
  position: relative;
  .mescroll {
    position: fixed;
    top: 44px;
    left: 0;
    bottom: 0;
    height: auto;
  }
}
</style>
