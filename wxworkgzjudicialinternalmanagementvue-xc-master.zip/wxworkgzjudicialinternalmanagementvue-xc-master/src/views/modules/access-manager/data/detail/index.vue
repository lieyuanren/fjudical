<!--
 * @Author: 陈毛毛
 * @Date: 2021-03-23 10:10:42
 * @LastEditors: 陈毛毛
 * @LastEditTime: 2021-04-07 13:54:14
 * @Description: file content
-->
<template>
  <div class="detail">
    <div class="title">
      权限组消息详情
    </div>
    <div class="info" ref="info" >
      <div class="top">
        <div>权限组名称：</div>
        <div>{{data.name}}</div>
      </div>
      <div class="btm">
        <div>组内人员：</div>
        <div>
          <div style="color:#363740">{{personsList.length}}人</div>
          <div>
            <span v-for="(v, index) in personsList"
              :key="index">
            {{ v }}
            <i v-show="index !== personsList.length - 1">、</i>
            </span>
          </div>
        </div>
      </div>
      <div class="btm">
        <div>关联设备：</div>
        <div>
          <div style="color:#363740">{{deviceList.length}}个</div>
          <div>
            <span v-for="(v, index) in deviceList"
              :key="index">
            {{ v }}
            <i v-show="index !== deviceList.length - 1">、</i>
            </span>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script lang='ts'>
import { Component, Prop, Vue } from 'vue-property-decorator';
@Component
export default class AccessDetail extends Vue {
  private data: any = {};
  private personsList: any = [];
  private deviceList: any = [];

  private onLoad() {
    this.getDetail();
    this.getPersonList();
    this.getDeviceList();
  }

  private activated() {
    this.onLoad();
  }

  private async getDetail(): Promise<any> {
    let params = {
      id: Number(this.$route.query.id)
    };
    const { code, data } = await this.$api.xHttp.post(
      this.$interface.accessControlManage.controlDetail,
      params
    );
    if (code === 0) {
      this.data = data;
    }
  }

  // 人员信息
  private async getPersonList(): Promise<void> {
    let params = {
      orgId: 1,
      index: 1,
      count: 99999
    };
    let that = this;
    const { code, data } = await this.$api.xHttp.post(
        this.$interface.accessControlManage.personList,
        params
    );
    if (code === 0) {
      that.personsList = [];
      data.forEach((it: any) => {
        if (that.data.persons.indexOf(it.id) !== -1) {
          that.personsList.push(it.name);
        }
      });
    }
  }

  // 设备信息
  private async getDeviceList(): Promise<void> {
    let params = {
      orgId: 3
    };
    let that = this;
    const { code, data } = await this.$api.xHttp.post(
        this.$interface.accessControlManage.deviceList,
        params
    );
    if (code === 0) {
      that.deviceList = [];
      data.forEach((it: any) => {
        if (that.data.devices.indexOf(it.id) !== -1) {
          that.deviceList.push(it.name);
        }
      });
    }
  }

}
</script>
<style lang="less">
.detail {
  height: 100%;
  overflow: hidden;
  background: #fff;
  .title {
    font-weight: 600;
    color: #FFFFFF;
    font-size: 48px;
    width: 100%;
    height: 268px;
    background: url('../../../../../assets/images/modules/access-manager/bg.png') no-repeat;
    background-size: contain;
    padding: 40px 0 0 60px;
  }

  .info {
    position: relative;
    top: -150px;
    width: 100%;
    height: 658px;
    background: #FFFFFF;
    border-radius: 48px 48px 0px 0px;
    font-weight: 500;
    color: #363740;
    font-size: 30px;
    padding: 40px 30px;
    box-sizing: border-box;
    .top, .btm {
      display: flex;
      margin-bottom: 30px;
      :nth-child(1) {
        width: 180px;
        font-size: 30px;
        font-weight: 400;
        color: #959BA6;
        margin-right: 38px;
      }
      :nth-child(2) {
        flex: 1;
      }
    }
    .btm:nth-child(1) {
      color:#363740;
    }
  }
}
</style>
