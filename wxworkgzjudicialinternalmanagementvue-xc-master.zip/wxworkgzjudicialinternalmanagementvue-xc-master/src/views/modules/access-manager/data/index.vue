<!--
 * @Author: lilili
 * @Date:2020-07-17 16:15:00
 * @LastEditors: 陈毛毛
 * @LastEditTime: 2021-04-07 16:58:52
 * @Description: file content
 -->
<template>
  <div class="access-manager">
    <div class="appraiser-head">
      <van-search @input="handleInput"
                  placeholder="搜索权限组名称"
                  v-model="keyword" />
      <div class="access-manager-select">
        <!-- 选择部门 -->
        <div class="van-cell__value"
             style="overflow:inherit; margin-left: 18px;">
          <div class="van-field__body">
            <van-button class="showPop"
                        @click="showPop"
                        type="default">{{treeDefault}}
              <van-icon name="play"
                        color="#323233"
                        size="2" />
            </van-button>
          </div>
        </div>
      </div>
    </div>
    <!-- 数据列表 -->
    <van-pull-refresh v-model="refreshing" @refresh="onRefresh">
      <van-list v-model="loading"
                :finished="finished"
                finished-text="没有更多了"
                @load="onLoad">
        <DataCard v-for="(item,index) in cardList"
                  :item="item"
                  :key="index" />
      </van-list>
    </van-pull-refresh>
    <!-- 所有权限 -->
    <van-popup v-model="isShowPop1"
               round
               closeable
               position="bottom"
               :style="{ height: '45%' }">
      <div>
        <h4 style="position:absolute;left: 20px;top: 15px" @click="returnLevel()">返回</h4>
        <h3 style="text-align:center ">{{treeDefault}}</h3>
      </div>
      <van-tree-select name="myTree"
                       :items="items"
                       :active-id.sync="activeId"
                       :main-active-index.sync="activeIndex"
                       @click-item="clickTreeItem"
                       @click-nav="indexChange" />
    </van-popup>

  </div>
</template>

<script lang='ts'>
  import { Component, Vue, Watch } from 'vue-property-decorator';
  import DataCard from '@/components/modules/access-manager/data-card/index.vue';
  import Authority from '@/components/modules/access-manager/authority-tree/index.vue';
  // @ts-ignore
  import Common from '@/utils/common/common';

  @Component({
    components: {
      DataCard,
      Authority
    }
  })
  export default class AttendanceData extends Vue {
    // 所有部门相关
    private keyword: string = '';
    private show: boolean = false;
    private selectAccess: string = '权限组根目录';
    private orgId: any = 0;
    private selectDepartmentSub: string = ''; // 辅助存储当前选中部门name
    private selectDepartmentIdSub: any = null; // 辅助存储当前选中部门id
    private accessTreeData: any[] = [];
    // 日期选择相关
    private dateShow: boolean = false; // 控件显隐
    private selectIndex: number = 1; // 被选中select的索引
    private startTime: string = Common.dateFmt('yyyy年MM月', new Date());
    private currentDate: any = new Date();

    private timerLimit: any = null;
    // 数据列表
    private cardList: any = [];
    // 刷新
    private currentPage: number = 1;
    private pageSize: number = 10;
    private loading: boolean = false;
    private finished: boolean = true;
    private refreshing: boolean = false;

    private isShowPop1: boolean = false;
    private items: any = [];
    private orgTree: any = [];
    private orgNames: string[];
    private treeDefault: string = '权限组根目录';
    private activeId: number = 1;
    private activeIndex: number = 0;

    private showPop() {
      this.isShowPop1 = true;
    }

    private clickTreeItem(data: any) {
      if (data.children && data.children.length !== 0) {
        this.items = data.children;
      }
      this.currentPage = 1;
      console.log('clickTreeItem', data);
      this.orgNames = [];
      this.orgNames.push(data.text);
      this.orgId = data.id;
      this.dataList();
      this.treeDefault = data.text;
      this.isShowPop1 = false;
    }

    private returnLevel() {
      this.items = this.orgTree;
      this.treeDefault = '选择单位';
      this.isShowPop1 = true;
    }

    private indexChange(index: any) {
      console.log(this.items[index], 'aaaa');
      if (!this.items[index].children) {
        this.orgNames = [];
        this.orgNames.push(this.items[index].text);
        this.orgId = this.items[index].id;
        this.dataList();
        this.treeDefault = this.items[index].text;
        this.isShowPop1 = false;
      }
    }

    // ================================================

    private handleInput(): void {
      this.currentPage = 1;
      this.cardList = [];
      this.dataList();
    }

    private onRefresh(): void {
      this.finished = false;
      this.onLoad();
    }

    private async onLoad(): Promise<void> {
      this.currentPage++;
      await this.dataList();
    }

    // private async created(): Promise<void> {
    //   await this.dataList();
    // }

    // 切换显示
    private switchShow(): void {
      this.show = !this.show;
    }

    // 切换权限
    private propMsg(id: any, name: string): void {
      this.selectAccess = name;
      this.orgId = id;
    }

    // 数据列表
    private async dataList(): Promise<any> {
      let params = {
        orgId: this.orgId,
        index: this.currentPage,
        count: this.pageSize,
        keyword: this.keyword.trim()
      };
      const { code, data } = await this.$api.xHttp.post(
          this.$interface.accessControlManage.dataList,
          params
      );
      this.refreshing = false;
      this.loading = false;
      if (code === 0) {
        const records = data.list;
        if (records === null || records.length === 0) {
          this.finished = true;
          return;
        }
        if (records.length < this.pageSize) {
          this.finished = true;
        }
        if (this.currentPage === 1) {
          this.cardList = records;
        } else {
          this.cardList.push(...records);
        }
      } else {
        this.$toast('查询失败！');
      }
    }

    /**
     * 日期选择相关
     */
    private selectShow(index: number): void {
      this.selectIndex = index;
      this.dateShow = true;
    }
    private onCancel(): void {
      this.dateShow = false;
    }
    private onConfirmDate(value: any): void {
      const news = new Date(value).getTime();
      this.startTime = Common.dateFmt('yyyy年MM月', new Date(value));
      this.dateShow = false;
    }

    private activated() {
      this.accessList();
      this.orgId = 2;
      this.currentPage = 1;
      this.dataList();
    }


    // 权限列表
    private async accessList(): Promise<void> {
      let params = {
        type: 1
      };
      const { code, data } = await this.$api.xHttp.post(
          this.$interface.accessControlManage.accessList,
          params
      );
      if (code === 0) {
        let dataStr = JSON.stringify(data);
        dataStr = dataStr.replace(/name/g, 'text');
        // dataStr = dataStr.replace(/childrenList/g, 'children');
        // dataStr = dataStr.replace(/organizationId/g, 'id');
        this.items = [JSON.parse(dataStr)];
        this.orgTree = [JSON.parse(dataStr)];
      }
    }

    // @Watch('startTime')
    // private async watchStartTime(): Promise<void> {
    //   this.refreshing = true;
    //   this.onRefresh();
    // }

    // 监听部门弹窗关闭时获取最新部门id以及数据
    // @Watch('show')
    // private async watchDepartmentShow(): Promise<void> {
    //   if (!this.show) {
    //     this.selectDepartmentSub &&
    //       (this.selectAccess = this.selectDepartmentSub);
    //     this.refreshing = true;
    //     this.onRefresh();
    //   }
    // }
  }
</script>

<style lang='less' scoped>
  .access-manager {
    &-head {
      background-color: #ffffff;
    }
    .tips {
      font-size: 24px;
      color: rgba(153, 153, 153, 1);
      padding: 30px;
    }
    &-select {
      display: flex;
      justify-content: space-between;
      background: #fff;
      padding: 0 0.4rem 0.2rem;
      font-size: 0.37333rem;
      .show-btn {
        color: #666666;
        span,
        i {
          vertical-align: middle;
        }

        span {
          margin-right: 8px;
        }
      }
      .department-name {
        height: 0.88rem;
        line-height: 0.88rem;
      }
    }
    .time-select {
      width: 260px;
      height: 66px;
      border-radius: 8px;
      border: 1px solid #ffffff;
      margin-left: 60px;
      display: flex;
      align-items: center;
      justify-content: flex-end;
      &:nth-child(3) {
        margin-left: 28px;
      }

      span {
        padding-right: 8px;
      }
      span,
      i {
        vertical-align: middle;
      }
    }
    .title {
      font-size: 32px;
      font-weight: 500;
      color: #363740;
      text-align: center;
      height: 104px;
      line-height: 104px;
    }
  }

  .van-hairline--top-bottom::after,
  .van-hairline-unset--top-bottom::after {
    border: none;
  }

  .van-search {
    padding: 30px;
  }
  .van-divider {
    margin: 0 0 10px;
  }

  .showPop.van-button--default {
    border: none;
    width: 100%;
    height: 1.28rem;
    z-index: 99;
    .van-icon-play {
      transform: rotate(90deg);
    }
  }
  .van-popup {
    overflow: hidden;
    h3 {
      font-size: 0.39rem;
      text-align: center;
      padding: 25px 0;
      color: #363740;
      border-bottom: 1px solid #eee;
    }
  }
  .van-tree-select {
    height: calc(100% - 1.25rem) !important;
  }
</style>
