<!--
 * @Author: lilili
 * @Date:2020-07-17 16:15:00
 * @LastEditors: 陈毛毛
 * @LastEditTime: 2021-04-07 14:36:46
 * @Description: file content
 -->
<template>
  <div class="internal-control">
    <div class="internal-control-body">
      <transition name="outIn"
                  mode="out-in">
        <keep-alive>
          <component :is="componentId[active]"></component>
        </keep-alive>
      </transition>
    </div>
    <div class="internal-control-menu">
      <van-tabbar v-model="active">
        <van-tabbar-item>
          <span>权限组信息</span>
          <img :src="props.active ? menuIcon.homeActive : menuIcon.homeInactive"
               class="internal-control-menu-icon"
               slot="icon"
               slot-scope="props" />
        </van-tabbar-item>
        <van-tabbar-item>
          <span>通行记录</span>
          <img :src="props.active ? menuIcon.recordActive : menuIcon.recordInactive"
               class="internal-control-menu-icon"
               slot="icon"
               slot-scope="props" />
        </van-tabbar-item>
      </van-tabbar>
    </div>
  </div>
</template>

<script lang='ts'>
import { Component, Vue } from 'vue-property-decorator';
import Data from './data/index.vue';
import DataDetail from './data/detail/index.vue';
import Record from './record/index.vue';

@Component({
  components: {
    Data,
    Record,
    DataDetail
  }
})
export default class InternalControl extends Vue {
  // 底部菜单图标
  private menuIcon: any = {
    homeActive: require('../../../assets/images/modules/access-manager/tabs/icon01-sel.png'),
    homeInactive: require('../../../assets/images/modules/access-manager/tabs/icon01.png'),
    recordActive: require('../../../assets/images/modules/access-manager/tabs/icon02-sel.png'),
    recordInactive: require('../../../assets/images/modules/access-manager/tabs/icon02.png')
  };
  private active: number = 0;

  // 组件名
  private componentId: string[] = ['Data', 'Record'];

  private created(): void {
    // this.checkAuth();
  }

  private async checkAuth() {
    // 权限校验
    const { code, data } = await this.$api.xHttp.post(
        this.$interface.accessManager.checkAuth,
        {}
    );
  }
}
</script>

<style lang='less' scoped>
.internal-control {
  height: 100%;
  overflow: hidden;

  &-menu {
    height: 102px;
    &-icon {
      height: 56px;
      width: 56px;
    }
  }
}

.outIn-enter,
.outIn-leave-to {
  opacity: 0;
}

.outIn-enter-active,
.outIn-leave-active {
  transition: opacity 0.3s;
}

.van-tabbar {
  height: 132px;
}
</style>

