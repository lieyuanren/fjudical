<!--
 * @Author: lilili
 * @Date:2020-07-17 16:15:00
 * @LastEditors: 陈毛毛
 * @LastEditTime: 2021-04-07 17:13:47
 * @Description: file content
 -->
 <template>
  <div class="attendance-manage">
    <div class="attendance-manage-head">
      <van-search @input="handleInput"
                  placeholder="搜索人员姓名"
                  v-model="keyword" />
      <div class="attendance-manage-select">
        <!-- 选择部门 -->
        <div class="van-cell__value"
             style="overflow:inherit;">
          <div class="van-field__body">
            <van-button class="show-btn department-name"
                        @click="showPop"
                        type="default">{{treeDefault}}
              <van-icon name="arrow-down"
                        color="#323233"
                        size="2" />
            </van-button>
          </div>
        </div>
        <!-- 选择月份 -->
        <div @click="selectShow(1)"
             class="time-select">
          <span>起止时间选择</span>
          <van-icon name="arrow-down" />
        </div>
      </div>
    </div>
    <!-- 记录列表 -->
    <van-pull-refresh v-model="refreshing"
                      @refresh="onRefresh">
      <van-list v-model="loading"
                :finished="finished"
                finished-text="没有更多了"
                @load="onLoad">
        <RecordCard v-for="(item,index) in cardList"
                    :item="item"
                    :key="index"
                    class="record-card" />
      </van-list>
    </van-pull-refresh>

    <!-- selectAccess -->
    <van-popup v-model="isShowPop1"
               round
               closeable
               position="bottom"
               :style="{ height: '45%' }">
      <div>
        <h4 style="position:absolute;left: 20px;top: 15px" @click="returnLevel()">返回</h4>
        <h3 style="text-align:center ">选择设备</h3>
      </div>
      <van-tree-select name="myTree"
                       :items="items"
                       :active-id.sync="activeId"
                       :main-active-index.sync="activeIndex"
                       @click-item="clickTreeItem"
                       @click-nav="indexChange" />
    </van-popup>
    <!-- 日期选择框 -->
    <van-popup :style="{ height: '50%' }"
               position="bottom"
               closeable
               v-model="dateShow">
      <div class="show-time-area">
        <div class="start">
          <div v-if="startTime">
            <div class="time" :class="{ 'choose' : showStartTime }">开始时间</div>
            <div class="text" @click="setTime(1)">{{startTime}}</div>
          </div>
          <div v-else class="no-time no-time-start">
            开始时间
          </div>
        </div>
        <div class="end">
          <div v-if="endTime">
            <div class="time" :class="{ 'choose' : showEndTime }">结束时间</div>
            <div class="text" @click="setTime(2)">{{endTime}}</div>
          </div>
         <div v-else class="no-time no-time-end">
            结束时间
         </div>
        </div>
      </div>
      <van-datetime-picker type="datetime"
                           :show-toolbar="false"
                           :formatter="formatter"
                           @change="dateChange"
                           v-model="currentDate"/>
      <div class="cBtn" @click="confirmTime">确定</div>
    </van-popup>
  </div>
</template>

<script lang='ts'>
import { Component, Vue, Watch } from 'vue-property-decorator';
import RecordCard from '@/components/modules/access-manager/record-card/index.vue';
import Authority from '@/components/modules/access-manager/authority-tree/index.vue';
// @ts-ignore
import Common from '@/utils/common/common';

@Component({
  components: {
    RecordCard,
    Authority
  }
})
export default class RecordList extends Vue {
  // 所有部门相关
  private keyword: string = '';
  private show: boolean = false;
  private selectAccess: string = '权限组根目录';
  private selectDepartmentId: any = null;
  private selectDepartmentSub: string = ''; // 辅助存储当前选中部门name
  private selectDepartmentIdSub: any = null; // 辅助存储当前选中部门id
  private accessTreeData: any[] = [];
  // 日期选择相关
  private dateShow: boolean = false; // 控件显隐
  private selectIndex: number = 1; // 被选中select的索引
  // private startTime: string = Common.dateFmt('yyyy-MM-dd hh:mm', new Date());
  private endTime: string = '';
  private startTime: string = '';
  private currentDate: any = new Date();
  private timerLimit: any = null;
  private count: number = 0;
  private selectedTime: string = Common.dateFmt('yyyy-MM-dd hh:mm', new Date());
  private showStartTime: boolean = false;
  private showEndTime: boolean = false;
  // 数据列表
  private cardList: any = [];
  // 刷新
  private currentPage: number = 1;
  private pageSize: number = 10;
  private loading: boolean = false;
  private finished: boolean = false;
  private refreshing: boolean = false;
  // 请求数据
  private orgId: any = null;


  private isShowPop1: boolean = false;
  private items: any = [];
  private orgTree: any = [];
  private orgNames: string[];
  private treeDefault: string = '设备根目录';
  private activeId: number = 1;
  private activeIndex: number = 0;

  private showPop() {
    this.isShowPop1 = true;
  }

  private clickTreeItem(data: any) {
    if (data.children && data.children.length !== 0) {
      this.items = data.children;
    }
    this.currentPage = 1;
    console.log('clickTreeItem', data);
    this.orgNames = [];
    this.orgNames.push(data.text);
    this.orgId = data.id;
    this.recordList();
    this.treeDefault = data.text;
    this.isShowPop1 = false;
  }

  private returnLevel() {
    this.items = this.orgTree;
    this.treeDefault = '选择单位';
    this.isShowPop1 = true;
  }

  private indexChange(index: any) {
    console.log(this.items[index], 'aaaa');
    if (!this.items[index].children) {
      this.orgNames = [];
      this.orgNames.push(this.items[index].text);
      this.orgId = this.items[index].id;
      this.recordList();
      this.treeDefault = this.items[index].text;
      this.isShowPop1 = false;
    }
  }

  // 切换显示，将临时值赋给查询对象
  private onConfirm(): void {
    this.show = !this.show;
  }

  // 切换显示
  private switchShow(): void {
    this.show = !this.show;
  }

  // 开门日志记录列表
  private async recordList(): Promise<any> {
    let params = {
      index: this.currentPage,
      count: this.pageSize,
      end_time: this.endTime ? this.endTime.replace(/\./g, '-') + ':00' : '',
      start_time: this.startTime ? this.startTime.replace(/\./g, '-') + ':00' : '',
      deviceIds: this.orgId === null ? [] : [this.orgId],
      keyword: this.keyword.trim()
    };
    const { code, data } = await this.$api.xHttp.post(
      this.$interface.accessControlManage.recordList,
      params
    );
    this.refreshing = false;
    this.loading = false;
    if (code === 0) {
      const records = data.list;
      records.forEach((it: any) => {
        it.photo_path_view = 'http://192.168.120.100:8080/' + it.photo_path_view;
      });
      if (records === null || records.length === 0) {
        this.finished = true;
        return;
      }
      if (records.length < this.pageSize) {
        this.finished = true;
      }
      if (this.currentPage === 1) {
        this.cardList = records;
      } else {
        this.cardList.push(...records);
      }
    } else {
      this.$toast('查询失败！');
    }
  }
  // 切换部门
  private propMsg(id: any, name: string, show: boolean): void {
    this.selectAccess = name;
    this.orgId = id;
  }

  /**
   * 日期选择相关
   */
  private selectShow(index: number): void {
    this.selectIndex = index;
    this.dateShow = true;
    this.count = 0;
  }

  private dateChange(value: any): void {
    const news = value.getValues();
    this.selectedTime = news.join('').replace('年', '.').replace('月', '.').replace('日', ' ').replace('时', ':').replace('分', '');
  }

  private formatter(type: any, val: any): string {
      if (type === 'year') {
        return `${val}年`;
      } else if (type === 'month') {
        return `${val}月`;
      } else if (type === 'day') {
        return `${val}日`;
      } else if (type === 'hour') {
        return `${val}时`;
      } else if (type === 'minute') {
        return `${val}分`;
      }
      return val;
  }

  private confirmTime(): void {
    this.count ++;
    if (this.count === 1) {
      this.startTime = this.selectedTime;
    } else if (this.count === 2) {
      this.endTime = this.selectedTime;
    } else {
      this.dateShow = false;
      this.currentPage = 1;
      this.cardList = [];
      this.recordList();
    }
  }

  private setTime(val: any): void {
    if (val === 1) {
      this.count = 0;
      this.showEndTime = false;
      this.showStartTime = true;
    } else {
      this.count = 1;
      this.showEndTime = true;
      this.showStartTime = false;
    }
  }

  private handleInput(): void {
    this.currentPage = 1;
    this.cardList = [];
    this.recordList();
  }

  private onRefresh(): void {
    this.finished = false;
    this.onLoad();
  }

  private async onLoad(): Promise<void> {
    this.currentPage++;
    await this.recordList();
  }

  private async created() {
    window.sessionStorage.removeItem('selectedDepartment'); // 清除已选部门缓存
    // this.selectAccess = 'selectAccess';
    this.selectDepartmentId = null;
    this.accessTreeData = [];
    this.items = [];
    // this.onRefresh();
    this.recordList();
    this.accessList();
  }

  // 权限列表
  private async accessList(): Promise<void> {
    let params = {
      type: 2
    };
    const { code, data } = await this.$api.xHttp.post(
      this.$interface.accessControlManage.equipmentList,
      params
    );
    if (code === 0) {
      let dataStr = JSON.stringify(data);
      dataStr = dataStr.replace(/name/g, 'text');
      this.items = JSON.parse(dataStr).children;
      this.orgTree = [JSON.parse(dataStr)];
    }
  }



  // @Watch('startTime')
  // private async watchStartTime(): Promise<void> {
  //   this.refreshing = true;
  //   this.recordList();
  // }

  // 监听部门弹窗关闭时获取最新部门id以及数据
  // @Watch('show')
  // private async watchDepartmentShow(): Promise<void> {
  //   if (!this.show) {
  //     this.selectDepartmentSub &&
  //       (this.selectAccess = this.selectDepartmentSub);
  //     this.selectDepartmentIdSub &&
  //       (this.selectDepartmentId = this.selectDepartmentIdSub);
  //     this.refreshing = true;
  //     this.onRefresh();
  //   }
  // }
}
</script>

<style lang='less' scoped>
.attendance-manage {
  &-head {
    background-color: #ffffff;
    margin-bottom: 20px;
  }
  .tips {
    font-size: 24px;
    color: rgba(153, 153, 153, 1);
    padding: 30px;
  }
  &-select {
    display: flex;
    justify-content: space-between;
    background: #fff;
    padding: 0 0.4rem 0.2rem;
    font-size: 0.37333rem;
    .show-btn {
      color: #666666;
      span,
      i {
        vertical-align: middle;
      }

      span {
        margin-right: 8px;
      }
    }
    .department-name {
      height: 0.88rem;
      line-height: 0.88rem;
    }
  }
  .time-select {
    width: 260px;
    height: 66px;
    border-radius: 8px;
    border: 1px solid #ffffff;
    margin-left: 60px;
    display: flex;
    align-items: center;
    justify-content: flex-end;
    &:nth-child(3) {
      margin-left: 28px;
    }

    span {
      padding-right: 8px;
    }
    span,
    i {
      vertical-align: middle;
    }
  }
  .show-time-area {
    display: flex;
    justify-content: space-between;
    padding: 10px 20px;
    margin-bottom: 20px;
    margin-top: 60px;
    .start,.end {
      .time {
        font-size: 24px;
        font-weight: 400;
        color: #959BA6;
        line-height: 34px;
        margin-bottom: 8px;
      }
      .text {
        font-weight: 400;
        color: #363740;
        line-height: 50px;
        font-size: 36px;
      }
    }
  }

  .choose {
    color: #3770EB !important;
  }
  .cBtn{
    width: 90%;
    height: 92px;
    background: #3770EB;
    border-radius: 46px;
    font-size: 32px;
    font-weight: 500;
    color: #FFFFFF;
    line-height: 92px;
    text-align: center;
    margin: 20px auto 0;
  }
  .no-time {
    font-size: 32px;
    font-weight: 500;
    color: #3770EB;
    padding-left: 20px;
  }
  .no-time-start {
    padding-left: 40px;
  }
  .no-time-end {
    padding-right: 40px;
  }
  .title {
    font-size: 32px;
    font-weight: 500;
    color: #363740;
    text-align: center;
    height: 104px;
    line-height: 104px;
  }
}

.van-hairline--top-bottom::after,
.van-hairline-unset--top-bottom::after {
  border: none;
}

.van-search {
  padding: 30px;
}

.showPop.van-button--default {
  border: none;
  width: 100%;
  height: 1.28rem;
  z-index: 99;
  .van-icon-play {
    transform: rotate(90deg);
  }
}
.van-popup {
  overflow: hidden;
  h3 {
    font-size: 0.39rem;
    text-align: center;
    padding: 25px 0;
    color: #363740;
    border-bottom: 1px solid #eee;
  }
}
.van-tree-select {
  height: calc(100% - 1.25rem) !important;
}
</style>
