<template>
  <div class="attendance-detail">
    <p v-for="(item, index) in list"
       :key="index">{{ item.date }}({{item.result}})</p>
  </div>
</template>
<script lang='ts'>
import { Component, Prop, Vue } from 'vue-property-decorator';
@Component
export default class AttendanceDetail extends Vue {
  private list: any[] = [];
  // 异常列表
  private async created() {
    this.list = JSON.parse(window.sessionStorage.getItem('errorDetail') || '');
  }
}
</script>
<style lang="less">
.attendance-detail {
  font-size: 28px;
  color: #999;
  padding-top: 20px;
  p {
    background: #fff;
    padding: 28px 20px;
  }
  p + p {
    border-top: 1px solid #eee;
  }
}
</style>