<!--
 * @Author: lilili
 * @Date:2020-07-17 16:15:00
 * @LastEditors: lilili
 * @LastEditTime: 2020-07-17 16:15:00
 * @Description: file content
 -->
<template>
  <div class="internal-control">
    <div class="internal-control-body">
      <transition name="outIn"
                  mode="out-in">
        <component :is="componentId[active]"></component>
      </transition>
    </div>
    <div class="internal-control-menu">
      <van-tabbar v-model="active">
        <van-tabbar-item>
          <span>考勤数据</span>
          <img :src="props.active ? menuIcon.homeActive : menuIcon.homeInactive"
               class="internal-control-menu-icon"
               slot="icon"
               slot-scope="props" />
        </van-tabbar-item>
        <van-tabbar-item>
          <span>打卡记录</span>
          <img :src="props.active ? menuIcon.recordActive : menuIcon.recordInactive"
               class="internal-control-menu-icon"
               slot="icon"
               slot-scope="props" />
        </van-tabbar-item>
        <van-tabbar-item>
          <span>数据统计</span>
          <img :src="props.active ? menuIcon.assessActive : menuIcon.assessInactive"
               class="internal-control-menu-icon"
               slot="icon"
               slot-scope="props" />
        </van-tabbar-item>
      </van-tabbar>
    </div>
  </div>
</template>

<script lang='ts'>
import { Component, Vue } from 'vue-property-decorator';
import Data from './data/index.vue';
import Record from './record/index.vue';
import Statistics from './statistics/index.vue';

@Component({
  components: {
    Data,
    Record,
    Statistics
  }
})
export default class InternalControl extends Vue {
  // 底部菜单图标
  private menuIcon: any = {
    homeActive: require('../../../assets/images/modules/attendance-manage/tabs/icon01-sel.png'),
    homeInactive: require('../../../assets/images/modules/attendance-manage/tabs/icon01.png'),
    recordActive: require('../../../assets/images/modules/attendance-manage/tabs/icon02-sel.png'),
    recordInactive: require('../../../assets/images/modules/attendance-manage/tabs/icon02.png'),
    assessActive: require('../../../assets/images/modules/attendance-manage/tabs/icon03-sel.png'),
    assessInactive: require('../../../assets/images/modules/attendance-manage/tabs/icon03.png')
  };

  private active: number = 0;

  // 组件名
  private componentId: string[] = ['Data', 'Record', 'Statistics'];
}
</script>

<style lang='less' scoped>
.internal-control {
  height: 100%;

  &-menu {
    height: 92px;
    &-icon {
      height: 44px;
      width: 44px;
    }
  }
}

.outIn-enter,
.outIn-leave-to {
  opacity: 0;
}

.outIn-enter-active,
.outIn-leave-active {
  transition: opacity 0.3s;
}
</style>
 
