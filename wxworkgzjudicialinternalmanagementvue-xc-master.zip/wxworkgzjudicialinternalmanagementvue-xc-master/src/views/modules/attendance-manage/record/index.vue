<!--
 * @Author: lilili
 * @Date:2020-07-17 16:15:00
 * @LastEditors: lilili
 * @LastEditTime: 2020-07-17 16:15:00
 * @Description: file content
 -->
 <template>
  <div class="attendance-manage">
    <div class="attendance-manage-head">
      <van-search @input="handleInput"
                  placeholder="搜索姓名"
                  v-model="keyword" />
      <div class="attendance-manage-select">
        <!-- 选择部门 -->
        <!--<div class="van-cell__value"-->
             <!--style="overflow:inherit;">-->
          <!--<div class="van-field__body">-->
            <!--<div @click="switchShow"-->
                 <!--class="show-btn department-name">-->
              <!--<span>{{ selectDepartment }}</span>-->
              <!--<van-icon name="arrow-down" />-->
            <!--</div>-->
          <!--</div>-->
        <!--</div>-->
        <van-col span="12">
          <van-button class="showPop"
                      @click="showPop"
                      type="default">{{treeDefault}}
            <van-icon name="play"
                      color="#323233"
                      size="2" />
          </van-button>
        </van-col>
        <!-- 选择单位-弹出层 -->
        <van-popup v-model="isShowPop1"
                   round
                   closeable
                   position="bottom"
                   :style="{ height: '45%' }">
          <div>
            <h4 style="position:absolute;left: 20px;top: 15px" @click="returnLevel()">返回</h4>
            <h3 style="text-align:center ">{{treeDefault}}</h3>
          </div>
          <van-tree-select name="myTree"
                           :items="items"
                           :active-id.sync="activeId"
                           :main-active-index.sync="activeIndex"
                           @click-item="clickTreeItem"
                           @click-nav="indexChange" />
        </van-popup>
        <!-- 选择月份 -->
        <div @click="selectShow(1)"
             class="time-select">
          <span>{{ startTime }}</span>
          <van-icon name="arrow-down" />
        </div>
      </div>
    </div>
    <!-- 记录列表 -->
    <van-pull-refresh v-model="refreshing"
                      @refresh="onRefresh">
      <van-list v-model="loading"
                :finished="finished"
                finished-text="没有更多了"
                @load="onLoad">
        <RecordCard v-for="(item,index) in cardList"
                    :item="item"
                    :key="index"
                    class="record-card" />
      </van-list>
    </van-pull-refresh>
    <!-- <p class="tips">满足当前条件：{{ cardList.length }}条数据</p> -->

    <!--&lt;!&ndash; 所有部门 &ndash;&gt;-->
    <!--<van-popup v-model="show"-->
               <!--@click-overlay="switchShow"-->
               <!--close-icon="close"-->
               <!--closeable-->
               <!--:style="{ height: '60%' }"-->
               <!--position="bottom">-->
      <!--&lt;!&ndash; <Tree></Tree> &ndash;&gt;-->
      <!--<DepartmentTree :data="departmentTreeData"-->
                      <!--:isShow.sync="show"-->
                      <!--@bindSend="propMsg" />-->
    <!--</van-popup>-->
    <!-- 日期选择框 -->
    <van-popup :style="{ height: '40%' }"
               position="bottom"
               v-model="dateShow">
      <van-datetime-picker @cancel="onCancel"
                           @confirm="onConfirmDate"
                           type="year-month"
                           v-model="currentDate" />
    </van-popup>
  </div>
</template>

<script lang='ts'>
import { Component, Vue, Watch } from 'vue-property-decorator';
import RecordCard from '@/components/modules/attendance-manage/record-card/index.vue';
import DepartmentTree from '@/components/modules/attendance-manage/department-tree/index.vue';
// @ts-ignore
import Common from '@/utils/common/common';

@Component({
  components: {
    RecordCard,
    DepartmentTree
  }
})
export default class AttendanceRecord extends Vue {
  // 所有部门相关
  private keyword: string = '';
  private pageIndex: number = 1;
  private columns: string[] = [];
  private show: boolean = false;
  private selectDepartment: string = '所有部门';
  private selectDepartmentId: any = null;
  private selectDepartmentSub: string = ''; // 辅助存储当前选中部门name
  private selectDepartmentIdSub: any = null; // 辅助存储当前选中部门id
  private departmentTreeData: any[] = [];
  // 日期选择相关
  private dateShow: boolean = false; // 控件显隐
  private selectIndex: number = 1; // 被选中select的索引
  private startTime: string = Common.dateFmt('yyyy年MM月', new Date());
  private currentDate: any = new Date();
  private timerLimit: any = null;
  // 数据列表
  private cardList: any = [];
  // 刷新
  private currentPage: number = 1;
  private pageSize: number = 10;
  private loading: boolean = false;
  private finished: boolean = false;
  private refreshing: boolean = false;
  private treeDefault: string = '选择单位';
  private isShowPop1: boolean = false;
  private activeId: number = 1;
  private activeIndex: number = 0;
  private items: any = [];
  private orgTree: any = [];
  private orgList: number[];

  // 切换显示，将临时值赋给查询对象
  public onConfirm(): void {
    this.show = !this.show;
  }

  /**
   * 所有部门选择
   */

  // 切换显示
  private switchShow(): void {
    this.show = !this.show;
    // 部门列表
    this.show && this.departmentList();
  }
  // 部门列表
  private async departmentList(): Promise<void> {
    const res = await this.$api.xHttp.get(
      this.$interface.attendanceManage.department
    );
    if (res.code === 0) {
      this.departmentTreeData = [
        { id: null, name: '所有部门', parent: res.data[0].parent },
        ...res.data
      ];
    }
  }
  // 打卡记录列表
  private async attendanceList(): Promise<any> {
    const name = this.keyword;
    const time = this.startTime.replace('年', '-').replace('月', '');
    let params = {
      name: this.keyword,
      time,
      pageIndex: this.currentPage,
      pageSize: 10,
      orgList: this.orgList
    };
    const { code, data } = await this.$api.xHttp.post(
      this.$interface.attendanceManage.checkin,
      params
    );
    if (code === 0) {
      if (this.currentPage === 1) {
        this.cardList = [];
      }

      this.cardList.push(...data.records);
      this.loading = false;
      this.currentPage++;
      this.refreshing = false;
      this.finished = this.cardList.length === data.total; // 全部数据加载完成后停止懒加载
    }
  }
  // 切换部门
  private propMsg(id: any, name: string, show: boolean): void {
    this.show = show;
    this.selectDepartmentSub = name;
    this.selectDepartmentIdSub = id;
  }

  /**
   * 日期选择相关
   */
  private selectShow(index: number): void {
    this.selectIndex = index;
    this.dateShow = true;
  }
  private onCancel(): void {
    this.dateShow = false;
  }
  private onConfirmDate(value: any): void {
    const news = new Date(value).getTime();
    this.startTime = Common.dateFmt('yyyy年MM月', new Date(value));
    this.dateShow = false;
    this.currentPage = 1;
  }

  private async created() {
    this.getOrgList();
  }
  /**
   * 上拉刷新
   */
  private onLoad() {
    if (this.refreshing) {
      this.refreshing = false;
      this.cardList = [];
    }
    this.attendanceList();
  }

  private onRefresh() {
    this.currentPage = 1;
    // 清空列表数据
    this.finished = false;
    // 重新加载数据
    // 将 loading 设置为 true，表示处于加载状态
    this.loading = true;
    this.onLoad();
  }

  // 关键字搜索
  private handleInput(): void {
    clearTimeout(this.timerLimit);
    this.timerLimit = setTimeout(async () => {
      this.currentPage = 1;
      this.attendanceList();
    }, 1000);
  }

  @Watch('startTime')
  private async watchStartTime(): Promise<void> {
    this.refreshing = true;
    this.attendanceList();
  }

  // 监听部门弹窗关闭时获取最新部门id以及数据
  @Watch('show')
  private async watchDepartmentShow(): Promise<void> {
    if (!this.show) {
      this.selectDepartmentSub &&
        (this.selectDepartment = this.selectDepartmentSub);
      this.selectDepartmentIdSub &&
        (this.selectDepartmentId = this.selectDepartmentIdSub);
      this.refreshing = true;
      this.onRefresh();
    }
  }


  private async getOrgList(): Promise<void> {
    const res = await this.$api.xHttp.get(
      this.$interface.attendanceManage.department
    );
    if (res.code === 0) {
      let dataStr = JSON.stringify(res.data);
      dataStr = dataStr.replace(/name/g, 'text');
      dataStr = dataStr.replace(/children/g, 'children');
      dataStr = dataStr.replace(/id/g, 'id');
      this.items = [JSON.parse(dataStr)];
      this.orgTree = [JSON.parse(dataStr)];
    }
  }

  private clickTreeItem(data: any) {
    if (data.children.length !== 0) {
      this.items = data.children;
    }
    this.currentPage = 1;
    this.orgList = [];
    this.orgList.push(data.id);
    this.attendanceList();
    this.treeDefault = data.text;
    this.isShowPop1 = false;
  }

  private returnLevel() {
    this.items = this.orgTree;
    this.treeDefault = '选择单位';
    this.orgList = [];
    this.isShowPop1 = true;
  }
  private indexChange(index: any) {
    if (this.items[index].children.length === 0) {
      this.orgList = [];
      this.orgList.push(this.items[index].id);
      this.currentPage = 1;
      this.attendanceList();
      this.treeDefault = this.items[index].text;
      this.isShowPop1 = false;
    }
  }
  private showPop() {
    this.isShowPop1 = true;

  }

}
</script>

<style lang='less' scoped>
.attendance-manage {
  &-head {
    background-color: #ffffff;
    margin-bottom: 20px;
  }
  .tips {
    font-size: 24px;
    color: rgba(153, 153, 153, 1);
    padding: 30px;
  }
  &-select {
    display: flex;
    justify-content: space-between;
    background: #fff;
    padding: 0 0.4rem 0.2rem;
    font-size: 0.37333rem;
    .show-btn {
      color: #666666;
      span,
      i {
        vertical-align: middle;
      }

      span {
        margin-right: 8px;
      }
    }
    .department-name {
      height: 0.88rem;
      line-height: 0.88rem;
    }
  }
  .time-select {
    width: 260px;
    height: 66px;
    border-radius: 8px;
    border: 1px solid #ffffff;
    margin-left: 60px;
    display: flex;
    align-items: center;
    justify-content: flex-end;
    &:nth-child(3) {
      margin-left: 28px;
    }

    span {
      padding-right: 8px;
    }
    span,
    i {
      vertical-align: middle;
    }
  }
}

.van-hairline--top-bottom::after,
.van-hairline-unset--top-bottom::after {
  border: none;
}

.van-search {
  padding: 30px;
}


.showPop.van-button--default {
  border: none;
  width: 100%;
  height: 1.28rem;
  z-index: 99;
  .van-icon-play {
    transform: rotate(90deg);
  }
}
.van-popup {
  overflow: hidden;
  h3 {
    font-size: 0.39rem;
    text-align: center;
    padding: 25px 0;
    color: #363740;
    border-bottom: 1px solid #eee;
  }
}
.van-tree-select {
  height: calc(100% - 1.25rem) !important;
}
.van-button {
  text-align: left;
}
</style>
