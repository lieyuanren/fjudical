<!--
 * @Author: lilili
 * @Date:2020-07-17 16:15:00
 * @LastEditors: lilili
 * @LastEditTime: 2020-07-17 16:15:00
 * @Description: file content
 -->
 <template>
  <div class="attendance-manage">
    <div class="attendance-manage-head">
      <div class="attendance-manage-select">
        <!-- 选择部门 -->
        <div class="van-cell__value"
             style="overflow:inherit;">
          <div class="van-field__body">
            <div @click="showPop"
                 class="show-btn department-name">
              <span>{{ treeDefault }}</span>
              <i class="select-icon"></i>
            </div>
          </div>
        </div>
        <!-- 选择月份 -->
        <div @click="selectShow(1)"
             class="time-select">
          <span>{{ startTime }}</span>
          <i class="select-icon"></i>
        </div>
      </div>
    </div>
    <!-- 图表 -->
    <StatisticsChart :data="data" />

    <!-- 所有部门 -->
    <!-- 选择单位-弹出层 -->
    <van-popup v-model="isShowPop1"
               round
               closeable
               position="bottom"
               :style="{ height: '45%' }">
      <div>
        <h4 style="position:absolute;left: 20px;top: 15px" @click="returnLevel()">返回</h4>
        <h3 style="text-align:center ">{{treeDefault}}</h3>
      </div>
      <van-tree-select name="myTree"
                       :items="items"
                       :active-id.sync="activeId"
                       :main-active-index.sync="activeIndex"
                       @click-item="clickTreeItem"
                       @click-nav="indexChange" />
    </van-popup>
    <!--<van-popup v-model="show"-->
               <!--@click-overlay="switchShow"-->
               <!--close-icon="close"-->
               <!--closeable-->
               <!--:style="{ height: '60%' }"-->
               <!--position="bottom">-->
      <!--&lt;!&ndash; <Tree></Tree> &ndash;&gt;-->
      <!--<DepartmentTree :data="departmentTreeData"-->
                      <!--:isShow.sync="show"-->
                      <!--@bindSend="propMsg" />-->
    <!--</van-popup>-->
    <!-- 日期选择框 -->
    <van-popup :style="{ height: '40%' }"
               position="bottom"
               v-model="dateShow">
      <van-datetime-picker @cancel="onCancel"
                           @confirm="onConfirmDate"
                           type="year-month"
                           v-model="currentDate" />
    </van-popup>
  </div>
</template>

<script lang='ts'>
import { Component, Vue, Watch } from 'vue-property-decorator';
import StatisticsChart from '@/components/modules/attendance-manage/statistics-chart/index.vue';
import DepartmentTree from '@/components/modules/attendance-manage/department-tree/index.vue';
// @ts-ignore
import Common from '@/utils/common/common';

@Component({
  components: {
    StatisticsChart,
    DepartmentTree
  }
})
export default class AttendanceRecord extends Vue {
  // 所有部门相关
  private keyword: string = '';
  private pageIndex: number = 1;
  private columns: string[] = [];
  private show: boolean = false;
  private selectDepartment: string = '所有部门';
  private selectDepartmentId: any = null;
  private selectDepartmentSub: string = ''; // 辅助存储当前选中部门name
  private selectDepartmentIdSub: any = null; // 辅助存储当前选中部门id
  private departmentTreeData: any[] = [];
  // 日期选择相关
  private dateShow: boolean = false; // 控件显隐
  private selectIndex: number = 1; // 被选中select的索引
  private startTime: string = Common.dateFmt('yyyy年MM月', new Date());
  private currentDate: any = new Date();
  private timerLimit: any = null;
  // 数据列表
  private data: any = {};

  private treeDefault: string = '选择单位';
  private isShowPop1: boolean = false;
  private activeId: number = 1;
  private activeIndex: number = 0;
  private items: any = [];
  private orgTree: any = [];
  private orgList: number[];


  // 切换显示，将临时值赋给查询对象
  public onConfirm(): void {
    this.show = !this.show;
  }

  /**
   * 所有部门选择
   */

  // 切换显示
  private switchShow(): void {
    this.show = !this.show;
    // 部门列表
    this.show && this.departmentList();
  }

  // 切换部门
  private propMsg(id: any, name: string, show: boolean): void {
    this.show = show;
    this.selectDepartmentSub = name;
    this.selectDepartmentIdSub = id;
    this.attendanceList();
  }

  // 部门列表
  private async departmentList(): Promise<void> {
    const res = await this.$api.xHttp.get(
      this.$interface.attendanceManage.department
    );
    if (res.code === 0) {
      this.departmentTreeData = [
        { id: null, name: '所有部门', parent: res.data[0].parent },
        ...res.data
      ];
    }
  }
  // 统计数据
  private async attendanceList(): Promise<any> {
    const name = this.keyword;
    const time = this.startTime.replace('年', '-').replace('月', '');
    let params = {
      orgList: this.orgList,
      time
    };
    const { code, data } = await this.$api.xHttp.post(
      this.$interface.attendanceManage.static,
      params
    );
    if (code === 0) {
      this.data = data;
    }
  }

  /**
   * 日期选择相关
   */
  private selectShow(index: number): void {
    this.selectIndex = index;
    this.dateShow = true;
  }
  private onCancel(): void {
    this.dateShow = false;
  }
  private onConfirmDate(value: any): void {
    const news = new Date(value).getTime();
    this.startTime = Common.dateFmt('yyyy年MM月', new Date(value));
    this.dateShow = false;
  }

  private async created() {
    this.getOrgList();
    this.attendanceList();
  }
  // 关键字搜索
  private handleInput(): void {
    clearTimeout(this.timerLimit);
    this.timerLimit = setTimeout(async () => {
      this.attendanceList();
    }, 1000);
  }

  @Watch('startTime')
  private async watchStartTime(): Promise<void> {
    this.attendanceList();
  }

  // 监听部门弹窗关闭时获取最新部门id以及数据
  @Watch('show')
  private async watchDepartmentShow(): Promise<void> {
    if (!this.show) {
      this.selectDepartmentSub &&
        (this.selectDepartment = this.selectDepartmentSub);
      this.selectDepartmentIdSub &&
        (this.selectDepartmentId = this.selectDepartmentIdSub);
      this.attendanceList();
    }
  }
  private showPop() {
    this.isShowPop1 = true;

  }


  private async getOrgList(): Promise<void> {
    const res = await this.$api.xHttp.get(
      this.$interface.attendanceManage.department
    );
    if (res.code === 0) {
      let dataStr = JSON.stringify(res.data);
      dataStr = dataStr.replace(/name/g, 'text');
      dataStr = dataStr.replace(/children/g, 'children');
      dataStr = dataStr.replace(/id/g, 'id');
      this.items = [JSON.parse(dataStr)];
      this.orgTree = [JSON.parse(dataStr)];
    }
  }

  private clickTreeItem(data: any) {
    if (data.children.length !== 0) {
      this.items = data.children;
    }
    this.orgList = [];
    this.orgList.push(data.id);
    this.attendanceList();
    this.treeDefault = data.text;
    this.isShowPop1 = false;
  }

  private returnLevel() {
    this.items = this.orgTree;
    this.treeDefault = '选择单位';
    this.orgList = [];
    this.isShowPop1 = true;
  }
  private indexChange(index: any) {
    if (this.items[index].children.length === 0) {
      this.orgList = [];
      this.orgList.push(this.items[index].id);
      this.attendanceList();
      this.treeDefault = this.items[index].text;
      this.isShowPop1 = false;
    }
  }
}
</script>

<style lang='less' scoped>
.attendance-manage {
  &-head {
    margin-bottom: 20px;
    height: 190px;
    background-image: url(../../../../assets/images/modules/attendance-manage/data-statistics.png);
    background-size: cover;
    background-position: center;
    background-repeat: no-repeat;
    display: flex;
    align-items: center;
    .select-icon {
      margin-left: 10px;
      height: 10px;
      &:after {
        border: 3px solid;
        border-color: transparent transparent currentColor currentColor;
        -webkit-transform: rotate(-45deg);
        transform: rotate(-45deg);
        opacity: 0.8;
        display: block;
        content: "";
      }
    }
  }
  .tips {
    font-size: 24px;
    color: rgba(153, 153, 153, 1);
    padding: 30px;
  }
  &-select {
    display: flex;
    justify-content: space-between;
    width: 100%;
    padding: 0 0.4rem 0.2rem;
    font-size: 0.37333rem;
    .show-btn {
      color: #fff;
      span,
      i {
        vertical-align: middle;
      }

      span {
        margin-right: 8px;
      }
    }
    .department-name {
      position: relative;
      width: 310px;
      height: 66px;
      line-height: 63px;
      border: 1px solid #fff;
      border-radius: 8px;
      background: #607eae;
      display: flex;
      align-items: center;
      justify-content: center;
    }
  }
  .time-select {
    position: relative;
    width: 310px;
    height: 66px;
    line-height: 63px;
    border: 1px solid #fff;
    border-radius: 8px;
    background: #607eae;
    color: #fff;
    margin-left: 60px;
    display: flex;
    align-items: center;
    justify-content: center;
    &:nth-child(3) {
      margin-left: 28px;
    }

    span {
      padding-right: 8px;
    }
    span,
    i {
      vertical-align: middle;
    }
  }
}

.van-hairline--top-bottom::after,
.van-hairline-unset--top-bottom::after {
  border: none;
}

.van-search {
  padding: 30px;
}


.showPop.van-button--default {
  border: none;
  width: 100%;
  height: 1.28rem;
  z-index: 99;
  .van-icon-play {
    transform: rotate(90deg);
  }
}
.van-popup {
  overflow: hidden;
  h3 {
    font-size: 0.39rem;
    text-align: center;
    padding: 25px 0;
    color: #363740;
    border-bottom: 1px solid #eee;
  }
}
.van-tree-select {
  height: calc(100% - 1.25rem) !important;
}
.van-button {
  text-align: left;
}
</style>
