<template>
  <div class="baseservice-container">
    <div>
      <persons v-if="active === 0"
               :bCards="items"
               :personSum="personSum"
               :servicePlaceSum="servicePlaceSum"></persons>
      <static v-else></static>
    </div>
    <div class="baseservice-container-menu">
      <van-tabbar v-model="active">
        <van-tabbar-item>
          <div style="display: block; text-align: center; padding-bottom: 2px;">
            <img class="baseservice-container-menu-icon"
                 :src="active === 0 ? menuIcon.homeActive : menuIcon.homeInactive" />
          </div>
          <div style="display: block; padding-bottom: 4px;">
            <span>机构人员</span>
          </div>
        </van-tabbar-item>
        <van-tabbar-item @click="tabClick(1)">
          <div style="display: block; text-align: center; padding-bottom: 2px;">
            <img class="baseservice-container-menu-icon"
                 :src="active === 1 ? menuIcon.recordActive : menuIcon.recordInactive" />
          </div>
          <div style="display: block; padding-bottom: 4px;">
            <span>数据统计</span>
          </div>
        </van-tabbar-item>
      </van-tabbar>
    </div>
  </div>
</template>

<script lang="ts">
import BCard from '@/model/modules/baseservice/BCard';
import { Component, Vue } from 'vue-property-decorator';
import Persons from './persons/index.vue';
import Static from './static/index.vue';

@Component({
  components: {
    Persons,
    Static
  }
})
export default class BaseService extends Vue {
  public active: number = 0;

  // 底部菜单图标
  public menuIcon: any = {
    homeActive: require('../../../assets/images/modules/baseservice/index-active.png'),
    homeInactive: require('../../../assets/images/modules/baseservice/index-inactive.png'),
    recordActive: require('../../../assets/images/modules/baseservice/static-active.png'),
    recordInactive: require('../../../assets/images/modules/baseservice/static-inactive.png')
  };

  public personData = [];

  public items: BCard[] = [];
  // 总人数
  private personSum: number = 0;
  // 服务所总数
  private servicePlaceSum: number = 0;

  /**
   * 标签点击
   */
  public tabClick(e: number): void {
    this.active = e;
    this.$forceUpdate();
  }

  public async created(): Promise<void> {
    // 获取人员数据
    await this.getPersonData();
  }

  /**
   * 获取人员数据
   */
  public async getPersonData() {
    const res = await this.$api.xHttp.post(
      this.$interface.baseService.person,
      {}
    );
    if (res.code === 0) {
      this.personData = res.data;
      // 数据组装与计算
      this.handlerPersonData();
    }
  }

  /**
   * 数据组装与计算
   */
  public handlerPersonData() {
    const that = this;
    let items: BCard[] = [];
    let servicePlaceSum = 0;
    let personSum = 0;
    that.personData.forEach((it: any) => {
      servicePlaceSum += it.servicePlaceList.length;
      personSum += it.totalPerson;
      let bCard = new BCard();
      bCard.name = it.region;
      bCard.count = it.totalPerson;
      let cards: any[] = [];
      it.servicePlaceList.forEach((item: any) => {
        let card = new BCard();
        card.name = item.key;
        card.count = item.value;
        cards.push(card);
      });
      bCard.cards = cards;
      items.push(bCard);
    });
    this.servicePlaceSum = servicePlaceSum;
    this.personSum = personSum;
    this.items = items;
  }
}
</script>

<style lang="less" scoped>
.baseservice-container {
  background: #ececee;
  width: 100%;
  height: 100%;

  &-menu {
    height: 92px;
    &-icon {
      height: 44px;
      width: 44px;
    }
  }
}

// 样式重置
.van-tabbar-item--active {
  color: #0a5ffe;
}
</style>
