<template>
  <div class="persons-container">
    <div class="persons-container-title">
      基层法律服务所{{ servicePlaceSum }}所，服务所工作人员{{ personSum }}人
    </div>
    <div v-for="(item, idx) in bCards"
         :key="idx">
      <card :item="item"></card>
    </div>
  </div>
</template>

<script lang="ts">
  import Card from '@/components/modules/baseservice/ccard.vue';
  import {Component, Prop, Vue} from 'vue-property-decorator';
  import BCard from '../../../../model/modules/baseservice/BCard';

  @Component({
    components: {Card}
  })
  export default class BPersons extends Vue {

    @Prop() private bCards: BCard[];
    @Prop() private personSum: number;
    @Prop() private servicePlaceSum: number;

  }
</script>

<style lang="less" scoped>
  .persons-container {
    width: 750px;
    margin: auto;

    &-title {
      font-size: 24px;
      font-weight: 500;
      color: rgba(153, 153, 153, 1);
      margin: 30px 0 30px 30px;
    }
  }
</style>
