<template>
  <div class="container">
    <div class="container-header">
      <div class="container-header-left"
           @click="show=true">
        {{ regionColumn }} <font size="1px">▼</font>
      </div>
      <div class="container-header-right"
           @click="show1=true">
        {{showDate}} <font size="1px">▼</font>
      </div>
    </div>

    <div class="container-person">
      <div class="container-person-top">
        <h3>基层法律工作人员概况</h3>
      </div>
      <div class="container-person-bottom">
        <canvas id="myChart1"
                style="width:100%;height:200px;"></canvas>
      </div>
    </div>

    <div class="container-region">
      <div class="container-region-top">
        <h3>区域分布</h3>
      </div>
      <div class="container-person-bottom"
           style="margin-top: 20px">
        <div v-for="(item, index) in regions"
             style="margin-bottom: 15px"
             :key="index">
          <div class="progress-font">
            <div>{{item.region}}</div>
            <div>{{item.number}}人( {{(item.number/item.total*100).toFixed(1)}}% )</div>
          </div>
          <div>
            <van-progress stroke-width="10px"
                          :percentage="parseInt((item.number / item.total * 100).toFixed(0))"
                          :show-pivot="false"></van-progress>
          </div>
        </div>
      </div>
    </div>

    <div class="container-common">
      <div class="container-common-top">
        <h3>年龄分布</h3>
      </div>
      <div class="container-common-bottom">
        <canvas id="myChart2"
                style="width:100%;height:200px;"></canvas>
      </div>
    </div>

    <div class="container-common">
      <div class="container-common-top">
        <h3>学历情况</h3>
      </div>
      <div class="container-common-bottom">
        <canvas id="myChart3"
                style="width:100%;height:200px;"></canvas>
      </div>
    </div>

    <div class="container-baseinfo">
      <div class="container-baseinfo-top">
        <h3>执业准入方式</h3>
      </div>
      <div class="details-card">
        <div class="content">
          <div class="sameMonth">
            <p class="text5"
               style="width:76%">2018年后通过省级司法行政机关考试</p>
            <p class="text1">{{ practice3 }}</p>
            <p class="text5">具法律执业资格</p>
            <p class="text1">{{ practice1 }}</p>
          </div>
          <div class="cumulative">
            <div style="margin-left: 12%">
              <p class="text5"
                 style="width:76%">具基层法律服务工作者职业资格</p>
              <p class="text1">{{ practice2 }}</p>
              <p class="text5">其他</p>
              <p class="text1">{{ practice4 }}</p>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="container-politics">
      <div class="container-politics-top">
        <h3>政治面貌</h3>
      </div>
      <div class="container-politics-bottom">
        <div class="container-politics-bottom-item"
             style="border-right: 0.7px solid rgba(238, 238, 238, 1);">
          <p class="text5">中共党员</p>
          <p class="text1">{{ politics1 }}</p>
        </div>
        <div class="container-politics-bottom-item"
             style="border-right: 0.7px solid rgba(238, 238, 238, 1);margin-left: 11%">
          <p class="text5">民主党派</p>
          <p class="text1">{{ politics2 }}</p>
        </div>
        <div class="container-politics-bottom-item"
             style="margin-left:10%">
          <p class="text5">其他</p>
          <p class="text1">{{ personSum - politics1 - politics2 }}</p>
        </div>
      </div>
    </div>

    <!-- 区域选择 -->
    <van-popup v-model="show"
               position="bottom"
               :style="{ height : '30%' }">
      <van-picker show-toolbar
                  :columns="columns"
                  @cancel="show = false"
                  @confirm="requestData" />
    </van-popup>
    <!-- 时间选择 -->
    <van-popup v-model="show1"
               position="bottom">
      <van-datetime-picker show-toolbar
                           v-model="currentDate"
                           type="year-month"
                           @cancel="show1=false"
                           @confirm="onConfirm" />
    </van-popup>

  </div>
</template>

<script lang="ts">
import PieType from '@/model/common/f2/PieType';
import pie from '@/plugins/antv-f2/pie';
// @ts-ignore
import pieInfo from '@/plugins/antv-f2/pieInFo';
import { Component, Vue } from 'vue-property-decorator';

@Component({})
export default class BPersons extends Vue {
  private personData: PieType[] = [];
  private eduData: PieType[] = [];
  private ageData: PieType[] = [];
  private regions: any[] = [];
  private columns: string[] = [
    '全部',
    '越秀区',
    '荔湾区',
    '黄埔区',
    '花都区',
    '从化'
  ];
  private regionColumn: string = '全部';
  private currentDate: Date = new Date();
  private show: boolean = false;
  private show1: boolean = false;
  private columns1: string[] = [];
  // 女性
  private womanSum: number = 0;
  // 男性
  private manSum: number = 0;

  private persons: any[] = [];
  // 总人数
  private personSum: number = 0;
  // 具有法律执业资格
  private practice1: number = 0;
  // 具有基层法律服务工作者职业资格
  private practice2: number = 0;
  // 2018年后通过省级司法行政机关组织的考试
  private practice3: number = 0;
  // 其他
  private practice4: number = 0;
  // 中共党员
  private politics1: number = 0;
  // 民主党派
  private politics2: number = 0;

  private showDate: string = this.$utils.Common.dateFmt('yyyy年MM月', new Date());

  public async mounted() {
    await this.requestData(null);
  }

  public async initData() {
    let personSum = 0;
    let womanSum = 0;
    let practice1 = 0;
    let practice2 = 0;
    let practice3 = 0;
    let practice4 = 0;
    let politics1 = 0;
    let politics2 = 0;
    this.persons.forEach((it: any) => {
      personSum += it.totalPerson;
      womanSum += it.sexList[0].value;
      practice1 += it.practiceList[0].value;
      practice2 += it.practiceList[1].value;
      practice3 += it.practiceList[2].value;
      practice4 += it.practiceList[3].value;
      politics1 += it.politicsList[0].value;
      politics2 += it.politicsList[1].value;
    });
    this.personSum = personSum;
    this.womanSum = womanSum;
    this.manSum = this.personSum - this.womanSum;
    this.practice1 = practice1;
    this.practice2 = practice2;
    this.practice3 = practice3;
    this.practice4 = practice4;
    this.politics1 = politics1;
    this.politics2 = politics2;
  }

  public async onConfirm(value: string) {
    this.showDate = this.$utils.Common.dateFmt('yyyy年MM月', new Date(value));
    this.show1 = false;
    await this.requestData(null);
  }

  private async initRegions() {
    this.regions = [];
    if (this.persons && this.persons.length === 1) {
        this.persons[0].servicePlaceList.forEach((it: any) => {
            this.regions.push({
                region: it.key,
                number: it.value,
                total: this.personSum,
                percent: it.value / this.persons[0].totalPerson
            });
        });
    } else {
    this.persons.forEach((it: any) => {
        this.regions.push({
            region: it.region,
            number: it.totalPerson,
            total: this.personSum,
            percent: it.totalPerson / this.personSum
        });
    });
    }
  }

  private async initSexData() {
    const p = new PieType();
    p.type = '女性';
    p.precent = parseFloat(
      ((this.womanSum / this.personSum) * 100).toFixed(1));
    p.num = this.womanSum;
    const p1 = new PieType();
    p1.type = '男性';
    p1.precent = parseFloat(((this.manSum / this.personSum) * 100).toFixed(1));
    p1.num = this.manSum;
    this.personData = [];
    this.personData.push(p1);
    this.personData.push(p);
    // 调用antv/f2组件
    pieInfo('myChart1', this.personData, ['#1F80F1', '#E55857'], '人');
  }

  private async initAgeData() {
    // 65岁以上
    let age1 = 0;
    // 30到49岁
    let age2 = 0;
    // 30到49岁
    let age3 = 0;
    // 29岁以下
    let age4 = 0;
    this.persons.forEach((it: any) => {
      age1 += it.ageList[0].value;
      age2 += it.ageList[1].value;
      age3 += it.ageList[2].value;
      age4 += it.ageList[3].value;
    });
    const num = parseFloat(((age1 / this.personSum) * 100).toFixed(1));
    const num1 = parseFloat(((age2 / this.personSum) * 100).toFixed(1));
    const num2 = parseFloat(((age3 / this.personSum) * 100).toFixed(1));
    const num3 = parseFloat(((age4 / this.personSum) * 100).toFixed(1));
    const p = new PieType();
    p.type = '65岁以上';
    p.num = num;
    const p1 = new PieType();
    p1.type = '30到49岁';
    p1.num = num1;
    const p2 = new PieType();
    p2.type = '50到64岁';
    p2.num = num2;
    const p3 = new PieType();
    p3.type = '29岁以下';
    p3.num = num3;
    this.ageData = [];
    this.ageData.push(p);
    this.ageData.push(p1);
    this.ageData.push(p2);
    this.ageData.push(p3);
    // 调用antv/f2组件
    pie('myChart2', this.ageData, ['#00B67D', '#F6B043', '#1F80F1', '#E55857']);
  }

  private async initEduData() {
    let education = 0;
    let education1 = 0;
    let education2 = 0;
    let education3 = 0;
    let education4 = 0;
    this.persons.forEach((it: any) => {
      education += it.educationList[0].value;
      education1 += it.educationList[1].value;
      education2 += it.educationList[2].value;
      education3 += it.educationList[3].value;
      education4 += it.educationList[4].value;
    });
    const p = new PieType();
    p.type = '本科法律';
    p.num = parseFloat(((education / this.personSum) * 100).toFixed(1));
    const p1 = new PieType();
    p1.type = '本科非法律';
    p1.num = parseFloat(((education1 / this.personSum) * 100).toFixed(1));
    const p2 = new PieType();
    p2.type = '大专法律';
    p2.num = parseFloat(((education2 / this.personSum) * 100).toFixed(1));
    const p3 = new PieType();
    p3.type = '大专非法律';
    p3.num = parseFloat(((education3 / this.personSum) * 100).toFixed(1));
    const p4 = new PieType();
    p4.type = '大专及以下';
    p4.num = parseFloat(((education4 / this.personSum) * 100).toFixed(1));
    this.eduData = [];
    this.eduData.push(p);
    this.eduData.push(p1);
    this.eduData.push(p2);
    this.eduData.push(p3);
    this.eduData.push(p4);
    // 调用antv/f2组件
    pie('myChart3', this.eduData, [
      '#00B67D',
      '#F6B043',
      '#1F80F1',
      '#E55857',
      '#6E52D0'
    ]);
  }

  /**
   * 请求数据
   */
  private async requestData(value: any) {
    this.regionColumn = value === null ? '全部' : value;
    if (value === '全部') {
      value = null;
    }
    const body = {
      region: value
    };
    const res = await this.$api.xHttp.post(
      this.$interface.baseService.person,
      body
    );
    if (res.code === 0) {
      this.persons = res.data;
      this.$forceUpdate();
      await this.initData();
      await this.initRegions();
      await this.initSexData();
      await this.initAgeData();
      await this.initEduData();
    }
    this.show = false;
  }
}
</script>

<style lang="less" scoped>
.container {
  &-header {
    background: url("../../../../assets/images/modules/baseservice/bg.png")
      no-repeat;
    background-size: cover;
    height: 160px;
    width: 100%;
    display: flex;
    line-height: 80px;
    justify-content: space-around;
    font-size: 30px;

    &-left {
      margin: auto 0;
      line-height: 66px;
      height: 66px;
      width: 260px;
      border: 0.5px solid rgba(255, 255, 255, 1);
      background: #607eae;
      border-radius: 8px;
      color: white;
      text-align: center;
    }

    &-right {
      width: 260px;
      margin: auto 0;
      line-height: 66px;
      height: 66px;
      border: 0.5px solid rgba(255, 255, 255, 1);
      background: #607eae;
      border-radius: 8px;
      color: white;
      text-align: center;
    }
  }

  &-person {
    height: 451px;
    width: 94%;
    background: #ffffff;
    margin: 0 auto;
    margin-top: 60px;
    border-radius: 12px;

    &-top {
      padding-left: 30px;
      position: relative;
      top: 25px;
    }

    &-bottom {
      min-height: 381px;
      padding: 0 30px 30px 30px;
    }
  }

  &-region {
    min-height: 600px;
    width: 94%;
    background: #ffffff;
    margin: 0 auto;
    margin-top: 30px;
    border-radius: 12px;

    &-top {
      padding-left: 30px;
      position: relative;
      top: 25px;
    }
  }

  &-common {
    height: 500px;
    width: 94%;
    background: #ffffff;
    margin: 0 auto;
    margin-top: 30px;
    border-radius: 12px;

    &-top {
      padding-left: 30px;
      position: relative;
      top: 25px;
    }

    &-bottom {
      padding-top: 40px;
      height: 381px;
      padding-left: 30px;
      padding-right: 30px;
    }
  }

  &-baseinfo {
    height: 345px;
    width: 94%;
    background: #ffffff;
    margin: 0 auto;
    margin-top: 30px;
    border-radius: 12px;

    &-top {
      padding-left: 30px;
      position: relative;
      top: 25px;
    }

    &-bottom {
      padding-top: 40px;
      height: 361px;
      padding-left: 30px;
      padding-right: 30px;
    }
  }

  &-politics {
    height: 218px;
    width: 94%;
    background: #ffffff;
    margin: 0 auto;
    margin-top: 30px;
    border-radius: 12px;
    margin-bottom: 50px;

    &-top {
      padding-left: 30px;
      position: relative;
      top: 25px;
    }

    &-bottom {
      justify-content: flex-start;
      padding-top: 40px;
      height: 90px;
      padding-left: 60px;
      padding-right: 30px;
      display: flex;

      &-item {
        width: 33.3%;
      }
    }
  }
}

.details-card {
  background: rgba(255, 255, 255, 1);
  border-radius: 12px;
  padding-right: 30px;
  height: 200px;
  margin-top: 35px;

  h2 {
    padding: 0 36px;

    img {
      width: 48px;
      height: 48px;
      vertical-align: middle;
    }

    span {
      vertical-align: middle;
      padding-left: 20px;
    }
  }

  .content {
    width: 100%;
    display: flex;
    margin-top: 22px;
    flex-wrap: wrap;

    .sameMonth,
    .cumulative {
      width: 50%;
      padding-left: 30px;
      box-sizing: border-box;
      flex-shrink: 0;
    }

    div:nth-child(2n) {
      border-left: 0.7px solid rgba(238, 238, 238, 1);
    }
  }
}

.progress-font {
  display: flex;
  justify-content: space-between;
  margin-bottom: 5px;
  font-size: 26px;
  font-weight: 500;
}
</style>
