<template>
  <div class="modify">
    <div class="modify-item" style="padding-top:.4rem">
      <div class="modify-item-left">车场车位</div>
      <div class="modify-item-right">{{size.remain}}/{{size.total}}</div>
    </div>
    <div class="modify-item">
      <div class="modify-item-left">人员编号</div>
      <div class="modify-item-right">{{isShowPerson?personCode:'自动编号'}}</div>
    </div>
    <div class="modify-item" style="border-bottom: 1px solid #f4f4f4;padding-bottom: .5rem">
      <div class="modify-item-left">车辆编号</div>
      <div class="modify-item-right">{{isShowPerson?carCode:'自动编号'}}</div>
    </div>

    <div class="modify-item1">
      <div class="modify-item1-left1">
        <font color="red">*</font>
        车牌号码
        <div @click="showCarNo" class="carNo">
          {{carStart}}
          <img
            src="../../../../assets/images/modules/car-manager/sj.png"
            style="width:10px;margin-bottom: 2px"
          />
        </div>
      </div>
      <div class="modify-error" v-show="errorCar">车牌号有误</div>
      <div class="modify-item1-right1">
        <label>
          <input class="modify-item1-right1-input" placeholder="请输入车牌" type="text" v-model="carNo"/>
        </label>
      </div>
    </div>

    <van-popup @click-overlay="showPopup2=false" position="bottom" v-model="showPopup2">
      <van-picker
        :columns="carArray"
        :default-index="defaultType"
        @cancel="showPopup2=false"
        @confirm="onChange1"
        show-toolbar
      />
    </van-popup>

    <div class="modify-item1">
      <div class="modify-item1-left1">
        <font color="red">*</font>车辆类型
      </div>
      <div class="modify-error" v-show="errorType">*请选择类型</div>
      <div class="modify-item1-right2">
        <div>
          <div @click="selectType()" style="float: left;height: 50px">{{ monthType?monthType:'请选择'}}</div>
          <div class="icon">
            <van-icon name="arrow"/>
          </div>
        </div>
      </div>
    </div>
    <van-popup @click-overlay="showPopup1=false" position="bottom" v-model="showPopup1">
      <van-picker
        :columns="columns"
        :default-index="defaultType"
        @cancel="showPopup1=false"
        @confirm="onConfirm"
        show-toolbar
      />
    </van-popup>

    <div class="modify-item1">
      <div class="modify-item1-left1">
        <font color="red">*</font>有效起日
      </div>
      <div class="modify-item1-right2">
        <div>
          <div style="float: left;height: 50px">{{ startTime}}</div>
          <div class="icon">
            <van-icon name="arrow"/>
          </div>
        </div>
      </div>
    </div>

    <div class="modify-item1">
      <div class="modify-item1-left1">
        <font color="red">*</font>有效止日
      </div>
      <div class="modify-error" v-show="errorDate">*请选择止期</div>
      <div class="modify-item1-right2">
        <div>
          <div @click="selectDate(2)" style="float: left;height: 50px">{{ endTime?endTime:'请选择'}}</div>
          <div class="icon">
            <van-icon name="arrow"/>
          </div>
        </div>
      </div>
    </div>

    <van-popup @click-overlay="showPopup=false" position="bottom" v-model="showPopup">
      <van-datetime-picker
        :max-date="maxDate"
        :min-date="minDate"
        @cancel="showPopup=false"
        @confirm="dateArrow"
        type="year-month"
        v-model="current"
      />
    </van-popup>

    <div class="modify-item1">
      <div class="modify-item1-left1">人员姓名</div>
      <div class="modify-item1-right1">
        <label>
          <input
            class="modify-item1-right1-input"
            placeholder="请输入姓名"
            type="text"
            v-model="userName"
          />
        </label>
      </div>
    </div>

    <div class="modify-item1">
      <div class="modify-item1-left1">手机号码</div>
      <div class="modify-error" v-show="errorPhone">*号码有误</div>
      <div class="modify-item1-right1">
        <label>
          <input
            class="modify-item1-right1-input"
            placeholder="请输入号码"
            type="text"
            v-model="mobNumber"
          />
        </label>
      </div>
    </div>

    <div class="modify-item1">
      <div class="modify-item1-left1">车辆型号</div>
      <div class="modify-item1-right1">
        <label>
          <input
            class="modify-item1-right1-input"
            placeholder="请输入车型"
            type="text"
            v-model="carType"
          />
        </label>
      </div>
    </div>

    <!--<div class="modify-item1">-->
    <!--<div class="modify-item1-left1">车场车位</div>-->
    <!--<div class="modify-item1-right1">-->
    <!--<label>-->
    <!--<input type="text" placeholder="请输入车场车位" class="modify-item1-right1-input" />-->
    <!--</label>-->
    <!--</div>-->
    <!--</div>-->

    <div class="modify-item1">
      <div class="modify-item1-left1">车辆备注</div>
      <div class="modify-item1-right1">
        <label>
          <input class="modify-item1-right1-input" placeholder="请输入备注" type="text" v-model="marker"/>
        </label>
      </div>
    </div>

    <div class="modify-button">
      <van-button
        @click="deleteCar"
        class="modify-button-info"
        color="#e0423e"
        style="margin-bottom: 10px"
        v-if="isShowPerson"
      >删除
      </van-button>
      <van-button
        @click="updateCar"
        class="modify-button-info"
        color="#457BC7"
      >{{isShowPerson?'修改':'提交'}}
      </van-button>
    </div>
  </div>
</template>

<script lang="ts">
import { Component } from 'vue-property-decorator';
import { DatetimePicker, Icon, Picker, Popup, Search } from 'vant';
import Vue from 'vue';
import store from '@/store';
import ParkSize from '@/model/modules/car-manager/ParkSize';
import Car from '@/model/modules/car-manager/Car';

Vue.use(DatetimePicker);
Vue.use(Popup);
Vue.use(Search);
Vue.use(Picker);
Vue.use(Icon);
@Component({
  components: { DatetimePicker }
})
export default class AddCar extends Vue {
  public mobNumber?: string = '';

  public userName?: string = '';

  public carType: string = '';

  public marker?: string = '';

  public startTime?: string = this.getNowDate();

  public endTime?: string = '';

  public monthType: string = '';

  public showPopup1: boolean = false;

  public errorPhone: boolean = false;

  public showPopup2: boolean = false;

  public personCode: string = '';
  public carCode: string = '';

  public errorCar: boolean = false;
  public errorType: boolean = false;
  public errorDate: boolean = false;

  public current: Date = new Date();

  public isShowPerson: boolean = false;
  public showPopup: boolean = false;

  public carNo: string = '';

  public defaultType: number = 1;

  public carId: string = '';

  public count: number = 0;

  public typeCode: string;

  public size: ParkSize = new ParkSize();

  public columns: string[] = ['月租车A', '月租车B', '月租车C', '月租车D'];

  public columnsValue: string[] = ['3652', '3653', '3654', '3655'];

  public carArray: string[] = [
    '京',
    '津',
    '冀',
    '晋',
    '蒙',
    '辽',
    '吉',
    '黑',
    '沪',
    '苏',
    '浙',
    '皖',
    '闽',
    '赣',
    '鲁',
    '豫',
    '鄂',
    '湘',
    '粤',
    '桂',
    '琼',
    '渝',
    '川',
    '贵',
    '云',
    '藏',
    '陕',
    '甘',
    '青',
    '宁',
    '新'
  ];

  public type: number = 0;

  public carStart: string = '粤';

  public minDate: Date = this.getMinDate();
  public maxDate: Date = new Date('2099-12-30');

  public car: Car = new Car();

  public getNowDate() {
    let data = new Date();
    let time = data.getTime() - 1000 * 60 * 60 * 24;
    data = new Date(time);
    return (
      data.getFullYear() +
      '-' +
      this.handleZero(data.getMonth() + 1) +
      '-' +
      this.handleZero(data.getDate())
    );
  }

  public handleZero(item: number): string {
    if (item < 10) {
      return '0' + item;
    } else {
      return item.toString();
    }
  }

  public getMinDate(): Date {
    return new Date();
  }

  public showCarNo(): void {
    this.showPopup2 = true;
  }

  public created() {
    this.errorCar = false;
    this.errorType = false;
    this.errorDate = false;
    this.isShowPerson = false;
    this.size = this.$store.state.car.parkSize;
    if (!this.size.total) {
      this.$api.xHttp
        .get(this.$interface.car.parkSize, null, null)
        .then((res: any) => {
          this.size = res.data;
          store.commit('SET_PARKSIZE', res.data);
        });
    }
    const query: any = this.$route.query;
    const carNo = query.carNo;
    if (carNo && carNo.length > 0) {
      this.clearAll();
      this.carId = carNo;
      this.$api.xHttp
        .get(this.$interface.car.itemInfo + carNo, null, null)
        .then((res: any) => {
          this.isShowPerson = true;
          this.car = res.data;
          this.showValue(res.data);
        });
      this.count = 1;
    } else {
      this.count = 0;
      this.startTime = this.getNowDate();
    }
  }

  public deleteCar(): void {
    const carCard = this.carStart + this.carNo;
    this.$api.xHttp
      .get(this.$interface.car.deleteCar + carCard, null, null)
      .then((res: any) => {
        this.clearAll();
        this.$router.back();
      });
  }

  public showValue(data: Car): void {
    this.carStart = data.carNo.substr(0, 1);
    this.carNo = data.carNo.substr(1, data.carNo.length);

    for (let i = 0; i < this.columnsValue.length; i++) {
      if (this.columnsValue[i] === data.carType) {
        this.monthType = this.columns[i];
        this.typeCode = data.carType;
        this.defaultType = i;
      }
    }
    this.carType = data.carModel;
    this.marker = data.remark;
    this.startTime = data.startTime;
    this.endTime = data.endTime;
    this.mobNumber = data.telephone;
    this.userName = data.username;
    this.carCode = data.carCode;
    this.personCode = data.personCode;
  }

  public onConfirm(value: any, index: any): void {
    this.monthType = value;
    this.typeCode = this.columnsValue[index];
    this.showPopup1 = false;
  }

  public onChange1(value: any, index: any): void {
    this.carStart = value;
    this.showPopup2 = false;
  }

  public clearAll(): void {
    this.userName = '';
    this.mobNumber = '';
    this.carType = '';
    this.marker = '';
    this.startTime = '';
    this.endTime = '';
    this.typeCode = '';
    this.carNo = '';
    this.monthType = '';
    this.carId = '';
    this.isShowPerson = false;
    this.errorPhone = false;
    this.errorCar = false;
    this.errorType = false;
    this.errorDate = false;
    this.car = new Car();
    store.commit('SET_CAR_NULL', { show: false });
  }

  public checkLicensePlate(licensePlate: any): boolean {
    let re = /^[京津沪渝冀豫云辽黑湘皖鲁新苏浙赣鄂桂甘晋蒙陕吉闽贵粤青藏川宁琼使领A-Z]{1}[A-Z]{1}[A-Z0-9]{4}[A-Z0-9挂学警港澳]{1}$/;
    if (licensePlate.search(re) === -1) {
      return false;
    } else {
      return true;
    }
  }

  public updateCar(): void {
    const carCard = (this.carStart + this.carNo).trim();

    if (
      !(this.carNo && this.carNo.length > 0) ||
      !this.checkLicensePlate(carCard)
    ) {
      this.errorCar = true;
      this.errorType = false;
      this.errorDate = false;
      this.errorPhone = false;
      return;
    }

    if (!(this.typeCode && this.typeCode.length > 0)) {
      this.errorType = true;
      this.errorCar = false;
      this.errorDate = false;
      this.errorPhone = false;
      return;
    }

    if (!(this.endTime && this.endTime.length > 0)) {
      this.errorDate = true;
      this.errorType = false;
      this.errorCar = false;
      this.errorPhone = false;

      return;
    }
    // if (!(this.mobNumber && this.mobNumber.length > 0)) {
    //
    // }
    const phone = /^(((13[0-9]{1})|(15[0-9]{1})|(18[0-9]{1}))+\d{8})$/;
    if (this.mobNumber) {
      if (this.mobNumber.length === 11) {
        // 手机号码
        if (!phone.test(this.mobNumber)) {
          this.errorCar = false;
          this.errorType = false;
          this.errorDate = false;
          this.errorPhone = true;
          return;
        }
      } else {
        this.errorPhone = true;
        this.errorCar = false;
        this.errorType = false;
        this.errorDate = false;
        return;
      }
    }
    let oldCard = '';
    if (this.carId && this.carId !== carCard) {
      oldCard = this.carId;
    }
    let data = {
      personDTO: {
        userName: this.userName,
        mobNumber: this.mobNumber
      },
      carDTO: {
        carType: this.carType,
        marker: this.marker,
        startTime: this.startTime,
        endTime: this.endTime,
        monthType: this.typeCode,
        carNo: carCard
      },
      only: this.compare(),
      oldCard
    };
    this.$api.xHttp
      .post(this.$interface.car.updateCar, data, '')
      .then((res: any) => {
        this.clearAll();
        this.$router.back();
      });
  }

  public dateArrow(type: any): void {

    let time = new Date(type.getTime() - 1000 * 60 * 60 * 24);
    let year = time.getFullYear();
    let month = time.getMonth() + 1 + 1;

    let time1 = new Date().getTime() - 1000 * 60 * 60 * 24;
    let data1 = new Date(time1);

    let data =
      year +
      '-' +
      this.handleZero(month) +
      '-' +
      this.handleZero(data1.getDate());
    if (this.type === 1) {
      this.startTime = data;
    } else {
      this.endTime = data;
    }
    this.showPopup = false;
  }

  public selectDate(type: number): void {
    this.startTime = this.getNowDate();
    this.showPopup = true;
    this.type = type;
  }

  public selectType(): void {
    this.showPopup1 = true;
  }

  public compare(): boolean {
    const carCard = this.carStart + this.carNo;
    if (this.count !== 1) {
      return false;
    }

    let flag = true;
    if (this.startTime !== this.car.startTime) {
      flag = false;
    }
    if (this.endTime !== this.car.endTime) {
      flag = false;
    }
    if (this.mobNumber !== this.car.telephone) {
      flag = false;
    }
    if (this.userName !== this.car.username) {
      flag = false;
    }
    if (this.typeCode !== this.car.carType) {
      flag = false;
    }
    if (carCard !== this.car.carNo) {
      flag = false;
    }
    return flag;
  }
}
</script>

<style lang="less" scoped>
.carNo {
  background: #457bc7;
  color: white;
  height: 52px;
  width: 99px;
  font-size: 32px;
  text-align: center;
  border-radius: 6px;
  line-height: 52px;
  margin-left: 25px;
  display: inline-block;
}

.modify {
  min-height: 100%;
  width: 100%;
  background: white;

  &-error {
    color: red;
    font-size: 32px;
    width: 23%;
    text-align: right;
  }

  &-item {
    display: flex;
    justify-content: space-between;
    margin-left: 5%;
    width: 95%;
    font-size: 32px;
    color: #333333;

    &-left {
      color: #333333;
    }

    &-right {
      color: #333333;
      margin-right: 5%;
    }
  }

  &-item1 {
    display: flex;
    justify-content: space-between;
    margin-left: 5%;
    width: 95%;
    font-size: 32px;
    color: #333333;
    border-bottom: 1px solid #f4f4f4;
    height: 1.5rem;
    line-height: 1.5rem;

    &-left1 {
      color: #333333;
    }

    &-right2 {
      width: 40%;
      color: #666666;
      display: flex;
      justify-content: flex-end;
      margin-right: 5%;
    }

    &-right1 {
      color: #666666;
      width: 30%;
      margin-right: 5%;

      &-input {
        border: none;
        width: 100%;
        text-align: right;
      }
    }
  }
  &-button {
    background: white;
    padding: 0 30px;
    margin-top: 54px;
    margin-bottom: 40px;

    &-info {
      font-size: 36px;
      border-radius: 12px;
      width: 100%;
    }
  }
}

.icon {
  display: inline-block;
  vertical-align: middle;
}

.modify-item1-right1-input::placeholder {
  font-size: 32px;
}
</style>
