<template>
  <div class="car">
    <div class="car-size">
      <div class="car-size-banner">
        <div class="car-size-banner-left">剩余车位数量</div>
        <div @click="toRegister" class="car-size-banner-right">
          <img
            class="car-size-banner-right-img"
            src="../../../assets/images/modules/car-manager/book.png"
          /> 已登记车牌
        </div>
      </div>
      <div class="car-size-number">{{size.remain}}/{{size.total}}</div>
    </div>

    <div class="car-list">
      <div
        :key="index"
        @click="itemInfo(item.carNo)"
        class="car-list-item blackColor"
        v-for="(item,index) in dataList"
        v-if="item.isShow"
      >
        <div class="car-list-item-left">{{item.carNo}}</div>
        <div class="car-list-item-right">{{item.startTime}}~{{ item.endTime }}</div>
      </div>
    </div>
    <div class="car-button">
      <van-button @click="addCar" class="plain car-button-info" color="#EFF5FF">添加车牌</van-button>
    </div>
  </div>
</template>

<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';

@Component({})
export default class CarManager extends Vue {
  public isLoading: boolean = false;
  public size: object = { total: 0, remain: 0 };
  public dataList: any[] = [];

  public activated() {
    this.list();
  }

  public created() {
    this.list();
  }

  public list(): void {
    this.isLoading = false;
    this.$api.xHttp
      .get(this.$interface.car.parkSize, { load: false }, null)
      .then((res: any) => {
        this.size = res.data;
        this.$store.commit('SET_PARKSIZE', res);
        this.$api.xHttp
          .get(this.$interface.car.index, null, null)
          .then(({ data }: any) => {
            const ite: any[] = [];
            data.forEach((item: any) => ite.push(item));
            this.$store.commit('SET_CARLIST', ite);
            const items = data.reverse();
            this.dataList = items;
          });
      });
  }

  public itemInfo(carNo: string): void {
    this.$router.push({
      path: '/modify',
      query: {
        carNo
      }
    });
  }

  public toRegister(): void {
    this.$router.push('/register');
  }

  public addCar(): void {
    this.$router.push('/add');
  }
}
</script>
<style lang="less" scoped>
.blackColor {
  color: black;
}

.car {
  background: white;
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: column;
  &-size {
    color: white;
    height: 260px;
    background: url('../../../assets/images/modules/car-manager/bg.png');
    background-size: 100% 100%;
    width: 100%;
    position: relative;
    &-number {
      position: absolute;
      top: 111px;
      margin-left: 41px;
      font-size: 54px;
      font-weight: bold;
    }
    &-banner {
      &-left {
        position: absolute;
        top: 53px;
        left: 41px;
        color: #e3eaf6;
        font-size: 32px;
      }
      &-right {
        position: absolute;
        top: 45px;
        right: 0;
        width: 220px;
        height: 53px;
        border-radius: 50px 0 0 50px;
        background: #66ace8;
        line-height: 53px;
        &-img {
          position: relative;
          margin-bottom: 2px;
          margin-left: 30px;
          width: 26px;
          height: 29px;
          line-height: 20px;
        }
      }
    }
  }
  &-list {
    flex: 1;
    overflow: scroll;
    padding-bottom: 130px;
    &-item {
      font-size: 0.4rem;
      color: #333333;
      width: 90%;
      height: 1.6rem;
      text-align: center;
      display: flex;
      border-bottom: 1px solid #eeeeee;
      align-items: center;
      margin-left: 5%;
      justify-content: space-between;
    }
  }

  &-button {
    display: flex;
    flex-direction: column-reverse;
    width: 100%;
    background-color: rgb(255, 255, 255);
    position: fixed;
    bottom: 0px;
    padding-bottom: 20px;
    &-info {
      font-size: 36px;
      height: 98px;
      margin: 0 75px;
      color: #457bc7 !important;
      border-radius: 6px;
      border: 1px solid #457bc7 !important;
    }
  }
}
</style>
