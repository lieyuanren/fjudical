<template>
  <div class="register">
    <div class="register-size">
      <van-search
        @search="onSearch"
        background="#5576AB"
        class="register-size-se"
        placeholder="搜索车牌"
        v-model="searchValue1"
      />
    </div>
    <div class="register-list">
      <div
        :class="[item.isShow? 'register-list-item blackColor' :'register-list-item   grey']"
        :key="index"
        @click="itemInfo(item.carNo)"
        v-for="(item,index) in carList"
      >
        <div class="register-list-item-left">{{item.carNo}}</div>
        <div class="register-list-item-right">{{item.startTime}}~{{ item.endTime }}</div>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
import { Component, Vue, Watch } from 'vue-property-decorator';
import { Search } from 'vant';

Vue.use(Search);
@Component({})
export default class Registered extends Vue {
  public searchValue1: string = '';
  public carList: any[] = [];
  public timerLimit: any = null;

  // 搜索定时器
  @Watch('searchValue1')
  public handleSearch(): void {
    clearTimeout(this.timerLimit);
    this.timerLimit = setTimeout(() => {
      this.onSearch();
    }, 1500);
  }
  public activated() {
    this.list();
  }

  public created() {
    this.carList = this.$store.state.car.carList;
    if (!this.carList || this.carList.length === 0) {
      this.list();
      this.$forceUpdate();
    }
  }

  public itemInfo(carNo: string): void {
    this.$router.push({
      path: '/modify',
      query: {
        carNo
      }
    });
  }

  public list(): void {
    this.$api.xHttp
      .get(this.$interface.car.index, null, null)
      .then((res: any) => {
        this.$store.commit('SET_CARLIST', res.data);
        this.carList = res.data;
      });
  }

  public onSearch(): void {
    if (this.searchValue1 && this.searchValue1.length !== 0) {
      const array: any[] = [];
      this.$store.state.car.carList.forEach((item: any) => {
        if (item.carNo.indexOf(this.searchValue1) !== -1) {
          array.push(item);
        }
      });
      this.carList = array;
    } else {
      this.carList = this.$store.state.car.carList;
    }
  }
}
</script>


<style lang="less" scoped>
.grey {
  color: #999999;
}

.blackColor {
  color: #333333;
}

.register {
  background: white;
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: column;
  &-size {
    height: 127px;
    background: #5576ab;
    width: 100%;
    display: flex;
    align-items: center;
    &-se {
      width: 100%;
      height: 74px;
      border-radius: 10px;
    }
  }
  &-list {
    flex: 1;
    height: 100%;
    overflow: scroll;
    &-item {
      color: #333333;
      font-size: 34px;
      height: 120px;
      display: flex;
      border-bottom: 1px solid #eeeeee;
      align-items: center;
      margin-left: 40px;
      margin-right: 40px;
      justify-content: space-between;
      &-left {
        text-align: left;
      }
      &-right {
        text-align: center;
      }
    }
  }
}
</style>
