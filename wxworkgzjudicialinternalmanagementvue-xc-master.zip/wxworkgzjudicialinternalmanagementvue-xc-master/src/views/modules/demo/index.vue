<template>
  <div class="car">
    <div class="car-content">
      <transition mode="out-in" name="component-fade">
        <component :is="components[active]"></component>
      </transition>
    </div>
    <div class="car-menu">
      <van-tabbar v-model="active">
        <van-tabbar-item icon="home-o">Home</van-tabbar-item>
        <van-tabbar-item icon="search">Demo</van-tabbar-item>
      </van-tabbar>
    </div>
  </div>

</template>

<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';
import { Tabbar, TabbarItem } from 'vant';
// @ts-ignore
import first from './first/index';
// @ts-ignore
import second from './second/index';

Vue.use(Tabbar).use(TabbarItem);

@Component({
  components: { first, second }
})
export default class Demo1 extends Vue {
  public active: number = 0;
  public components: any = ['first', 'second'];

  public mounted() {
    console.log('i am demo1 mounted');
  }
}
</script>
<style lang="less" scoped>
.car {
  height: 100%;
  display: flex;
  flex-direction: column;

  &-content {
    flex: 1;
  }

  &-menu {
    height: 92px;
  }
}

// 动画
.component-fade-enter-active, .component-fade-leave-active {
  transition: opacity .3s ease;
}

.component-fade-enter, .component-fade-leave-to
  /* .component-fade-leave-active for below version 2.1.8 */ {
  opacity: 0;
}
</style>
