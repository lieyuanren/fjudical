<template>
  <div class="first box">
    Demo2 First
    <div>
      <span>套你猴子</span>
    </div>
  </div>
</template>

<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';

@Component
export default class Car extends Vue {
}
</script>
<style lang="less" scoped>
.first {
  height: 100%;
  span {
    font-size: 34px;
    font-weight: bold;
  }
}
</style>
