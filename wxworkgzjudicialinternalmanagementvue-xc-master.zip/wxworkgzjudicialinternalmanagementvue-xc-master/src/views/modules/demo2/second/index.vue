<template>
  <div class="second box">
    Demo2 SECOND
    <div>
      <span>我行 你也行</span>
    </div>
  </div>
</template>

<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';

@Component
export default class Black extends Vue {
}
</script>
<style lang="less" scoped>
.second {
  height: 100%;
  span {
    font-size: 34px;
    font-weight: bold;
  }
}
</style>
