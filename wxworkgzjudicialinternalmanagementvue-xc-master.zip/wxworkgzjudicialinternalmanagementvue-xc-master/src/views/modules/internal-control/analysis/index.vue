<!--
 * @Author: tangzhicheng
 * @Date: 2020-03-16 09:52:31
 * @LastEditors: tangzhicheng
 * @LastEditTime: 2020-03-17 17:04:52
 * @Description: 数据分析组件
 -->

 <template>
  <div class="analysis">
    <div class="analysis-head">
      <prop-select @onConfirm="onConfirm"></prop-select>
    </div>
    <div class="analysis-tips">
      （单位：元）
    </div>
    <div class="analysis-body">
      <transition name="animate"
                  mode="out-in">
        <component :is="componentId[active]"
                   :statics="statics"
                   :year="year"
                   :type="type"></component>
      </transition>
    </div>
  </div>
</template>

 <script lang='ts'>
import { Component, Vue, Watch } from 'vue-property-decorator';
import PropSelect from '@/components/modules/internal-control/analysis/v-prop-select/index.vue';
import BudgetPanel from '@/components/modules/internal-control/analysis/v-budget-panel/index.vue';
import PayPanel from '@/components/modules/internal-control/analysis/v-pay-panel/index.vue';

@Component({
  components: {
    BudgetPanel,
    PayPanel,
    PropSelect
  }
})
export default class Analysis extends Vue {
  private active: number = 0;
  private componentId: string[] = ['BudgetPanel', 'PayPanel'];

  /**
   * 参数
   */
  private statics: string = '年度预算汇总分析';
  private year: string = `${new Date().getFullYear()}`;
  private type: string = '部门';

  public async created() {
    // const data = await this.$api.xHttp.get('/api/test');
    // console.log(data);
  }

  @Watch('statics')
  private watchStatics(): void {
    if (this.statics === '年度预算汇总分析') {
      this.active = 0;
    } else {
      this.active = 1;
    }
  }

  private onConfirm(active: number, str: string): void {
    if (active === 1) {
      this.statics = str;
    } else if (active === 2) {
      this.year = str;
    } else if (active === 3) {
      this.type = str;
    }
  }
}
</script>

 <style lang='less' scoped>
.analysis {
  height: 100%;

  &-head {
    height: 204px;
  }

  &-tips {
    padding: 20px;
    font-size: 24px;
    color: #666666;
    text-align: right;
  }
}

.animate-enter {
  transform: translate3d(100%, 0, 0);
}
.animate-leave-to {
  transform: translate3d(-100%, 0, 0);
}

.animate-enter-active,
.animate-leave-active {
  transition: transform 0.2s;
}
</style>

