<!--
 * @Author: tangzhicheng
 * @Date: 2020-03-16 15:41:34
 * @LastEditors: tangzhicheng
 * @LastEditTime: 2020-03-24 08:53:53
 * @Description: 内控管理详情页
 -->
<template>
  <div class="details">
    <!-- 详情信息 -->
    <div class="details-content">
      <p class="title">{{ controlProjectDetail[modelJson.name]}}</p>
      <div v-for="(_, idx) in numArr"
           :key="idx">
        <cell-row :label="modelJson[`label${idx + 1}`]"
                  :value="controlProjectDetail[modelJson[`field${idx + 1}`]]"></cell-row>
      </div>
    </div>
    <!-- 审批流程 -->
    <div class="details-content">
      <p class="title">审批流程</p>
      <div class="details-content-procedure">
        <approval-step v-for="(item, index) in stepList"
                       :icon="icon"
                       :item="item"
                       :key="index"></approval-step>
        <nodata v-if="stepList.length === 0"></nodata>
      </div>
    </div>
    <!-- 审批意见 -->
    <div class="details-content">
      <p class="title">审批意见</p>
      <div class="details-content-opinion">
        <opinion-card v-for="(item, index) in opinionList"
                      :item="item"
                      :key="index"
                      :auditStatus="auditStatus"></opinion-card>
        <nodata v-if="opinionList.length === 0"></nodata>
      </div>
    </div>
  </div>
</template>

<script lang='ts'>
  import OpinionCard from '@/components/modules/internal-control/analysis/v-opinion-card/index.vue';
  import ApprovalStep from '@/components/modules/internal-control/control/v-approval-step/index.vue';
  import CellRow from '@/components/modules/internal-control/control/v-cell-row/index.vue';
  import OpinionCardType from '@/model/modules/internal-control/analysis/OpinionCardType';
  import Module from '@/model/modules/internal-control/common/Module';
  import ApprovalStepType from '@/model/modules/internal-control/control/ApprovalStepType';
  import {Component, Vue} from 'vue-property-decorator';
  import Nodata from '@/components/common/v-nodata/index.vue';

  let modelsJson = require('./modules.json');

  @Component({
    components: {
      CellRow,
      ApprovalStep,
      OpinionCard,
      Nodata
    }
  })
  export default class Details extends Vue {

    private controlProjectDetail: any = {};

    private stepList: ApprovalStepType[] = [];

    private opinionList: OpinionCardType[] = [];

    private icon: any = {
      awaiting_check: `${require('@/assets/images/modules/internal-control/state-01.png')}`,
      agree: `${require('@/assets/images/modules/internal-control/state-02.png')}`,
      return: `${require('@/assets/images/modules/internal-control/state-03.png')}`
    };

    private auditStatus: any = {
      start: '发起流程',
      awaiting_check: '待审批',
      agree: '同意',
      against: '反对',
      return: '驳回',
      abandon: '弃权',
      retrieve: '追回'
    };
    // 项目主键
    private id: string;

    private numArr: any[] = [];

    private modelJson: Module = new Module();

    public async created(): Promise<void> {

      const id = this.$route.query.id;
      const model = this.$route.query.model as string;
      const type = this.$route.query.type as string; // 区别个人办公和其他模块（个人办公时有值）

      this.id = id as string;
      this.modelJson = modelsJson[model];
      const keys = Object.keys(this.modelJson);
      this.$utils.Common.setTitle('详情');

      this.numArr = [];
      keys.forEach((it: any) => {
        if (it.indexOf('field') !== -1) {
          this.numArr.push(0);
        }
      });

      // 获取项目基本详情
      await this.getDetail(id, model, type);

      // 获取审批流程及审批意见
      await this.getAudit(id);
    }

    /**
     * 获取项目详情
     * @param id 项目主键
     * @param model
     * @param type
     */
    public async getDetail(id: any, model: any, type: any): Promise<void> {
      let res;
      if (type === 'grbg') {
        const body = {
          id,
          code: model
        };
        res = await this.$api.xHttp.get(this.$interface.internalControl.person.detail, body, null);
      } else {
        res = await this.$api.xHttp.get(this.$interface.internalControl.conproject.detail[this.modelJson.urlName], {id});
      }
      if (res.code === 0) {
        this.controlProjectDetail = res.data;
      }
    }

    /**
     * 获取审核信息
     * @param id
     * @returns {Promise<void>}
     */
    public async getAudit(id: any): Promise<void> {
      const body = {
        id,
        code: this.$route.query.model
      };
      const res = await this.$api.xHttp.get(this.$interface.internalControl.conproject.audit, body, null);
      if (res.code === 0) {
        this.stepList = res.data.auditFlow;
        this.opinionList = res.data.auditAdvise;
      }
    }
  }
</script>

<style lang='less' scoped>
  .details {
    &-content {
      padding: 30px;
      background-color: #ffffff;
      margin-top: 20px;

      &:nth-child(1) {
        margin-top: 0;
      }

      .title {
        font-size: 36px;
        font-weight: bold;
        padding-bottom: 20px;
      }

      &-procedure,
      &-opinion {
        border-top: 1px solid #eeeeee;
      }
    }
  }
</style>

