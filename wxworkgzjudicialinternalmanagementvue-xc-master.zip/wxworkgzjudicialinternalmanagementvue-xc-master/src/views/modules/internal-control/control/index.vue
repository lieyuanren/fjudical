<!--
 * @Author: tangzhicheng
 * @Date: 2020-03-16 09:51:39
 * @LastEditors: tangzhicheng
 * @LastEditTime: 2020-03-17 08:59:17
 * @Description: 内控管理组件
 -->

<template>
  <div class="control">
    <manage-panel title="项目管理">
      <manage-item name="建设项目申报"
                   url="/projectDeclaration"
                   :data="{ module : 'jsxmsb' }"
                   :icon="iconArr[0]"></manage-item>
      <manage-item name="建设项目变更"
                   url="/projectDeclaration"
                   :data="{ module : 'jsxmbg' }"
                   :icon="iconArr[1]"></manage-item>
      <manage-item name="建设项目验收"
                   url="/projectDeclaration"
                   :data="{ module : 'jsxmys' }"
                   :icon="iconArr[2]"></manage-item>
    </manage-panel>
    <manage-panel title="预算管理">
      <manage-item name="建设编织"
                   :icon="iconArr[3]"></manage-item>
      <manage-item name="预算调整"
                   url="/projectDeclaration"
                   :data="{ module : 'ystzgl' }"
                   :icon="iconArr[4]"></manage-item>
      <manage-item name="预算编制"
                   url="/projectDeclaration"
                   :data="{ module : 'ysbz' }"
                   :icon="iconArr[0]"></manage-item>
    </manage-panel>
    <manage-panel title="收支管理">
      <manage-item name="经费申请"
                   url="/projectDeclaration"
                   :data="{ module : 'jfsqgl' }"
                   :icon="iconArr[5]"></manage-item>
      <manage-item name="借款申请"
                   url="/projectDeclaration"
                   :data="{ module : 'jksqgl' }"
                   :icon="iconArr[6]"></manage-item>
      <manage-item name="报账申请"
                   url="/projectDeclaration"
                   :data="{ module : 'bzsqgl' }"
                   :icon="iconArr[7]"></manage-item>
    </manage-panel>
    <manage-panel title="采购管理">
      <manage-item name="采购申请"
                   url="/projectDeclaration"
                   :data="{ module : 'cgsqgl' }"
                   :icon="iconArr[8]"></manage-item>
      <manage-item name="招标管理"
                   url="/projectDeclaration"
                   :data="{ module : 'zbgl' }"
                   :icon="iconArr[9]"></manage-item>
      <manage-item name="招标变更"
                   url="/projectDeclaration"
                   :data="{ module : 'zbbggl' }"
                   :icon="iconArr[10]"></manage-item>
      <manage-item name="单一来源"
                   url="/projectDeclaration"
                   :data="{ module : 'dylygl' }"
                   :icon="iconArr[11]"></manage-item>
    </manage-panel>
    <manage-panel title="合同管理">
      <manage-item name="合同审签"
                   url="/projectDeclaration"
                   :data="{ module : 'htsqgl' }"
                   :icon="iconArr[12]"></manage-item>
      <manage-item name="合同变更 "
                   url="/projectDeclaration"
                   :data="{ module : 'htbggl' }"
                   :icon="iconArr[13]"></manage-item>
      <manage-item name="合同解除"
                   url="/projectDeclaration"
                   :data="{ module : 'htjcgl' }"
                   :icon="iconArr[14]"></manage-item>
    </manage-panel>
    <manage-panel title="资产管理">
      <manage-item name="资产配置"
                   url="/projectDeclaration"
                   :data="{ module : 'zcpzgl' }"
                   :icon="iconArr[15]"></manage-item>
      <manage-item name="采购计划 "
                   url="/projectDeclaration"
                   :data="{ module : 'cgjhgl' }"
                   :icon="iconArr[16]"></manage-item>
      <manage-item name="资产处置"
                   url="/projectDeclaration"
                   :data="{ module : 'zcczgl' }"
                   :icon="iconArr[17]"></manage-item>
      <manage-item name="出租出借"
                   url="/projectDeclaration"
                   :data="{ module : 'czcjgl' }"
                   :icon="iconArr[18]"></manage-item>
      <manage-item name="资产调拨"
                   url="/projectDeclaration"
                   :data="{ module : 'zcdbgl' }"
                   :icon="iconArr[19]"></manage-item>
      <manage-item name="资产领用"
                   url="/projectDeclaration"
                   :data="{ module : 'zclygl' }"
                   :icon="iconArr[20]"></manage-item>
      <manage-item name="资产移交"
                   url="/projectDeclaration"
                   :data="{ module : 'zcyjgl' }"
                   :icon="iconArr[21]"></manage-item>
    </manage-panel>
    <manage-panel title="绩效管理">
      <manage-item name="项目支出"
                   url="/projectDeclaration"
                   :data="{ module : 'xmzcjx' }"
                   :icon="iconArr[22]"></manage-item>
      <manage-item name="部门支出"
                   url="/projectDeclaration"
                   :data="{ module : 'bmzcjx' }"
                   :icon="iconArr[23]"></manage-item>
    </manage-panel>
  </div>
</template>

<script lang='ts'>
  import ManageItem from '@/components/modules/internal-control/control/v-manage-item/index.vue';
  import ManagePanel from '@/components/modules/internal-control/control/v-manage-panel/index.vue';
  import {Component, Vue} from 'vue-property-decorator';

  @Component({
    components: {
      ManagePanel,
      ManageItem
    }
  })
  export default class Control extends Vue {
    // 图标数组
    private iconArr: string[] = [
      require('@/assets/images/modules/internal-control/icon-01.png'),
      require('@/assets/images/modules/internal-control/icon-02.png'),
      require('@/assets/images/modules/internal-control/icon-03.png'),
      require('@/assets/images/modules/internal-control/icon-04.png'),
      require('@/assets/images/modules/internal-control/icon-05.png'),
      require('@/assets/images/modules/internal-control/icon-06.png'),
      require('@/assets/images/modules/internal-control/icon-06(1).png'),
      require('@/assets/images/modules/internal-control/icon-07.png'),
      require('@/assets/images/modules/internal-control/icon-08.png'),
      require('@/assets/images/modules/internal-control/icon-09.png'),
      require('@/assets/images/modules/internal-control/icon-10.png'),
      require('@/assets/images/modules/internal-control/icon-11.png'),
      require('@/assets/images/modules/internal-control/icon-11(1).png'),
      require('@/assets/images/modules/internal-control/icon-12.png'),
      require('@/assets/images/modules/internal-control/icon-13.png'),
      require('@/assets/images/modules/internal-control/icon-14.png'),
      require('@/assets/images/modules/internal-control/icon-15.png'),
      require('@/assets/images/modules/internal-control/icon-16.png'),
      require('@/assets/images/modules/internal-control/icon-17.png'),
      require('@/assets/images/modules/internal-control/icon-18.png'),
      require('@/assets/images/modules/internal-control/icon-19.png'),
      require('@/assets/images/modules/internal-control/icon-20.png'),
      require('@/assets/images/modules/internal-control/icon-20(1).png'),
      require('@/assets/images/modules/internal-control/icon-21.png')
    ];

    private test: string = require('@/assets/images/modules/internal-control/state-01.png');

    public created() {
      console.log(this.test);
    }

    private handleClick(): void {
      console.log('click123123');
    }
  }
</script>

<style lang='less' scoped>
  .control {
    padding-top: 30px;
    padding-bottom: 60px;
  }
</style>

