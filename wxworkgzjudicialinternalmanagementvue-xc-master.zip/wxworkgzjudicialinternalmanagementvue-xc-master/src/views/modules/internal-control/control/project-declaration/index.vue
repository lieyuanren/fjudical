<!--
 * @Author: tangzhicheng
 * @Date: 2020-03-16 11:08:46
 * @LastEditors: tangzhicheng
 * @LastEditTime: 2020-03-20 16:42:24
 * @Description: 建设项目申报
 -->

<template>
  <div>
    <project-search :placeholder="module.placeholder"
                    :searchKey="searchKey"
                    @search="searchProjectByKey"></project-search>
    <van-list v-model="loading"
              finished-text="没有更多了"
              :finished="finished"
              :immediate-check="false"
              :offset="10"
              direction="up"
              @load="onLoad"
    >
      <div v-if="buildingProjectInfos.length > 0">
        <div v-for="(item, index) in buildingProjectInfos"
             :key="index">
          <project-content :item="item"
                           :module="module"
                           @click="projectClick(item)"></project-content>
        </div>
      </div>
    </van-list>
    <nodata v-if="buildingProjectInfos.length === 0"></nodata>
  </div>
</template>

<script lang='ts'>
  import Nodata from '@/components/common/v-nodata/index.vue';
  import Module from '@/model/modules/internal-control/common/Module';
  import {Component, Vue} from 'vue-property-decorator';
  import ProjectContent from '../../../../../components/modules/internal-control/control/v-project-content/index.vue';
  import ProjectSearch from '../../../../../components/modules/internal-control/control/v-project-search/index.vue';
  let modulesJson = require('./modules.json');

  @Component({
    components: {
      ProjectSearch,
      ProjectContent,
      Nodata
    }
  })
  export default class ProjectDeclaration extends Vue {

    private searchKey: string = '';
    // 显示模块
    private module: Module = new Module();

    private buildingProjectInfos: any[] = [];

    private loading: boolean = false;

    private finished: boolean = false;

    private currentPage: number = 1;

    private pageSize: number = 10;

    private timeLimit: any = null;

    public created(): void {
      let routeParam = this.$route.query.module;
      if (routeParam) {
        this.module = modulesJson[`${routeParam}`];
        // 设置页面标题
        this.$utils.Common.setTitle(this.module.title);
      } else {
        this.$router.push({
          path: '/internalControl'
        });
      }
      this.searchProjectByKey(this.searchKey);
    }
    private searchProjectByKey(searchKey: string): void {
      // 重置数据
      this.buildingProjectInfos = [];
      // 搜索
      this.searchProject(searchKey);
    }

    /**
     * 通过关键字查找
     */
    private searchProject(searchKey: string): void {
      let searchStr = null;
      if (searchKey && searchKey.length > 0) {
        searchStr = searchKey;
      }
      const that = this;
      that.searchKey = searchKey;
      const body = {
        search: searchStr,
        currentPage: that.currentPage,
        pageSize: that.pageSize
      };
      that.$api.xHttp.post(that.$interface.internalControl.conproject.list[that.module.urlName], body).then((res: any) => {
        if (res.code === 0) {
          if (res.data.data && res.data.data.length) {
            for (let item of res.data.data) {
              that.buildingProjectInfos.push(item);
            }
            that.finished = that.buildingProjectInfos.length < that.pageSize && that.currentPage !== 1;
          } else {
            that.finished = false;
          }
          that.loading = false;
        }
      });
    }

    /**
     * 上拉刷新
     */
    private onLoad() {
      clearTimeout(this.timeLimit);
      this.timeLimit = setTimeout(() => {
        this.currentPage++;
        this.searchProject(this.searchKey);
      }, 1500);
    }

    private projectClick(item: any) {
      if (item.id) {
        this.$router.push({
          path: '/details',
          query: {
            id: `${item.id}`,
            model: this.$route.query.module
          }
        });
      } else {
        this.$router.push({
          path: '/internalControl'
        });
      }
    }
  }
</script>

<style lang='less' scoped>
</style>

<style lang="less">
  .van-tabs--line .van-tabs__wrap {
    height: 100px;
  }

  .van-tab {
    position: relative;
    -webkit-box-flex: 1;
    flex: 1;
    box-sizing: border-box;
    min-width: 0;
    padding: 0 0.13333rem;
    font-size: 28px;
    line-height: 100px;
    text-align: center;
    cursor: pointer;
  }
</style>
