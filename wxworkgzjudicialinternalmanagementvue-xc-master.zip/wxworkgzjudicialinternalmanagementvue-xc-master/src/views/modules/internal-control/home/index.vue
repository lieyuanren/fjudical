<!--
 * @Author: tangzhicheng
 * @Date: 2020-03-16 09:50:24
 * @LastEditors: tangzhicheng
 * @LastEditTime: 2020-03-31 10:07:47
 * @Description: 首页组件
 -->

<template>
  <div class="home">
    <div class="home-head">
      <TabList :tabs="tabs"
               @onClick="handleClick" />
    </div>
    <div class="tips">
      2020年根据预算总额排序
    </div>
    <div class="home-body">
      <info-list :infoList="infoList"></info-list>
    </div>
  </div>
</template>

<script lang='ts'>
import MoneyInfo from '@/model/modules/internal-control/analysis/MoneyInfo';
import { Component, Vue } from 'vue-property-decorator';
import TabList from '@/components/modules/internal-control/home/v-tab-list/index.vue';
import BudgetPanel from '@/components/modules/internal-control/analysis/v-budget-panel/index.vue';
import InfoList from '../../../../components/modules/internal-control/analysis/v-info-list/index.vue';

@Component({
  components: {
    TabList,
    BudgetPanel,
    InfoList
  }
})
export default class Home extends Vue {
  private tabs: string[] = ['部门预算', '项目预算', '预算支出功能'];
  private infoList: MoneyInfo[] = [];

  private async handleClick(index: number): Promise<void> {
    console.log(index);
    this.infoList = [
      {
        name: '办公室',
        budgetMoney: '3000000/45%',
        accountMoney: '2000000',
        expenditureMoney: '1500000'
      },
      {
        name: '机关党委',
        budgetMoney: '3000000/45%',
        accountMoney: '2000000',
        expenditureMoney: '1500000'
      },
      {
        name: '立法一处',
        budgetMoney: '3000000/45%',
        accountMoney: '2000000',
        expenditureMoney: '1500000'
      },
      {
        name: '综合保障中心',
        budgetMoney: '3000000/45%',
        accountMoney: '2000000',
        expenditureMoney: '1500000'
      },
      {
        name: '综合保障中心',
        budgetMoney: '3000000/45%',
        accountMoney: '2000000',
        expenditureMoney: '1500000'
      },
      {
        name: '综合保障中心',
        budgetMoney: '3000000/45%',
        accountMoney: '2000000',
        expenditureMoney: '1500000'
      },
      {
        name: '综合保障中心',
        budgetMoney: '3000000/45%',
        accountMoney: '2000000',
        expenditureMoney: '1500000'
      },
      {
        name: '综合保障中心',
        budgetMoney: '3000000/45%',
        accountMoney: '2000000',
        expenditureMoney: '1500000'
      },
      {
        name: '综合保障中心',
        budgetMoney: '3000000/45%',
        accountMoney: '2000000',
        expenditureMoney: '1500000'
      },
      {
        name: '综合保障中心',
        budgetMoney: '3000000/45%',
        accountMoney: '2000000',
        expenditureMoney: '1500000'
      }
    ];
    this.infoList.map((item: any, index: number) => {
      if (index === 0) {
        item.icon =
          'http://a3.att.hudong.com/68/61/300000839764127060614318218_950.jpg';
      } else if (index === 1) {
        item.icon =
          'http://a3.att.hudong.com/68/61/300000839764127060614318218_950.jpg';
      } else if (index === 2) {
        item.icon =
          'http://a3.att.hudong.com/68/61/300000839764127060614318218_950.jpg';
      } else {
        item.icon = index;
      }
    });
    if (index === 0) {
      // 部门预算请求
      // await this.requestData();
    } else if (index === 1) {
      // 项目预算
      // await this.requestData();
    } else {
      // 预算支出功能
      // await this.requestData();
    }
  }

  /**
   * 数据请求
   * @param {string} url
   * @returns {Promise<void>}
   */
  private async requestData(url: string): Promise<void> {
    const res = await this.$api.xHttp.get(url);
    if (res.code === 0) {
      this.infoList = res.data;
    }
  }
}
</script>

<style lang='less' scoped>
.home {
  height: 100%;
  overflow-x: hidden;
  overflow-y: auto;

  &-head {
    height: 238px;
  }

  .tips {
    padding: 20px;
    color: #666666;
    font-size: 24px;
  }
}
</style>

