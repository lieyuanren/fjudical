<!--
 * @Author: tangzhicheng
 * @Date: 2020-03-16 09:40:11
 * @LastEditors: tangzhicheng
 * @LastEditTime: 2020-03-16 10:04:44
 * @Description: 内控管理根组件
 -->

<template>
  <div class="internal-control">
    <div class="internal-control-body">
      <transition name="outIn"
                  mode="out-in">
        <component :is="componentId[active]"></component>
      </transition>
    </div>
    <div class="internal-control-menu">
      <van-tabbar v-model="active">
        <!--<van-tabbar-item>-->
          <!--<span>首页</span>-->
          <!--<img :src="props.active ? menuIcon.homeActive : menuIcon.homeInactive"-->
               <!--class="internal-control-menu-icon"-->
               <!--slot="icon"-->
               <!--slot-scope="props" />-->
        <!--</van-tabbar-item>-->
        <van-tabbar-item>
          <span>个人办公</span>
          <img :src="props.active ? menuIcon.recordActive : menuIcon.recordInactive"
               class="internal-control-menu-icon"
               slot="icon"
               slot-scope="props" />
        </van-tabbar-item>
        <van-tabbar-item>
          <span>年度考核</span>
          <img :src="props.active ? menuIcon.assessActive : menuIcon.assessInactive"
               class="internal-control-menu-icon"
               slot="icon"
               slot-scope="props" />
        </van-tabbar-item>
        <van-tabbar-item>
          <span>数据统计</span>
          <img :src="props.active ? menuIcon.statisticsActive : menuIcon.statisticsInactive"
               class="internal-control-menu-icon"
               slot="icon"
               slot-scope="props" />
        </van-tabbar-item>
      </van-tabbar>
    </div>
  </div>
</template>

<script lang='ts'>
import { Component, Vue } from 'vue-property-decorator';
import Home from './home/index.vue';
import Office from './office/index.vue';
import Control from './control/index.vue';
import Analysis from './analysis/index.vue';

@Component({
  components: {
    Home,
    Office,
    Control,
    Analysis
  }
})
export default class InternalControl extends Vue {
  // 底部菜单图标
  private menuIcon: any = {
    homeActive: require('../../../assets/images/modules/notarization/index/home-active.png'),
    homeInactive: require('../../../assets/images/modules/notarization/index/home-inactive.png'),
    recordActive: require('../../../assets/images/modules/notarization/index/record-active.png'),
    recordInactive: require('../../../assets/images/modules/notarization/index/record-inactive.png'),
    assessActive: require('../../../assets/images/modules/notarization/index/assess-active.png'),
    assessInactive: require('../../../assets/images/modules/notarization/index/assess-inactive.png'),
    statisticsActive: require('../../../assets/images/modules/notarization/index/statistics-active.png'),
    statisticsInactive: require('../../../assets/images/modules/notarization/index/statistics-inactive.png')
  };

  private active: number = 0;

  // 组件名
  private componentId: string[] = ['Office', 'Control', 'Analysis'];
}
</script>

<style lang='less' scoped>
.internal-control {
  height: 100%;

  &-menu {
    height: 92px;
    &-icon {
      height: 44px;
      width: 44px;
    }
  }
}

.outIn-enter,
.outIn-leave-to {
  opacity: 0;
}

.outIn-enter-active,
.outIn-leave-active {
  transition: opacity 0.3s;
}

</style>

