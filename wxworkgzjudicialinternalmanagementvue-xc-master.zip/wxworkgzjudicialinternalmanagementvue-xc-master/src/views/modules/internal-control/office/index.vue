<!--
 * @Author: tangzhicheng
 * @Date: 2020-03-16 09:51:00
 * @LastEditors: tangzhicheng
 * @LastEditTime: 2020-03-24 08:53:23
 * @Description: 个人办公组件
 -->

<template>
  <div>
    <schedule></schedule>
  </div>
</template>

<script lang='ts'>
  import {Component, Vue} from 'vue-property-decorator';
  import Schedule from './schedule/index.vue';

  @Component({
    components: {
      Schedule
    }
  })
  export default class Office extends Vue {
  }
</script>

<style lang='less' scoped>
</style>

