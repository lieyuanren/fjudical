<!--
 * @Author: tangzhicheng
 * @Date: 2020-03-16 11:06:58
 * @LastEditors: tangzhicheng
 * @LastEditTime: 2020-03-24 08:55:04
 * @Description: 待办事项
 -->

<template>
  <div class="schedule">
    <project-search placeholder="搜索标题"
                    :searchKey="searchKey"
                    @search="searchProject"></project-search>

    <van-tabs v-model="activeName"
              color="#0D61FE"
              title-active-color="#0D61FE"
              title-inactive-color="#666666"
              @click="tabsClick">
      <van-tab name="dbsx"
               title="代办事项">
        <div class="tips">
          共 {{ total }} 个代办事项
        </div>
        <div v-for="(item, index) in buildingProjectInfos"
             :key="index">
          <project-content :item="item"
                           :module="modules[index]"
                           @click="toDetail(item)"></project-content>
        </div>
      </van-tab>
      <van-tab name="blls"
               title="办理历史">
        <div class="tips">
          共 {{ total }} 个办理历史
        </div>
        <div v-for="(item, index) in buildingProjectInfos"
             :key="index">
          <project-content :item="item"
                           :module="modules[index]"
                           @click="toDetail(item)"></project-content>
        </div>
      </van-tab>
      <van-tab name="sqls"
               title="申请历史">
        <div class="tips">
          共 {{ total }} 个申请历史
        </div>
        <div v-for="(item, index) in buildingProjectInfos"
             :key="index">
          <project-content :item="item"
                           预算支出功能科目                        :module="modules[index]"
                           @click="toDetail(item)"></project-content>
        </div>
      </van-tab>
    </van-tabs>
    <nodata v-if="buildingProjectInfos.length === 0"></nodata>
  </div>
</template>

<script lang='ts'>
  import Module from '@/model/modules/internal-control/common/Module';
  import {Component, Vue} from 'vue-property-decorator';
  import ProjectContent from '../../../../../components/modules/internal-control/control/v-project-content/index.vue';
  import ProjectSearch from '../../../../../components/modules/internal-control/control/v-project-search/index.vue';
  import Nodata from '@/components/common/v-nodata/index.vue';

  let modulesJson = require('../../../internal-control/control/project-declaration/modules.json');

  @Component({
    components: {
      ProjectSearch,
      ProjectContent,
      Nodata
    }
  })
  export default class Schedule extends Vue {

    private total: number = 0;

    private searchKey: string = '';

    private activeName: string = 'dbsx';

    // 显示模块
    private modules: Module[] = [];

    private buildingProjectInfos: any[] = [];

    public async mounted() {
      // 个人任务模块
      await this.request();
    }

    /**
     * 通过关键字查找
     */
    private searchProject(searchKey: string): void {
      this.searchKey = searchKey;
      console.log('输入的关键字：' + this.searchKey);
    }

    /**
     * tab点击
     * @param name
     * @param title
     */
    private async tabsClick(name: string): Promise<void> {
      await this.request();
    }

    /**
     * 请求数据
     * @returns {Promise<void>}
     */
    private async request(): Promise<void> {
      const that = this;
      const body = {
        search: this.searchKey
      };
      const res = await that.$api.xHttp.post(that.$interface.internalControl.person.list[that.activeName], body);
      that.buildingProjectInfos = [];
      that.total = 0;
      if (res.code === 0) {
        if (res.data.data && res.data.data.length) {
          that.buildingProjectInfos = [];
          that.modules = [];
          that.total = res.data.totals;
          res.data.data.map((item: any) => {
            that.modules.push(modulesJson[item.code]);
            that.buildingProjectInfos.push(item);
          });
        }
      }
    }

    /**
     * 详情
     */
    private toDetail(item: any) {
      this.$router.push({
        path: '/details',
        query: {
          id: item.id,
          model: item.code,
          type: 'grbg'
        }
      });
    }
  }
</script>

<style lang='less' scoped>
  .schedule {
    height: 100%;
  }
  .tips {
    font-size: 24px;
    color: rgba(153, 153, 153, 1);
    padding: 15px 15px 0px 15px;
  }
</style>

