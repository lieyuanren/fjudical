<template>
  <div class="appraisal-institution">
    <div class="appraisal-institution-head">
      <van-search @input="handleInput"
                  placeholder="请输入搜索关键词"
                  v-model="searchKey" />
      <van-dropdown-menu>
        <van-dropdown-item :options="options"
                           v-model="optionIndex" />
      </van-dropdown-menu>
    </div>
    <p class="tips">共{{ count }}家，满足当前条件：{{ conformCount }}家</p>
    <div style="margin-bottom: 60px;">
      <van-pull-refresh v-model="refreshing" @refresh="onRefresh">
        <van-list
            v-model="loading"
            :finished="finished"
            finished-text="没有更多了"
            @load="onLoad"
        >
          <InstitutionCard :item="item" :key="index" v-for="(item,index) in cardList" />
        </van-list>
      </van-pull-refresh>
    </div>
  </div>
</template>

<script lang='ts'>
import { Component, Vue, Watch } from 'vue-property-decorator';
import InstitutionCardModel from '@/model/modules/judicial-expertise/appraisal-institution/InstitutionCardModel';
import InstitutionCard from '@/components/modules/judicial-expertise/appraisal-institution/v-institution-card/index.vue';

// 鉴定机构
@Component({
  components: {
    InstitutionCard
  }
})
export default class AppraisalInstitution extends Vue {
  private searchKey: string = '';
  private optionIndex: number = 0;
  private options: any = [
    { text: '执业状态(正常)', value: 0 },
    { text: '执业状态(注销)', value: 1 },
    { text: '执业状态(暂停)', value: 2 }
  ];
  private timerLimit: any = null;

  // 机构数据
  private cardList: InstitutionCardModel[] = [];
  // 机构总数
  private count: number = 0;
  // 满足条件案件数
  private conformCount: number = 0;

  private currentPage: number = 1;
  private pageSize: number = 10;

  private loading: boolean = false;
  private finished: boolean = false;
  private refreshing: boolean = false;

  private async created() {
    this.count = await this.getCount();
    // await this.search(this.searchKey);
  }

  private handleInput() {
    this.cardList = [];
    this.onRefresh();
  }

  @Watch('optionIndex')
  private async watchOptionIndex() {
    this.cardList = [];
    this.currentPage = 1;
    await this.search(this.searchKey);
  }

  /**
   * 请求数据
   * @data :后端请求回来的数据
   * @res :处理后的数据
   * @params :{searchkey, options[optionIndex].text} 搜索字段 和 状态
   * @return :返回的res必须符合InstitutionCardModel数据结构的数据
   */
  private async search(searchKey: string): Promise<any> {
    const that = this;
    let params = {
      name: searchKey,
      status: this.getStatus(),
      currentPage: that.currentPage,
      pageSize: that.pageSize
    };
    const res = await that.$api.xHttp.post(
      that.$interface.judicialExpertise.organization.list,
      params
    );
    if (res.code === 0) {
      that.conformCount = res.data.total;
      let arr: InstitutionCardModel[] = [];
      if (res.data.list.length) {
        for (let item of res.data.list) {
          let institutionCardModel = new InstitutionCardModel();
          institutionCardModel.organizationId = item.id;
          institutionCardModel.organizationName = item.name;
          institutionCardModel.person = item.leader;
          institutionCardModel.address = item.address;
          institutionCardModel.phoneNum = item.mobile;
          institutionCardModel.imgUrl = item.orgImg;
          institutionCardModel.state = item.status;
          arr.push(institutionCardModel);
        }
      }
      this.cardList.push(...arr);
      this.loading = false;
      this.currentPage++;
      this.finished = res.data.pageNum >= res.data.pages;
    } else {
      this.$toast(res.msg);
    }
  }

  /**
   * 获取机构总数
   */
  private async getCount() {
    const res = await this.$api.xHttp.get(
      this.$interface.judicialExpertise.organization.count
    );
    if (res.code === 0) {
      return res.data;
    } else {
      this.$toast(res.msg);
    }
  }

  /**
   * 获取选中状态
   */
  private getStatus(): string {
    let text = this.options[this.optionIndex].text
      .replace('(', '')
      .replace(')', '');
    return text.substring(text.length - 2, text.length);
  }

  /**
   * 上拉刷新
   */
  private async onLoad(): Promise<void> {
    if (this.refreshing) {
      this.cardList = [];
      this.refreshing = false;
    }
    await this.search(this.searchKey);
  }

  private onRefresh() {
    this.currentPage = 1;
    // 清空列表数据
    this.finished = false;
    // 重新加载数据
    // 将 loading 设置为 true，表示处于加载状态
    this.loading = true;
    this.onLoad();
  }
}
</script>

<style lang='less' scoped>

/deep/ .van-dropdown-menu {
  height: 0.9rem;
}
.appraisal-institution {
  &-head {
    background-color: #ffffff;
  }

  .tips {
    font-size: 24px;
    color: rgba(153, 153, 153, 1);
    padding: 15px;
  }
}

.van-hairline--top-bottom::after,
.van-hairline-unset--top-bottom::after {
  border: none;
}

.van-search {
  padding: 30px;
}
</style>
