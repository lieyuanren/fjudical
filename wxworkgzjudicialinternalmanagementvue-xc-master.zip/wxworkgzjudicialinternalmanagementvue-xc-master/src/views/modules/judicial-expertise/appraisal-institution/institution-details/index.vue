<template>
  <div class="institution-details">
    <div class="institution-details-head">
      <div class="institution-details-head-title">
        <span class="text1">{{ detailsObj.organizationName }}</span>
        <van-tag plain :type="state">{{ detailsObj.state }}
        </van-tag>
      </div>
      <p class="text4">许可证号：{{ detailsObj.licenseKey }}</p>
      <p class="text4">有效期：{{ detailsObj.termOfValidity }}</p>
      <p class="text4">联系电话：{{ detailsObj.phoneNum}}</p>
      <p class="text4">机构地址：{{ detailsObj.organizationAddress }}</p>
      <p class="text4">统一社会信用代码：{{ detailsObj.creditCode }}</p>
      <div class="institution-details-head-appraisal">
        <p class="text2">司法鉴定类别</p>
        <p class="text4">{{ detailsObj.judicialCategory | textLimit }}</p>
      </div>
    </div>
    <div :class="{'institution-details-panel' : true, 'open' : bool1}">
      <div class="institution-details-panel-head"
           @click="handleOpen(0)">
        <span class="text2">人员信息</span>
        <van-icon name="arrow-down active"/>
      </div>
      <div :class="{'institution-details-panel-list' : true, 'show' : bool1}">
        <PersonnelCard v-for="(item, index) in personnelList"
                       :item="item"
                       :key="index"/>
      </div>
    </div>
    <div :class="{'institution-details-panel' : true, 'open' : bool2}">
      <div class="institution-details-panel-head"
           @click="handleOpen(1)">
        <span class="text2">鉴定人名单</span>
        <van-icon name="arrow-down active"/>
      </div>
      <div :class="{'institution-details-panel-list' : true, 'show' : bool2}">
        <PersonnelCard v-for="(item, index) in nameList"
                       :item="item"
                       :key="index"/>
      </div>
    </div>
    <div :class="{'institution-details-panel' : true, 'open' : bool3}">
      <div class="institution-details-panel-head"
           @click="handleOpen(2)">
        <span class="text2">资质质量</span>
        <van-icon name="arrow-down active"/>
      </div>
      <div :class="{'institution-details-panel-list' : true, 'show' : bool3}">
        <div class="more-btn">
          <div class="btn"
               @click="goRouter">更多信息
          </div>
        </div>
        <div class="certificate">
          <div class="title">
            <span class="blue"></span>
            <span>资质认定证书</span>
          </div>
          <CertificateCard v-for="(item, index) in qualityList"
                           :item="item"
                           :key="index"/>
        </div>
        <div class="certificate">
          <div class="title">
            <span class="blue"></span>
            <span>认可证书</span>
          </div>
          <CertificateCard v-for="(item, index) in approvalList"
                           :item="item"
                           :key="index"/>
        </div>
      </div>
    </div>
    <div :class="{'institution-details-panel' : true, 'open' : bool4}">
      <div class="institution-details-panel-head"
           @click="handleOpen(3)">
        <span class="text2">信用信息</span>
        <van-icon name="arrow-down active"/>
      </div>
      <div :class="{'institution-details-panel-list' : true, 'show' : bool4}">
        <CreditInfo :creditList="creditList"
                    @getCreditList="getCreditList"/>
      </div>
    </div>
  </div>
</template>

<script lang='ts'>
import CertificateCard from '@/components/modules/judicial-expertise/appraisal-institution/v-certificate-card/index.vue';
import CreditInfo from '@/components/modules/judicial-expertise/appraisal-institution/v-credit-info/index.vue';
import PersonnelCard from '@/components/modules/judicial-expertise/appraisal-institution/v-personnel-card/index.vue';
import CertificateCardModel from '@/model/modules/judicial-expertise/appraisal-institution/CertificateCardModel';
import InstitutionDetailsModel from '@/model/modules/judicial-expertise/appraisal-institution/InstitutionDetailsModel';
import PersonnelCardModel from '@/model/modules/judicial-expertise/appraisal-institution/PersonnelCardModel';
import {Component, Vue} from 'vue-property-decorator';

@Component({
  components: {
    PersonnelCard,
    CertificateCard,
    CreditInfo
  },
  filters: {
    textLimit(value: string): string {
      if (!value) {
        return '/';
      } else {
        if (value.length > 70) {
          return value.substring(0, 70) + '…';
        }
        return value;
      }
    }
  }
})
export default class InstitutionDetails extends Vue {
  private organizationId: string = '';
  // 详情数据
  private detailsObj: InstitutionDetailsModel = {} as InstitutionDetailsModel;
  // 状态
  private state: string = 'primary';
  // 人员信息数据
  private personnelList: any[] = [];
  // 人员名单
  private nameList: PersonnelCardModel[] = [];
  // 资质认定证书
  private qualityList: CertificateCardModel[] = [];
  // 认可证书
  private approvalList: CertificateCardModel[] = [];
  // 机构主键
  private id: string;
  // 信用信息
  private creditList: number[] = [];

  // 是否展开
  private bool1: boolean = true;
  private bool2: boolean = false;
  private bool3: boolean = false;
  private bool4: boolean = false;

  /**
   * 获取机构id
   * 请求数据
   */
  public async activated(): Promise<void> {
    await this.reset();
    await this.getID();
    await this.getDetails();
  }

  private getID() {
    this.id = this.$route.query.id as string;
  }

  private goRouter(): void {
    this.$router.push('/moreInfo');
  }

  // 重置状态
  private reset(): void {
    this.bool1 = true;
    this.bool2 = false;
    this.bool3 = false;
    this.bool4 = false;
    this.personnelList = [];
    this.nameList = [];
    this.qualityList = [];
    this.approvalList = [];
    this.creditList = [];
  }

  // 根据详情变更状态
  private setState(): void {
    if (this.detailsObj.state === '注销') {
      this.state = 'danger';
    } else if (this.detailsObj.state === '暂停') {
      this.state = 'warning';
    }
  }

  /**
   * 列表卡初次展开  触发数据请求
   */
  private handleOpen(index: number): void {
    if (index === 0) {
      this.bool1 = !this.bool1;
    } else if (index === 1) {
      this.bool2 = !this.bool2;
      if (this.bool2 && this.nameList.length === 0) {
        this.getNameList();
      }
    } else if (index === 2) {
      this.bool3 = !this.bool3;
      if (this.bool3 && this.qualityList.length === 0) {
        this.getQualityAndApproval();
      }
    } else if (index === 3) {
      this.bool4 = !this.bool4;
      if (this.bool4 && this.creditList.length === 0) {
        console.log(this.creditList);
        this.getCreditList(new Date().getFullYear());
      }
    }
  }

  /**
   * 基本信息数据请求：
   * @data :后端请求回来的数据；
   * @res :处理之后的数据
   * @param :id
   */
  private async getDetails(): Promise<void> {
    const res = await this.$api.xHttp.get(
      this.$interface.judicialExpertise.organization.orgPersonDetail,
      {id: this.id}
    );
    if (res.code === 0) {
      const data = res.data;
      const dataObj = {
        organizationName: data.orgName,
        state: data.status,
        licenseKey: data.licenseKey,
        termOfValidity: data.startTime + '至' + data.endTime,
        phoneNum: data.mobile,
        organizationAddress: data.address,
        creditCode: data.creditCode,
        judicialCategory: data.category
      };
      this.detailsObj = dataObj;
      this.getPersonnel(data);
    } else {
      this.$toast(res.msg);
    }
  }

  private appendEmptyObj(value: any): void {
    return value || '/';
  }

  /**
   * 人员信息请求
   * @data ；后端请求请求的额数数据
   * @res :处理之后的数据
   * @param :id
   */
  private async getPersonnel(data: any): Promise<void> {
    const legalPerson = {
      title1: this.appendEmptyObj(data.legalPerson),
      title2: `${'法人代表'}|${this.appendEmptyObj(data.lLevel)}`,
      dataList: [
        {label: '法人职务', value: this.appendEmptyObj(data.lJobthis)},
        {label: '身份证号', value: this.appendEmptyObj(data.lIDCard)},
        {label: '电话', value: this.appendEmptyObj(data.lPhone)}
      ]
    };
    this.personnelList.push(legalPerson);
    const principal = {
      title1: this.appendEmptyObj(data.principal),
      title2: `${'机构负责人'}|${this.appendEmptyObj(data.pLevel)}`,
      dataList: [
        {label: '法人职务', value: this.appendEmptyObj(data.pJob)},
        {label: '身份证号', value: this.appendEmptyObj(data.pIDCard)},
        {label: '电话', value: this.appendEmptyObj(data.pPhone)}
      ]
    };
    this.personnelList.push(principal);
    const jb = {
      title1: this.appendEmptyObj(data.handlePerson),
      title2: `${'经办人'}|${this.appendEmptyObj(data.hJob)}`,
      dataList: [
        {label: 'QQ', value: this.appendEmptyObj(data.hQQ)},
        {label: '邮箱', value: this.appendEmptyObj(data.eMail)},
        {label: '电话', value: this.appendEmptyObj(data.hPhone)}
      ]
    };
    this.personnelList.push(jb);
  }

  /**
   * 鉴定人名单
   * @data :后端请求请求的额数数据
   * @res :处理之后的数据
   * @param :id
   */
  private async getNameList(): Promise<void> {
    const res = await this.$api.xHttp.get(
      this.$interface.judicialExpertise.organization.orgAppraiserDetail,
      {id: this.id}
    );
    if (res.code === 0) {
      const dataList = res.data.list;
      const data = [];
      if (dataList.length) {
        for (let item of dataList) {
          let obj = {
            title1: item.name,
            dataList: [
              {label: '身份证号', value: item.idCard},
              {label: '执业证号', value: item.code},
              {
                label: '执业类别',
                value: item.classes
              }
            ]
          };
          data.push(obj);
        }
      }
      this.nameList = data;
    } else {
      this.$toast(res.msg);
    }
  }

  /**
   * 资质质量
   *
   */
  private async getQualityAndApproval(): Promise<void> {
    const res = await this.$api.xHttp.get(
      this.$interface.judicialExpertise.organization.orgAbilityDetail,
      {id: this.id}
    );
    console.log(res.data.list);
    if (res.code === 0) {
      const dataList = res.data.list;
      const qualityList = [];
      const approvalList = [];
      if (dataList.length) {
        for (let item of dataList) {
          if (item.type === '01') {
            let obj = {
              title: item.labName,
              state: item.status,
              dataList: [
                {label: '实验室地址', value: item.labAddress},
                {label: '证书编号', value: item.certificateNo},
                {label: '发证机关', value: item.office},
                {label: '发证日期', value: item.date + '至' + item.validTime}
              ]
            };
            qualityList.push(obj);
          } else if (item.type === '02') {
            let obj = {
              title: item.acceptScope,
              state: item.status,
              dataList: [
                {label: '初次认可', value: item.accessTime},
                {label: '证书编号', value: item.certificateNo},
                {label: '发证机关', value: item.office},
                {label: '发证日期', value: item.date + '至' + item.validTime}
              ]
            };
            approvalList.push(obj);
          }
        }
      }
      this.approvalList = approvalList;
      this.qualityList = qualityList;
    } else {
      this.$toast(res.msg);
    }
  }

  /**
   * 信用信息
   * @data :后端请求数据
   * @res :处理数据
   * @param :id , year
   */
  private getCreditList(year: number): void {
    this.creditList = [0, 0, 1, 0, 0, 1, 0] as number[];
  }
}
</script>

<style lang='less' scoped>
  .institution-details {
    padding-bottom: 60px;

    &-head {
      padding: 30px;
      background-color: #ffffff;

      &-title {
        padding: 20px 0;
        display: flex;
        align-items: center;

        .text1 {
          vertical-align: middle;
          padding-right: 24px;
          width: 600px;
        }

        .van-tag {
          vertical-align: middle;
          display: inline-block;
          text-align: center;
          width: 60px;
        }
      }

      &-appraisal {
        margin-top: 20px;

        .text2 {
          padding: 20px 0;
        }
      }
    }

    &-panel {
      background-color: #ffffff;
      margin-top: 20px;

      &-head {
        padding: 0 30px;
        height: 102px;
        border-bottom: 1px solid #eeeeee;
        display: flex;
        justify-content: space-between;
        align-items: center;

        i {
          font-size: 34px;
        }
      }

      &-list {
        padding: 0 0 30px 30px;
        overflow: hidden;
        display: none;

        .more-btn {
          padding: 20px 0;
          display: flex;
          justify-content: flex-end;

          .btn {
            width: 154px;
            height: 56px;
            box-sizing: border-box;
            border: 1px solid #0a5ffe;
            border-radius: 6px;
            font-size: 28px;
            color: #0a5ffe;
            text-align: center;
            line-height: 56px;
          }
        }

        .certificate {
          margin-top: 24px;

          .title {
            display: flex;
            align-items: center;
            font-size: 32px;

            .blue {
              width: 10px;
              height: 32px;
              margin-right: 24px;
              background: rgba(10, 95, 254, 1);
              border-radius: 5px;
            }
          }
        }
      }
    }

    .open {
      .active {
        transform: rotateX(180deg);
      }

      .show {
        display: block;
      }
    }
  }
</style>
