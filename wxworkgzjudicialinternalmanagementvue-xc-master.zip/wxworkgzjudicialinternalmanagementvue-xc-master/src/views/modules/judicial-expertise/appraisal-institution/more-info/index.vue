<template>
  <div class="more-info">
    <div class="more-info-head">
      <van-dropdown-menu>
        <van-dropdown-item :options="option1" v-model="value1"/>
        <van-dropdown-item :options="option2" v-model="value2"/>
      </van-dropdown-menu>
    </div>
    <div class="more-info-list">
      <EquipmentCard :item="item" :key="index" v-for="(item,index) in equipmentList"/>
    </div>
  </div>
</template>

<script lang='ts'>
import { Component, Vue, Watch } from 'vue-property-decorator';
import EquipmentCard from '@/components/modules/judicial-expertise/appraisal-institution/v-equipment-card/index.vue';
import EquipmentCardModel from '@/model/modules/judicial-expertise/appraisal-institution/EquipmentCardModel';

@Component({
  components: {
    EquipmentCard
  }
})
export default class MoreInfo extends Vue {
  private option1: any[] = [
    { text: '仪器设备维护', value: 0 },
    { text: '能力验证情况', value: 1 }
  ];
  private option2: any[] = [
    { text: '已审核', value: 0 },
    { text: '未审核', value: 1 },
    { text: '全部', value: 2 }
  ];
  private value1: number = 0;
  private value2: number = 2;
  // 设备信息
  private equipmentList: EquipmentCardModel[] = [];

  public created() {
    this.getEquipment();
  }

  @Watch('value1')
  private watchValue1(): void {
    this.getEquipment();
  }

  @Watch('value2')
  private watchValue2(): void {
    this.getEquipment();
  }

  /**
   * 请求数据
   * @data :请求数据
   * @res :处理数据
   * @params :option1[value1].text,option2[value2].text
   */
  private async getEquipment(): Promise<void> {
    //   const data = await this.$api.xHttp.get()
    const res = [
      {
        name: '502熏显柜',
        type: '',
        count: 1,
        payTime: '2016-12-21',
        serialNumber: '09332700',
        state: '已审核'
      },
      {
        name: '502熏显柜',
        type: '',
        count: 1,
        payTime: '2016-12-21',
        serialNumber: '09332700',
        state: '未审核'
      }
    ] as EquipmentCardModel[];
    this.equipmentList = res;
  }
}
</script>

<style lang='less' scoped>
</style>
