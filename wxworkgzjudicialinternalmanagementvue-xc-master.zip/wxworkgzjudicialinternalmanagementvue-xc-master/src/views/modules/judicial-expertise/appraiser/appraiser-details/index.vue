<template>
  <div class="appraiser-details">
    <div class="appraiser-details-base">
      <div class="title">
        <span class="text1">{{ appraiserDetails.name }}</span>
        <van-tag :type="state"
                 plain>{{ appraiserDetails.state }}</van-tag>
      </div>
      <p class="text4">所属机构：{{ appraiserDetails.mechanism }}</p>
      <p class="text4">执业证号：{{ appraiserDetails.certificateNumber }}</p>
      <p class="text4">有 效 期：{{ appraiserDetails.validity }}</p>
      <p class="text4">身份证号：{{ appraiserDetails.idCard}}</p>
      <p class="text4">执业方式：{{ appraiserDetails.practiceWay }}</p>
      <p class="text4">专业技术职务：{{ appraiserDetails.duty }}</p>
      <p class="text4">职称等级：{{ appraiserDetails.title }}</p>
      <p class="text4">手机号码：{{ appraiserDetails.phoneNumber }}</p>
      <p class="text4">鉴定类别：{{ appraiserDetails.category }}</p>
      <p class="text4">通讯地址：{{ appraiserDetails.address }}</p>
      <div class="img-box">
        <img v-if="!appraiserDetails.photo"
             :src="Photo">
        <img v-else
             :src="appraiserDetails.photo">
      </div>
    </div>
    <div class="appraiser-details-credit">
      <div class="appraiser-details-credit-panel">
        <div class="appraiser-details-credit-panel-head">
          <span class="text2">信用信息</span>
        </div>
        <div class="appraiser-details-credit-panel-list">
          <CreditInfo :creditList="appraiserDetails.creditList"
                      @getCreditList="getCreditList" />
        </div>
      </div>
    </div>
  </div>
</template>

<script lang='ts'>
import { Component, Vue } from 'vue-property-decorator';
import CreditInfo from '@/components/modules/judicial-expertise/appraisal-institution/v-credit-info/index.vue';
import AppraiserDetailsModel from '@/model/modules/judicial-expertise/appraiser/AppraiserDetailsModel';
// @ts-ignore
import Photo from '@/assets/images/modules/judicial-expertise/avtor.png';

@Component({
  components: {
    CreditInfo
  }
})
export default class AppraiserDetails extends Vue {
  // 年份
  private year: number = 0;
  // 年份数组
  private yearArr: number[] = [];
  private Photo = Photo;
  // id
  private id: string = '';
  private state: string = 'primary';
  // 鉴定人详情数据
  private appraiserDetails: AppraiserDetailsModel = new AppraiserDetailsModel();

  public async activated(): Promise<void> {
    await this.getID();
    await this.getAppraiser();
    await this.setState();
  }

  private getID() {
    this.id = this.$route.query.id as string;
  }

  private getYear(): void {
    if (this.yearArr.length !== 0) {
      return;
    }
    const curYear = new Date().getFullYear();
    this.year = curYear;
    for (let i = 0; i < 5; i++) {
      this.yearArr.push(curYear - i);
    }
  }

  private setState(): void {
    if (this.appraiserDetails.state === '暂停') {
      this.state = 'warning';
    } else if (this.appraiserDetails.state === '注销') {
      this.state = 'danger';
    }
  }

  /**
   * 获取数据
   * @data :请求数据
   * @res :处理之后数据
   * @params :id
   */
  private async getAppraiser(): Promise<void> {
    // const data = this.$api
    const res = new AppraiserDetailsModel();
    res.name = '陈小春';
    res.sex = '男';
    res.state = '正常';
    res.mechanism = 'xxx广东省机构';
    res.certificateNumber = '23942384901389012';
    res.category = '法医物证司法鉴定';
    res.validity = '2019/07/09 - 2024/07/08';
    res.idCard = '410511198800000000';
    res.practiceWay = '专职';
    res.duty = '高级工程师';
    res.title = '正高级';
    res.phoneNumber = '18299990000';
    res.address = '广州市白云区粤溪北路';
    res.creditList = [0, 0, 0, 1, 0, 1, 0];

    this.appraiserDetails = res;
  }

  /**
   * 获取信用数据
   * @data :请求数据
   * @res :处理数据
   * @params :year,id
   */
  private async getCreditList(year: number): Promise<void> {
    // const data = this.$api
    const res = [0, 23, 4, 4, 4, 10, 0] as number[];
    this.appraiserDetails.creditList = res;
    console.log('执行了');
  }
}
</script>

<style lang='less' scoped>
.appraiser-details {
  &-base {
    padding: 48px 30px;
    background-color: #ffffff;

    .title {
      display: flex;
      align-items: center;
      margin: 20px 0;
      span {
        margin-right: 12px;
      }
    }

    .img-box {
      position: absolute;
      width: 190px;
      height: 190px;
      background-color: #666666;
      top: 68px;
      right: 30px;

      img {
        width: 100%;
        height: 100%;
      }
    }
  }

  &-credit {
    &-panel {
      background-color: #ffffff;
      margin-top: 20px;

      &-head {
        padding: 0 30px;
        height: 102px;
        border-bottom: 1px solid #eeeeee;
        display: flex;
        justify-content: space-between;
        align-items: center;

        i {
          font-size: 34px;
        }
      }

      &-list {
        padding: 30px;
        overflow: hidden;

        .more-btn {
          padding: 20px 0;
          display: flex;
          justify-content: flex-end;
          .btn {
            width: 154px;
            height: 56px;
            box-sizing: border-box;
            border: 1px solid #0a5ffe;
            border-radius: 6px;
            font-size: 28px;
            color: #0a5ffe;
            text-align: center;
            line-height: 56px;
          }
        }

        .certificate {
          margin-top: 24px;
          .title {
            display: flex;
            align-items: center;
            font-size: 32px;
            .blue {
              width: 10px;
              height: 32px;
              margin-right: 24px;
              background: rgba(10, 95, 254, 1);
              border-radius: 5px;
            }
          }
        }

        .credit-list {
          display: flex;
          padding: 0 30px;
          justify-content: space-between;
          font-size: 28px;
          color: #333333;
          margin: 30px 0;

          span {
            color: #999999;
          }

          .red {
            color: #f84242;
          }
        }
      }
    }
  }
}

.timer-select {
  .timer {
    width: 184px;
    height: 56px;
    background: rgba(247, 247, 247, 1);
    border: 1px solid rgba(230, 230, 230, 1);
    border-radius: 28px;
    text-align: center;
    line-height: 56px;
    font-size: 24px;
    color: #666666;

    .year {
      padding-right: 12px;
    }

    span {
      vertical-align: middle;
    }
  }
}
</style>
