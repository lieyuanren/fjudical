<template>
  <div class="appraiser">
    <div class="appraiser-head">
      <van-search @input="handleInput" placeholder="请输入搜索关键词" v-model="searchkey"/>
      <van-dropdown-menu>
        <van-dropdown-item :options="options" v-model="optionIndex"/>
      </van-dropdown-menu>
    </div>
    <p class="tips">共{{ count }}人，满足当前条件：{{ props }}人</p>
    <div style="margin-bottom: 60px;">
      <van-pull-refresh v-model="refreshing" @refresh="onRefresh">
        <van-list
          v-model="loading"
          :finished="finished"
          finished-text="没有更多了"
          @load="onLoad"
        >
          <AppraiserCard :item="item" :key="index" v-for="(item,index) in cardList"/>
        </van-list>
      </van-pull-refresh>
    </div>
  </div>
</template>

<script lang='ts'>
  import { Component, Vue, Watch } from 'vue-property-decorator';
  import AppraiserCardModel from '@/model/modules/judicial-expertise/appraiser/AppraiserCardModel';
  import AppraiserCard from '@/components/modules/judicial-expertise/appraiser/v-appraiser-card/index.vue';

  @Component({
    components: {
      AppraiserCard
    }
  })
  export default class Appraiser extends Vue {
    private searchkey: string = '';
    private optionIndex: number = 0;
    private options: any = [
      { text: '执业状态(正常)', value: 0 },
      { text: '执业状态(注销)', value: 1 },
      { text: '执业状态(暂停)', value: 2 }
    ];
    private timerLimit: any = null;

    // 数据列表
    private cardList: AppraiserCardModel[] = [];

    // 鉴定人总数
    private count: number = 0;
    private props: number = 0;
    private currentPage: number = 1;
    private pageSize: number = 10;

    private loading: boolean = false;
    private finished: boolean = false;
    private refreshing: boolean = false;

    private async created(): Promise<void> {
      this.getCount();
      // this.search();
    }

    private handleInput(): void {
      this.cardList = [];
      this.onRefresh();
    }

    @Watch('optionIndex')
    private watchOptionIndex(): void {
      this.cardList = [];
      this.currentPage = 1;
      this.search();
    }

    /**
     * 请求数据
     * @data : 请求回来的数据
     * @res :处理后的数据
     * @params :传参对象
     * @return ：返回的res满足AppraiserCardModel类型
     */
    private async search(): Promise<void> {
      let params = {
        name: this.searchkey,
        status: this.getStatus(),
        currentPage: this.currentPage,
        pageSize: this.pageSize
      };
      const res = await this.$api.xHttp.post(
        this.$interface.judicialExpertise.appraiser.list,
        params
      );
      if (res.code === 0) {
        let list = res.data.list;
        this.props = res.data.total;
        let arr: AppraiserCardModel[] = [];
        if (list.length) {
          for (let item of list) {
            let appraiserCardModel = new AppraiserCardModel();
            // TODO:注意补充id，跳转详情页需要
            appraiserCardModel.id = '1';
            appraiserCardModel.name = item.name;
            appraiserCardModel.organization = item.organization;
            appraiserCardModel.category = item.category;
            appraiserCardModel.state = item.status;
            appraiserCardModel.imgUrl = item.head;
            arr.push(appraiserCardModel);
          }
        }
        this.cardList.push(...arr);
        this.loading = false;
        this.currentPage++;
        this.finished = res.data.pageNum >= res.data.pages;
      } else {
        this.$toast(res.msg);
      }
    }

    /**
     * 获取鉴定人总数
     */
    private async getCount(): Promise<void> {
      const res = await this.$api.xHttp.get(
        this.$interface.judicialExpertise.appraiser.count
      );
      if (res.code === 0) {
        this.count = res.data;
      } else {
        this.$toast(res.msg);
      }
    }

    /**
     * 获取选中状态
     */
    private getStatus(): string {
      let text = this.options[this.optionIndex].text
        .replace('(', '')
        .replace(')', '');
      return text.substring(text.length - 2, text.length);
    }

    /**
     * 上拉刷新
     */
    private async onLoad(): Promise<void> {
      if (this.refreshing) {
        this.cardList = [];
        this.refreshing = false;
      }
      await this.search();
    }

    private onRefresh() {
      this.currentPage = 1;
      // 清空列表数据
      this.finished = false;
      // 重新加载数据
      // 将 loading 设置为 true，表示处于加载状态
      this.loading = true;
      this.onLoad();
    }
  }
</script>

<style lang='less' scoped>
  .appraiser {
    &-head {
      background-color: #ffffff;
    }
    .tips {
      font-size: 24px;
      color: rgba(153, 153, 153, 1);
      padding: 30px;
    }
  }

  .van-hairline--top-bottom::after,
  .van-hairline-unset--top-bottom::after {
    border: none;
  }

  /deep/ .van-dropdown-menu {
    height: 0.9rem;
  }

  .van-search {
    padding: 15px;
  }
</style>
