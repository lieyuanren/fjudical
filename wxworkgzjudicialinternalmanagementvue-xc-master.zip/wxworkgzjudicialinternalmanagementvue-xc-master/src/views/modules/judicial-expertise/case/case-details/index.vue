<template>
  <div class="container-details">
    <div class="container-details-head">
      <p class="text1">统一案号：{{ detailsData.caseID }}</p>
      <p class="text4">机构名称：{{ detailsData.organizationName }}</p>
      <p class="text4">结案时间：{{ detailsData.overTime }}</p>
    </div>
    <p class="container-details-title">基本信息</p>
    <div class="container-details-base">
      <div class="card">
        <p class="text2">委托人信息</p>
        <p class="text4">委托人：{{ detailsData.client }}</p>
        <p class="text4">委托人类型/属地：{{ detailsData.clientTypes }}</p>
        <p class="text4">鉴定类别：{{ detailsData.appraisalType }}</p>
        <p class="text4">委托日期：{{ detailsData.entrustDate }}</p>
        <p class="text4">联系人：{{ detailsData.contacts }}</p>
        <p class="text4">联系地址：{{ detailsData.contactsAddress }}</p>
      </div>
      <div class="card">
        <p class="text2">委托事项</p>
        <p class="text4">鉴定对象：{{ detailsData.appraiserObj }}</p>
        <p class="text4">鉴定对象类型：{{ detailsData.appraiserType }}</p>
        <p class="text4">委托鉴定事项：{{ detailsData.appraisalMatter }}</p>
      </div>
      <div class="card">
        <p class="text2">其他</p>
        <p class="text4">鉴定用途：{{ detailsData.appraisalUse }}</p>
        <p class="text4">基本案情：{{ detailsData.basicCase | limitText }}</p>
      </div>
    </div>
    <p class="container-details-title">更多案件信息</p>
    <div class="container-details-more">
      <div class="card">
        <p class="text4">机构案号：{{ detailsData.organizationCaseID }}</p>
        <p class="text4">鉴定人：{{ detailsData.appraiser }}</p>
        <p class="text4">文书复核人：{{ detailsData.documentReviewer }}</p>
        <p class="text4">文书签发人：{{ detailsData. issuedby}}</p>
        <p class="text4">重大事项报告类型：{{ detailsData. importantMatters}}</p>
        <p class="text4">鉴定时限：{{ detailsData. appraisalTimeLimit}}</p>
      </div>
    </div>
  </div>
</template>

<script lang='ts'>
import { Component, Vue } from 'vue-property-decorator';
import CaseDetailsModel from '@/model/modules/judicial-expertise/case/CaseDetailsModel';

// 测试数据
const details = new CaseDetailsModel();
details.caseID = '029391012313';
details.overTime = '2020-1-6';
details.organizationName = '广州市某某机构';
details.client = '何晓明';
details.clientTypes = '市外个人';
details.entrustDate = '2019-1-12';
details.contacts = '何晓明';
details.contactsAddress = '广东省';
details.appraiserObj = '何晓明，何小红';
details.appraiserType = '人';
details.appraisalMatter = '亲自鉴定';
details.appraisalUse = '其他';
details.basicCase =
  ' 2019年10月25日，委托人要求对何小明与何小虹之间有无亲生血缘关系进行鉴定。2019年10月25日，委托人要求对何小明与何小虹之间有无亲生。大飒飒委托人要求对何小明与何小虹之间有无亲生委托人要求对何小明与何小虹之间有无亲生';
details.organizationCaseID = '广华物司[2019]物鉴字第XXXX号';
details.appraiser = '罗斌， 谢剑捷';
details.documentReviewer = '王鸿';
details.issuedby = '罗斌';
details.importantMatters = '不属于重大事项类型报告案件';
details.appraisalTimeLimit = '2019-11-24';

@Component({
  filters: {
    // 基本信息不能超过三行
    limitText(value: string): string {
      if (value && value.length > 74) {
        return value.substring(0, 70) + '……';
      }
      return value;
    }
  }
})
export default class CaseDetails extends Vue {
  // 统一案号
  private caseID: string = '';
  // 详情数据
  private detailsData: CaseDetailsModel = new CaseDetailsModel();

  private async activated(): Promise<void> {
    // 获取案号
    this.caseID = this.$route.query.caseID as string;
    this.detailsData = await this.getDetails();
  }

  /**
   * 请求数据
   * @data :后端请求的数据
   * @res :处理后的数据
   * @params :传参对象,{ caseID }
   * @return :返回的res必须满足 CaseDetailsModel数据结构
   */
  private async getDetails(): Promise<any> {
    let res = await this.$api.xHttp.get(
      this.$interface.judicialExpertise.case.detail,
      { code: this.caseID }
    );
    if (res.code === 0) {
      const data = res.data;
      let details = new CaseDetailsModel();
      details.caseID = data.code;
      details.overTime = data.closeTime;
      details.organizationName = data.organization;
      details.client = data.bailor;
      details.clientTypes = data.bailorType;
      details.appraisalType = data.category;
      details.entrustDate = data.entrustDate;
      details.contacts = data.linkman;
      details.contactsAddress = data.address;
      details.appraiserObj = data.authenticateObj;
      details.appraiserType = data.objType;
      details.appraisalMatter = data.matter;
      details.appraisalUse = data.purpose;
      details.basicCase = data.details;
      details.organizationCaseID = data.orgCode;
      details.appraiser = data.appraiser;
      details.documentReviewer = data.reviewer;
      details.issuedby = data.signer;
      details.importantMatters = data.reportType;
      details.appraisalTimeLimit = data.timeLimit;
      return details;
    } else {
      this.$toast(res.msg);
    }
  }
}
</script>

<style lang='less' scoped>
.container-details {
  .card {
    padding: 30px;
    background-color: #ffffff;
    margin: 20px 0;

    .text2 {
      font-weight: normal !important;
      padding-bottom: 28px;
      margin-bottom: 20px;
      border-bottom: 1px solid rgba(238, 238, 238);
    }
  }

  &-head {
    padding: 50px 30px;
    margin-bottom: 20px;
    background-color: #ffffff;
    .text1 {
      font-weight: normal !important;
    }
  }

  &-title {
    font-size: 32px;
    padding: 0 30px;
  }
}
</style>
