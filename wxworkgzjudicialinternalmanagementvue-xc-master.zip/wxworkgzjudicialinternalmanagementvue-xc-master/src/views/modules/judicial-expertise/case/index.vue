<template>
  <div class="case">
    <div class="case-head">
      <div class="row">
        <div @click="switchShow"
             class="timer-select">
          <span class="label">{{ sureTime }}</span>
          <van-icon name="arrow-down" />
        </div>
        <div class="search-box">
          <van-search @input="handleSearch"
                      background="#f2f2f2"
                      placeholder="搜索统一案号或者委托人姓名"
                      v-model="searchKey"></van-search>
        </div>
      </div>
    </div>
    <div class="case-content">
      <p class="tips">
        <span>共</span>
        <span>{{ caseCount }}</span>
        <span>件，</span>
        <span>满足当前条件：</span>
        <span>{{ conformCount }}</span>
      </p>
      <van-pull-refresh v-model="loading" @refresh="onRefresh">
        <van-list v-model="loading"
                  finished-text="没有更多了"
                  :finished="finished"
                  :immediate-check="false"
                  :offset="10"
                  direction="down"
                  @load="onLoad">
          <CaseCard :item="item"
                    :key="index"
                    v-for="(item,index) in caseList" />
        </van-list>
      </van-pull-refresh>
    </div>
    <van-popup @click-overlay="switchShow"
               position="bottom"
               v-model="isShow">
      <van-picker :columns="timeStrArr"
                  @cancel="isShow = false"
                  @confirm="onConfirm"
                  show-toolbar />
    </van-popup>
  </div>
</template>

<script lang='ts'>
import { Component, Vue, Watch } from 'vue-property-decorator';
import CaseCard from '@/components/modules/judicial-expertise/case/v-case-card/index.vue';
import CaseCardModel from '@/model/modules/judicial-expertise/case/CaseCardModel';

// 案件
@Component({
  components: {
    CaseCard
  }
})
export default class Case extends Vue {
  // 时间
  private sureTime: number = new Date().getFullYear();
  // 搜索关键字
  private searchKey: string = '';
  // 是否显示
  private isShow: boolean = false;
  // 年份项
  private timeStrArr: number[] = [2019];
  // 案件数据
  private caseList: CaseCardModel[] = [];
  private timerLimit: any = null;
  // 案件总数
  private caseCount: number = 0;
  // 满足条件案件数
  private conformCount: number = 0;
  private timeLimit: any = null;
  private finished: boolean = false;
  private loading: boolean = false;
  private currentPage: number = 1;
  private pageSize: number = 10;

  private async created(): Promise<void> {
    this.timeStrArr = this.getYearArr();
    // 获取案件总数
    this.caseCount = await this.getCaseCount();
    // 获取案件列表
    this.caseList = [];
    await this.getCaseList(this.searchKey);
  }

  private onRefresh() {
    this.currentPage = 0;
    // 清空列表数据
    this.finished = false;
    // 重新加载数据
    // 将 loading 设置为 true，表示处于加载状态
    this.loading = true;
    this.caseList = [];
    this.onLoad();
  }

  /**
   * 请求数据
   * @data :请求回来的数据
   * @res :处理过的数据
   * @params :传参对象，{ sureTime, searchKey}
   */
  private async getCaseList(searchKey: string): Promise<any> {
    const that = this;
    let param = {
      year: this.sureTime,
      codeOrName: searchKey,
      currentPage: that.currentPage ++,
      pageSize: that.pageSize
    };
    let res = await that.$api.xHttp.post(
      that.$interface.judicialExpertise.case.list,
      param
    );
    if (res.code === 0) {
      const length = res.data.list.length;
      that.conformCount = res.data.total;
      let caseArr: CaseCardModel[] = [];
      if (length) {
        for (let i = 0; i < length; i++) {
          let caseCardModel = new CaseCardModel();
          const caseVO = res.data.list[i];
          caseCardModel.caseID = caseVO.code;
          caseCardModel.organizationName = caseVO.organization;
          caseCardModel.client = caseVO.bailor;
          caseCardModel.overTime = caseVO.date;
          caseArr.push(caseCardModel);
        }
        that.finished = that.conformCount < that.currentPage * that.pageSize;
      } else {
        that.finished = true;
      }
      that.loading = false;
      this.caseList.push(...caseArr);
    } else {
      that.$toast(res.msg);
    }
  }

  // 年份更改触发搜索
  @Watch('sureTime')
  private async watchSureTime(): Promise<void> {
    this.caseList = [];
    await this.getCaseList(this.searchKey);
  }

  // 时间选择显示控制
  private switchShow(): void {
    this.isShow = !this.isShow;
  }

  // 输入完触发搜索
  private handleSearch(): void {
    // 防抖节流
    clearTimeout(this.timerLimit);
    this.timerLimit = setTimeout(async () => {
      this.caseList = [];
      this.currentPage = 0;
      await this.getCaseList(this.searchKey);
    }, 1000);
  }

  // onConfirm
  private onConfirm(value: number): void {
    this.sureTime = value;
    this.isShow = false;
  }

  // 获取年份选项
  private getYearArr(): number[] {
    let arr = [];
    const date = new Date();
    let year = date.getFullYear();
    for (let i = 0; i < 5; i++) {
      arr.push(year);
      year--;
    }
    return arr;
  }

  // 获取年份案件总数
  private async getCaseCount() {
    const data = {
      year: this.sureTime
    };
    let res = await this.$api.xHttp.get(
      this.$interface.judicialExpertise.case.count,
      data
    );
    if (res.code === 0) {
      return res.data;
    } else {
      this.$toast(res.msg);
    }
  }

  /**
   * 下拉加载
   */
  private onLoad() {
    this.getCaseList(this.searchKey);
  }
}
</script>

<style lang='less' scoped>
.case {
  &-head {
    padding: 30px;
    background-color: rgb(255, 255, 255);

    .row {
      display: flex;
      border: 0;
      line-height: 72px;
      height: 72px;
      border-radius: 6px;
      overflow: hidden;
      .timer-select {
        width: 156px;
        text-align: center;
        font-size: 28px;
        font-weight: 500;
        height: 100%;
        background-color: #f2f2f2;
        i {
          vertical-align: middle;
        }

        .label {
          color: #333333;
          padding-right: 8px;
          vertical-align: middle;
        }
      }
      .search-box {
        display: flex;
        flex: 1;
        background-color: #f2f2f2;
      }
    }
  }

  &-content {
    .tips {
      padding: 30px 40px;
      font-size: 24px;
      color: rgba(153, 153, 153, 1);
    }
    margin-bottom: 17%;
  }

  // 重置vant组件样式
  .van-search__content {
    background-color: #f2f2f2;
  }

  .van-cell {
    padding: 0;
    box-sizing: border-box;
  }

  .van-search {
    width: 100%;
    padding: 0;
  }

  [class*="van-hairline"]::after {
    border: none;
  }
}
</style>
