<template>
  <div class="home">
    <h1 class="home-title">数据汇聚统计</h1>
    <HomeCard :item="item" :key="index" v-for="(item,index) in cardList"/>
  </div>
</template>

<script lang='ts'>
import { Component, Vue } from 'vue-property-decorator';
import HomeCard from '@/components/modules/judicial-expertise/home/v-home-card/index.vue';
import HomeCardModel from '@/model/modules/judicial-expertise/home/HomeCardModel';

// 首页
@Component({
  components: {
    HomeCard
  }
})
export default class Home extends Vue {
  // 展示卡数据
  private cardList: HomeCardModel[] = [];

  private async created(): Promise<void> {
    this.cardList = await this.getHomeData();
  }

  /**
   * 请求后端接口
   * @data :后端获取的数据
   * @res : 处理后data后，前端需要的数据
   * @params :传参对象，null
   */
  private async getHomeData(): Promise<any> {
    let res = await this.$api.xHttp.get(this.$interface.judicialExpertise.index.index);
    if (res.code === 0) {
      let org = new HomeCardModel();
      let arr: HomeCardModel[] = [];
      org.data = res.data.orgCount;
      org.prop = '鉴定机构（家）';
      org.imgUrl = require('../../../../assets/images/modules/judicial-expertise/home-1.png');
      arr.push(org);
      let appraiser = new HomeCardModel();
      appraiser.data = res.data.appraiserCount;
      appraiser.prop = '鉴定人（人）';
      appraiser.imgUrl = require('../../../../assets/images/modules/judicial-expertise/home-2.png');
      arr.push(appraiser);
      let cases = new HomeCardModel();
      cases.data = res.data.caseCount;
      cases.prop = '本年度鉴定案件（件）';
      cases.imgUrl = require('../../../../assets/images/modules/judicial-expertise/home-3.png');
      arr.push(cases);
      return arr;
    } else {
      this.$toast(res.msg);
    }
  }
}
</script>

<style lang='less' scoped>
.home {
  position: absolute;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  background-color: #ffffff;
  padding: 30px;
  &-title {
    font-size: 48px;
    font-weight: bold;
    margin-top: 30px;
    margin-bottom: 60px;
  }
}
</style>
