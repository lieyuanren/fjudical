<template>
  <div class="judicial-expertise">
    <transition mode="out-in"
                name="component-fade">
      <component :is="componentIdArr[active]"></component>
    </transition>
    <div class="judicial-expertise-menu">
      <van-tabbar v-model="active">
        <van-tabbar-item>
          <span>首页</span>
          <img :src="props.active ? menuIcon.homeActive : menuIcon.homeInactive"
               class="judicial-expertise-menu-icon"
               slot="icon"
               slot-scope="props" />
        </van-tabbar-item>
        <van-tabbar-item>
          <span>案件</span>
          <img :src="props.active ? menuIcon.recordActive : menuIcon.recordInactive"
               class="judicial-expertise-menu-icon"
               slot="icon"
               slot-scope="props" />
        </van-tabbar-item>
        <van-tabbar-item>
          <span>鉴定机构</span>
          <img :src="props.active ? menuIcon.assessActive : menuIcon.assessInactive"
               class="judicial-expertise-menu-icon"
               slot="icon"
               slot-scope="props" />
        </van-tabbar-item>
        <van-tabbar-item>
          <span>鉴定人</span>
          <img :src="props.active ? menuIcon.authenticActActive : menuIcon.authenticActInactive"
               class="judicial-expertise-menu-icon"
               slot="icon"
               slot-scope="props" />
        </van-tabbar-item>
        <van-tabbar-item>
          <span>统计分析</span>
          <img :src="props.active ? menuIcon.statisticsActive : menuIcon.statisticsInactive"
               class="judicial-expertise-menu-icon"
               slot="icon"
               slot-scope="props" />
        </van-tabbar-item>
      </van-tabbar>
    </div>
  </div>
</template>

<script lang='ts'>
import { Component, Vue } from 'vue-property-decorator';
import Home from '@/views/modules/judicial-expertise/home/index.vue';
import Case from '@/views/modules/judicial-expertise/case/index.vue';
import Appraisal from '@/views/modules/judicial-expertise/appraiser/index.vue';
import AppraisalEnstitution from '@/views/modules/judicial-expertise/appraisal-institution/index.vue';
import StatisticalAnalysis from '@/views/modules/judicial-expertise/statistical-analysis/index.vue';

@Component({
  components: {
    Home,
    Case,
    Appraisal,
    AppraisalEnstitution,
    StatisticalAnalysis
  }
})
export default class JudicialExpertise extends Vue {
  // 组件名数组
  private componentIdArr: string[] = [
    'Home',
    'Case',
    'AppraisalEnstitution',
    'Appraisal',
    'StatisticalAnalysis'
  ];
  private active: number = 0;
  // 底部菜单图标
  private menuIcon: any = {
    homeActive: require('../../../assets/images/modules/notarization/index/home-active.png'),
    homeInactive: require('../../../assets/images/modules/notarization/index/home-inactive.png'),
    recordActive: require('../../../assets/images/modules/notarization/index/record-active.png'),
    recordInactive: require('../../../assets/images/modules/notarization/index/record-inactive.png'),
    assessActive: require('../../../assets/images/modules/notarization/index/assess-active.png'),
    assessInactive: require('../../../assets/images/modules/notarization/index/assess-inactive.png'),
    authenticActActive: require('../../../assets/images/modules/notarization/index/authentic-act-active.png'),
    authenticActInactive: require('../../../assets/images/modules/notarization/index/authentic-act-inactive.png'),
    statisticsActive: require('../../../assets/images/modules/notarization/index/statistics-active.png'),
    statisticsInactive: require('../../../assets/images/modules/notarization/index/statistics-inactive.png')
  };
}
</script>

<style lang='less' scoped>
.judicial-expertise {
  position: relative;
  min-height: 100%;
  &-menu {
    span {
      font-size: 20px;
    }

    &-icon {
      width: 48px;
      height: 48px;
    }
  }
}

// 重置样式
.van-tabbar-item--active {
  color: #0a5ffe;
}
</style>
