<template>
  <div class="appraisal-institution">
    <div class="appraisal-institution-content" >
      <div class="text2">广州市机构类别占有率</div>
      <div class="appraisal-institution-content-in">
        <div :key="index" class="percentage-box" v-for="(item,index) in topList">
          <van-circle
            :clockwise="false"
            :color="setColor(index)"
            :rate="item.proportion"
            :stroke-width="70"
            :text="percentage(item.proportion)"
            layer-color="#F2F2F2"
            size="2.53333rem"
            v-model="item.proportion"
          />
          <p class="text4">{{ item.organizationName }}</p>
        </div>
      </div>
    </div>
    <div class="appraisal-institution-content">
      <div class="text2">机构类别占有情况</div>
      <div class="progress-list">
        <ProgressItem :item="item" :key="index" v-for="(item,index) in otherList"/>
      </div>
    </div>
  </div>
</template>

<script lang='ts'>
import { Component, Prop, Vue, Watch } from 'vue-property-decorator';
import ProgressItemModel from '@/model/modules/judicial-expertise/statistical-analysis/ProgressItemModel';
import ProgressItem from '@/components/modules/judicial-expertise/statistical-analysis/v-progress-item/index.vue';

@Component({
  components: {
    ProgressItem
  }
})
export default class AppraisalInstitution extends Vue {
  @Prop({
    type: Array,
    default: () => []
  })
  private readonly organizationList!: ProgressItemModel[];

  private topList: ProgressItemModel[] = [];
  private otherList: ProgressItemModel[] = [];

  public created() {
    this.handleList();
  }

  // TODO:数据变动更改图标

  @Watch('organizationList')
  private watchOrganizationList(): void {
    this.handleList();
  }

  private setColor(index: number): string {
    if (index === 0) {
      return '#1F80F1';
    } else if (index === 1) {
      return '#03B57D';
    } else {
      return '#F6B042';
    }
  }

  // 计算百分比
  private percentage(value: any): string {
    if (!value) {
      return '0%';
    }
    if (value === 0 ) {
      return '0%';
    }
    return `${ value }%`;
  }

  private handleList(): void {
    this.topList = this.organizationList.slice(0, 3);
    this.otherList = this.organizationList.slice(3);
  }
}
</script>

<style lang='less' scoped>
.appraisal-institution {
  margin-bottom: 130px;
  &-content {
    background: rgba(255, 255, 255, 1);
    border: 1px solid rgba(224, 224, 224, 0.2);
    border-radius: 12px;
    margin: 30px;
    padding: 30px;

    &-in {
      display: flex;
      margin-top: 48px;
      justify-content: space-between;
      .percentage-box {
        text-align: center;
        width: 190px;
      }
    }

    .progress-list {
      margin-top: 48px;
    }
  }
}
</style>
