<template>
  <div class="appraiser">
    <div class="appraiser-content">
      <div class="text2">广州市鉴定人类别占有量</div>
      <div class="appraiser-content-f2">
        <canvas id="myChart" style="width:100%;"></canvas>
      </div>
    </div>
    <div class="appraiser-content">
      <div class="text2">鉴定人类别占有情况</div>
      <div class="appraiser-content-list">
        <div :key="index" class="appraiser-content-list-item" v-for="(item,index) in appraiserList">
          <img :src="imgUrl1" v-if="index===0"/>
          <img :src="imgUrl2" v-else-if="index===1"/>
          <img :src="imgUrl3" v-else-if="index===2"/>
          <span class="ranking" v-else>{{ index+1 | handleNumber }}</span>
          <span class="mechanism">{{ item.mechanism }}</span>
          <span class="sales">{{ item.sales }}</span>
        </div>
      </div>
    </div>
  </div>
</template>

<script lang='ts'>
import {Component, Prop, Vue, Watch} from 'vue-property-decorator';
import AppraiserNumberModel from '@/model/modules/judicial-expertise/statistical-analysis/AppraiserNumberModel';
import bar from '@/plugins/antv-f2/bar';

@Component({
  filters: {
    handleNumber(value: number): string {
      return value > 9 ? `${ value }` : `0${ value }`;
    }
  }
})
export default class Appraiser extends Vue {
  @Prop({
    type: Array,
    default: () => []
  })
  private readonly appraiserList!: AppraiserNumberModel[];

  private topList: AppraiserNumberModel[] = [];
  private otherList: AppraiserNumberModel[] = [];
  private imgUrl1: string = require('@/assets/images/modules/notarization/index/top-01.png');
  private imgUrl2: string = require('@/assets/images/modules/notarization/index/top-02.png');
  private imgUrl3: string = require('@/assets/images/modules/notarization/index/top-03.png');

  @Watch('appraiserList')
  public dragPig() {
    if (this.appraiserList.length > 0) {
      this.appraiserList.length > 3 ? bar(this.appraiserList.slice(0, 3)) : bar(this.appraiserList);
    }
  }
}
</script>

<style lang='less' scoped>
.appraiser {
  margin-bottom: 130px;
  &-content {
    background: rgba(255, 255, 255, 1);
    border: 1px solid rgba(224, 224, 224, 0.2);
    border-radius: 12px;
    margin: 30px;
    padding: 30px 0;

    .text2 {
      padding: 0 30px;
    }

    &-f2 {
      width: 100%;
    }

    &-list {
      padding: 0 60px;
      margin-top: 48px;
      &-item {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin: 34px 0;

        img {
          width: 48px;
          height: 48px;
        }

        .ranking {
          width: 48px;
          height: 48px;
          font-size: 32px;
          color: #999999;
          font-weight: bold;
          text-align: center;
        }

        .mechanism {
          font-size: 32px;
          margin-right: auto;
          margin-left: 64px;
          color: #333333;
        }

        .sales {
          font-size: 36px;
          font-weight: bold;
          color: #333333;
        }
      }
    }
  }
}
</style>
