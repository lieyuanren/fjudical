<template>
  <div class="statistical-analysis">
    <div class="statistical-analysis-head">
      <div :class="{'statistical-analysis-head-btn' : true, 'active' : activeIndex === 0}"
           @click="clickBtn(0)">鉴定机构
      </div>
      <div :class="{'statistical-analysis-head-btn' : true, 'active' : activeIndex === 1}"
           @click="clickBtn(1)">鉴定人
      </div>
    </div>
    <div class="timer-box">
      <div class="timer-box-select"
           @click="handleClick">
        <span class="year">{{ dateStr }}</span>
        <van-icon name="arrow-down" />
      </div>
    </div>
    <component :appraiserList="appraiserList"
               :is="componentsId[activeIndex]"
               :organizationList="organizationList"></component>
    <van-popup v-model="show"
               position="bottom">
      <van-picker show-toolbar
                  v-model="dateStr"
                  :columns="timeStrArr"
                  @cancel="onCancel"
                  @confirm="onConfirm" />
    </van-popup>
  </div>
</template>

<script lang='ts'>
import AppraiserNumberModel from '@/model/modules/judicial-expertise/statistical-analysis/AppraiserNumberModel';
import ProgressItemModel from '@/model/modules/judicial-expertise/statistical-analysis/ProgressItemModel';
import AppraisalInstitution from '@/views/modules/judicial-expertise/statistical-analysis/components/v-appraisal-institution/index.vue';
import Appraiser from '@/views/modules/judicial-expertise/statistical-analysis/components/v-appraiser/index.vue';
import { Component, Vue, Watch } from 'vue-property-decorator';

@Component({
  components: {
    AppraisalInstitution,
    Appraiser
  }
})
export default class StatisticalAnalysis extends Vue {
  private activeIndex: number = 0;
  private currentRate: number = 30;
  private currentDate: Date = new Date();
  private sureDate: Date = new Date();
  private maxDate: Date = new Date();
  private show: boolean = false;
  private componentsId: string[] = ['AppraisalInstitution', 'Appraiser'];
  // 年份项
  private timeStrArr: number[] = [2019];
  // 鉴定机构数据
  private organizationList: ProgressItemModel[] = [];
  // 鉴定人数据
  private appraiserList: AppraiserNumberModel[] = [];
  private dateStr = 2019;
  private types: string[] = [
    '法医临床',
    '法医物证',
    '痕迹',
    '法医毒物',
    '文书',
    '声像资料',
    '微量物证',
    '法医病理',
    '法医精神病',
    '知识产权',
    '空气污染环境损害',
    '污染物性质',
    '生态系统环境损害',
    '土壤与地下水环境损害',
    '近海洋与海岸带环境损害',
    '地表水和沉积物环境损害',
    '其他环境损害'
  ];

  public async created(): Promise<void> {
    this.timeStrArr = this.getYearArr();
    await this.getOrganizationList();
  }

  // 获取年份选项
  private getYearArr(): number[] {
    let arr = [];
    const date = new Date();
    let year = date.getFullYear();
    this.dateStr = year;
    for (let i = 0; i < 5; i++) {
      arr.push(year);
      year--;
    }
    return arr;
  }

  private clickBtn(index: number): void {
    this.activeIndex = index;
  }

  private onCancel(): void {
    this.show = false;
  }

  private onConfirm(year: number): void {
    this.show = false;
    this.dateStr = year;
    this.watchActiveIndex();
  }

  private handleClick(): void {
    this.show = !this.show;
  }

  @Watch('activeIndex')
  private watchActiveIndex(): void {
    if (this.activeIndex === 1) {
      this.getAppraiserList();
    } else {
      this.getOrganizationList();
    }
  }

  /**
   * 时间变更请求数据
   */
  @Watch('sureDate')
  private async watchSureDate(): Promise<void> {
    if (this.activeIndex === 0) {
      await this.getOrganizationList();
    } else {
      await this.getAppraiserList();
    }
  }

  /**
   * 获取 鉴定机构 数据
   * @data :请求数据
   * @res :处理数据
   * @parmas : year年份
   */
  private async getOrganizationList(): Promise<void> {
    const items: any[] = await this.getStaticListByStr('org');
    const sum = items.reduce((r1: any, r2: any) => {
      return r1 + r2.sales;
    }, 0);
    for (let item of items) {
      item.organizationName = item.mechanism;
      item.proportion = sum && this.getPercent(item.sales, sum);
    }
    this.organizationList = items;
  }
  /**
   * 获取 鉴定人 数据
   * @data :请求数据
   * @res :处理数据
   * @params :year年份
   */
  private async getAppraiserList(): Promise<void> {
    this.appraiserList = await this.getStaticListByStr('person');
  }

  private getPercent(num: any, total: any) {
    /// <summary>
    /// 求百分比
    /// </summary>
    /// <param name="num">当前数</param>
    /// <param name="total">总数</param>
    num = parseFloat(num);
    total = parseFloat(total);
    if (isNaN(num) || isNaN(total)) {
      return '-';
    }
    return total <= 0 ? '0' : Math.round((num / total) * 10000) / 100.0;
  }

  private async getStaticListByStr(type: string) {
    const res = await this.$api.xHttp.get(
      this.$interface.judicialExpertise.static +
        `?type=${type}&time=${this.dateStr}`,
      null,
      null
    );
    return res.data;
  }
}
</script>

<style lang='less' scoped>
.statistical-analysis {
  padding-bottom: 60px;
  &-head {
    height: 238px;
    padding: 30px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    background: url(../../../../assets/images/modules/notarization/index/bg@2x.png)
      no-repeat;
    background-size: 132%;

    &-btn {
      width: 320px;
      height: 90px;
      background-color: #ffffff;
      border-radius: 8px;
      font-size: 32px;
      color: #666666;
      text-align: center;
      line-height: 90px;
    }

    .active {
      background-color: #0a5ffe;
      color: #ffffff;
    }
  }

  .timer-box {
    margin: 34px 30px;

    &-select {
      width: 184px;
      height: 56px;
      background: rgba(255, 255, 255, 1);
      border: 1px solid rgba(230, 230, 230, 1);
      border-radius: 28px;
      text-align: center;
      font-size: 24px;
      color: #666666;
      line-height: 56px;

      span {
        padding-right: 12px;
      }

      span,
      i {
        vertical-align: middle;
      }
    }
  }
}
</style>
