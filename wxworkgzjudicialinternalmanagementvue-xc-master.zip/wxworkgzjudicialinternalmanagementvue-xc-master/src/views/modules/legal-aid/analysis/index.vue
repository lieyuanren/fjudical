<template>
  <div class="analysis">
    <div class="analysis-select">
      <div @click="selectShow(1)"
           class="time-select">
        <span>{{ startTime }}</span>
        <van-icon name="arrow-down" />
      </div>
      <div class="line"></div>
      <div @click="selectShow(2)"
           class="time-select">
        <span>{{ endTime }}</span>
        <van-icon name="arrow-down" />
      </div>
    </div>
    <div class="more">
      <template v-if="activeIndex===0">
        <span @click="handleToggel">查看更多</span>
        <van-icon name="arrow" />
      </template>
      <template v-else>
        <van-icon name="arrow-left" />
        <span @click="handleToggel">返回</span>
      </template>
    </div>
    <component :caseCount="caseCount"
               :caseGroup=caseGroup
               :caseMain="caseMain"
               :caseOver="caseOver"
               :consultNumber="consultNumber"
               :is="componentId[activeIndex]"
               :legalAdvice="legalAdvice"></component>
    <van-popup :style="{ height: '40%' }"
               position="bottom"
               v-model="show">
      <van-datetime-picker @cancel="onCancel"
                           @confirm="onConfirm"
                           type="year-month"
                           v-model="currentDate" />
      <!--<van-picker show-toolbar-->
      <!--title="选择年份"-->
      <!--:columns="columns"-->
      <!--@cancel="onCancel"-->
      <!--@change="onChange"-->
      <!--@confirm="onConfirm" />-->
    </van-popup>
  </div>
</template>

<script lang='ts'>
import { Component, Vue, Watch } from 'vue-property-decorator';
import CaseMainModel from '@/model/modules/legal-aid/analysis/CaseMainModel';
import CaseOverModel from '@/model/modules/legal-aid/analysis/CaseOverModel';
import MainPanel from '@/components/modules/legal-aid/analysis/v-main-panel/index.vue';
import MorePanel from '@/components/modules/legal-aid/analysis/v-more-panel/index.vue';
// @ts-ignore
import Common from '@/utils/common/common';

@Component({
  components: {
    MainPanel,
    MorePanel
  }
})
export default class Analysis extends Vue {
  private startTime: string = Common.dateFmt('yyyy-MM', new Date());
  private endTime: string = Common.dateFmt('yyyy-MM', new Date());
  private currentDate: any = new Date();
  // 法援案件数量
  private caseCount: number = 0;
  // 法援咨询数量
  private consultNumber: number = 0;
  // 案件主体分部
  private caseMain: CaseMainModel = new CaseMainModel();
  // 案件结案情况
  private caseOver: CaseOverModel = new CaseOverModel();
  // 群体案件情况
  private caseGroup: CaseMainModel = new CaseMainModel();
  // 法律咨询案件类型
  private legalAdvice: CaseMainModel = new CaseMainModel();
  private show: boolean = false;
  // 被选中select的索引
  private selectIndex: number = 1;
  private componentId: string[] = ['MainPanel', 'MorePanel'];
  // 当前展示组件的索引
  private activeIndex: number = 0;
  // 月-日
  private columns: any = [
    // 第一列
    {
      values: [],
      defaultIndex: 2
    },
    // 第二列
    {
      values: [1, 23, 4, 4],
      defaultIndex: 1
    }
  ];

  public created(): void {
    this.initColumns();
    this.getData();
  }

  /**
   * 计算百分比
   */
  public percent(count: number, sum: number): number {
    const num = Math.round((count / sum) * 10000) / 100.0;
    return num > 0 ? num : 0;
  }

  @Watch('startTime')
  private watchStartTime(): void {
    this.getData();
  }

  @Watch('endTime')
  private watchEndTime(): void {
    this.getData();
  }

  /**
   * 请求数据
   * @data :请求数据
   * @res ；处理数据
   * @params :startTime,endTime
   */
  private async getData(): Promise<void> {
    this.caseAndConsultCount();
    this.caseDistribution();
    this.caseFinishCondition();
    this.consultTypeCase();
    this.groupCaseCondition();
  }

  /**
   * 案件/咨询数量
   * @returns {Promise<void>}
   */
  private async caseAndConsultCount(): Promise<void> {
    const param: any = {
      startTime: this.startTime,
      endTime: this.endTime
    };
    const res = await this.$api.xHttp.post(
      this.$interface.legalAid.dataStatistics.caseAndConsultCount,
      { ...param },
      null
    );
    this.caseCount = res.data.case;
    this.consultNumber = res.data.consultation;
  }

  /**
   * 案件分布
   * @returns {Promise<void>}
   */
  private async caseDistribution(): Promise<void> {
    const param: any = {
      startTime: this.startTime,
      endTime: this.endTime
    };
    const res = await this.$api.xHttp.post(
      this.$interface.legalAid.dataStatistics.caseDistribution,
      { ...param },
      null
    );
    this.caseMain = res.data.map((it: any) => ({
      type: it.type === '总计' ? '总计' : it.type + '案件',
      num: this.percent(it.count, it.sum),
      const: 'const'
    }));
  }

  /**
   * 结案情况
   * @returns {Promise<void>}
   */
  private async caseFinishCondition(): Promise<void> {
    const param: any = {
      startTime: this.startTime,
      endTime: this.endTime
    };
    const res = await this.$api.xHttp.post(
      this.$interface.legalAid.dataStatistics.caseFinishCondition,
      { ...param },
      null
    );
    const finishList = res.data.finishList.map((it: any) => ({
      type: it.type === '总计' ? '总计' : it.type + '案件',
      count: this.percent(it.count, it.sum),
      name: '已结案'
    }));
    const processList = res.data.processList.map((it: any) => ({
      type: it.type === '总计' ? '总计' : it.type + '案件',
      count: this.percent(it.count, it.sum),
      name: '未结案'
    }));
    this.caseOver = finishList.concat(processList);
  }

  /**
   * 咨询案件类型
   * @returns {Promise<void>}
   */
  private async consultTypeCase(): Promise<void> {
    const param: any = {
      startTime: this.startTime,
      endTime: this.endTime
    };
    const res = await this.$api.xHttp.post(
      this.$interface.legalAid.dataStatistics.consultTypeCase,
      { ...param },
      null
    );
    this.legalAdvice = res.data.map((it: any) => ({
      type: it.type + '案件',
      num: this.percent(it.count, it.sum),
      const: 'const'
    }));
  }

  /**
   * 群体案件
   * @returns {Promise<void>}
   */
  private async groupCaseCondition(): Promise<void> {
    const param: any = {
      startTime: this.startTime,
      endTime: this.endTime
    };
    const res = await this.$api.xHttp.post(
      this.$interface.legalAid.dataStatistics.groupCaseCondition,
      { ...param },
      null
    );
    this.caseGroup = res.data.map((it: any) => ({
      type: it.type,
      num: this.percent(it.count, it.sum),
      const: 'const'
    }));
  }

  private onCancel(): void {
    this.show = false;
  }

  private onConfirm(value: any): void {
    const news = new Date(value).getTime();
    if (this.selectIndex === 1) {
      const end = new Date(this.endTime).getTime();
      if (news > end) {
        this.$toast.fail('开始时间不能大于结束时间');
        return;
      }
      this.startTime = Common.dateFmt('yyyy-MM', new Date(value));
    } else if (this.selectIndex === 2) {
      const start = new Date(this.startTime).getTime();
      if (news < start) {
        this.$toast.fail('结束时间不能小于开始时间');
        return;
      }
      this.endTime = Common.dateFmt('yyyy-MM', new Date(value));
    }
    this.show = false;
  }

  private onChange(picker: any, values: any): void {
    picker.setColumnValues(1, this.changeDateList(parseInt(values[0], 10)));
  }

  private selectShow(index: number): void {
    this.selectIndex = index;
    this.show = true;
  }

  // 切换组件
  private handleToggel(): void {
    if (this.activeIndex === 1) {
      this.activeIndex = 0;
    } else {
      this.activeIndex = 1;
    }
  }

  // 初始化月份
  private initColumns(): void {
    let monthList: string[] = [];
    let dateList: string[] = [];
    for (let i = 1; i <= 12; i++) {
      monthList.push(`${i}月`);
    }
    for (let i = 1; i <= 31; i++) {
      dateList.push(`${i}日`);
    }
    this.columns[0].values = monthList;
    this.columns[1].values = dateList;
  }

  private setDateList(type: number): string[] {
    let limit: number = 31;
    const dataList: string[] = [];
    if (type === 1) {
      limit = 31;
    } else if (type === 2) {
      limit = 30;
    } else if (type === 3) {
      limit = 29;
    }

    for (let i = 1; i <= limit; i++) {
      dataList.push(`${i}日`);
    }
    return dataList;
  }

  // 根据月份变动日期数量
  private changeDateList(month: number): string[] {
    let dateList: string[] = [];
    // 大月
    if (month % 2 !== 0 || month === 8) {
      dateList = this.setDateList(1);
      // 小月
    } else if (month % 2 === 0 && month !== 2) {
      dateList = this.setDateList(2);
    } else {
      dateList = this.setDateList(3);
    }
    return dateList;
  }
}
</script>

<style lang='less' scoped>
.analysis {
  padding-bottom: 120px;
  &-select {
    display: flex;
    height: 160px;
    background-color: #476ba1;
    align-items: center;
    font-size: 32px;
    color: #ffffff;
    text-align: center;

    .time-select {
      width: 260px;
      height: 66px;
      border-radius: 8px;
      border: 1px solid #ffffff;
      margin-left: 60px;
      display: flex;
      align-items: center;
      justify-content: center;
      &:nth-child(3) {
        margin-left: 28px;
      }

      span {
        padding-right: 8px;
      }
      span,
      i {
        vertical-align: middle;
      }
    }

    .line {
      width: 52px;
      height: 1px;
      background-color: #ffffff;
      margin-left: 28px;
    }
  }
  .more {
    padding: 30px;
    text-align: right;
    font-size: 24px;
    color: #2666de;

    span,
    i {
      vertical-align: middle;
    }
  }
}
</style>
