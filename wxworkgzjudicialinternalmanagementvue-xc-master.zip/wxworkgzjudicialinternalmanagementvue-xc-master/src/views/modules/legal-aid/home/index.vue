<!--
 * @Author: tangzhicheng
 * @Date: 2020-03-09 09:17:18
 * @LastEditors: tangzhicheng
 * @LastEditTime: 2020-04-03 15:25:49
 * @Description: file content
 -->
<template>
  <div class="Home">
    <h1>数据盘点</h1>
    <div class="data-list">
      <DataCard :class="`color${index+1}`"
                :key="index"
                :index="index"
                :tips="key"
                :value="value"
                v-for="(value,key, index) in allData" />
    </div>
  </div>
</template>

<script lang='ts'>
import { Component, Vue } from 'vue-property-decorator';
import DataInventoryModel from '@/model/modules/legal-aid/home/DataInventoryModel';
import DataCard from '@/components/modules/legal-aid/home/v-data-card/index.vue';

@Component({
  components: {
    DataCard
  }
})
export default class Home extends Vue {
  // 数据盘点
  private allData: DataInventoryModel = new DataInventoryModel();

  public created(): void {
    this.getData();
  }

  /**
   * 获取数据
   * @data :获取数据
   * @res :处理数据
   */
  private async getData(): Promise<void> {
    // 首页各案件数
    const res = await this.$api.xHttp.get(
      this.$interface.legalAid.index.indexInfo,
      null,
      null
    );
    this.allData = res.data;
  }
}
</script>

<style lang='less' scoped>
.Home {
  height: 100%;
  color: #333333;
  overflow: hidden;
  background-color: #ffffff;

  h1 {
    margin-top: 62px;
    padding: 0 40px;
    font-size: 48px;
    font-weight: 400;
  }
}

.color1 {
  background-color: #53bcfe;
}

.color2 {
  background-color: #6593d6;
}

.color3 {
  background-color: #1eb7a3;
}

.color4 {
  background-color: #5483df;
}
</style>
