<!--
 * @Author: tangzhicheng
 * @Date: 2020-03-09 09:17:18
 * @LastEditors: tangzhicheng
 * @LastEditTime: 2020-05-06 11:19:41
 * @Description: file content
 -->
<template>
  <div class="legal-aid">
    <transition mode="out-in"
                name="component-fade">
      <component :is="componentIdArr[active]"></component>
    </transition>
    <div class="legal-aid-menu">
      <van-tabbar v-model="active" style="border-top: 1px solid #EAEAEA">
        <van-tabbar-item>
          <span>首页</span>
          <img :src="props.active ? menuIcon.homeActive : menuIcon.homeInactive"
               class="legal-aid-menu-icon"
               slot="icon"
               slot-scope="props" />
        </van-tabbar-item>
        <van-tabbar-item>
          <span>机构</span>
          <img :src="props.active ? menuIcon.assessActive : menuIcon.assessInactive"
               class="legal-aid-menu-icon"
               slot="icon"
               slot-scope="props" />
        </van-tabbar-item>
        <van-tabbar-item>
          <span>案件查询</span>
          <img :src="props.active ? menuIcon.recordActive : menuIcon.recordInactive"
               class="legal-aid-menu-icon"
               slot="icon"
               slot-scope="props" />
        </van-tabbar-item>
        <van-tabbar-item>
          <span>统计分析</span>
          <img :src="props.active ? menuIcon.statisticsActive : menuIcon.statisticsInactive"
               class="legal-aid-menu-icon"
               slot="icon"
               slot-scope="props" />
        </van-tabbar-item>
      </van-tabbar>
    </div>
  </div>
</template>

<script lang='ts'>
import { Component, Vue } from 'vue-property-decorator';
import Home from '@/views/modules/legal-aid/home/index.vue';
import Mechanism from '@/views/modules/legal-aid/mechanism/index.vue';
import Query from '@/views/modules/legal-aid/query/index.vue';
import Analysis from '@/views/modules/legal-aid/analysis/index.vue';

@Component({
  components: {
    Home,
    Mechanism,
    Query,
    Analysis
  }
})
export default class LegalAid extends Vue {
  private active: number = 0;
  // 底部菜单图标
  private menuIcon: any = {
    homeActive: require('../../../assets/images/modules/notarization/index/home-active.png'),
    homeInactive: require('../../../assets/images/modules/notarization/index/home-inactive.png'),
    recordActive: require('../../../assets/images/modules/legalAid/case-active.png'),
    recordInactive: require('../../../assets/images/modules/legalAid/case-inactive.png'),
    assessActive: require('../../../assets/images/modules/legalAid/org-active.png'),
    assessInactive: require('../../../assets/images/modules/legalAid/org-inactive.png'),
    statisticsActive: require('../../../assets/images/modules/notarization/index/statistics-active.png'),
    statisticsInactive: require('../../../assets/images/modules/notarization/index/statistics-inactive.png')
  };
  private componentIdArr: string[] = ['Home', 'Mechanism', 'Query', 'Analysis'];
}
</script>

<style lang='less' scoped>
.legal-aid {
  height: 100%;

  &-menu {
    span {
      font-size: 20px;
    }

    &-icon {
      width: 48px;
      height: 48px;
    }
  }
}
</style>
