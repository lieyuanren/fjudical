<template>
  <div class="mechanism">
    <p class="tips">法律援助机构共{{list.length}}家</p>
    <div class="mechanism-list">
      <MechanismCard :item="item" :key="index" v-for="(item, index) in list"/>
    </div>
  </div>
</template>

<script lang='ts'>
import { Component, Vue } from 'vue-property-decorator';
import MechanismModel from '@/model/modules/legal-aid/mechanism/MechanismModel';
import MechanismCard from '@/components/modules/legal-aid/mechanism/v-mechanism-card/index.vue';

@Component({
  components: {
    MechanismCard
  }
})
export default class Mechanism extends Vue {
  // 机构列表
  private list: MechanismModel[] = [];

  public created(): void {
    this.getList();
  }

  /**
   * 数据请求
   * @data ：请求数据
   * @res : 处理数据
   */
  private async getList(): Promise<void> {
    const res = await this.$api.xHttp.get(this.$interface.legalAid.organization.list, null, null);
    this.list = res.data.list;
  }
}
</script>

<style lang='less' scoped>
.mechanism {
  padding-bottom: 120px;

  &-list {
    overflow: hidden;
  }
  .tips {
    padding: 30px;
    font-size: 28px;
    color: #999999;
    padding-bottom: 0;
  }
}
</style>
