<template>
  <div class="query">
    <div class="query-head">
      <div @click="selectShow"
           class="year-select">
        <span class="year">{{year}}</span>
        <van-icon name="arrow-down" />
      </div>
      <van-search @search="getCaseList"
                  placeholder="搜索案件号、受授人或承办人姓名"
                  v-model="keyString" />
    </div>
    <p class="tips">共{{total}}件,满足当前条件{{dataCount}}件</p>
    <div class="query-content">
      <van-pull-refresh @refresh="onRefresh"
                        v-model="refreshing">
        <van-list :finished="finished"
                  :finished-text="finishedText"
                  @load="getCaseList"
                  v-model="loading">
          <CaseCard :item="item"
                    :key="index"
                    v-for="(item, index) in caseList" />
        </van-list>
      </van-pull-refresh>
    </div>
    <van-popup position="bottom"
               v-model="show">
      <van-picker :columns="yearList"
                  @cancel="onCancel"
                  @confirm="onConfirm"
                  show-toolbar
                  title="选择年份" />
    </van-popup>
  </div>
</template>

<script lang='ts'>
import { Component, Vue, Watch } from 'vue-property-decorator';
import CaseModel from '@/model/modules/legal-aid/query/CaseModel';
import CaseCard from '@/components/modules/legal-aid/query/v-case-card/index.vue';
import PageParam from '@/model/modules/legal-aid/pageParam';

@Component({
  components: {
    CaseCard
  }
})
export default class Query extends Vue {
  public loading: boolean = false;
  public refreshing: boolean = false;
  public finished: boolean = false;
  public finishedText: string = '没有更多了';
  // 年份
  private year: number = new Date().getFullYear();
  // 查询字符串
  private keyString: string = '';
  // 案件列表
  private caseList: CaseModel[] = [];
  private timer: any = null;
  private show: boolean = false;
  private yearList: number[] = [];
  private dataCount: number = 0;
  private total: number = 0;
  // 分页
  private pageParam: PageParam = {
    currentPage: 0,
    pageSize: 10
  };

  public created(): void {
    this.setYearList();
    this.getCaseTotal();
  }

  /**
   * 下拉刷新
   */
  public onRefresh(): void {
    this.pageParam.currentPage = 0;
    this.caseList = [];
    this.getCaseList();
    this.finished = false;
    this.loading = true;
  }

  // 监听查询
  @Watch('keyString')
  private watchKeyString(): void {
    clearTimeout(this.timer);
    this.timer = setTimeout(() => {
      this.caseList = [];
      this.pageParam.currentPage = 0;
      this.getCaseList();
    }, 700);
  }

  // 监听年份
  @Watch('year')
  private watchyear(): void {
   this.getCaseList();
  }

  /**
   * 列表数据请求
   * @data :请求数据
   * @res :处理数据
   * @params :year年份 , keyString查询字符串
   */
  private getCaseList(): void {
    if (this.refreshing) {
      this.refreshing = false;
    }
    const param: any = {
      year: this.year,
      searchKey: this.keyString
    };
    this.$api.xHttp
      .post(
        this.$interface.legalAid.case.list,
        { ...param, ...this.pageParam },
        null
      )
      .then((res: any) => {
        this.caseList = [...this.caseList, ...res.data.list];
        this.dataCount = res.data.total;
        this.loading = false;
        this.pageParam.currentPage += 1;
        this.finished = res.data.pageNum >= res.data.pages;
        this.finishedText = this.caseList.length > 0 ? '没有更多了' : '';
      });
  }

  /**
   * 案件总数
   * @returns {Promise<void>}
   */
  private async getCaseTotal(): Promise<void> {
    const res = await this.$api.xHttp.get(
      this.$interface.legalAid.case.count,
      null,
      null
    );
    this.total = res.data;
  }

  private selectShow(): void {
    this.show = true;
  }

  private onCancel(): void {
    this.show = false;
  }

  private onConfirm(value: number): void {
    this.year = value;
    this.show = false;
  }

  private setYearList(): void {
    let currentYear: number = new Date().getFullYear();
    for (let i = 0; i < 10; i++) {
      this.yearList.push(currentYear - i);
    }
  }
}
</script>

<style lang='less' scoped>
.query {
  height: 100%;
  padding-bottom: 120px;

  &-head {
    padding: 30px;
    background-color: #ffffff;
    display: flex;
    font-size: 0px;

    .year-select {
      width: 118px;
      height: 68px;
      background-color: #f2f2f2;
      text-align: center;
      line-height: 68px;
      font-size: 28px;
      border-radius: 6px 0 0 6px;
      color: #333333;
      span,
      i {
        vertical-align: middle;
      }

      span {
        padding-right: 2px;
      }
    }
  }

  .tips {
    padding: 30px;
    font-size: 24px;
    color: #999999;
  }
}

// 样式重置
.van-search {
  padding: 0;
  flex: 1;
}

.van-search__content {
  background-color: #f2f2f2;
}
</style>
