<template>
  <div class="analysis">
    <div class="analysis-head">
      <div class="organization-select">
        <OrganizationSelect :list="organizationList"
                            @onConfirm="handleConfirm" />
      </div>
      <div class="time-select"
           @click="show = true">
        <span>{{ sureTime | handleTime }}</span>
        <van-icon name="play" />
      </div>
    </div>
    <div class="analysis-btn">
      <van-icon name="arrow-left"
                v-if="active === 1" />
      <span @click="toggel">{{ active===0?'查看更多':'返回' }}</span>
      <van-icon name="arrow"
                v-if="active === 0" />
    </div>
    <div class="analysis-body">
      <transition name="out-in"
                  mode="out-in">
        <component :is="componentId[active]"
                   :date="sureTime"
                   :organization="organization"></component>
      </transition>
    </div>

    <van-popup v-model="show"
               round
               position="bottom">
      <van-datetime-picker v-model="currentTime"
                           type="date"
                           @cancel="onCancel"
                           @confirm="onConfirm" />
    </van-popup>
  </div>
</template>

<script lang='ts'>
import { Component, Vue } from 'vue-property-decorator';
import OrganizationSelect from '@/components/common/v-organization-select/index.vue';
import common from '@/utils/common/common';
import MainPanel from '@/components/modules/mediation/analysis/v-main-panel/index.vue';
import OthterPanel from '@/components/modules/mediation/analysis/v-other-panel/index.vue';

@Component({
  components: {
    OrganizationSelect,
    MainPanel,
    OthterPanel
  },
  filters: {
    handleTime(date: Date) {
      return common.dateFmt('yyyy-MM-dd', date);
    }
  }
})
export default class Analysis extends Vue {
  private active: number = 0;
  private componentId: string[] = ['MainPanel', 'OthterPanel'];
  private organization: string = '';
  private currentTime: Date = new Date();
  private sureTime: Date = new Date();
  private show: boolean = false;
  private organizationList: any[] = [];

  public async created() {
    await this.getOrganizationList();
  }

  private handleConfirm(str: string): void {
    this.organization = str;
  }

  private onCancel(): void {
    this.show = false;
  }

  private onConfirm(date: Date): void {
    this.show = false;
    this.sureTime = date;
  }

  private toggel(): void {
    if (this.active === 0) {
      this.active = 1;
    } else {
      this.active = 0;
    }
  }

  /**
   * 请求数据
   * 获取机构列表信息
   */
  private async getOrganizationList(): Promise<void> {
    this.organizationList = [
      {
        text: '浙江',
        children: [
          {
            text: '杭州',
            children: [{ text: '西湖区' }, { text: '余杭区' }]
          },
          {
            text: '温州',
            children: [{ text: '鹿城区' }, { text: '瓯海区' }]
          }
        ]
      },
      {
        text: '福建',
        children: [
          {
            text: '福州',
            children: [{ text: '鼓楼区' }, { text: '台江区' }]
          },
          {
            text: '厦门',
            children: [{ text: '思明区' }, { text: '海沧区' }]
          }
        ]
      }
    ];
  }
}
</script>

<style lang='less' scoped>
.analysis {
  height: 100%;
  &-head {
    position: relative;
    background-color: #5573a6;
    height: 180px;
    font-size: 32px;
    color: #ffffff;

    .organization-select {
      position: absolute;
      left: 30px;
      top: 40px;
    }

    .time-select {
      position: absolute;
      left: 30px;
      top: 98px;
    }

    span,
    i {
      vertical-align: middle;
    }

    i {
      transform: rotateZ(90deg);
      margin-left: 6px;
    }
  }

  &-btn {
    padding: 30px;
    font-size: 24px;
    color: #0a5ffe;
    text-align: right;

    span,
    i {
      vertical-align: middle;
    }
  }
}

.out-in-enter {
  transform: translate3d(100%, 0, 0);
}
.out-in-leave-to {
  transform: translate3d(-100%, 0, 0);
}
.out-in-enter-active,
.out-in-leave-active {
  transition: transform 0.3s;
}
</style>