<template>
  <div class="case-handle">
    <div class="case-handle-tpes">
      <van-steps :active="active"
                 active-color="#4E60FE"
                 active-icon="checked"
                 inactive-icon="arrow">
        <van-step>案件</van-step>
        <van-step>申请人</van-step>
        <van-step>被申请人</van-step>
        <van-step>结果</van-step>
      </van-steps>
    </div>
    <div class="case-handle-content">
      <transition name="popIn"
                  mode="out-in">
        <component :is="componentId[active]"
                   @nextStep="nextStep"></component>
      </transition>
    </div>
  </div>
</template>

<script lang='ts'>
import { Component, Vue } from 'vue-property-decorator';
import CasePanel from '@/components/modules/mediation/case_manager/v-case-panel/index.vue';
import ProposerPanel from '@/components/modules/mediation/case_manager/v-proposer-panel/index.vue';
import RespondentPanel from '@/components/modules/mediation/case_manager/v-respondent-panel/index.vue';
import ResultPanel from '@/components/modules/mediation/case_manager/v-result-panel/index.vue';

@Component({
  components: {
    CasePanel,
    ProposerPanel,
    RespondentPanel,
    ResultPanel
  }
})
export default class CaseHandle extends Vue {
  private active: number = 0;
  private componentId: string[] = [
    'CasePanel',
    'ProposerPanel',
    'RespondentPanel',
    'ResultPanel'
  ];
  private id: string = '';

  private getId(): void {
    this.id = this.$route.query.id as string;
  }

  private nextStep(index: number): void {
    this.active = index;
  }
}
</script>

<style lang='less' scoped>
.case-handle {
  &-tpes {
    padding: 0 90px;
    margin-top: 20px;
    background-color: #ffffff;
  }
}

.popIn-enter {
  transform: translate3d(100%, 0, 0);
}

.popIn-leave-to {
  transform: translate3d(-100%, 0, 0);
}

.popIn-enter-active,
.popIn-leave-active {
  transition: all 0.2s linear;
}
</style>
