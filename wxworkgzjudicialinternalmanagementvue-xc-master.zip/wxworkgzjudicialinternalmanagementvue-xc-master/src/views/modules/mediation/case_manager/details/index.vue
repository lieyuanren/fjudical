<template>
  <div class="details">
    <div class="details-info">
      <p class="title">
        <span class="case-id">12354351312</span>
        <span class="material-science"
              v-if="state === '已结案'"
              @click="goRoute">卷宗材料</span>
      </p>
      <p class="text">
        <span class="label">纠纷类型：</span>
        <span class="value">领里纠纷</span>
      </p>
      <p class="text">
        <span class="label">纠纷级别：</span>
        <span class="value">简单纠纷</span>
      </p>
      <p class="text">
        <span class="label">纠纷描述：</span>
        <span class="value">稔岗13号02号房的水渠堵塞，造成11号 楼1楼漏水，经调解由02号房全体住户共 同承担。</span>
      </p>
      <p class="text">
        <span class="label">纠纷地点：</span>
        <span class="value">越秀区大塘街人民调委会</span>
      </p>
      <p class="text">
        <span class="label">申请人诉求：</span>
        <span class="value">显示申请人诉求信息</span>
      </p>
      <p class="text">
        <span class="label">申请时间：</span>
        <span class="value">2019-11-18 17:02:03</span>
      </p>
    </div>
    <van-cell title="附件"
              is-link
              :arrow-direction="direction?'up':'down'"
              @click="direction = !direction" />
    <transition name="toggel">
      <div class="details-enclosure"
           v-show="direction">
        <van-image width="2.05333rem"
                   height="2.05333rem"
                   src="https://img.yzcdn.cn/vant/cat.jpeg"
                   v-for="(item,index) in 6"
                   :key="index" />
      </div>
    </transition>
    <div class="details-info">
      <p class="text">
        <span class="label">申请人：</span>
        <span class="value">和小馋</span>
      </p>
      <p class="text">
        <span class="label">身份证号码：</span>
        <span class="value">452312380899190893</span>
      </p>
      <p class="text">
        <span class="label">联系方式：</span>
        <span class="value">18022345678</span>
      </p>
    </div>
    <div class="details-info top">
      <p class="text">
        <span class="label">当事人：</span>
        <span class="value">和小馋</span>
      </p>
      <p class="text">
        <span class="label">身份证号码：</span>
        <span class="value">452312380899190893</span>
      </p>
      <p class="text">
        <span class="label">联系方式：</span>
        <span class="value">18022345678</span>
      </p>
      <p class="more">
        更多当事人
      </p>

    </div>
    <!-- 已结案显示 -->
    <div class="details-info top"
         v-if="state === '已结案'">
      <p class="text">
        <span class="label">调解方式：</span>
        <span class="value">书面调解</span>
      </p>
      <p class="text">
        <span class="label">案件状态：</span>
        <span class="value">调解成功</span>
      </p>
      <p class="text">
        <span class="label">协议时间（调解时间）：</span>
        <span class="value">2019-11-18 17:04:09</span>
      </p>
      <p class="text">
        <span class="label">涉案金额：</span>
        <span class="value">人民币3000元</span>
      </p>
      <p class="text">
        <span class="label">涉案金额：</span>
        <span class="value">人民币3000元</span>
      </p>
      <p class="text">
        <span class="label">处案调委会：</span>
        <span class="value">XXXXXX人民调解委员会</span>
      </p>
      <p class="text">
        <span class="label">处案调解员：</span>
        <span class="value">鸿宝</span>
      </p>
      <p class="text">
        <span class="label">其他处案调解员：叶小舒</span>
        <span class="value">叶小舒</span>
      </p>
      <p class="text">
        <span class="label">协议内容：</span>
        <span class="value">（显示协议内容）稔岗13号02号房的水渠堵塞，造成11号楼1楼漏水，经调解由02号房全体住户共同承担。</span>
      </p>
    </div>
    <div v-if="state === '已结案'">
      <van-cell title="补充材料"
                is-link
                :arrow-direction="direction1?'up':'down'"
                @click="direction1 = !direction1" />
      <transition name="toggel">
        <div class="details-enclosure"
             v-show="direction1">
          <van-image width="2.05333rem"
                     height="2.05333rem"
                     src="https://img.yzcdn.cn/vant/cat.jpeg"
                     v-for="(item,index) in 6"
                     :key="index" />
        </div>
      </transition>
    </div>
    <div  v-if="state === '待接单'" class="top">
      <van-cell title="处理调委会" value="凤凰街人民调解委员会"
                is-link />
      <!-- 待接单状态显示 -->
      <div class="details-btn">
        <p class="tips">
          注：纠纷地点不在管辖范围内，可将工单流转至其他调委会。
        </p>
        <div class="btn btn1">
          不受理
        </div>
        <div class="btn btn2">
          受理
        </div>
        <!--<div class="btn btn3">-->
          <!--流转其他委员会-->
        <!--</div>-->
      </div>
    </div>
    <!-- 待处理状态显示 -->
    <div class="details-btn-other"
         v-else-if="state === '待处理'">
      <p class="tips">
        注：与当事人联系后，请选择处理方式。
      </p>
      <van-cell title="请选择处理方式"
                is-link />
      <div class="btn">
        提交
      </div>

    </div>
  </div>
</template>

<script lang='ts'>
/**
 * 1.判断传入的状态
 * 2.获取案件的id
 */

// TODO:逻辑善未完善
import { Component, Vue, Prop } from 'vue-property-decorator';

@Component({
  // beforeRouteEnter(to,)
})
export default class Details extends Vue {
  @Prop() private readonly item: any;
  private caseId: string = '';
  private direction: boolean = true;
  private direction1: boolean = true;
  private state: string = '';

  private created() {
    this.getCaseQuery();
  }

  private getCaseQuery(): void {
    this.caseId = this.$route.query.caseId as string;
    this.state = this.$route.query.state as string;
  }

  private goRoute(): void {
    this.$router.push({
      path: '/dossier'
    });
  }
}
</script>

<style lang='less' scoped>
.details {
  &-info {
    background-color: #ffffff;
    padding: 0 30px;
    overflow: hidden;

    .title {
      font-size: 36px;
      margin-top: 30px;
      display: flex;
      justify-content: space-between;
    }

    .text {
      display: flex;
      font-size: 28px;
      margin: 30px 0;
      .label {
        color: #999999;
        width: 200px;
        display: inline-block;
        padding-right: 8px;
      }
      .value {
        flex: 1;
      }
    }

    .more {
      font-size: 28px;
      color: #4284f1;
      text-align: right;
      margin: 30px 0;
    }
  }

  &-enclosure {
    padding: 30px;
    background-color: #ffffff;
    overflow: hidden;

    .van-image {
      margin-right: 24px;

      &:nth-child(4n) {
        margin-right: 0px;
      }
    }
  }

  &-btn {
    padding: 10px 40px;
    padding-bottom: 40px;
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
    background-color: #ffffff;

    .btn {
      width: 310px;
      height: 98px;
      border-radius: 12px;
      font-size: 36px;
      text-align: center;
      line-height: 98px;
    }

    .btn1 {
      box-sizing: border-box;
      border: 1px solid #0a5ffe;
      background-color: #edf2fe;
      color: #0a5ffe;
    }

    .btn2 {
      background-color: #0a5ffe;
      color: #ffffff;
    }

    .btn3 {
      width: 100%;
      background-color: #0a5ffe;
      color: #ffffff;
      margin-top: 52px;
    }
  }

  &-btn-other {
    background-color: #ffffff;
    padding: 20px 0;

    .tips {
      padding: 30px;
    }

    .btn {
      width: 310px;
      height: 98px;
      border-radius: 12px;
      font-size: 36px;
      text-align: center;
      line-height: 98px;
      background-color: #0a5ffe;
      color: #ffffff;
      margin: 30px auto;
    }
  }
}

.tips {
  color: #999999;
  font-size: 24px;
  padding: 20px 0;
}

.material-science {
  font-size: 28px;
  color: #4284f1;
}

.top {
  margin-top: 20px;
}

.toggel-enter,
.toggel-leave-to {
  max-height: 0px;
}

.toggel-enter-to,
.toggel-leave {
  max-height: 350px;
}

.toggel-enter-active,
.toggel-leave-active {
  transition: all 0.3s;
}
</style>
