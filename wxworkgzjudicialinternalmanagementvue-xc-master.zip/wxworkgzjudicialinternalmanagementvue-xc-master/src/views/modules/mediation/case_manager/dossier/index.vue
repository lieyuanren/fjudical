<template>
  <div class="dossier">
    <van-cell-group>
      <van-cell title="人民调解申请书">
        <img :src="iconUrl"
             class="img"
             slot="right-icon">
      </van-cell>
      <van-cell title="人民调解受理登记书">
        <img :src="iconUrl"
             class="img"
             slot="right-icon">
      </van-cell>
      <van-cell title="人民调解调查记录">
        <img :src="iconUrl"
             class="img"
             slot="right-icon">
      </van-cell>
      <van-cell title="人民调解证据材料">
        <img :src="iconUrl"
             class="img"
             slot="right-icon">
      </van-cell>
      <van-cell title="人民调解记录">
        <img :src="iconUrl"
             class="img"
             slot="right-icon">
      </van-cell>
      <van-cell title="人民调解协议书">
        <img :src="iconUrl"
             class="img"
             slot="right-icon">
      </van-cell>
      <van-cell title="人民调解回访记录">
        <img :src="iconUrl"
             class="img"
             slot="right-icon">
      </van-cell>
      <van-cell title="卷宗情况说明">
        <img :src="iconUrl"
             class="img"
             slot="right-icon">
      </van-cell>
    </van-cell-group>
    <div class="btn">
      申请归档
    </div>
  </div>
</template>

<script lang='ts'>
import { Component, Vue } from 'vue-property-decorator';
// TODO:善未完善
@Component
export default class Dossier extends Vue {
  private iconUrl: string = require('@/assets/images/modules/mediation/icon.png');
}
</script>

<style lang='less' scoped>
.dossier {
  height: 100%;
  background-color: #ffffff;
  .img {
    width: 46px;
    height: 46px;
  }

  .btn {
    width: 670px;
    height: 98px;
    background-color: #0a5ffe;
    border-radius: 12px;
    font-size: 36px;
    color: #ffffff;
    text-align: center;
    line-height: 98px;
    position: fixed;
    left: 50%;
    transform: translateX(-50%);
    bottom: 54px;
  }
}
</style>
