<template>
  <div class="case-manager">
    <div class="case-manager-head">
      <div class="case-manager-head-address">
        <OrganizationSelect :list="organizationList"
                            @onConfirm="onConfirm" />
      </div>
      <van-search v-model="searchKey"
                  placeholder="请输入搜索关键词" />
      <van-dropdown-menu>
        <van-dropdown-item v-model="value1"
                           :options="option1"
                           @change="onChange1" />
        <van-dropdown-item v-model="value2"
                           :options="option2"
                           @change="onChange2" />
        <van-dropdown-item v-model="value3"
                           :options="option3"
                           @change="onChange3" />
      </van-dropdown-menu>
    </div>
    <div class="case-manager-body">
      <div class="tips">
        共 {{ currentList.length }} 个案件，满足当前筛选条件
      </div>
      <CaseCard v-for="item in currentList"
                :key="item.caseId"
                :item="item" />
    </div>
  </div>
</template>

<script lang='ts'>
import { Component, Vue, Watch } from 'vue-property-decorator';
import CaseCard from '@/components/modules/mediation/case_manager/v-case-card/index.vue';
import CaseCardType from '@/model/modules/mediation/case_manager/CaseCardType';
import OrganizationSelect from '@/components/common/v-organization-select/index.vue';

@Component({
  components: {
    CaseCard,
    OrganizationSelect
  }
})
export default class CaseManager extends Vue {
  private searchKey: string = '';
  private value1: number = 0;
  private value2: number = 0;
  private value3: number = 0;
  private option1: any[] = [
    { text: '状态（全部）', value: 0 },
    { text: '带处理', value: 1 },
    { text: '调节中', value: 2 }
  ];
  private option2: any[] = [
    { text: '纠纷类型（全部）', value: 0 },
    { text: '带处理', value: 1 },
    { text: '调节中', value: 2 }
  ];
  private option3: any[] = [
    { text: '本月', value: 0 },
    { text: '近三个月', value: 1 },
    { text: '近一年', value: 2 }
  ];
  private timeLimit: any = null;

  private currentList: CaseCardType[] = [];

  private organizationList: any = [];

  private organization: string = '';

  public async created() {
    await this.getOrganization();
    await this.getList();
  }

  @Watch('searchKey')
  private onSearch(): void {
    clearTimeout(this.timeLimit);
    this.timeLimit = setTimeout(() => {
      this.getList();
    }, 500);
  }

  private onConfirm(str: string): void {
    this.organization = str;
  }

  private onChange1(): void {
    this.getList();
  }

  private onChange2(): void {
    this.getList();
  }

  private onChange3(): void {
    this.getList();
  }

  /**
   * 请求数据
   * @params :searchkey 搜索字符
   * @params :option1[value1] 状态
   * @params :option2[value2] 纠纷类型
   * @params :option3[value3] 时间
   */
  private async getList(): Promise<void> {
    console.log('get');
    this.currentList = [
      {
        caseId: '1237821313',
        type: '邻居纠纷',
        mediationDate: '2020-02-14',
        committee: 'xxxx广州委员会',
        mediator: '叶小化',
        otherMediator: '唐某人',
        state: '已结案',
        describe:
          '三大撒多撒ad大数据库就看到数据库黄金卡好几款回家时肯三大撒多撒实打实萨定会见客户加速度'
      },
      {
        caseId: '12373489313',
        type: '邻居纠纷',
        mediationDate: '2020-02-14',
        committee: 'xxxx广州委员会',
        mediator: '叶小化',
        otherMediator: '唐某人',
        state: '待接单',
        describe:
          '三大撒多撒ad大数据库就看到数据库黄金卡好几款回家时肯三大撒多撒实打实萨定会见客户加速度'
      },
      {
        caseId: '1232139313',
        type: '邻居纠纷',
        mediationDate: '2020-02-14',
        committee: 'xxxx广州委员会',
        mediator: '叶小化',
        otherMediator: '唐某人',
        state: '待处理',
        describe:
          '三大撒多撒ad大数据库就看到数据库黄金卡好几款回家时肯三大撒多撒实打实萨定会见客户加速度'
      }
    ];
  }

  /**
   * 请求数据
   * 获取地区数据列表
   */
  private async getOrganization(): Promise<void> {
    this.organizationList = [
      {
        text: '浙江',
        children: [
          {
            text: '杭州',
            children: [{ text: '西湖区' }, { text: '余杭区' }]
          },
          {
            text: '温州',
            children: [{ text: '鹿城区' }, { text: '瓯海区' }]
          }
        ]
      },
      {
        text: '福建',
        children: [
          {
            text: '福州',
            children: [{ text: '鼓楼区' }, { text: '台江区' }]
          },
          {
            text: '厦门',
            children: [{ text: '思明区' }, { text: '海沧区' }]
          }
        ]
      }
    ];
  }
}
</script>

<style lang='less' scoped>
.case-manager {
  padding-bottom: 40px;
  &-head {
    background-color: #ffffff;

    &-address {
      padding: 40px 30px 20px 40px;
      font-size: 32px;

      span,
      i {
        vertical-align: middle;
        margin-left: 10px;
        transform: rotateZ(90deg);
      }

      i {
        font-size: 26px;
      }
    }
  }

  &-body {
    .tips {
      padding: 20px;
      font-size: 24px;
      color: #999999;
    }
  }
}
</style>