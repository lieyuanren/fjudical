<template>
  <div class="dispute-details">
    <van-cell-group>
      <van-cell title="案件信息" />
      <van-field v-model="fromData.address"
                 label="地址"
                 required
                 right-icon="aim"
                 input-align="right"
                 placeholder="请输入地址" />
      <van-cell title="信息来源"
                @click="handleShow(1)"
                :value="fromData.infoFrom"
                is-link />
      <van-cell title="纠纷级别"
                is-link
                :value="fromData.disputeLevel"
                @click="handleShow(2)" />
      <van-cell title="时间"
                is-link
                :value="fromData.date"
                @click="show2 = true" />
      <van-field v-model="fromData.situation"
                 label="排查情况"
                 required
                 input-align="right"
                 placeholder="请输入排查情况" />
    </van-cell-group>
    <div class="enclosure">
      <div class="title">附件</div>
      <van-uploader :after-read="afterRead"
                    multiple
                    v-model="fileList" />
    </div>
    <div class="btn"
         @click="handleClick">
      已排查
    </div>

    <van-popup v-model="show1"
               position="bottom">
      <van-picker :columns="columns"
                  show-toolbar
                  @cancel="show1 = false"
                  @confirm="onConfirm" />
    </van-popup>
    <van-popup v-model="show2"
               position="bottom">
      <van-datetime-picker v-model="currentDate"
                           type="date"
                           @cancel="show2 = false"
                           @confirm="onConfirmTime" />
    </van-popup>
  </div>
</template>

<script lang='ts'>
import { Component, Vue } from 'vue-property-decorator';
import DisputeDetailsType from '@/model/modules/mediation/dispute/DisputeDetailsType';

@Component
export default class DisputeDetails extends Vue {
  // 表单数据
  private fromData: DisputeDetailsType = new DisputeDetailsType();
  // 图片数据列表项
  private fileList: any = [];
  private columns: string[] = [];
  private currentDate: Date = new Date();
  private activeIndex: number = 1;
  private show1: boolean = false;
  private show2: boolean = false;

  // 信息来源
  private infoFromList: string[] = ['群众', '调解员'];
  // 纠纷级别
  private disputeListL: string[] = ['简单纠纷', '一般纠纷', '疑难纠纷'];

  /**
   * 增加已排查
   */
  private async addTroubleshooting(): Promise<void> {
    //   ...
    console.log('数据请求');
  }

  private afterRead(file: any) {
    // 此时可以自行将文件上传至服务器
    console.log(file);
  }

  // 已排查
  private async handleClick(): Promise<void> {
    if (this.checkFrom()) {
      await this.addTroubleshooting();
      this.$router.push({
        path: '/disputeList'
      });
    } else {
      this.$toast('请输入必填信息!');
    }
  }

  // 表单检测
  private checkFrom(): boolean {
    if (this.fromData.address !== '' && this.fromData.situation !== '') {
      return true;
    } else {
      return false;
    }
  }

  // 展示列表选项
  private handleShow(index: number): void {
    this.activeIndex = index;
    this.show1 = true;
    if (index === 1) {
      this.columns = this.infoFromList;
    } else if (index === 2) {
      this.columns = this.disputeListL;
    }
  }

  private onConfirm(str: string): void {
    this.show1 = false;
    if (this.activeIndex === 1) {
      this.fromData.infoFrom = str;
    } else {
      this.fromData.disputeLevel = str;
    }
  }

  private onConfirmTime(date: Date): void {
    this.show2 = false;
    this.fromData.date = this.$utils.Common.dateFmt('yyyy-MM-dd', date);
  }
}
</script>

<style lang='less' scoped>
.dispute-details {
  height: 100%;
  padding-top: 30px;
  box-sizing: border-box;

  .enclosure {
    padding: 30px;
    margin-top: 20px;
    background-color: #ffffff;

    .title {
      font-size: 28px;
      padding-bottom: 30px;
    }
  }

  .btn {
    width: 670px;
    height: 96px;
    background-color: #0a5ffe;
    border-radius: 12px;
    color: #ffffff;
    font-size: 36px;
    text-align: center;
    line-height: 96px;
    position: fixed;
    left: 50%;
    transform: translateX(-50%);
    bottom: 45px;
  }
}
</style>
