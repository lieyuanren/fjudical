<template>
  <div class="dispute-list">
    <van-tabs v-model="active"
              background="#F2F2F2"
              color="#0A5FFE"
              @change="handleChange">
      <van-tab title="未排查">未排查</van-tab>
      <van-tab title="已排查">已排查</van-tab>
    </van-tabs>
    <van-dropdown-menu>
      <van-dropdown-item v-model="value1"
                         :options="option1"
                         @change="onChange" />
      <van-dropdown-item v-model="value2"
                         :options="option2"
                         @change="onChange" />
    </van-dropdown-menu>
    <div class="dispute-list-body">
      <DisputeCard v-for="(item, index) in currentList"
                   :key="index"
                   :item="item" />
    </div>
    <div class="add"
         @click="goRoute">
      <img :src="imgUrl">
    </div>
  </div>
</template>

<script lang='ts'>
import { Component, Vue } from 'vue-property-decorator';
import DisputeCardType from '@/model/modules/mediation/dispute/DisputeCardType';
import DisputeCard from '@/components/modules/mediation/dispute/v-dispute-card/index.vue';

@Component({
  components: {
    DisputeCard
  }
})
export default class DisputeList extends Vue {
  private active: number = 1;
  private value1: number = 0;
  private value2: number = 0;
  private option1: any = [
    { text: '信息来源', value: 0 },
    { text: '信息来源1', value: 1 }
  ];
  private option2: any = [
    { text: '纠纷级别', value: 0 },
    { text: '纠纷级别1', value: 1 }
  ];
  private imgUrl: string = require('@/assets/images/modules/tmanager/task-add.png');
  private currentState: string = '已排查';

  private currentList: DisputeCardType[] = [];

  public created() {
    this.getList();
  }

  /**
   * 请求数据
   * @params : currentState 是否排查
   * @params : option1[value1].text 参数
   * @params : option2[value2].text 参数
   */
  private async getList(): Promise<void> {
    console.log('获取数据');
    this.currentList = [
      {
        troubleshooting: '未发现异常',
        infoFrom: '群众',
        time: '2020-03-11',
        disputeLevel: '简单纠纷'
      },
      {
        troubleshooting: '未发现异常',
        infoFrom: '群众',
        time: '2020-03-11',
        disputeLevel: '疑难纠纷'
      }
    ];
  }

  private goRoute(): void {
    this.$router.push({
      path: '/disputeDetails'
    });
  }

  private handleChange(text: string): void {
    this.currentState = text;
    this.getList();
  }

  private onChange(): void {
    this.getList();
  }
}
</script>

<style lang='less' scoped>
.dispute-list {
  height: 100%;
  .add {
    position: fixed;
    right: 40px;
    bottom: 146px;
    z-index: 999;
    width: 110px;
    height: 110px;
  }

  &-body {
    margin-top: 20px;
    padding-bottom: 300px;
  }
}

.van-tab__pane {
  display: none !important;
  opacity: 0;
  height: 0;
  overflow: hidden;
}

/deep/.van-tab--active {
  color: #0a5ffe;
}
</style>
