<template>
  <div class="home">
    <div class="home-head">
      <div class="home-head-tips" @click="toMore">
        <span>查看更多</span>
        <van-icon name="arrow"/>
      </div>
      <div class="home-head-card">
        <div class="home-head-card-id">
          <div class="line"></div>
          <span class="id">32011401000</span>
        </div>
        <div class="home-head-card-time">申请时间：2019-11-01</div>
        <div class="home-head-card-name">处案调委会：凤凰街人民调解委员会</div>
        <div class="warn">
          <div><img src="../../../../assets/images/modules/mediation/light.png"></div>
          <div>已催办24小时</div>
        </div>
      </div>
      <div class="home-head-text">
        <img class="home-new" src="../../../../assets/images/modules/mediation/new.png">
        <div class="home-head-text-text">您好，何小灿催办您处理案件编号44010...</div>
        <div class="home-head-text-arrow">
          <van-icon name="arrow"/>
        </div>
      </div>
    </div>
    <div class="grey-line"></div>
    <div class="home-body">
      <div class="home-body-tips">
        <span class="left-tips">待处理</span>
        <span class="right-tips">共12个</span>
      </div>
      <div class="home-body-list">
        <CaseCard name="待接单" :items='caseList2'/>
        <CaseCard name="待审定" :items='caseList2'/>
      </div>
    </div>
  </div>
</template>

<script lang='ts'>
import {Component, Vue} from 'vue-property-decorator';
import CaseCard from '@/components/modules/mediation/home/v-case-card/index.vue';
import CaseCardModel from '@/model/modules/mediation/home/CaseCardModel';
import HeadCard from '@/components/modules/mediation/home/v-head-card/index.vue';
import HeadCardType from '@/model/modules/mediation/home/HeadCardType';

@Component({
  components: {CaseCard, HeadCard}
})
export default class Home extends Vue {
  private caseList1: HeadCardType[] = [];
  private caseList2: CaseCardModel[] = [];
  private swiperOption: any = {
    loop: false,
    centeredSlides: true,
    slidesPerView: 'auto'
  };

  public created (): void {
    this.getDateList();
  }

  private toMore (): void {
    this.$router.push({
      path: '/track'
      // query: {
      //   id: this.item.caseId
      // }
    });
  }

  /**
   * 请求数据
   */
  private async getDateList (): Promise<void> {
    this.caseList1 = [
      {
        name: '和小陈',
        caseId: '1237821313',
        type: '邻居纠纷',
        mediationDate: '2020-02-14',
        committee: 'xxxx广州委员会',
        state: '待接单',
        dispute: '打上打上打上大打上大大大阿萨德阿达规划师的=',
        phoneNum: '123123123'
      },
      {
        name: '和小陈',
        caseId: '5673458313',
        type: '邻居纠纷',
        mediationDate: '2020-02-14',
        committee: 'xxxx广州委员会',
        state: '待接单',
        dispute: 'asdsa',
        phoneNum: '123123123'
      }
    ];
    this.caseList2 = [
      {
        caseId: '44011104000020180001',
        time: '3/26'
      },
      {
        caseId: '44011104000020180002',
        time: '3/26'
      },
      {
        caseId: '44011104000020180003',
        time: '3/26'
      },
      {
        caseId: '44011104000020180004',
        time: '3/26'
      },
      {
        caseId: '44011104000020180005',
        time: '3/26'
      }
    ];
  }
}
</script>

<style lang='less' scoped>
.line {
  width: 8px;
  height: 34px;
  background-color: #0a5ffe;
  border-radius: 4px;
  display: inline-block;
}

.grey-line {
  height: 20px;
  background: #eeeeee;
}

.id {
  font-size: 32px;
  margin-right: auto;
  margin-left: 20px;
}

.warn {
  position: relative;
  margin-left: 560px;
  margin-top: -130px;

  img {
    height: 50px;
    width: 50px;
    margin-left: 40px;
  }

  div {
    color: #F5675D;
    font-size: 20px;
    width: 150px;
  }
}

.home {
  height: 100%;
  background: white;

  &-new {
    width: 45px;
    height: 50px;
    margin: auto 0;
  }

  &-head {
    top: 0;
    width: 100%;
    z-index: 999;
    border: none;
    background: url("../../../../assets/images/modules/mediation/bg.png") no-repeat;
    background-size: 100% 50%;

    &-tips {
      padding-top: 20px;
      padding-bottom: 30px;
      padding-right: 20px;
      text-align: right;
      height: 20px;
      color: #ffffff;

      span, i {
        vertical-align: middle;
      }
    }

    &-text {
      display: flex;
      margin: 20px 30px;
      height: 80px;
      justify-content: space-between;
      font-size: 28px;
      color: #666666;

      &-text {
        width: 95%;
        line-height: 80px;
        padding-left: 20px;
      }

      &-arrow {
        line-height: 80px;
        margin-right: 30px;
        width: 10px;
      }

      i {
        vertical-align: middle;
      }
    }

    &-card {
      height: 200px;
      margin: 0px 30px;
      background: white;
      box-shadow: 0px 4px 21px 0px rgba(221, 221, 221, 0.48);
      border-radius: 12px;

      &-id {
        padding-left: 30px;
        padding-top: 30px;
      }

      &-time {
        font-size: 25px;
        color: #666666;
        padding-left: 30px;
        padding-top: 5px;
      }

      &-name {
        font-size: 25px;
        color: #666666;
        padding-left: 30px;
        padding-top: 5px;
      }
    }
  }

  &-body {
    background: white;

    &-tips {
      padding: 20px 40px;
      display: flex;
      justify-content: start;
      align-items: center;

      .left-tips {
        font-size: 34px;
        font-weight: bold;
      }

      .right-tips {
        background: rgba(236, 245, 255, 1);
        border-radius: 18px;
        font-size: 22px;
        color: #0A5FFE;
        padding: 0 10px;
        margin-left: 30px;
      }
    }

    &-list {
      padding: 0 40px;
      margin-bottom: 70px;
    }
  }
}
</style>
