<template>
  <div class="home">
    <div class="home-head">
      <div class="home-head-tips">
        <span>待接单/待处理</span>
        <div class="tag">
          {{ caseList1.length }}
        </div>
      </div>
      <div class="swiper-box">
        <van-swipe class="my-swipe"
                   indicator-color="white">
          <van-swipe-item v-for="item in caseList1"
                          :key="item.caseId">
            <div class="box">
              <HeadCard :item="item" />
            </div>
          </van-swipe-item>
        </van-swipe>
      </div>
    </div>
    <div class="home-body">
      <div class="home-body-tips">
        <span class="left-tips">调解中</span>
        <span class="right-tips">共有6个案件</span>
      </div>
      <div class="home-body-list">
        <MediationCard v-for="item in caseList2"
                       :key="item.caseId"
                       :item="item" />
      </div>
    </div>
  </div>
</template>

<script lang='ts'>
import { Component, Vue } from 'vue-property-decorator';
import MediationCard from '@/components/modules/mediation/home/v-mediation-card/index.vue';
import MediationCardType from '@/model/modules/mediation/home/MediationCardType';
import HeadCard from '@/components/modules/mediation/home/v-head-card/index.vue';
import HeadCardType from '@/model/modules/mediation/home/HeadCardType';

@Component({
  components: { MediationCard, HeadCard }
})
export default class Home extends Vue {
  private caseList1: HeadCardType[] = [];
  private caseList2: MediationCardType[] = [];
  private swiperOption: any = {
    loop: false,
    centeredSlides: true,
    slidesPerView: 'auto'
  };

  public created(): void {
    this.getDateList();
  }

  /**
   * 请求数据
   */
  private async getDateList(): Promise<void> {
    this.caseList1 = [
      {
        name: '和小陈',
        caseId: '1237821313',
        type: '邻居纠纷',
        mediationDate: '2020-02-14',
        committee: 'xxxx广州委员会',
        state: '待接单',
        dispute: '打上打上打上大打上大大大阿萨德阿达规划师的=',
        phoneNum: '123123123'
      },
      {
        name: '和小陈',
        caseId: '5673458313',
        type: '邻居纠纷',
        mediationDate: '2020-02-14',
        committee: 'xxxx广州委员会',
        state: '待接单',
        dispute: 'asdsa',
        phoneNum: '123123123'
      }
    ];
    this.caseList2 = [
      {
        caseId: '1237821313',
        type: '邻居纠纷',
        mediationDate: '2020-02-14',
        committee: 'xxxx广州委员会',
        mediator: '叶小化',
        otherMediator: '唐某人',
        state: '已结案'
      },
      {
        caseId: '5673458313',
        type: '邻居纠纷',
        mediationDate: '2020-02-14',
        committee: 'xxxx广州委员会',
        mediator: '叶小化',
        otherMediator: '无',
        state: '已结案'
      }
    ];
  }
}
</script>

<style lang='less' scoped>
.home {
  height: 100%;

  &-head {
    position: fixed;
    top: 0;
    width: 100%;
    overflow: hidden;
    z-index: 999;
    border: none;
    background: linear-gradient(180deg, #2067ee, #e0e7f3, #ffffff);

    &-tips {
      position: relative;
      padding: 30px 40px;
      span {
        font-size: 42px;
        font-weight: bold;
        color: #ffffff;
      }

      .tag {
        position: absolute;
        top: 20px;
        left: 310px;
        width: 42px;
        height: 28px;
        background-color: #ffc000;
        font-size: 22px;
        color: #0d61fe;
        text-align: center;
        line-height: 28px;
        border-radius: 14px 14px 14px 0;
      }
    }
  }

  &-body {
    margin-top: 500px;
    background: linear-gradient(
      180deg,
      rgba(255, 255, 255, 1) 10%,
      rgba(240, 240, 240, 1)
    );
    &-tips {
      padding: 30px 40px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      .left-tips {
        font-size: 36px;
      }

      .right-tips {
        font-size: 26px;
        color: #999999;
      }
    }

    &-list {
      padding: 0 40px;
    }
  }
}
</style>