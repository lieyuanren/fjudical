<template>
  <div class="mediation">
    <div class="mediation-content">
      <transition mode="out-in"
                  name="component-fade">
        <component :is="components[activeIndex]"></component>
      </transition>
    </div>
    <div class="mediation-menu">
      <van-tabbar v-model="active">
        <van-tabbar-item>
          <span>首页</span>
          <img :src="props.active ? menuIcon.homeActive : menuIcon.homeInactive"
               class="mediation-menu-icon"
               slot="icon"
               slot-scope="props" />
        </van-tabbar-item>
        <van-tabbar-item>
          <span>案件管理</span>
          <img :src="props.active ? menuIcon.recordActive : menuIcon.recordInactive"
               class="mediation-menu-icon"
               slot="icon"
               slot-scope="props" />
        </van-tabbar-item>
        <van-tabbar-item>
          <div class="ball"
               @click="handleShow">
            <img :src="ballIcon">
          </div>
        </van-tabbar-item>
        <van-tabbar-item>
          <span>机构人员</span>
          <img :src="props.active ? menuIcon.authenticActActive : menuIcon.authenticActInactive"
               class="mediation-menu-icon"
               slot="icon"
               slot-scope="props" />
        </van-tabbar-item>
        <van-tabbar-item>
          <span>统计分析</span>
          <img :src="props.active ? menuIcon.statisticsActive : menuIcon.statisticsInactive"
               class="mediation-menu-icon"
               slot="icon"
               slot-scope="props" />
        </van-tabbar-item>
      </van-tabbar>
    </div>
    <van-popup v-model="show"
               position="bottom">
      <div class="tabs">
        <div class="tab-item">
          <img :src="icon1"
               @click="goRoute(1)">
          <span class="text">新增调解员</span>
        </div>
        <div class="tab-item"
             @click="goRoute(2)">
          <img :src="icon2">
          <span class="text">调解员信息</span>
        </div>
        <div class="tab-item"
             @click="goRoute(3)">
          <img :src="icon3">
          <span class="text">纠纷排查</span>
        </div>
        <div class="tab-item"
             @click="goRoute(4)">
          <img :src="icon4">
          <span class="text">案件录入</span>
        </div>
      </div>
      <div class="cancel"
           @click="show = false">
        <img :src="cancelIcon">
      </div>
    </van-popup>
  </div>
</template>

<script lang='ts'>
import { Component, Vue, Watch } from 'vue-property-decorator';
import Home from '@/views/modules/mediation/home/index.vue';
import Analysis from '@/views/modules/mediation/analysis/index.vue';
import CaseManager from '@/views/modules/mediation/case_manager/index.vue';
import Mechanismer from '@/views/modules/mediation/mechanismer/index.vue';

@Component({
  components: {
    Home,
    Analysis,
    CaseManager,
    Mechanismer
  }
})
export default class Mediation extends Vue {
  private active: number = 0;
  private show: boolean = false;
  private activeIndex: number = 0;

  private menuIcon: any = {
    homeActive: require('@/assets/images/modules/mediation/icon-01-sel.png'),
    homeInactive: require('@/assets/images/modules/mediation/icon-01.png'),
    recordActive: require('@/assets/images/modules/mediation/icon-02-sel.png'),
    recordInactive: require('@/assets/images/modules/mediation/icon-02_1.png'),
    authenticActActive: require('@/assets/images/modules/mediation/icon-03-sel.png'),
    authenticActInactive: require('@/assets/images/modules/mediation/icon-03.png'),
    statisticsActive: require('@/assets/images/modules/mediation/icon-04-sel.png'),
    statisticsInactive: require('@/assets/images/modules/mediation/icon-04.png')
  };
  private ballIcon: string = require('@/assets/images/modules/mediation/zh-icon.png');
  private icon1: string = require('@/assets/images/modules/mediation/01-icon1.png');
  private icon2: string = require('@/assets/images/modules/mediation/02-icon1.png');
  private icon3: string = require('@/assets/images/modules/mediation/03-icon1.png');
  private icon4: string = require('@/assets/images/modules/mediation/04-icon1.png');
  private cancelIcon: string = require('@/assets/images/modules/mediation/close-icon.png');

  private components: string[] = [
    'Home',
    'CaseManager',
    '',
    'Mechanismer',
    'Analysis'
  ];

  @Watch('active')
  private watchActive(): void {
    if (this.active === 2) {
      this.active = this.activeIndex;
      return;
    }
    this.activeIndex = this.active;
  }

  private handleShow(): void {
    this.show = true;
  }

  private goRoute(index: number): void {
    this.show = false;
    if (index === 1) {
      this.$router.push({
        path: '/addMediator'
      });
    } else if (index === 2) {
      this.$router.push({
        path: '/mediatorList',
        query: {
          isInfo: 'noInfo'
        }
      });
    } else if (index === 3) {
      this.$router.push({
        path: '/disputeList'
      });
    } else if (index === 4) {
      this.$router.push({
        path: '/caseHandle'
      });
    }
  }
}
</script>

<style lang='less' scoped>
.mediation {
  position: relative;
  height: 100%;

  &-menu {
    height: 92px;
    &-icon {
      height: 44px;
      width: 44px;
    }
  }
}

.ball {
  position: relative;
  z-index: 999;
  width: 90px;
  height: 90px;
  margin-bottom: 60px;
  img {
    width: 100%;
    height: 100%;
  }
}

// 样式重置
.van-tabbar-item--active {
  color: #0a5ffe;
}

.tabs {
  display: flex;
  justify-content: space-around;
  padding-top: 86px;
  padding-bottom: 70px;

  .tab-item {
    width: 140px;
    height: 166px;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    align-items: center;

    img {
      width: 108px;
      height: 108px;
    }

    text {
      font-size: 28px;
    }
  }
}

.cancel {
  width: 84px;
  height: 84px;
  margin: 50px auto;

  img {
    width: 100%;
    height: 100%;
  }
}
</style>
