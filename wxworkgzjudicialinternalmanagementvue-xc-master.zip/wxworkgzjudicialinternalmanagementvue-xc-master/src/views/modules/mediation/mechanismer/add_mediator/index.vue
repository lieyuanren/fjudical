<template>
  <div class="add-mediator">
    <div class="add-mediator-main">
      <van-cell-group>
        <van-field v-model="mediatorObj.name"
                   required
                   input-align="right"
                   label="姓名"
                   placeholder="请输入名字" />
        <van-field v-model="mediatorObj.phoneNum"
                   required
                   input-align="right"
                   label="联系方式"
                   placeholder="请输入联系方式" />
        <van-field v-model="mediatorObj.IdCard"
                   required
                   label="身份证号码"
                   input-align="right"
                   placeholder="请输入身份证号码" />
        <van-field v-model="mediatorObj.account"
                   required
                   label="羊城慧调解账号"
                   input-align="right"
                   placeholder="请输入羊城慧调解账号" />
        <van-field v-model="mediatorObj.password"
                   required
                   label="羊城慧调解密码"
                   input-align="right"
                   placeholder="请输入羊城慧调解密码" />
        <van-cell is-link
                  v-for="(item,index) in mediatorObj.organization"
                  :key="index"
                  :value="item"
                  @click="handleShow(index)">
          <template slot="title">
            <span class="label">*</span>
            <span class="custom-title">所属调委会</span>
          </template>
        </van-cell>
      </van-cell-group>
      <div class="add"
           @click="addOrganizaiton">
        添加
      </div>
    </div>
    <div class="add-mediator-other">
      <van-cell-group>
        <van-cell is-link>
          <template slot="title">
            <span class="custom-title">调解员级别</span>
          </template>
        </van-cell>
        <van-field v-model="mediatorObj.ohterIdentity"
                   label="兼备其他身份"
                   input-align="right"
                   placeholder="请输入兼备其他身份" />
        <van-field v-model="mediatorObj.position"
                   label="职位"
                   input-align="right"
                   placeholder="请输入职位" />
        <div class="check-box">
          <span>专兼职</span>
          <van-radio-group v-model="mediatorObj.mtcsol"
                           direction="horizontal">
            <van-radio name="专职">专职</van-radio>
            <van-radio name="兼职">兼职</van-radio>
          </van-radio-group>
        </div>
        <div class="check-box">
          <span>是否政府购买服务</span>
          <van-radio-group v-model="mediatorObj.isGovernment"
                           direction="horizontal">
            <van-radio name="是">是</van-radio>
            <van-radio name="否">否</van-radio>
          </van-radio-group>
        </div>
        <div class="check-box">
          <span>是否从事过相关方面工作或具备有关知识储备</span>
          <van-radio-group v-model="mediatorObj.isWorkOn"
                           direction="horizontal">
            <van-radio name="是">是</van-radio>
            <van-radio name="否">否</van-radio>
          </van-radio-group>
        </div>
        <van-cell is-link
                  :value="mediatorObj.politicsStatus">
          <template slot="title">
            <span class="custom-title">政治面貌</span>
          </template>
        </van-cell>
        <van-field v-model="mediatorObj.employDate"
                   label="聘用日期"
                   input-align="right"
                   placeholder="请输入聘用日期" />
        <van-cell is-link
                  :value="mediatorObj.nation">
          <template slot="title">
            <span class="custom-title">民族</span>
          </template>
        </van-cell>
        <van-cell is-link
                  :value="mediatorObj.education">
          <template slot="title">
            <span class="custom-title">学历</span>
          </template>
        </van-cell>
        <van-field v-model="mediatorObj.specialities"
                   label="所学专业"
                   input-align="right"
                   placeholder="请输入所学专业" />
        <van-field v-model="mediatorObj.occupation"
                   label="身份职业"
                   input-align="right"
                   placeholder="请输入身份职业" />
        <van-field v-model="mediatorObj.title"
                   label="资格职称"
                   input-align="right"
                   placeholder="请输入资格职称" />
        <van-cell is-link
                  :value="mediatorObj.maritalStatus">
          <template slot="title">
            <span class="custom-title">婚姻状况</span>
          </template>
        </van-cell>
        <van-field v-model="mediatorObj.address"
                   label="联系地址"
                   input-align="right"
                   placeholder="请输入联系地址" />
        <van-field v-model="mediatorObj.introduce"
                   label="个人简介"
                   type="textarea"
                   input-align="right"
                   placeholder="请输入个人简介" />
      </van-cell-group>
    </div>
    <div class="btn-box">
      <div class="btn"
           @click="onSubmit">
        提交
      </div>
    </div>
    <van-popup v-model="show"
               position="bottom">
      <van-picker :columns="columns"
                  show-toolbar
                  @cancel="onCancel"
                  @confirm="onConfirm" />
    </van-popup>
  </div>
</template>

<script lang='ts'>
import { Component, Vue } from 'vue-property-decorator';
import AddMediatorType from '@/model/modules/mediation/mechanismer/AddMediatorType';

@Component
export default class AddMediator extends Vue {
  private mediatorObj: AddMediatorType = new AddMediatorType();
  private show: boolean = false;
  private columns: string[] = [];
  private activeIndex: number = 0;

  public created() {
    this.getOrganizaitonList();
  }

  /**
   * 获取调委会数据
   */
  private async getOrganizaitonList(): Promise<void> {
    this.columns = ['asdas', 'dasd', '12312', 'asdasd'];
  }

  // 添加
  private addOrganizaiton(): void {
    this.mediatorObj.organization.push('请选择');
  }

  private handleShow(index: number): void {
    this.activeIndex = index;
    this.show = true;
  }

  private onCancel(): void {
    this.show = false;
  }

  private onConfirm(str: string): void {
    this.show = false;
    this.mediatorObj.organization[this.activeIndex] = str;
  }

  private onSubmit(): void {
    this.initList();
    console.log(this.mediatorObj);
  }

  private initList(): void {
    const arr = this.mediatorObj.organization.filter((str: string) => {
      if (str !== '请选择') {
        return str;
      }
    });
    this.mediatorObj.organization = arr;
  }
}
</script>

<style lang='less' scoped>
.add-mediator {
  .label {
    color: #f25968;
    margin-left: -16px;
  }

  .add {
    padding: 20px;
    font-size: 28px;
    color: #1567fe;
    text-align: right;
  }

  .check-box {
    display: flex;
    padding: 30px;
    justify-content: space-between;
    font-size: 28px;

    span {
      max-width: 280px;
    }
  }

  .btn-box {
    padding: 20px 40px 40px 40px;
    background-color: #ffffff;

    .btn {
      width: 100%;
      height: 96px;
      font-size: 36px;
      color: #ffffff;
      text-align: center;
      line-height: 96px;
      background-color: #0a5ffe;
      border-radius: 12px;
    }
  }

  &-main {
    margin-top: 30px;
  }
}
</style>
