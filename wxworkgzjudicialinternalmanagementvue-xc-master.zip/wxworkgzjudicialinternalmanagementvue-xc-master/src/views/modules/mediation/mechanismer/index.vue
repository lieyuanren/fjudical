<template>
  <div class="mechanismer">
    <div class="mechanismer-head">
      <div class="address-select">
        <OrganizationSelect :list="organizationList"
                            @onConfirm="onConfirm" />
      </div>
      <van-search v-model="searchKey"
                  placeholder="请输入搜索关键词" />
    </div>
    <div class="tips">共 n 个案件，满足当前筛选条件</div>
    <div class="mechanismer-body">
      <MechanismCard v-for="(item) in list"
                     :key="item.id"
                     :item="item" />
    </div>
  </div>
</template>

<script lang='ts'>
import { Component, Vue, Watch } from 'vue-property-decorator';
import MechanismCard from '@/components/modules/mediation/mechanismer/v-mechanism-card/index.vue';
import MechanismCardType from '@/model/modules/mediation/mechanismer/MechanismCardType';
import OrganizationSelect from '@/components/common/v-organization-select/index.vue';

@Component({
  components: {
    MechanismCard,
    OrganizationSelect
  }
})
export default class Mechanismer extends Vue {
  private organizationList: any = [];

  private organization: string = '';

  private searchKey: string = '';

  private timeLimit: any = null;

  private list: MechanismCardType[] = [];

  public async created() {
    await this.getOrganization();
    await this.getList();
  }

  @Watch('organization')
  private watchOrganization(): void {
    this.getList();
  }
  @Watch('searchKey')
  private watchSearchKey(): void {
    clearTimeout(this.timeLimit);
    this.timeLimit = setTimeout(() => {
      this.getList();
    }, 500);
  }

  private onConfirm(str: string): void {
    this.organization = str;
  }

  /**
   * 请求数据
   */
  private async getList(): Promise<void> {
    console.log('获取数据');
    this.list = [
      {
        id: '123w213',
        mechanismName: '沙面街人民调解委员会',
        category: '企事业单位调委会',
        person: '何小灿',
        address: '越秀区大塘街人民调委会',
        phoneNum: '18203434121',
        count: 3
      },
      {
        id: '12313',
        mechanismName: '沙面街人民调解委员会',
        category: '企事业单位调委会',
        person: '何小灿',
        address: '越秀区大塘街人民调委会',
        phoneNum: '18203434121',
        count: 3
      }
    ];
  }

  /**
   * 请求数据
   * 获取地区数据列表
   */
  private async getOrganization(): Promise<void> {
    this.organizationList = [
      {
        text: '浙江',
        children: [
          {
            text: '杭州',
            children: [{ text: '西湖区' }, { text: '余杭区' }]
          },
          {
            text: '温州',
            children: [{ text: '鹿城区' }, { text: '瓯海区' }]
          }
        ]
      },
      {
        text: '福建',
        children: [
          {
            text: '福州',
            children: [{ text: '鼓楼区' }, { text: '台江区' }]
          },
          {
            text: '厦门',
            children: [{ text: '思明区' }, { text: '海沧区' }]
          }
        ]
      }
    ];
  }
}
</script>

<style lang='less' scoped>
.mechanismer {
  &-head {
    background-color: #ffffff;
    .address-select {
      padding: 40px 30px 0 30px;

      .address {
        font-size: 32px;
      }

      i {
        transform: rotateZ(90deg);
        margin-left: 10px;
        font-size: 26px;
      }
    }
  }

  .tips {
    padding: 20px;
    font-size: 24px;
    color: #999999;
  }
}
</style>