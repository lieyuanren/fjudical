<template>
  <div class="mechanism-info">
    <div class="tips">
      <span @click="goRoute">更多信息</span>
    </div>
    <div class="mechanism-info-content">
      <div class="title">
        沙面街人民调解委员会
      </div>
      <p class="text">
        <span class="label">调委会编号</span>
        <span class="value"></span>
      </p>
      <p class="text">
        <span class="label">调委会类型</span>
        <span class="value"></span>
      </p>
      <p class="text">
        <span class="label">行专调委会类型</span>
        <span class="value"></span>
      </p>
      <p class="text">
        <span class="label">专职调解员数量</span>
        <span class="value"></span>
      </p>
      <p class="text">
        <span class="label">兼职调解员数量</span>
        <span class="value"></span>
      </p>
      <p class="text">
        <span class="label">负责人</span>
        <span class="value"></span>
      </p>
    </div>
    <div class="mechanism-info-content">
      <p class="text">
        <span class="label">主管机构</span>
        <span class="value"></span>
      </p>
      <p class="text">
        <span class="label">设立单位</span>
        <span class="value"></span>
      </p>
      <p class="text">
        <span class="label">管理体制</span>
        <span class="value"></span>
      </p>
      <p class="text">
        <span class="label">覆盖区域</span>
        <span class="value"></span>
      </p>
      <p class="text">
        <span class="label">成立时间</span>
        <span class="value"></span>
      </p>
      <p class="text">
        <span class="label">曾用名</span>
        <span class="value"></span>
      </p>
    </div>
    <div class="mechanism-info-content no-bottom">
      <p class="text">
        <span class="label">联系地址</span>
        <span class="value"></span>
      </p>
      <p class="text">
        <span class="label">邮政编码</span>
        <span class="value"></span>
      </p>
      <p class="text">
        <span class="label">电话号码</span>
        <span class="value"></span>
      </p>
      <p class="text">
        <span class="label">传真号码</span>
        <span class="value"></span>
      </p>
      <p class="text">
        <span class="label">电子邮箱</span>
        <span class="value"></span>
      </p>
      <p class="text">
        <span class="label">网址</span>
        <span class="value"></span>
      </p>
      <p class="text margin-top">
        <span class="label">简介</span>
        <span class="value">暂无数据</span>
      </p>
    </div>
  </div>
</template>

<script lang='ts'>
import { Component, Vue } from 'vue-property-decorator';

@Component({
  beforeRouteEnter(to, from, next) {
    if (!to.query.id) {
      next('/mediation');
    }
    next();
  }
})
export default class MechanismInfo extends Vue {
  private id: string = '';

  public async created() {
    await this.getId();
  }

  private getId(): void {
    this.id = this.$route.query.id as string;
  }

  private goRoute(): void {
    this.$router.push({
      path: '/mediatorList',
      query: {
        id: this.id,
        isInfo: 'isInfo'
      }
    });
  }

  /**
   * 请求数据
   */
  private async getInfo(): Promise<void> {
    console.log('请求数据');
  }
}
</script>

<style lang='less' scoped>
.mechanism-info {
  .tips {
    font-size: 28px;
    color: #2b65e1;
    padding: 20px;
    text-align: right;
  }

  &-content {
    padding: 30px;
    background-color: #ffffff;
    margin-bottom: 20px;

    .title {
      font-size: 36px;
      font-weight: bold;
    }

    .text {
      font-size: 28px;
      margin: 20px 0;
      .label {
        color: #999999;
        display: inline-block;
        width: 250px;
      }
    }

    .margin-top {
      margin-top: 60px;

      .label {
        width: 100%;
      }

      .value {
        display: inline-block;
        padding-top: 40px;
      }
    }
  }

  .no-bottom {
    margin-bottom: 0px;
  }
}
</style>