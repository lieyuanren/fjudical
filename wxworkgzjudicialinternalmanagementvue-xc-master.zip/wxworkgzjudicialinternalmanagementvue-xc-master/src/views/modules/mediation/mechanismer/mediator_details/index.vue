<template>
  <div class="mediator-details">
    <div class="more"
         @click="goRoute">更多信息</div>
    <div class="mediator-details-baseInfo">
      <p class="title">{{ mediator.name }}</p>
      <p class="text">
        <span class="label">所属调委会:</span>
        <span class="value">{{ mediator.organization }}</span>
      </p>
      <p class="text">
        <span class="label">专兼职:</span>
        <span class="value">{{ mediator.mtcsol }}</span>
      </p>
      <p class="text">
        <span class="label">从事法律职业类型:</span>
        <span class="value">{{ mediator.jobType }}</span>
      </p>
      <p class="text">
        <span class="label">学历学位:</span>
        <span class="value">{{ mediator.education }}</span>
      </p>
      <p class="text">
        <span class="label">调解擅长类型:</span>
        <span class="value">{{ mediator.beGoodAt }}</span>
      </p>
      <p class="text">
        <span class="label">处罚:</span>
        <span class="value">{{ mediator.punishment }}</span>
      </p>
      <p class="text">
        <span class="label">奖励:</span>
        <span class="value">{{ mediator.award }}</span>
      </p>
    </div>
    <div class="mediator-details-analysis">
      <div class="title">能力分析</div>
      <div class="canvas-box"
           @click="handleClick">
        <canvas id="myChart"></canvas>
      </div>
    </div>
    <div class="btn-box">
      <div class="btn">
        人民调解服务记录
      </div>
    </div>
  </div>
</template>

<script lang='ts'>
import { Component, Vue } from 'vue-property-decorator';
import MediatorDetailsType from '@/model/modules/mediation/mechanismer/MediatorDetailsType';
import radar from '@/plugins/antv-f2/radar';
import RadarType from '@/model/common/f2/RadarType';

@Component
export default class MediatorDetails extends Vue {
  private id: string = '';
  private mediator: MediatorDetailsType = new MediatorDetailsType();
  private dataList: RadarType[] = [
    {
      type: 'Design',
      name: '用户 A',
      value: 70
    },
    {
      type: 'Design',
      name: '用户 B',
      value: 30
    },
    {
      type: 'Development',
      name: '用户 A',
      value: 60
    },
    {
      type: 'Development',
      name: '用户 B',
      value: 70
    },
    {
      type: 'Marketing',
      name: '用户 A',
      value: 50
    },
    {
      type: 'Marketing',
      name: '用户 B',
      value: 60
    },
    {
      type: 'names',
      name: '用户 A',
      value: 40
    },
    {
      type: 'names',
      name: '用户 B',
      value: 50
    },
    {
      type: 'Test',
      name: '用户 A',
      value: 60
    },
    {
      type: 'Test',
      name: '用户 B',
      value: 70
    },
    {
      type: 'Language',
      name: '用户 A',
      value: 70
    },
    {
      type: 'Language',
      name: '用户 B',
      value: 50
    },
    {
      type: 'Technology',
      name: '用户 A',
      value: 70
    },
    {
      type: 'Technology',
      name: '用户 B',
      value: 40
    },
    {
      type: 'Support',
      name: '用户 A',
      value: 60
    },
    {
      type: 'Support',
      name: '用户 B',
      value: 40
    }
  ];

  private async created(): Promise<void> {
    await this.getId();
    await this.getData();
  }

  private mounted() {
    radar('myChart', this.dataList);
  }

  private async getData(): Promise<void> {
    console.log('获取数据');
    this.mediator = {
      name: '和小城',
      organization: 'xxxx广州调解会',
      mtcsol: '专职',
      jobType: '调解',
      education: '本科',
      beGoodAt: '调解',
      punishment: '无',
      award: '无'
    };
  }

  private handleClick(): void {
    console.log('click');
  }

  private goRoute(): void {
    this.$router.push({
      path: '/mediatorUpdata',
      query: {
        id: this.id
      }
    });
  }

  private getId(): void {
    this.id = this.$route.query.id as string;
  }
}
</script>

<style lang='less' scoped>
.mediator-details {
  .more {
    font-size: 28px;
    color: #2b65e1;
    padding: 20px 30px;
    text-align: right;
  }

  &-baseInfo {
    padding: 30px;
    background-color: #ffffff;

    .title {
      font-size: 36px;
      font-weight: bold;
    }

    .text {
      font-size: 28px;
      margin: 20px 0;
      .label {
        color: #999999;
        display: inline-block;
        width: 250px;
      }
    }
  }

  &-analysis {
    padding: 30px;
    margin-top: 20px;
    background-color: #ffffff;

    .title {
      font-size: 36px;
      font-weight: bold;
    }

    .canvas-box {
      width: 100%;
      height: 520px;

      #myChart {
        width: 100%;
        height: 100%;
      }
    }
  }

  .btn-box {
    background: #ffffff;
    padding: 40px 30px;

    .btn {
      height: 98px;
      font-size: 36px;
      color: #ffffff;
      text-align: center;
      line-height: 98px;
      border-radius: 12px;
      background-color: #0a5ffe;
    }
  }
}
</style>
