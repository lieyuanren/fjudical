<template>
  <div class="mediator-list">
    <div class="mediator-list-head"
         v-if="isInfo">
      <div class="address-select">
        <OrganizationSelect :list="organizationList"
                            @onConfirm="onConfirm" />
      </div>
      <van-search v-model="searchKey"
                  placeholder="请输入搜索关键词" />
    </div>
    <div class="tips">
      共 {{ currentList.length }} 个案件，满足当前筛选条件
    </div>
    <div class="mediator-list-body">
      <MediatorCard v-for="item in currentList"
                    :key="item.mediatorId"
                    :item="item" />
    </div>
  </div>
</template>

<script lang='ts'>
import { Component, Vue } from 'vue-property-decorator';
import OrganizationSelect from '@/components/common/v-organization-select/index.vue';
import MediatorCard from '@/components/modules/mediation/mechanismer/v-mediator-card/index.vue';
import MediatorCardType from '@/model/modules/mediation/mechanismer/MediatorCardType';

@Component({
  components: {
    OrganizationSelect,
    MediatorCard
  },
  beforeRouteEnter(to, from, next) {
    console.log(from.name, to.query.id);
    if (from.name === '机构信息') {
      if (!to.query.id) {
        next('/mediation');
      }
    }
    if (!from.name) {
      next('/mediation');
    }
    next();
  }
})
export default class MediatorList extends Vue {
  private id: string = '';
  private isInfo: boolean = false;
  private currentList: MediatorCardType[] = [];
  private searchKey: string = '';
  private organization: string = '';
  private organizationList: any = [
    {
      text: '浙江',
      children: [
        {
          text: '杭州',
          children: [{ text: '西湖区' }, { text: '余杭区' }]
        },
        {
          text: '温州',
          children: [{ text: '鹿城区' }, { text: '瓯海区' }]
        }
      ]
    },
    {
      text: '福建',
      children: [
        {
          text: '福州',
          children: [{ text: '鼓楼区' }, { text: '台江区' }]
        },
        {
          text: '厦门',
          children: [{ text: '思明区' }, { text: '海沧区' }]
        }
      ]
    }
  ];

  public async created() {
    if (this.$route.query.isInfo === 'isInfo') {
      await this.getId();
      await this.getList();
    } else {
      this.isInfo = true;
      await this.getList();
    }
  }

  private getId(): void {
    this.id = this.$route.query.id as string;
  }

  private onConfirm(str: string): void {
    this.organization = str;
  }

  /**
   * 请求数据
   * 1.如果是从机构信息进入，根据id请求该机构调解员
   * @params :id
   * 2.如说是从首页进入，直接请求默认
   * @params ：searchKey 搜索字符
   * @params ：organization 机构字段
   */
  private async getList(): Promise<void> {
    this.currentList = [
      {
        mediatorId: 'vsd13123',
        imgUrl: '',
        mediatorName: '何小灿',
        level: '一级调解员',
        organization: '广州调委会',
        year: 12,
        phoneNum: '123849383',
        state: '正常',
        caseCount: 10
      }
    ];
  }
}
</script>

<style lang='less' scoped>
.mediator-list {
  &-head {
    background-color: #ffffff;
    .address-select {
      padding: 40px 30px 0 30px;

      .address {
        font-size: 32px;
      }

      i {
        transform: rotateZ(90deg);
        margin-left: 10px;
        font-size: 26px;
      }
    }
  }
  .tips {
    padding: 20px;
    font-size: 24px;
    color: #999999;
  }
}
</style>