<template>
  <div class="mediator-updata">
    <div class="mediator-updata-content">
      <div class="head">
        <van-image width="1.33333rem"
                   height="1.33333rem"
                   src="https://img.yzcdn.cn/vant/cat.jpeg" />
        <div class="content">
          <p class="name">叶小每</p>
          <p class="other">
            <span class="sex">女</span>
            <span> | </span>
            <span class="age">29岁</span>
          </p>
        </div>
        <div class="toggel-box">
          <van-switch v-model="checked"
                      @change="onChange" />
          <span>停用/启用</span>
        </div>
      </div>
      <div class="feild">
        <div class="feild-content">
          <div class="feild-content-label">联系方式</div>
          <div class="feild-content-input">
            <input type="text"
                   :placeholder="mediator.name">
            <div class="icon-box">
              <van-icon name="edit" />
            </div>
          </div>
        </div>
      </div>
      <div class="feild">
        <div class="feild-content">
          <div class="feild-content-label">羊城慧调解帐号</div>
          <div class="feild-content-input">
            <input type="text"
                   :placeholder="mediator.account">
            <div class="icon-box">
              <van-icon name="edit" />
            </div>
          </div>
        </div>
      </div>
      <div class="feild">
        <div class="feild-content">
          <div class="feild-content-label">养成慧调解密码</div>
          <div class="feild-content-input">
            <input type="text"
                   :placeholder="mediator.password">
            <div class="btn">保存</div>
          </div>
        </div>
      </div>
    </div>
    <div class="mediator-updata-content">
      <van-cell title="所属机构"
                :value="item"
                v-for="(item,index) in mediator.organization"
                :key="index"
                @click="handleSelect(index)">
        <!-- 使用 right-icon 插槽来自定义右侧图标 -->
        <van-icon slot="right-icon"
                  name="add-o"
                  style="line-height: inherit;" />
      </van-cell>
      <div class="tips"
           @click="handleAdd">
        添加
      </div>
    </div>
    <div class="mediator-updata-content"
         style="margin-top:0;">
      <van-cell-group>
        <van-cell title="调解员级别"
                  is-link
                  @click="handleShow(1)"
                  :value="mediator.mediatorLevel" />
        <van-field v-model="mediator.ohterIdentity"
                   label="兼备其他身份"
                   input-align="right"
                   :value="mediator.ohterIdentity" />
        <van-field v-model="mediator.position"
                   input-align="right"
                   label="职位"
                   :placeholder="mediator.position" />
        <div class="check-box">
          <span>专兼职：</span>
          <van-radio-group v-model="mediator.mtcsol"
                           direction="horizontal">
            <van-radio name="专职">专职</van-radio>
            <van-radio name="兼职">兼职</van-radio>
          </van-radio-group>
        </div>
        <div class="check-box">
          <span>是否政府购买服务：</span>
          <van-radio-group v-model="mediator.isGovernment"
                           direction="horizontal">
            <van-radio name="是">是</van-radio>
            <van-radio name="否">否</van-radio>
          </van-radio-group>
        </div>
        <div class="check-box">
          <span>是否从事过相关方面工作或具备有关知识储备：</span>
          <van-radio-group v-model="mediator.isWorkOn"
                           direction="horizontal">
            <van-radio name="是">是</van-radio>
            <van-radio name="否">否</van-radio>
          </van-radio-group>
        </div>
        <van-field v-model="mediator.politicsStatus"
                   input-align="right"
                   label="政治面貌"
                   :placeholder="mediator.politicsStatus" />
        <van-cell title="聘用日期"
                  is-link
                  @click="handleShow(4)"
                  :value="mediator.employDate" />
        <van-field :v-model="mediator.IdCard"
                   label="身份证号码"
                   input-align="right"
                   readonly
                   :placeholder="mediator.IdCard" />
        <van-cell title="民族"
                  is-link
                  @click="handleShow(2)"
                  :value="mediator.nation" />
        <van-cell title="学历"
                  is-link
                  @click="handleShow(3)"
                  :value="mediator.education" />
        <van-field v-model="mediator.specialities"
                   label="所学专业"
                   input-align="right"
                   :placeholder="mediator.specialities" />
        <van-field v-model="mediator.occupation"
                   label="身份职业"
                   input-align="right"
                   :placeholder="mediator.occupation" />
        <van-field v-model="mediator.title"
                   input-align="right"
                   label="资格职称"
                   :placeholder="mediator.title" />
        <van-field v-model="mediator.maritalStatus"
                   input-align="right"
                   label="婚姻状况"
                   :placeholder="mediator.maritalStatus" />
        <van-field v-model="mediator.address"
                   label="联系地址"
                   input-align="right"
                   :placeholder="mediator.address" />
        <van-field :v-model="mediator.introduce"
                   label="个人简介"
                   type="textarea"
                   :placeholder="mediator.introduce" />
      </van-cell-group>
    </div>
    <div class="btn-box">
      <div class="btn"
           @click="onSubmit">保存</div>
    </div>
    <van-popup v-model="show"
               position="bottom">
      <van-picker :columns="columns"
                  show-toolbar
                  @cancel="show = false"
                  @confirm="onConfirm" />
    </van-popup>
    <van-popup v-model="show1"
               position="bottom">
      <van-datetime-picker v-model="currentDate"
                           type="date"
                           @cancel="show1 = false"
                           @confirm="onConfirm" />
    </van-popup>
    <van-popup v-model="show2"
               position="bottom">
      <van-picker :columns="committeeList"
                  show-toolbar
                  @cancel="show2 = false"
                  @confirm="onConfirm1" />
    </van-popup>
  </div>
</template>

<script lang='ts'>
import { Component, Vue } from 'vue-property-decorator';
import MediatorUpdataType from '@/model/modules/mediation/mechanismer/MediatorUpdataType';

@Component
export default class MediatorUpdata extends Vue {
  private mediator: MediatorUpdataType = new MediatorUpdataType();
  private checked: boolean = true;
  private value: string = '';
  private radio: string = '';
  private activeIndex: number = 0;
  private show: boolean = false;
  private show1: boolean = false;
  private show2: boolean = false;
  private currentDate: Date = new Date();
  private selectIndex: number = 0;

  private columns: string[] = [];
  // 调解员级别
  private mediatorLevel: string[] = ['低'];
  // 民族
  private nationList: string[] = ['汉'];
  // 学历
  private educationList: string[] = ['本科'];
  // 调委会列表
  private committeeList: string[] = ['调委会1'];

  public async created() {
    await this.getMediator();
  }

  /**
   * 获取调解员信息数据
   */
  private getMediator(): void {
    console.log('获取数据');
  }

  /**
   * 提交调解员修改的数据
   */
  private commitMediator(): void {
    console.log('提交数据');
  }

  private onConfirm(value: string | Date): void {
    if (this.activeIndex !== 4) {
      if (this.activeIndex === 1) {
        this.mediator.mediatorLevel = value as string;
      } else if (this.activeIndex === 2) {
        this.mediator.nation = value as string;
      } else if (this.activeIndex === 3) {
        this.mediator.education = value as string;
      }
      this.show = false;
    } else {
      this.mediator.employDate = this.$utils.Common.dateFmt(
        'yyyy-MM-dd',
        value
      );
      this.show1 = false;
    }
  }

  private onConfirm1(value: string): void {
    this.show2 = false;
    this.mediator.organization[this.selectIndex] = value;
  }

  private handleShow(index: number): void {
    this.activeIndex = index;
    if (this.activeIndex !== 4) {
      if (this.activeIndex === 1) {
        this.columns = this.mediatorLevel;
      } else if (this.activeIndex === 2) {
        this.columns = this.nationList;
      } else if (this.activeIndex === 3) {
        this.columns = this.educationList;
      }
      this.show = true;
    } else {
      this.show1 = true;
    }
  }

  private handleAdd(): void {
    this.mediator.organization.push('请选择');
  }

  private onChange(value: boolean): void {
    if (value) {
      this.$toast('已启用！');
    } else {
      this.$toast('已停用！');
    }
  }

  // 展示机构选择
  private handleSelect(index: number): void {
    this.selectIndex = index;
    this.show2 = true;
  }

  // 处理调委会数组
  private handleOrganization(): void {
    const arr = this.mediator.organization.filter((str: string) => {
      if (str !== '请选择') {
        return str;
      }
    });
    this.mediator.organization = arr as string[];
  }

  private onSubmit(): void {
    this.handleOrganization();
    console.log(this.mediator);
  }
}
</script>

<style lang='less' scoped>
.mediator-updata {
  &-content {
    margin-top: 30px;
    .head {
      padding: 20px 30px;
      background-color: #ffffff;
      display: flex;
      justify-content: space-between;
      align-items: center;

      .content {
        margin-right: auto;
        margin-left: 40px;
        .name {
          font-size: 32px;
        }

        .other {
          font-size: 28px;
          color: #999999;
        }
      }

      .toggel-box {
        display: flex;
        flex-direction: column;
        font-size: 28px;
        color: #999999;
      }
    }

    .tips {
      font-size: 28px;
      color: #1567fe;
      padding: 20px;
      text-align: right;
    }
  }

  .feild {
    position: relative;
    padding: 20px 30px;
    background-color: #ffffff;

    &-content {
      display: flex;
      align-items: center;

      &-label {
        width: 260px;
        height: 100%;
        font-size: 28px;
        display: flex;
        align-items: center;
      }

      &-input {
        flex: 1;
        display: flex;
        align-items: center;

        .icon-box {
          width: 40px;
          height: 40px;
          font-size: 40px;
          padding-left: 10px;
        }

        .btn {
          width: 62px;
          height: 40px;
          color: #ffffff;
          font-size: 24px;
          text-align: center;
          line-height: 40px;
          background-color: #2b65e1;
          border-radius: 6px;
          margin-left: 10px;
        }

        input {
          flex: 1;
          border: none;
          font-size: 32px;
          color: #666666;
        }

        input::placeholder {
          text-align: right;
          font-size: 28px;
        }
      }
    }

    &:not(:last-child)::after {
      position: absolute;
      box-sizing: border-box;
      content: " ";
      pointer-events: none;
      right: 0;
      bottom: 0;
      left: 0.42667rem;
      border-bottom: 1px solid #ebedf0;
      -webkit-transform: scaleY(0.5);
      transform: scaleY(0.5);
    }
  }

  .check-box {
    position: relative;
    padding: 20px 30px;
    display: flex;
    justify-content: space-between;
    span {
      font-size: 28px;
      max-width: 270px;
    }

    &:not(:last-child)::after {
      position: absolute;
      box-sizing: border-box;
      content: " ";
      pointer-events: none;
      right: 0;
      bottom: 0;
      left: 0.42667rem;
      border-bottom: 1px solid #ebedf0;
      -webkit-transform: scaleY(0.5);
      transform: scaleY(0.5);
    }
  }

  .btn-box {
    padding: 20px 40px 50px 40px;
    background-color: #ffffff;

    .btn {
      width: 100%;
      height: 96px;
      text-align: center;
      line-height: 96px;
      color: #ffffff;
      font-size: 36px;
      background-color: #0a5ffe;
      border-radius: 12px;
    }
  }
}
</style>
