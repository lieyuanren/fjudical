<template>
  <view class="home">
    <view class="home-card">
      <view class="home-head-card-id">
        <view class="line"></view>
        <span class="id">{{item.caseId}}</span>
      </view>
      <view class="home-card-time">申请时间：{{item.time}}</view>
      <view class="home-card-name">处案调委会：{{item.commitee}}</view>
      <view class="home-card-name home-card-bottom" @click="isShow = !isShow">当前处理流程：<span>催办{{item.commitee}}机构</span>
        <van-icon name="arrow-down" v-if="isShow"/>
        <van-icon name="arrow-up" v-if="!isShow"/>
      </view>
      <van-steps v-if="isShow" style="margin-left: 20px;margin-right: 30px;padding-bottom: 20px" direction="vertical"
                 :active="0"
                 active-color="#0A5FFE">
        <van-step>
          <p>催办凤凰街人民调解委员会机构</p>
        </van-step>
        <van-step>
          <p>呈报上级处理</p>
          <p style="font-size: 9px">(何小法)</p>
        </van-step>
        <van-step>
          <p>指派至XX调委会</p>
          <p style="font-size: 9px">(何小法)</p>
        </van-step>
        <van-step>
          <p>已接单</p>
        </van-step>
      </van-steps>
    </view>
  </view>
</template>

<script lang='ts'>
import {Component, Vue} from 'vue-property-decorator';
import CaseCard from '@/components/modules/mediation/home/v-case-card/index.vue';
import CaseCardType from '@/model/modules/mediation/home/CaseCardType';
import HeadCard from '@/components/modules/mediation/home/v-head-card/index.vue';
import HeadCardType from '@/model/modules/mediation/home/HeadCardType';

@Component({
  components: {CaseCard, HeadCard}
})
export default class Track extends Vue {
  // @ts-ignore
  private item: CaseCardType;
  // @ts-ignore
  private isShow: boolean = false;

  public created (): void {
    // @ts-ignore
    const query = this.$route.query as any;
    this.item = query.item;
  }

  /**
   * 请求数据
   */

  private async getData (): Promise<void> {
    // TODO
    // 获取数据
    console.log(this.item);
  }

}
</script>

<style lang='less' scoped>


[class*=van-hairline]::after {
  border: none;
}

p {
  font-size: 25px;
}

.line {
  margin-left: 30px;
  width: 8px;
  height: 28px;
  background-color: #0a5ffe;
  border-radius: 4px;
  display: inline-block;
}

.home {
  height: 100%;
  background: #f2f2f2;

  &-head {
    height: 132px;
    display: flex;
    align-items: center;
    background: white;
  }

  .search {
    width: 100%;
    background: white;
  }

  &-card {
    background: white;
    box-shadow: 0 4px 21px 0 rgba(221, 221, 221, 0.48);
    padding-top: 25px;

    &-id {
      padding-left: 30px;
      padding-top: 30px;
      font-weight: bold;

    }

    .id {
      font-size: 32px;
      margin-right: auto;
      margin-left: 20px;
    }

    &-time {
      font-size: 25px;
      color: #666666;
      padding-left: 30px;
      padding-top: 5px;
    }

    &-name {
      font-size: 25px;
      color: #666666;
      padding-left: 30px;
      padding-top: 5px;

      i {
        vertical-align: middle;
      }

      span {
        color: #0A5FFE;
        margin-right: 5px
      }
    }

    &-bottom {
      padding-bottom: 30px;
    }
  }
}
</style>
