<template>
  <div class="home">
    <div class="home-head">
      <div class="search">
        <van-search v-model="search" placeholder="输入案件编号或处案调委会进行搜索"/>
      </div>
    </div>
    <van-list
      v-model="loading"
      :finished="finished"
      finished-text="没有更多了"
      @load="onLoad"
    >
      <div class="home-card" v-for="(item,index) in caseList2" :key="index" @click="toDetail(item)">
        <div class="home-head-card-id">
          <div class="line"></div>
          <span class="id">{{item.caseId}}</span>
        </div>
        <div class="home-card-time">申请时间：{{item.time}}</div>
        <div class="home-card-name">处案调委会：{{item.commitee}}</div>
        <div class="warn" v-if="item.type === 1">
          <div><img src="../../../../assets/images/modules/mediation/light.png"></div>
          <div>{{item.desc}}</div>
        </div>
        <div class="had" v-else>
          {{ item.desc }}
        </div>
      </div>
    </van-list>

  </div>
</template>

<script lang='ts'>
import {Component, Vue} from 'vue-property-decorator';
import CaseCard from '@/components/modules/mediation/home/v-case-card/index.vue';
import CaseCardType from '@/model/modules/mediation/home/CaseCardType';
import HeadCard from '@/components/modules/mediation/home/v-head-card/index.vue';
import HeadCardType from '@/model/modules/mediation/home/HeadCardType';

@Component({
  components: {CaseCard, HeadCard}
})
export default class Home extends Vue {
  private caseList2: CaseCardType[] = [];
  private search: string = '';
  private loading: boolean = false;
  private finished: boolean = false;
  private currentPage: number = 1;
  private pageSize: number = 10;
  private timeLimit: any = null;

  public created (): void {
    this.getData(this.search);
  }

  /**
   * 上拉刷新
   */
  private onLoad () {
    clearTimeout(this.timeLimit);
    this.timeLimit = setTimeout(() => {
      this.currentPage++;
      this.getData(this.search);
    }, 1500);
  }

  private toDetail (item: any) {
    // @ts-ignore
    this.$router.push({
      path: 'trackDetail',
      query: {item}
    });
  }

  /**
   * 请求数据
   */

  private async getData (search: string): Promise<void> {
    this.caseList2.push(...[
      {
        caseId: '44011104000020180001',
        time: '2019-11-01',
        commitee: '凤凰街人民调解委员会',
        type: 1,
        desc: '已催办24小时'
      },
      {
        caseId: '44011104000020180002',
        time: '2019-11-01',
        commitee: '凤凰街人民调解委员会',
        type: 1,
        desc: '已催办24小时'
      },
      {
        caseId: '44011104000020180003',
        time: '2019-11-01',
        commitee: '凤凰街人民调解委员会',
        type: 1,
        desc: '已催办24小时'
      },
      {
        caseId: '44011104000020180004',
        time: '2019-11-01',
        commitee: '凤凰街人民调解委员会',
        type: 2,
        desc: '已接单'
      },
      {
        caseId: '44011104000020180005',
        time: '2019-11-01',
        commitee: '凤凰街人民调解委员会',
        type: 1,
        desc: '已催办24小时'
      }
    ]);
    this.loading = false;
    if (this.caseList2.length > 30) {
      this.finished = true;
    }
  }

}
</script>

<style lang='less' scoped>
.line {
  margin-left: 30px;
  width: 8px;
  height: 28px;
  background-color: #0a5ffe;
  border-radius: 4px;
  display: inline-block;
}

.had {
  position: relative;
  margin-left: 600px;
  margin-top: -130px;
  color: #00B67D;
  height: 36px;
  width: 83px;
  border-radius: 2px;
  border: 1px solid #00B67D;
  text-align: center;
  font-size: 20px;
  line-height: 36px;
}

.warn {
  position: relative;
  margin-left: 580px;
  margin-top: -120px;

  img {
    height: 50px;
    width: 50px;
    margin-left: 40px;
  }

  div {
    color: #F5675D;
    font-size: 20px;
    width: 150px;
  }
}

.home {
  height: 100%;
  background: #f2f2f2;

  &-head {
    height: 132px;
    display: flex;
    align-items: center;
    background: white;
  }

  .search {
    width: 100%;
    background: white;
  }

  &-card {
    height: 165px;
    background: white;
    box-shadow: 0 4px 21px 0 rgba(221, 221, 221, 0.48);
    margin-top: 20px;
    padding-top: 25px;

    &-id {
      padding-left: 30px;
      padding-top: 30px;
      font-weight: bold;

    }

    .id {
      font-size: 32px;
      margin-right: auto;
      margin-left: 20px;
    }

    &-time {
      font-size: 25px;
      color: #666666;
      padding-left: 30px;
      padding-top: 5px;
    }

    &-name {
      font-size: 25px;
      color: #666666;
      padding-left: 30px;
      padding-top: 5px;
    }
  }
}
</style>
