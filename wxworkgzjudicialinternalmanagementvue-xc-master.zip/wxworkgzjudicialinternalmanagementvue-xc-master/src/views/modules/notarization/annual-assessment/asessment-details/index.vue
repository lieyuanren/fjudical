<template>
  <div class="assessment-details"
       v-if="myShow">
    <div class="assessment-head">
      <div class="row"
           v-if="paramter">
        <div @click="switchShow"
             class="timer-select">
          <span class="label">{{ sureTimer }}</span>
          <van-icon name="arrow-down" />
        </div>
        <div class="search-box">
          <van-search @input="handleSearch"
                      background="#f2f2f2"
                      placeholder="搜索负责人名称"
                      v-model="searchString"></van-search>
        </div>
      </div>
      <van-dropdown-menu>
        <van-dropdown-item :options="organization"
                           @change="conditionSearch"
                           v-model="mechanismIndex" />
        <van-dropdown-item :options="option2"
                           @change="conditionSearch"
                           v-model="scoreIndex" />
        <van-dropdown-item :options="option3"
                           @change="conditionSearch"
                           v-model="stateIndex" />
      </van-dropdown-menu>
    </div>
    <div class="assessment-content">
      <van-pull-refresh @refresh="onRefresh"
                        v-model="refreshing">
        <van-list :finished="finished"
                  :finished-text="finishedText"
                  @load="assessList"
                  v-model="loading">
          <AssessmentCard :item="item"
                          :key="index"
                          v-for="(item, index) in assessmentList" />
        </van-list>
      </van-pull-refresh>
      <nodata v-if="assessmentList.length === 0"></nodata>
    </div>
    <van-popup @click-overlay="switchShow"
               position="bottom"
               v-model="show">
      <van-picker :columns="columns"
                  @cancel="show = false"
                  @change="onChange"
                  @confirm="onConfirm"
                  show-toolbar />
    </van-popup>
  </div>
</template>

<script lang="ts">
// mocks
const mocks = {
  // 人员数据
  personnel: [
    {
      pName: '陈春丽',
      mName: '广州公证处',
      timer: '2019-01-12 12:00',
      state: 1,
      score: 1
    },
    {
      pName: '何雷',
      mName: '苏州公证处',
      timer: '2019-01-12 12:00',
      state: 2,
      score: 2
    }
  ],
  // 机构数据
  mechanism: [
    {
      mName: '广州公证处',
      timer: '2019-01-12 12:00',
      state: 1,
      score: 1
    },
    {
      mName: '苏州公证处',
      timer: '2019-01-12 12:00',
      state: 2,
      score: 2
    }
  ]
};

// @ts-ignore
import AssessmentCard from '@/components/modules/notarization/annual-assessment/v-assessment-card';
// @ts-ignore
import AssessmentData from '@/model/modules/notarization/annual-assessment/Assessment';
// @ts-ignore
import AssessParam from '@/model/modules/notarization/annual-assessment/assessParam';
// @ts-ignore
import Common from '@/utils/common/common';
// @ts-ignore
import PageParam from '@/model/modules/notarization/pageParam';
// @ts-ignore
import Nodata from '@/components/common/v-nodata';
import { Component, Vue } from 'vue-property-decorator';

@Component({
  components: {
    AssessmentCard,
    Nodata
  }
})
// 年度考核详情路由（公证员考核，机构负责人）共用
export default class AssessmentDetails extends Vue {
  public show: boolean = false;
  public myShow: boolean = false;
  // 时间选择
  public columns: string[] = [];
  // 评估数据列表
  public assessmentList: AssessmentData[] = [];

  // 临时值
  public curTimer: string = this.columns[0];
  // 确认值
  public sureTimer: string = this.columns[0];
  // 搜索值：双绑
  public searchString: string = '';
  // 搜索值：真实查询值
  public sureSearch: string = '';
  // 机构索引
  public mechanismIndex: string = '全部';
  // 评分索引
  public scoreIndex: string = '全部';
  // 状态索引
  public stateIndex: string = '全部';
  // 节流定时器
  public timerLimit: any = null;
  public loading: boolean = false;
  public refreshing: boolean = false;
  public finished: boolean = false;
  public finishedText: string = '没有更多了';
  // 分页
  private pageParam: PageParam = {
    currentPage: 0,
    pageSize: 10
  };
  private organization: any[] = [{ text: '所有机构', value: '全部' }];
  private option2: any[] = [
    { text: '评分', value: '全部' },
    { text: '无评分', value: 'none' },
    { text: '优秀', value: '优秀' },
    { text: '合格', value: '合格' },
    { text: '不合格', value: '不合格' }
  ];
  private option3: any[] = [
    { text: '状态', value: '全部' },
    { text: '已评', value: '已评' },
    { text: '待评', value: '待评' }
  ];

  // 根据不同评估类型发送请求->评估数据列表
  public created(): void {
    this.$nextTick(function() {
      this.myShow = true;
      this.assessmentList = [];
      this.pageParam.currentPage = 0;
      this.loadDate();
      this.loadData();
      console.log(2, '2');
      this.notarizationList();
      this.refreshing = false;
      this.finished = false;
      this.loading = true;
    });
  }
  public activated(): void {
    console.log('activated');
    this.myShow = true;
    this.assessmentList = [];
    this.pageParam.currentPage = 0;
    this.loadDate();
    this.loadData();
    // this.assessList();
    this.refreshing = false;
    this.finished = false;
    this.loading = true;
  }
  get paramter(): boolean {
    return this.$route.query.type !== 'JG';
  }
  /**
   * 获取年份
   */
  public loadDate(): void {
    const date = new Date();
    const year = date.getFullYear();
    const dates: string[] = [];
    dates.push('全部');
    for (let i = 0; i < 10; i++) {
      dates.push(`${year - i}`);
    }
    this.columns = dates;
    this.sureTimer = this.columns[0];
    this.curTimer = this.columns[0];
  }

  // 切换显示
  public switchShow(): void {
    this.show = !this.show;
  }

  // 确定选择，并赋值
  public onConfirm(): void {
    this.show = !this.show;
    // 存放在临时值
    this.sureTimer = this.curTimer;
    this.loadData();
  }

  public onChange(picker: any, value: any): void {
    this.curTimer = value;
    this.conditionSearch();
  }

  /**
   * 精准查询：
   * 1.后期根据后端接口可能要改变
   * 2.定时器保证节流
   */
  public handleSearch(): void {
    clearTimeout(this.timerLimit);
    this.timerLimit = setTimeout(() => {
      this.sureSearch = this.searchString;
      this.conditionSearch();
    }, 1000);
  }

  /**
   * 机构列表
   */
  public async notarizationList(): Promise<void> {
    const pageDTO: PageParam = {
      currentPage: 0,
      pageSize: 20
    };
    const res = await this.$api.xHttp.post(
      this.$interface.notarization.organization.list,
      { ...pageDTO },
      null
    );
    if (res.code === 0) {
      const list = res.data.list.map((it: any) => ({
        text: it.name,
        value: it.code
      }));
      const defaultList: any[] = [{ text: '所有机构', value: '全部' }];
      this.organization = defaultList.concat(list);
    }
  }

  /**
   * 考核列表
   */
  public async assessList(): Promise<void> {
    this.pageParam.currentPage++;
    const param: AssessParam = {
      assessYear: this.curTimer === '全部' ? '' : this.curTimer,
      belongOrganCode: this.mechanismIndex === '全部' ? '' : this.mechanismIndex,
      grade: this.scoreIndex === '全部' ? '' : this.scoreIndex,
      name: this.sureSearch,
      state: this.stateIndex === '全部' ? '' : this.stateIndex,
      type: this.$route.query.type
    };
    // 请求接口
    const res = await this.$api.xHttp.post(
      this.$interface.notarization.annualAssessment.list,
      {
        ...param,
        ...this.pageParam
      },
      null
    );
    if (res.code === 0) {
      res.data.list.forEach((it: any) => {
        it.assessTime = Common.dateFmt(
          'yyyy-MM-dd hh:mm',
          new Date(it.assessTime)
        );
      });
      this.assessmentList = this.assessmentList.concat(res.data.list);
    }
    this.loading = false;
    this.finished = res.data.pageNum >= res.data.pages;
    this.finishedText = this.assessmentList.length > 0 ? '没有更多了' : '';
  }

  public loadData(): void {
    this.assessList();
  }

  /**
   * 下拉刷新
   */
  public async onRefresh(): Promise<void> {
    this.pageParam.currentPage = 0;
    this.assessmentList = [];
    this.loadData();
    this.refreshing = false;
    this.finished = false;
    this.loading = true;
  }

  /**
   * 条件查询
   */
  public async conditionSearch(): Promise<void> {
    this.pageParam.currentPage = 0;
    this.assessmentList = [];
    this.loading = true;
    this.loadData();
  }
}
</script>

<style lang="less" scoped>
.assessment-details {
  .assessment-head {
    padding: 0 30px;
    overflow: hidden;
    background-color: rgb(255, 255, 255);

    .row {
      display: flex;
      border: 0;
      line-height: 72px;
      height: 72px;
      margin-top: 30px;

      .timer-select {
        width: 156px;
        text-align: center;
        font-size: 28px;
        height: 100%;
        background-color: #f2f2f2;

        i {
          vertical-align: middle;
        }

        .label {
          color: #333333;
          padding-right: 8px;
          vertical-align: middle;
        }
      }

      .search-box {
        display: flex;
        flex: 1;
        background-color: #f2f2f2;
      }
    }
  }

  // 重置vant组件样式
  .van-search__content {
    background-color: #f2f2f2;
  }

  .van-cell {
    padding: 0;
    box-sizing: border-box;
  }

  .van-search {
    width: 100%;
    padding: 0;
  }

  [class*="van-hairline"]::after {
    border: none;
  }
}

.UpIn-enter,
.UpIn-leave-to {
  opacity: 0;
  transform: translate3d(0, 60px, 0);
}

.UpIn-enter-active,
.UpIn-leave-active {
  transition: all 0.3s;
}
</style>
