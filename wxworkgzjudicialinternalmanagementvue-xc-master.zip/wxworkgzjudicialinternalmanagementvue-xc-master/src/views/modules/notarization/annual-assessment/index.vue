<template>
  <div class="record box">
    <menu-list :item="item" :key="index" v-for="(item, index) in menuList"></menu-list>
  </div>
</template>

<script lang="ts">
// @ts-ignore
import MenuList from '@/components/common/v-menu-list';
// @ts-ignore
import { Component, Vue } from 'vue-property-decorator';
// @ts-ignore
import MenuData from '@/model/modules/notarization/integrityRecord/MenuData';

@Component({
  components: { MenuList }
})
// 年度考核
export default class AnnualAssessment extends Vue {
  // 档案菜单
  public menuList: MenuData[] = [
    {
      name: '机构考核',
      // @ts-ignore
      icon: require('@/assets/images/modules/notarization/index/record-organ.png'),
      toUrl: 'assessmentDetails',
      type: 'JG'
    },
    {
      name: '公证员考核',
      // @ts-ignore
      icon: require('@/assets/images/modules/notarization/index/gz.png'),
      toUrl: 'assessmentDetails',
      type: 'GZY'
    },
    {
      name: '机构负责人考核',
      // @ts-ignore
      icon: require('@/assets/images/modules/notarization/index/record-person.png'),
      toUrl: 'assessmentDetails',
      type: 'JGFZR'
    }
  ];
}
</script>
