<template>
  <div class="authentic-details">
    <!--基本信息-->
    <detail-info :columns="columns" :detail="detail"></detail-info>
    <DetailsList :itemList="testimonyList" title="证词"/>
    <DetailsList :content="content" title="笔录"/>
  </div>
</template>

<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';
// @ts-ignore
import DetailsList from '@/components/modules/notarization/authentic-act/v-details-list';
// @ts-ignore
import DetailInfo from '@/components/modules/notarization/integrity-record/v-detail-info';
// @ts-ignore
// @ts-ignore
import Detail from '@/model/global/DetailInfo';
// @ts-ignore
import DolumnInfo from '@/model/global/DolumnInfo';
// @ts-ignore
import Common from '@/utils/common/common';

// 公证查询路由
@Component({
  components: { DetailInfo, DetailsList }
})
export default class AuthenticActDetails extends Vue {
  public detail: Detail = {};
  public columns: DolumnInfo[] = [];

  public testimonyList: any[] = [];

  public content: string = '';

  // 拿取仓库数据,筛选出组件需要的数据
  public activated(): void {
    // 根据对应ID查找
    const id = this.$route.query.id;
    this.loadAuthenticAct();
  }

  /**
   * 公证书详情
   */
  public async loadAuthenticAct(): Promise<void> {
    // 请求接口
    const res = await this.$api.xHttp.get(this.$interface.notarization.authenticAct.findByCode, { code: this.$route.query.id }, null);
    if (res.code === 0) {
      this.detail = {
        title: res.data.organization,
        // @ts-ignore
        imgUrl: require('@/assets/images/modules/notarization/index/institution-head.png')
      };
      this.columns = [
        { label: '卷宗号', value: res.data.fileNo },
        { label: '使用地', value: res.data.useTo },
        { label: '公证用途', value: res.data.authenticUse },
        { label: '公证事项', value: res.data.matter }
      ];
      this.testimonyList = [
        { label: '公证书编号', value: res.data.authenticActCode },
        { label: '公证员', value: res.data.notary },
        {
          label: '审批时间',
          value: res.data.approvalTime ? Common.dateFmt('yyyy-MM-dd hh:mm', new Date(res.data.approvalTime)) : ''
        },
        {
          label: '正文内容',
          value: res.data.content
        }
      ];
      this.content = res.data.takeDown;
    }
  }
}
</script>