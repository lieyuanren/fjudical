<template>
  <div class="authentic-list">
    <van-pull-refresh @refresh="onRefresh" v-model="refreshing">
      <van-list
        :finished="finished"
        :finished-text="finishedText"
        @load="authenticActList"
        v-model="loading"
      >
        <AuthenticCard :item="item" :key="item.dossierId" v-for="item in authenticActData"/>
      </van-list>
    </van-pull-refresh>
    <nodata v-if="authenticActData.length === 0"></nodata>
  </div>
</template>


<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';
// @ts-ignore
import AuthenticCard from '@/components/modules/notarization/authentic-act/v-authentic-card';
// @ts-ignore
import AuthenticData from '@/model/modules/notarization/AuthenticAct/AuthenticData';
// @ts-ignore
import Nodata from '@/components/common/v-nodata';
import Common from '@/utils/common/common';
import PageParam from '@/model/modules/notarization/pageParam';

// 公证书详情
@Component({
  components: {
    AuthenticCard,
    Nodata
  }
})
export default class AuthenticActList extends Vue {
  public loading: boolean = false;
  public refreshing: boolean = false;
  public finished: boolean = false;
  public finishedText: string = '没有更多了';
  // 分页
  private pageParam: PageParam = {
    currentPage: 1,
    pageSize: 10
  };

  private authenticActData: AuthenticData[] = [];

  /**
   * 公证书列表
   */
  public async authenticActList(): Promise<void> {
    const param: any = {
      authenticActCode: this.$route.query.authenticActCode,
      organizationCode: this.$route.query.organizationCode,
      applicant: this.$route.query.applicant,
      idCard: this.$route.query.idCard
    };
    // 请求接口
    const res = await this.$api.xHttp.post(
      this.$interface.notarization.authenticAct.list,
      {
        ...param,
        ...this.pageParam
      },
      null
    );
    if (res.code === 0) {
      const list = res.data.list.map((it: any) => ({
        organizationName: it.organization,
        dossierId: it.fileNo,
        notarizationCode: it.authenticActCode,
        notarizationPurpose: it.authenticUse,
        notarizationMatter: it.matter,
        place: it.useTo,
        notary: it.notary,
        state: it.status,
        settlingTime: Common.dateFmt(
          'yyyy-MM-dd hh:mm',
          new Date(it.inscribeTime)
        )
      }));
      this.authenticActData = this.authenticActData.concat(list);
    }
    this.loading = false;
    this.finished = res.data.pageNum >= res.data.pages;
    this.pageParam.currentPage += 1;
    this.finishedText = this.authenticActData.length > 0 ? '没有更多了' : '';
  }

  /**
   * 下拉刷新
   */
  public async onRefresh(): Promise<void> {
    this.pageParam.currentPage = 1;
    this.authenticActData = [];
    this.authenticActList();
    this.refreshing = false;
    this.finished = false;
    this.loading = true;
  }
}
</script>
