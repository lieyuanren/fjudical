<template>
  <div class="authentic-act">
    <div class="search-panel">
      <van-cell-group :border="false">
        <div class="van-cell van-cell--borderless van-field"
             style="overflow:inherit;">
          <div class="van-cell__title van-field__label">
            <span>公证处</span>
          </div>
          <div class="van-cell__value"
               style="overflow:inherit;">
            <div class="van-field__body">
              <div @click="switchShow"
                   class="show-btn">
                <span>{{ searchParam.notarialOffice }}</span>
                <van-icon name="arrow-down" />
              </div>
            </div>
          </div>
        </div>
        <van-field class="authentic-field"
                   :clearable="true"
                   label="当事人"
                   placeholder="请输入"
                   v-model.trim="searchParam.party" />
        <van-field :clearable="true"
                   label="公证编号"
                   placeholder="请输入"
                   v-model.trim="searchParam.notarizationId" />
        <van-field :clearable="true"
                   class="border-class"
                   label="证件号码"
                   placeholder="请输入"
                   v-model.trim="searchParam.certificatesId" />
        <van-divider  dashed v-show="false"></van-divider>
      </van-cell-group>
      <div class="btn-box">
        <van-button @click="search"
                    block
                    type="info">查找</van-button>
      </div>
      <van-popup @click-overlay="switchShow"
                 position="bottom"
                 v-model="show">
        <van-picker :columns="columns"
                    @cancel="show = false"
                    @change="onChange"
                    @confirm="onConfirm"
                    show-toolbar />
      </van-popup>
    </div>
  </div>
</template>

<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';
// @ts-ignore
import SearchParam from '@/model/modules/notarization/AuthenticAct/SearchParam';
import PageParam from '@/model/modules/notarization/pageParam';

@Component
// 公证书查询
export default class AuthenticAct extends Vue {
  public show: boolean = false;
  public columns: string[] = [];
  public organization: any[] = [{ text: '所有机构', value: '全部' }];
  public organIndex: number = 0;
  // 查询对象
  public searchParam: SearchParam = {
    notarialOffice: '所有机构',
    party: '',
    notarizationId: '',
    certificatesId: ''
  };

  // 公证处临时值
  public curNotarialOffice: string = '';

  // 切换显示
  public switchShow(): void {
    this.show = !this.show;
  }

  // 切换显示，将临时值赋给查询对象
  public onConfirm(): void {
    this.show = !this.show;
    this.searchParam.notarialOffice = this.curNotarialOffice;
  }

  // 赋值给临时值
  public onChange(picker: any, value: string, index: number): void {
    this.curNotarialOffice = value;
    this.organIndex = index;
  }

  // 查找
  public async search(): Promise<void> {
    if (
      this.searchParam.notarizationId === '' &&
      this.searchParam.party === '' &&
      this.searchParam.certificatesId === ''
    ) {
      this.$toast('请至少满足两项查询条件');
      return;
    }
    /**
     * 发起请求
     *
     * 响应成功：切换路由，数据存仓库
     *
     * 响应失败：提示失败，不切换路由
     *
     */
    const param: any = {
      authenticActCode: this.searchParam.notarizationId,
      organizationCode:
        this.organization[this.organIndex].value !== '全部'
          ? this.organization[this.organIndex].value
          : '',
      applicant: this.searchParam.party,
      idCard: this.searchParam.certificatesId
    };
    // 检查是否有数据 再跳转
    const res = await this.$api.xHttp.post(
      this.$interface.notarization.authenticAct.count,
      param,
      null
    );
    if (res.data > 0) {
      await this.$router.push({
        path: '/authenticActList',
        query: param
      });
    } else {
      this.$toast('暂无数据');
    }
  }

  public created(): void {
    // 机构列表
    this.notarizationList();
  }

  /**
   * 机构列表
   */
  public async notarizationList(): Promise<void> {
    const pageDTO: PageParam = {
      currentPage: 1,
      pageSize: 20
    };
    const res = await this.$api.xHttp.post(
      this.$interface.notarization.organization.list,
      { ...pageDTO },
      null
    );
    if (res.code === 0) {
      const list = res.data.list.map((it: any) => ({
        text: it.name,
        value: it.code
      }));
      const defaultList: any[] = [{ text: '所有机构', value: '全部' }];
      this.organization = defaultList.concat(list);
      this.organization.forEach((it: any) => {
        this.columns.push(it.text);
      });
    }
  }
}
</script>


<style lang="less" scoped>

/deep/ .van-cell:not(:last-child)::after {
  width: 70%;
  margin-left: 150px;
}
/deep/ .van-cell:not(:last-child):before {
  width: 70%;
  margin-left: 150px;
}
.authentic-act {
  padding: 40px 30px;
  .search-panel {
    border-radius: 12px;
    background: rgba(255, 255, 255, 1);
    padding: 30px;

    .btn-box {
      margin-top: 80px;
      margin-bottom: 50px;
      display: flex;
      justify-content: center;
    }
    .show-btn {
      color: #666666;
      span,
      i {
        vertical-align: middle;
      }

      span {
        margin-right: 8px;
      }
    }
  }
}

.van-button {
  font-size: 36px;
  width: 600px;
  height: 98px;
  border-radius: 12px;
}

.authentic-field::before {
  position: absolute;
  box-sizing: border-box;
  content: " ";
  pointer-events: none;
  right: 0;
  top: 0;
  left: 0.42667rem;
  border-bottom: 1px solid #ebedf0;
  -webkit-transform: scaleY(0.5);
  transform: scaleY(0.5);
}
</style>
