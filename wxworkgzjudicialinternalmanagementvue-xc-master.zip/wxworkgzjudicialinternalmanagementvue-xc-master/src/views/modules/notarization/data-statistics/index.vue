<template>
  <div class="data-statistics">
    <div class="data-head">
      <div class="data-top">
        <div class="line"></div>
        <div @click="switchShow(0)"
             class="situation-select">
          <span class="text2">{{ situation }}</span>
          <van-icon name="arrow-down" />
        </div>
        <div class="line"></div>
      </div>
      <div class="data-mid">
        <div @click="switchShow(1)"
             class="condition-select">
          <span class="text2">{{ condition }}</span>
          <van-icon name="arrow-down" />
        </div>
        <div @click="show1 = true"
             class="condition-select">
          <span class="text2">{{ timer }}</span>
          <van-icon name="arrow-down" />
        </div>
      </div>
    </div>
    <p class="unit">(单位：件)</p>
    <component :chargetList="chargetList"
               :contrastList="contrastList"
               :is="componentId[activeIndex]"
               :notariesData="notariesData"
               :notariesList="notariesList"
               :personnelList="personnelList"
               :statisticsList="statisticsList"></component>
    <van-popup @click-overlay="show = false"
               position="bottom"
               v-model="show">
      <van-picker :columns="columns[curIndex]"
                  @cancel="onCancel"
                  @confirm="onConfirm"
                  show-toolbar />
    </van-popup>
    <van-popup @click-overlay="show1 = false"
               position="bottom"
               v-model="show1">
      <van-datetime-picker :formatter="formatter"
                           @cancel="onCancel1"
                           @confirm="onConfirm1"
                           type="year-month"
                           v-model="currentDate" />
    </van-popup>
  </div>
</template>

<script lang="ts">
// @ts-ignore
import ChargePanel from '@/components/modules/notarization/data-statistics/v-charge-panel';
// @ts-ignore
import ContrastPanel from '@/components/modules/notarization/data-statistics/v-contrast-panel';
// @ts-ignore
import MainPanel from '@/components/modules/notarization/data-statistics/v-main-panel';
// @ts-ignore
import NotariesAllShow from '@/components/modules/notarization/data-statistics/v-notaries-all-show';
// @ts-ignore
import NotaryPanel from '@/components/modules/notarization/data-statistics/v-notary-panel';
// @ts-ignore
import PersonnelPanel from '@/components/modules/notarization/data-statistics/v-personnel-panel';
// @ts-ignore
import PersonnelCardData from '@/model/modules/notarization/data-statistics/PersonnelCardData.ts';
// @ts-ignore
import Charge from '@/model/modules/notarization/home/Charge';
// @ts-ignore
import StatisticsData from '@/model/modules/notarization/data-statistics/StatisticsData.ts';
// @ts-ignore
import NotariesModel from '@/model/modules/notarization/home/Notaries';
import { Component, Vue, Watch } from 'vue-property-decorator';

@Component({
  components: {
    MainPanel,
    PersonnelPanel,
    NotariesAllShow,
    ContrastPanel,
    ChargePanel,
    NotaryPanel
  }
})
export default class DataStatistics extends Vue {
  // 参数一
  public situation: string = '主要公证事项';
  // 参数二
  public condition: string = '全市';
  // 参数三
  public timer: string = `${new Date().getFullYear()}年${new Date().getMonth()}月`;

  // 主要公证事项数据
  public statisticsList: StatisticsData[] = [];
  // 人员整体情况
  public personnelList: PersonnelCardData[] = [];
  // 公证一览
  public notariesList: PersonnelCardData[] = [];
  // 今年与去年对比
  public contrastList: PersonnelCardData[] = [];
  // 公证收费情况
  public chargetList: Charge[] = [];
  // 公证员情况
  public notariesData: NotariesModel = {
    title: '加载中……',
    inEditing: 0,
    nonEditing: 0,
    subtotal: 0,
    viewData: []
  };

  public currentDate: Date = new Date();
  public show: boolean = false;
  public show1: boolean = false;
  public componentId: string[] = [
    'MainPanel',
    'PersonnelPanel',
    'NotariesAllShow',
    'ContrastPanel',
    'ChargePanel',
    'NotaryPanel'
  ];
  public curIndex: number = 0;
  public activeIndex: number = 0;
  public columns: any = [
    [
      '公证情况一览',
      '今年与去年同期对照',
      '公证收费情况',
      '主要公证事项',
      '公证员情况',
      '人员整体情况'
    ],
    ['全市', '广州公证处', '海珠公证处', '南沙公证处']
  ];
  // 所有机构信息
  public organization: any[];
  // 机构编码
  public orgCode: string;

  @Watch('situation')
  public onSituation(newVal: string, oldVal: string): void {
    this.changeComponent();
  }

  @Watch('condition')
  public onCondition(newVal: string, oldVal: string): void {
    this.changeComponent();
  }

  @Watch('timer')
  public onTimer(newVal: string, oldVal: string): void {
    this.changeComponent();
  }

  public async created(): Promise<void> {
    this.columns[1] = await this.getOrganization();
    this.search();
  }

  /**
   * 获取公证机构
   */
  public async getOrganization() {
    const res = await this.$api.xHttp.get(
      this.$interface.notarization.organization.allList,
      null,
      null
    );
    if (res.code === 0) {
      let arr = [];
      arr.push('全市');
      this.organization = res.data;
      for (let item of res.data) {
        if (item.name !== '广州市司法局公法处') {
          arr.push(item.name);
        }
      }
      return arr;
    } else {
      this.$toast(res.msg);
    }
  }

  /**
   * 数据请求
   */
  public async search(): Promise<void> {
    const resData = await this.send(
      this.$interface.notarization.dataStatistics.majorCase
    );
    this.majorCaseHandler(resData);
  }

  // 根据当前搜索条件 判断渲染什么组件
  public async changeComponent(): Promise<void> {
    // 展示组件的切换
    if (this.situation === '主要公证事项') {
      this.activeIndex = 0;
      const resData = await this.send(
        this.$interface.notarization.dataStatistics.majorCase
      );
      this.majorCaseHandler(resData);
    } else if (this.situation === '人员整体情况') {
      this.activeIndex = 1;
      const resData = await this.send(
        this.$interface.notarization.dataStatistics.personCase
      );
      this.personCaseHandler(resData);
    } else if (this.situation === '公证情况一览') {
      this.activeIndex = 2;
      const resData = await this.send(
        this.$interface.notarization.dataStatistics.caseView
      );
      this.notariesList = this.caseViewHandler(resData);
    } else if (this.situation === '今年与去年同期对照') {
      this.activeIndex = 3;
      const resData = await this.send(
        this.$interface.notarization.dataStatistics.caseContrast
      );
      this.contrastList = this.caseContrastHandler(resData);
    } else if (this.situation === '公证收费情况') {
      this.activeIndex = 4;
      const resData = await this.send(
        this.$interface.notarization.dataStatistics.charge
      );
      this.chargetList = this.chargeHandler(resData);
    } else if (this.situation === '公证员情况') {
      this.activeIndex = 5;
      const resData = await this.send(
        this.$interface.notarization.dataStatistics.notaryCase
      );
      this.notaryCaseHandler(resData);
    }
  }

  public async send(url: string) {
    const time = this.timerHandler();
    const param = {
      month: this.situation === '主要公证事项' ? time.substring(0, 4) : time,
      orgCode: this.orgCode
    };
    const res = await this.$api.xHttp.post(url, param);
    if (res.code === 0) {
      return res.data;
    } else {
      this.$toast(res.msg);
    }
  }

  public switchShow(index: number): void {
    this.curIndex = index;
    this.show = true;
  }

  public onCancel(): void {
    this.show = false;
  }

  public onConfirm(value: string, index: number): void {
    this.show = false;
    if (!this.curIndex) {
      this.situation = value;
    } else {
      this.condition = value;
      if (value !== '全市') {
        this.orgCode = this.organization[index].code;
      } else {
        this.orgCode = '';
      }
    }
  }

  public onCancel1(): void {
    this.show1 = false;
  }

  public onConfirm1(value: Date): void {
    this.show1 = false;
    this.timer = `${value.getFullYear()}年${value.getMonth() + 1}月`;
  }

  public formatter(type: any, value: any): string {
    if (type === 'year') {
      return `${value}年`;
    } else if (type === 'month') {
      return `${value}月`;
    }
    return value;
  }

  public timerHandler(): string {
    let timer = this.timer.split('年');
    let month = timer[1].split('月');
    if (month[0].length < 2) {
      return timer[0] + ('0' + month[0]);
    } else {
      return this.timer.replace('年', '').replace('月', '');
    }
  }

  /**
   * 公证情况一览数据填充
   * @param data
   */
  public caseViewHandler(data: string): PersonnelCardData[] {
    const arr = data.split(',');
    console.log(data);
    const dataList4: PersonnelCardData[] = [
      {
        title: '办证总数',
        paramData: [
          { label: '当月', value: arr[1] },
          { label: '累计', value: arr[3] },
          { label: '占比', value: arr[2] },
          { label: '占比', value: arr[4] }
        ]
      },
      {
        title: '国内民事公证',
        paramData: [
          { label: '当月', value: arr[5] },
          { label: '累计', value: arr[7] },
          { label: '占比', value: arr[6] },
          { label: '占比', value: arr[8] }
        ]
      },
      {
        title: '国内经济公证',
        paramData: [
          { label: '当月', value: arr[9] },
          { label: '累计', value: arr[11] },
          { label: '占比', value: arr[10] },
          { label: '占比', value: arr[12] }
        ]
      },
      {
        title: '涉外民事公证',
        paramData: [
          { label: '当月', value: arr[13] },
          { label: '累计', value: arr[15] },
          { label: '占比', value: arr[14] },
          { label: '占比', value: arr[16] }
        ]
      },
      {
        title: '涉外经济公证',
        paramData: [
          { label: '当月', value: arr[17] },
          { label: '累计', value: arr[19] },
          { label: '占比', value: arr[18] },
          { label: '占比', value: arr[20] }
        ]
      }
    ];
    return dataList4;
  }

  /**
   * 今年与去年同期对照数据填充
   * @param data
   */
  public caseContrastHandler(data: string): PersonnelCardData[] {
    const arr = data.split(',');
    const dataList4: PersonnelCardData[] = [
      {
        title: '办证总数',
        paramData: [
          { label: '今年累计', value: arr[1] },
          { label: '去年同期', value: arr[2] },
          { label: '占全市总数', value: arr[3] }
        ]
      },
      {
        title: '国内民事公证',
        paramData: [
          { label: '今年累计', value: arr[4] },
          { label: '去年同期', value: arr[5] },
          { label: '占全市总数', value: arr[6] }
        ]
      },
      {
        title: '国内经济公证',
        paramData: [
          { label: '今年累计', value: arr[7] },
          { label: '去年同期', value: arr[8] },
          { label: '占全市总数', value: arr[9] }
        ]
      },
      {
        title: '涉外民事公证',
        paramData: [
          { label: '今年累计', value: arr[10] },
          { label: '去年同期', value: arr[11] },
          { label: '占全市总数', value: arr[12] }
        ]
      },
      {
        title: '涉外经济公证',
        paramData: [
          { label: '今年累计', value: arr[13] },
          { label: '去年同期', value: arr[14] },
          { label: '占全市总数', value: arr[15] }
        ]
      }
    ];
    return dataList4;
  }

  /**
   * 公证收费情况数据填充
   * @param data
   */
  public chargeHandler(data: string): Charge[] {
    let dataList5: Charge[] = [];
    const arr = data.split(';');
    const cityArr = arr[0].split(',');
    const notarization = arr[1].split(',');
    if (notarization[0] === cityArr[0]) {
      dataList5.push({
        title: '收费总额',
        sameMonth: Number(cityArr[1]),
        annualCumulative: Number(cityArr[2]),
        lastYear: Number(cityArr[3]),
        contrast: cityArr[4]
      });
    } else {
      dataList5 = [
        {
          title: '收费总额',
          sameMonth: Number(notarization[1]),
          annualCumulative: Number(notarization[2]),
          lastYear: Number(notarization[3]),
          contrast: notarization[4]
        },
        {
          title: '全市情况',
          sameMonth: Number(cityArr[1]),
          annualCumulative: Number(cityArr[2]),
          lastYear: Number(cityArr[3]),
          contrast: cityArr[4]
        }
      ];
    }
    return dataList5;
  }

  /**
   * 主要公证事项数据填充
   * @param data
   */
  public majorCaseHandler(data: string) {
    const arr = data.split(';');
    const typeArr = arr[0].split(',');
    const countArr = arr[1].split(',');
    if (this.condition === '全市') {
      const dataList1: StatisticsData[] = [
        { index: 1, typeName: typeArr[1], count: Number(countArr[1]) },
        { index: 2, typeName: typeArr[2], count: Number(countArr[2]) },
        { index: 3, typeName: typeArr[3], count: Number(countArr[3]) },
        { index: 4, typeName: typeArr[4], count: Number(countArr[4]) },
        { index: 5, typeName: typeArr[5], count: Number(countArr[5]) }
      ];
      this.statisticsList = dataList1;
    } else {
      const notarizationCountArr = arr[2].split(',');
      const dataList2: StatisticsData[] = [
        {
          index: 1,
          typeName: typeArr[1],
          count: Number(notarizationCountArr[1]),
          whole: Number(countArr[1])
        },
        {
          index: 2,
          typeName: typeArr[2],
          count: Number(notarizationCountArr[2]),
          whole: Number(countArr[2])
        },
        {
          index: 3,
          typeName: typeArr[3],
          count: Number(notarizationCountArr[3]),
          whole: Number(countArr[3])
        },
        {
          index: 4,
          typeName: typeArr[4],
          count: Number(notarizationCountArr[4]),
          whole: Number(countArr[4])
        },
        {
          index: 5,
          typeName: typeArr[5],
          count: Number(notarizationCountArr[5]),
          whole: Number(countArr[5])
        }
      ];
      this.statisticsList = dataList2;
    }
  }

  /**
   * 公证员情况数据填充
   * @param data
   */
  public notaryCaseHandler(data: any) {
    console.log(data);
    let notaryArr = data.notary.split(',');
    let levelArr = data.notaryLevel.split(',');
    const dataList7: NotariesModel = {
      title: notaryArr[0],
      inEditing: notaryArr[1],
      nonEditing: notaryArr[2],
      subtotal: notaryArr[3],
      viewData: [
        {
          const: 'const',
          type: '一级',
          num: Number(levelArr[1])
        },
        {
          const: 'const',
          type: '二级',
          num: Number(levelArr[2])
        },
        {
          const: 'const',
          type: '三级',
          num: Number(levelArr[3])
        },
        {
          const: 'const',
          type: '四级',
          num: Number(levelArr[4])
        },
        {
          const: 'const',
          type: '未评',
          num: Number(levelArr[5])
        }
      ]
    };
    this.notariesData = dataList7;
  }

  /**
   * 人员总体情况数据填充
   * @param data
   */
  public personCaseHandler(data: any) {
    console.log(data);
    // 编制人员情况
    const notaryPreparedArr = data.notaryPrepared.split(',');
    // 公证人员情况
    const notary = data.notary.split(',');
    // 非公证人员编制情况
    const unNotaryPrepared = data.unNotaryPrepared.split(',');
    // 非公证人员情况
    const unNotary = data.unNotary.split(',');
    const dataList3: PersonnelCardData[] = [
      {
        title: '人员整体情况',
        paramData: [
          { label: '编制数', value: notaryPreparedArr[1] },
          { label: '在编人数', value: notaryPreparedArr[2] },
          { label: '公证员小计', value: notary[1] },
          {
            label: '公证员/在编人数',
            value: Number(notaryPreparedArr[3]).toFixed(0)
          },
          { label: '全市公证员/编制数', value: Number(notary[2]).toFixed(0) },
          { label: '在编公证员/编制数', value: Number(notary[3]).toFixed(0) }
        ]
      },
      {
        title: '非公证员',
        paramData: [
          { label: '在编', value: unNotaryPrepared[1] },
          { label: '非编', value: unNotaryPrepared[2] },
          { label: '行政人员', value: unNotary[1] },
          { label: '公证员助理', value: unNotary[2] },
          { label: '其他人员', value: unNotary[3] }
        ]
      }
    ];
    this.personnelList = dataList3;
  }
}
</script>
<style lang="less" scoped>
.data-statistics {
  .unit {
    color: #666666;
    text-align: right;
    font-size: 24px;
    margin-top: 44px;
    padding: 0 54px;
  }

  .data-head {
    height: 204px;
    background-image: url("../../../../assets/images/modules/notarization/index/data-statistics.png");
    background-position: center center;
    background-repeat: no-repeat;
    background-size: cover;
    overflow: hidden;

    .data-top {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-top: 42px;

      .line {
        width: 170px;
        height: 1px;
        background-color: #7e99c1;
      }

      .situation-select {
        width: 370px;
        height: 60px;
        border: 1px solid rgba(255, 255, 255, 1);
        border-radius: 30px;
        text-align: center;
        line-height: 60px;

        i,
        span {
          vertical-align: middle;
        }
      }
    }

    .data-mid {
      display: flex;
      justify-content: space-between;
      margin-top: 26px;

      .condition-select {
        padding: 0 52px;

        i,
        span {
          vertical-align: middle;
        }
      }
    }
  }

  .text2 {
    color: rgb(255, 255, 255);
    font-weight: 500 !important;
    padding-right: 15px;
  }

  .van-icon {
    color: rgb(255, 255, 255) !important;
    font-size: 32px;
  }
}
</style>
