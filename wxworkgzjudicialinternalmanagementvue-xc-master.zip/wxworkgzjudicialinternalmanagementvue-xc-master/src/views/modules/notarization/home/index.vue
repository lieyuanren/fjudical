<template>
  <div class="home">
    <div class="head-tabs">
      <div
        :class="activeIndex === i?'head-tab tab-active':'head-tab'"
        :key="i"
        @click="setActiveIndex(i)"
        v-for="(text,i) in tabs"
      >{{ text }}
      </div>
    </div>
    <div class="unit">
      <span>时间：{{ lastMonth | changeTime }}</span>
      <span>(单位：{{unit[activeIndex]}})</span>
    </div>
    <!-- 首页的三个模块 -->
    <transition mode="out-in" name="van-pop-in">
      <component
        :chargeData="chargeData"
        :is="componentIds[activeIndex]"
        :notariesData="notariesData"
        :notarizationArr="notarizationArr"
      ></component>
    </transition>
  </div>
</template>

<script lang="ts">
// @ts-ignore
import ChargeSituation from '@/components/modules/notarization/home/v-charge-situation';
// @ts-ignore
import Notaries from '@/components/modules/notarization/home/v-notaries';
// @ts-ignore
import NotarizationDetails from '@/components/modules/notarization/home/v-notarization-details';
// @ts-ignore
import ChargeModel from '@/model/modules/notarization/home/Charge';
// @ts-ignore
import NotariesModel from '@/model/modules/notarization/home/Notaries';
// @ts-ignore
import { Component, Vue } from 'vue-property-decorator';

@Component({
  components: {
    NotarizationDetails,
    Notaries,
    ChargeSituation
  },
  filters: {
    changeTime(value: string) {
      return `${ value.substring(0, 4) }-${ value.substring(4) }`;
    }
  }
})
export default class Home extends Vue {
  // tabs数组
  public tabs: string[] = ['公证情况', '收费情况', '公证员情况'];
  // 当前tab索引
  public activeIndex: number = 0;
  // 单位
  public unit: string[] = ['件', '万元', '人'];
  // 首页三模块组件名
  public componentIds: string[] = [
    'notarizationDetails',
    'chargeSituation',
    'notaries'
  ];
  public number: string[] = ['一', '二', '三', '四', '五'];
  // 公证情况数据
  public notarizationArr: any[] = [];
  // 收费情况数据
  public chargeData: ChargeModel = {
    // 标题
    title: '加载中……',
    // 当月
    sameMonth: 0,
    // 年累计
    annualCumulative: 0,
    // 去年同期
    lastYear: 0,
    // 对比
    contrast: 0
  };
  // 公证员情况数据
  public notariesData: NotariesModel = {
    // 标题
    title: '加载中……',
    // 在编
    inEditing: 0,
    // 非编
    nonEditing: 0,
    // 小计
    subtotal: 0,
    // 环形图数据
    viewData: []
  };

  public lastMonth: string = '';

  // 这里执行三个报表数据请求
  public async created(): Promise<void> {
    this.lastMonth = this.getMonth();
    this.notarizationArr = await this.getNotarization();
    this.chargeData = await this.getCharge();
    this.notariesData = await this.getNotaries();
  }

  // 获取公证情况数据
  public async getNotarization(): Promise<any[]> {
    // 处理请求数据
    const param = {
      month: this.getMonth()
    };
    let notarizationArr: any[] = [];
    const res = await this.$api.xHttp.post(
      this.$interface.notarization.index.caseView,
      param
    );
    if (res.code === 0) {
      const arr = res.data.split(',');
      notarizationArr = [
        {
          notarizationType: '全市办证总数',
          sameMonth: arr[1],
          cumulative: arr[3]
        },
        {
          notarizationType: '国内民事公证',
          sameMonth: arr[5],
          monthProportion: arr[6],
          cumulative: arr[7],
          cumulativeProportion: arr[8]
        },
        {
          notarizationType: '国内经济公证',
          sameMonth: arr[9],
          monthProportion: arr[10],
          cumulative: arr[11],
          cumulativeProportion: arr[12]
        },
        {
          notarizationType: '涉外民事公证',
          sameMonth: arr[13],
          monthProportion: arr[14],
          cumulative: arr[15],
          cumulativeProportion: arr[16]
        },
        {
          notarizationType: '涉外经济公证',
          sameMonth: arr[17],
          monthProportion: arr[18],
          cumulative: arr[19],
          cumulativeProportion: arr[20]
        }
      ];
    } else {
      this.$toast(res.msg);
    }
    return notarizationArr;
  }

  // 获取收费数据
  public async getCharge(): Promise<ChargeModel> {
    const param = {
      month: this.getMonth()
    };
    const res = await this.$api.xHttp.post(
      this.$interface.notarization.index.charge,
      param
    );
    const chargeModel = new ChargeModel();
    if (res.code === 0) {
      let arr = res.data.split(';')[0].split(',');
      chargeModel.title = '全市收费总额';
      chargeModel.sameMonth = arr[1];
      chargeModel.annualCumulative = arr[2];
      chargeModel.lastYear = arr[3];
      chargeModel.contrast = arr[4];
    } else {
      this.$toast(res.msg);
    }
    return chargeModel;
  }

  // 获取公证员数据
  public async getNotaries(): Promise<NotariesModel> {
    const param = {
      month: this.getMonth()
    };
    const res = await this.$api.xHttp.post(
      this.$interface.notarization.index.notaryCase,
      param
    );
    const notariesModel = new NotariesModel();
    if (res.code === 0) {
      let notaryArr = res.data.notary.split(',');
      notariesModel.inEditing = notaryArr[1];
      notariesModel.nonEditing = notaryArr[2];
      notariesModel.subtotal = notaryArr[3];
      let level = res.data.notaryLevel.split(',');
      for (let i = 1; i < level.length; i++) {
        let obj = {
          const: '',
          type: '',
          num: 0
        };
        obj.const = 'const';
        obj.type = this.number[i - 1];
        obj.num = level[i] * 1;
        notariesModel.viewData.push(obj);
      }
    } else {
      this.$toast(res.msg);
    }
    return notariesModel;
  }

  public setActiveIndex(index: number): void {
    this.activeIndex = index;
  }

  public getMonth(): any {
    const nowDate = new Date();
    let year = nowDate.getFullYear();
    let month = nowDate.getMonth();
    if (month === 0) {
      month = 12;
      year = year - 1;
    }
    let monthStr = month.toString();
    if (monthStr.length < 2) {
      monthStr = '0' + month;
    }
    return year + monthStr;
  }
}
</script>
<style lang="less" scoped>
.home {
  .head-tabs {
    width: 100%;
    height: 238px;
    display: flex;
    justify-content: space-around;
    background-image: url('../../../../assets/images/modules/notarization/index/bg@2x.png');
    background-position: center center;
    background-repeat: no-repeat;
    background-size: cover;
    overflow: hidden;

    .head-tab {
      width: 214px;
      height: 90px;
      background: rgba(255, 255, 255, 1);
      border-radius: 8px;
      align-self: center;
      font-size: 32px;
      color: rgba(102, 102, 102, 1);
      text-align: center;
      line-height: 90px;
    }

    .tab-active {
      background: rgba(10, 95, 254, 1);
      color: rgba(255, 255, 255, 1);
    }
  }

  .unit {
    text-align: right;
    margin-top: 42px;
    padding: 0 40px;
    display: flex;
    font-size: 24px;
    justify-content: space-between;
  }
}
</style>
