<template>
  <div class="notarization">
    <div class="  notarization-content">
      <transition mode="out-in" name="component-fade">
        <component :is="components[active]"></component>
      </transition>
    </div>
    <div class="notarization-menu">
      <van-tabbar v-model="active">
        <van-tabbar-item>
          <span>首页</span>
          <img
            :src="props.active ? menuIcon.homeActive : menuIcon.homeInactive"
            class="notarization-menu-icon"
            slot="icon"
            slot-scope="props"
          />
        </van-tabbar-item>
        <van-tabbar-item>
          <span>诚信档案</span>
          <img
            :src="props.active ? menuIcon.recordActive : menuIcon.recordInactive"
            class="notarization-menu-icon"
            slot="icon"
            slot-scope="props"
          />
        </van-tabbar-item>
        <van-tabbar-item>
          <span>年度考核</span>
          <img
            :src="props.active ? menuIcon.assessActive : menuIcon.assessInactive"
            class="notarization-menu-icon"
            slot="icon"
            slot-scope="props"
          />
        </van-tabbar-item>
        <van-tabbar-item>
          <span>公证书查询</span>
          <img
            :src="props.active ? menuIcon.authenticActActive : menuIcon.authenticActInactive"
            class="notarization-menu-icon"
            slot="icon"
            slot-scope="props"
          />
        </van-tabbar-item>
        <van-tabbar-item>
          <span>数据统计</span>
          <img
            :src="props.active ? menuIcon.statisticsActive : menuIcon.statisticsInactive"
            class="notarization-menu-icon"
            slot="icon"
            slot-scope="props"
          />
        </van-tabbar-item>
      </van-tabbar>
    </div>
  </div>
</template>

<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';
// @ts-ignore
import annualAssessment from './annual-assessment/index';
// @ts-ignore
import authenticAct from './authentic-act/index';
// @ts-ignore
import dataStatistics from './data-statistics/index';
// @ts-ignore
import home from './home/index';
// @ts-ignore
import integrityRecord from './integrity-record/index';

@Component({
  components: {
    home,
    integrityRecord,
    annualAssessment,
    authenticAct,
    dataStatistics
  }
})
export default class Notarization extends Vue {
  public active: number = 0;
  // 底部菜单
  public components: any = [
    'home',
    'integrityRecord',
    'annualAssessment',
    'authenticAct',
    'dataStatistics'
  ];
  // 底部菜单图标
  public menuIcon: any = {
    homeActive: require('../../../assets/images/modules/notarization/index/home-active.png'),
    homeInactive: require('../../../assets/images/modules/notarization/index/home-inactive.png'),
    recordActive: require('../../../assets/images/modules/notarization/index/record-active.png'),
    recordInactive: require('../../../assets/images/modules/notarization/index/record-inactive.png'),
    assessActive: require('../../../assets/images/modules/notarization/index/assess-active.png'),
    assessInactive: require('../../../assets/images/modules/notarization/index/assess-inactive.png'),
    authenticActActive: require('../../../assets/images/modules/notarization/index/authentic-act-active.png'),
    authenticActInactive: require('../../../assets/images/modules/notarization/index/authentic-act-inactive.png'),
    statisticsActive: require('../../../assets/images/modules/notarization/index/statistics-active.png'),
    statisticsInactive: require('../../../assets/images/modules/notarization/index/statistics-inactive.png')
  };

  public mounted() {
    console.log('i am notarization mounted');
  }
}
</script>
<style lang="less" scoped>
.notarization {
  height: 100%;
  display: flex;
  flex-direction: column;

  &-content {
    flex: 1;
    padding-bottom: 120px;
  }

  &-menu {
    height: 92px;
    &-icon {
      height: 44px;
      width: 44px;
    }
  }
}

// 样式重置
.van-tabbar-item--active {
  color: #0a5ffe;
}
</style>
