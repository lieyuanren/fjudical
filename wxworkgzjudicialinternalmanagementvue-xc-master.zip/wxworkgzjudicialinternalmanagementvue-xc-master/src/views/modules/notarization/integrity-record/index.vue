<template>
  <div class="record">
    <div v-if="menuList.length > 0">
      <div :key="index" v-for="(item, index) in menuList">
        <menu-list :item="item"></menu-list>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
// @ts-ignore
import MenuList from '@/components/common/v-menu-list';
// @ts-ignore
import { Component, Vue } from 'vue-property-decorator';
// @ts-ignore
import MenuData from '@/model/modules/notarization/integrityRecord/MenuData';

@Component({
  components: { MenuList }
})
export default class IntegrityRecord extends Vue {
  // 档案菜单
  public menuList: MenuData[] = [
    {
      name: '机构诚信档案',
      // @ts-ignore
      icon: require('@/assets/images/modules/notarization/index/record-organ.png'),
      toUrl: '/institutionList'
    },
    {
      name: '人员诚信档案',
      // @ts-ignore
      icon: require('@/assets/images/modules/notarization/index/record-person.png'),
      toUrl: '/personList'
    }
  ];
}
</script>
<style lang="less" scoped>
.record {
  height: 100%;
  padding: 40px 30px;
}
</style>
