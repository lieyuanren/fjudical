<template>
  <div class="institution">
    <!--基本信息-->
    <detail-info :columns="columns" :detail="detail"></detail-info>
    <case-list :caseList="assessList" title="考核情况"></case-list>
    <case-list :caseList="citeList" title="嘉奖情况"></case-list>
    <case-list :caseList="punishList" title="处罚情况"></case-list>
  </div>
</template>

<script lang="ts">
// @ts-ignore
import CaseList from '@/components/modules/notarization/integrity-record/v-case-list';
// @ts-ignore
import DetailInfo from '@/components/modules/notarization/integrity-record/v-detail-info';
// @ts-ignore
import Case from '@/model/global/Case';
// @ts-ignore
import Detail from '@/model/global/DetailInfo';
// @ts-ignore
import DolumnInfo from '@/model/global/DolumnInfo';
// @ts-ignore
import { Component, Vue } from 'vue-property-decorator';
import Common from '@/utils/common/common';

@Component({
  components: { DetailInfo, CaseList }
})
export default class InstitutionDetail extends Vue {
  public detail: Detail = {};
  public columns: DolumnInfo[] = [];
  public assessList: Case[] = [];
  public citeList: Case[] = [];
  public punishList: Case[] = [];
  // 奖惩类别
  public citePunishCategory: any = {
    cite: 'JJ',
    punish: 'CF'
  };

  public created(): void {
    // 基本信息
    this.detailInfo();
    // 考核列表
    this.loadAssessList();
    // 嘉奖列表
    this.loadCitePunishList(this.citePunishCategory.cite);
    // 处罚列表
    this.loadCitePunishList(this.citePunishCategory.punish);
  }

  /**
   * 机构基本信息
   */
  public async detailInfo(): Promise<void> {
    const code = this.$route.query.code;
    const res = await this.$api.xHttp.get(this.$interface.notarization.organization.detail, { code }, null);
    if (res.code === 0) {
      this.detail = {
        title: res.data.name,
        imgUrl: require('@/assets/images/modules/notarization/index/institution-head.png'),
        intro: res.data.intro
      };
      this.columns = [
        { label: '机构隶属', value: res.data.subjection },
        { label: '机构体制', value: res.data.system },
        { label: '经费管理', value: res.data.fundsManager },
        { label: '机构负责人', value: res.data.leader },
        { label: 'phone', value: res.data.phone },
        { label: '机构地址', value: res.data.address }
      ];
    }
  }

  /**
   * 考核列表
   */
  public async loadAssessList(): Promise<void> {
    const orgCode = this.$route.query.code;
    const category = 'JG';
    const res = await this.$api.xHttp.get(this.$interface.notarization.annualAssessment.findByOrgCode, {
      orgCode, category
    }, null);
    if (res.code === 0) {
      let list: Case[] = res.data.filter((it: Case) => {
        return it.assessYear && it.grade;
      });
      list = list.map((it: Case) => (
        {
          year: it.assessYear || '-', grade: it.grade || '-', content: it.remark || '-'
        }
      ));
      this.assessList = list;
    }
  }

  /**
   * 奖惩列表
   */
  public async loadCitePunishList(category: string): Promise<void> {
    const orgCode = this.$route.query.code;
    const res = await this.$api.xHttp.get(this.$interface.notarization.rewardPunishment.findByOrgCode, {
      orgCode, category
    }, null);
    if (res.code === 0) {
      const list: Case[] = res.data.map((it: any) => (
        {
          year: Common.dateFmt('yyyy-MM-dd', new Date(it.date)), grade: it.type, content: it.content
        }
      ));
      if (category === this.citePunishCategory.cite) {
        this.citeList = list;
      } else if (category === this.citePunishCategory.punish) {
        this.punishList = list;
      }

    }
  }
}
</script>
<style lang="less" scoped>
.institution {
  // height: 100%;
}
</style>
