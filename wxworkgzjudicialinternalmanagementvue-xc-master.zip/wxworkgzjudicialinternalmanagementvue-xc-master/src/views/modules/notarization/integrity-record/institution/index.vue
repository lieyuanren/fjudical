<template>
  <div class="institution">
    <van-pull-refresh
      @refresh="onRefresh"
      v-model="refreshing">
      <van-list
        :finished="finished"
        :finished-text="finishedText"
        @load="notarizationList"
        finished-text="没有更多了"
        v-model="loading">
        <card-list :item="item" :key="index" :labelArr="labelArr" :toUrl="toUrl" :types="types"
                   v-for="(item, index) in list"></card-list>
      </van-list>
    </van-pull-refresh>
    <nodata v-if="list.length === 0"></nodata>
  </div>
</template>

<script lang="ts">
// @ts-ignore
import CardList from '@/components/modules/notarization/integrity-record/v-card-list';
// @ts-ignore
import { Component, Vue } from 'vue-property-decorator';
// @ts-ignore
import Nodata from '@/components/common/v-nodata';
// @ts-ignore
import IntegrityRecord from '@/model/global/IntegrityRecord';
import PageParam from '@/model/modules/notarization/pageParam';

@Component({
  components: { CardList, Nodata }
})
export default class Institution extends Vue {
  private labelArr: string[] = ['机构体制', '机构负责人'];
  private toUrl: string = '/institutionDetail';
  private types: string = 'institution';
  private loading: boolean = false;
  private refreshing: boolean = false;
  private finished: boolean = false;
  private finishedText: string = '没有更多了';
  // 列表
  private list: IntegrityRecord[] = [];
  // 分页
  private pageParam: PageParam = {
    currentPage: 1,
    pageSize: 15
  };

  /**
   * 下拉刷新
   */
  public async onRefresh(): Promise<void> {
    this.pageParam.currentPage = 1;
    this.list = [];
    this.notarizationList();
    this.refreshing = false;
    this.finished = false;
    this.loading = true;
  }

  /**
   * 机构列表
   */
  public async notarizationList(): Promise<void> {
    const res = await this.$api.xHttp.post(this.$interface.notarization.organization.list, this.pageParam, null);
    if (res.code === 0) {
      const list: IntegrityRecord[] = res.data.list.map((it: any) => (
        {
          name: it.name, position: it.system, institution: it.leader, phone: it.phone, code: it.code,
          headImg: require('@/assets/images/modules/notarization/index/institution-head.png')
        }
      ));
      this.list = this.list.concat(list);
    }
    this.loading = false;
    this.finished = res.data.pageNum >= res.data.pages;
    this.pageParam.currentPage += 1;
    this.finishedText = this.list.length > 0 ? '没有更多了' : '';
  }
}
</script>
<style lang="less" scoped>
.institution {
  height: 100%;
  margin-top: 20px;
}
</style>
