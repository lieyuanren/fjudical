<template>
  <div class="institution">
    <!--基本信息-->
    <detail-info :columns="columns" :detail="detail"></detail-info>
    <case-list :caseList="assessList" title="考核情况"></case-list>
    <case-list :caseList="citeList" title="嘉奖情况"></case-list>
    <case-list :caseList="punishList" title="处罚情况"></case-list>
    <case-list :caseList="withdrawList" title="撤案情况"></case-list>
  </div>
</template>

<script lang="ts">
// @ts-ignore
import CaseList from '@/components/modules/notarization/integrity-record/v-case-list';
// @ts-ignore
import DetailInfo from '@/components/modules/notarization/integrity-record/v-detail-info';
// @ts-ignore
import Case from '@/model/global/Case';
// @ts-ignore
import Detail from '@/model/global/DetailInfo';
// @ts-ignore
import DolumnInfo from '@/model/global/DolumnInfo';
// @ts-ignore
import { Component, Vue } from 'vue-property-decorator';
import Common from '@/utils/common/common';

@Component({
  components: { DetailInfo, CaseList }
})
export default class InstitutionDetail extends Vue {
  public detail: Detail = {};
  public columns: DolumnInfo[] = [];
  public assessList: Case[] = [];
  public citeList: Case[] = [];
  public punishList: Case[] = [];
  public withdrawList: Case[] = [];
  // 奖惩类别
  public citePunishCategory: any = {
    cite: 'JJ',
    punish: 'CF'
  };

  public created(): void {
    this.getBaseInfo();
  }

  public activated(): void {
    this.getBaseInfo();
  }
  public getBaseInfo(): void {
    // 基本信息
    this.detailInfo();
    // 考核列表
    this.loadAssessList();
    // 嘉奖列表
    this.loadCitePunishList(this.citePunishCategory.cite);
    // 处罚列表
    this.loadCitePunishList(this.citePunishCategory.punish);
    // 撤案情况
    this.loadWithdrawList();
  }

  /**
   * 人员基本信息
   */
  public async detailInfo(): Promise<void> {
    const code = this.$route.query.code;
    const res = await this.$api.xHttp.get(this.$interface.notarization.personnel.findByCode, { code }, null);
    if (res.code === 0) {
      this.detail = {
        title: res.data.name,
        imgUrl: res.data.sex === '女' ? require('@/assets/images/modules/notarization/index/head-girl.png') : require('@/assets/images/modules/notarization/index/head-man.png')
      };
      this.columns = [
        { label: '党派', value: this.emptyValue(res.data.party) },
        { label: '所属机构', value: this.emptyValue(res.data.organization) },
        { label: '全日制教育学历', value: this.emptyValue(res.data.fullTime) },
        { label: '现公证员级别', value: this.emptyValue(res.data.notaryLevel) },
        { label: '公证员执业资格证号码', value: this.emptyValue(res.data.notaryNO) },
        { label: '任命公证员资格时间', value: this.emptyValue(res.data.notaryTime) },
        { label: '任命涉外公证员资格时间', value: this.emptyValue(res.data.outerNotaryTime) }
      ];
    }
  }

  public emptyValue(va: string): string {
    if (!va) {
      return '-';
    }
    return va;
  }
  /**
   * 考核列表
   */
  public async loadAssessList(): Promise<void> {
    const orgCode = this.$route.query.code;
    const category = 'JG';
    const res = await this.$api.xHttp.get(this.$interface.notarization.annualAssessment.findByOrgCode, {
      orgCode, category
    }, null);
    if (res.code === 0) {
      const list: Case[] = res.data.map((it: any) => (
        {
          year: it.assessYear, grade: it.grade, content: it.remark
        }
      ));
      this.assessList = list;
    }
  }

  /**
   * 奖惩列表
   */
  public async loadCitePunishList(category: string): Promise<void> {
    const orgCode = this.$route.query.code;
    const res = await this.$api.xHttp.get(this.$interface.notarization.rewardPunishment.findByOrgCode, {
      orgCode, category
    }, null);
    if (res.code === 0) {
      const list: Case[] = res.data.map((it: any) => (
        {
          year: Common.dateFmt('yyyy-MM-dd', new Date(it.date)), grade: it.type, content: it.content
        }
      ));
      if (category === this.citePunishCategory.cite) {
        this.citeList = list;
      } else if (category === this.citePunishCategory.punish) {
        this.punishList = list;
      }
    }
  }

  /**
   * 撤案情况列表
   */
  public async loadWithdrawList(): Promise<void> {
    const code = this.$route.query.code;
    const res = await this.$api.xHttp.get(this.$interface.notarization.authenticAct.findWithdrawn, {
      code
    }, null);
    if (res.code === 0) {
      const list: Case[] = res.data.map((it: any) => (
        {
          year: Common.dateFmt('yyyy-MM-dd', new Date(it.time)), grade: it.number, content: it.reason
        }
      ));
      this.withdrawList = list;
    }
  }
}
</script>
<style lang="less" scoped>
.institution {
  height: 100%;
}
</style>
