<template>
  <div class="person">
    <div class="head">
      <van-search @input="handleSearch" class="head-search" placeholder="搜索姓名" v-model="searchString"/>
      <van-dropdown-menu class="menu-item">
        <van-dropdown-item :options="organization" @change="conditionSearch" v-model="organizationIndex"/>
      </van-dropdown-menu>
    </div>
    <div class="condition">满足当前条件: {{total}}人</div>
    <van-pull-refresh
      @refresh="onRefresh"
      v-model="refreshing">
      <van-list
        :finished="finished"
        :finished-text="finishedText"
        @load="loadList"
        v-model="loading">
        <card-list :item="item" :key="index" :labelArr="labelArr" :toUrl="toUrl" :types="types"
                   v-for="(item, index) in list"></card-list>
      </van-list>
    </van-pull-refresh>
    <nodata v-if="list.length === 0"></nodata>
  </div>
</template>

<script lang="ts">
// @ts-ignore
import CardList from '@/components/modules/notarization/integrity-record/v-card-list';
// @ts-ignore
import { Component, Vue } from 'vue-property-decorator';
// @ts-ignore
import Nodata from '@/components/common/v-nodata';
// @ts-ignore
import IntegrityRecord from '@/model/global/IntegrityRecord';
import PageParam from '@/model/modules/notarization/pageParam';

@Component({
  components: { CardList, Nodata }
})
export default class Person extends Vue {
  private organizationIndex = '全部';
  private index = 0;
  private total = 0;
  private organization: any = [];
  private labelArr: string[] = ['党派', '所属机构', '现公证员级别'];
  private toUrl: string = '/personDetail';
  private types: string = 'person';
  // 列表
  private list: IntegrityRecord[] = [];
  private loading: boolean = false;
  private refreshing: boolean = false;
  private finished: boolean = false;
  // 搜索值：双绑
  private searchString: string = '';
  // 搜索值：真实查询值
  private sureSearch: string = '';
  // 节流定时器
  private timerLimit: any = null;
  private finishedText: string = '没有更多了';
  // 分页
  private pageParam: PageParam = {
    currentPage: 1,
    pageSize: 10
  };

  public created(): void {
    // 机构列表
    this.notarizationList();
  }

  /**
   * 名称搜索
   */
  public handleSearch(): void {
    clearTimeout(this.timerLimit);
    this.timerLimit = setTimeout(() => {
      this.sureSearch = this.searchString;
      this.conditionSearch();
    }, 1000);
  }

  /**
   * 条件查询
   */
  public async conditionSearch(): Promise<void> {
    this.pageParam.currentPage = 1;
    this.list = [];
    this.loading = true;
    this.loadList();
  }

  /**
   * 下拉刷新
   */
  public async onRefresh(): Promise<void> {
    this.pageParam.currentPage = 1;
    this.list = [];
    this.loadList();
    this.refreshing = false;
    this.finished = false;
    this.loading = true;
  }

  /**
   * 人员列表
   */
  public async loadList(): Promise<void> {
    const param = {
      organizationCode: this.organizationIndex === '全部' ? '' : this.organizationIndex,
      name: this.sureSearch
    };
    const res = await this.$api.xHttp.post(this.$interface.notarization.personnel.list, { ...param, ...this.pageParam }, null);
    if (res.code === 0) {
      const list: IntegrityRecord[] = res.data.list.map((it: any) => (
        {
          name: it.name,
          position: it.party,
          institution: it.organization,
          level: it.level,
          code: it.code,
          headImg: it.sex === '女' ? require('@/assets/images/modules/notarization/index/head-girl.png') : require('@/assets/images/modules/notarization/index/head-man.png')
        }
      ));
      this.total = res.data.total;
      this.list = this.list.concat(list);
    }
    this.loading = false;
    this.finished = res.data.pageNum >= res.data.pages;
    this.pageParam.currentPage += 1;
    this.finishedText = this.list.length > 0 ? '没有更多了' : '';
  }

  /**
   * 机构列表
   */
  public async notarizationList(): Promise<void> {
    const pageDTO: PageParam = {
      currentPage: 1,
      pageSize: 20
    };
    const res = await this.$api.xHttp.post(this.$interface.notarization.organization.list, { ...pageDTO }, null);
    if (res.code === 0) {
      const list = res.data.list.map((it: any) => ({ text: it.name, value: it.code }));
      const defaultList: any[] = [{ text: '所有机构', value: '全部' }];
      this.organization = defaultList.concat(list);
    }
  }
}
</script>
<style lang="less" scoped>
.person {
  height: 100%;
  .head {
    height: 180px;
    background: rgba(255, 255, 255, 1);
    &-search {
    }
    .van-hairline--top-bottom::after {
      border: 0 !important;
    }
    .menu-item {
      height: 60px;
      font-size: 28px !important;
      .van-dropdown-menu__title {
        color: #666666 !important;
      }
    }
  }
  .condition {
    margin-top: 30px;
    height: 40px;
    padding: 0 30px;
    font-size: 24px;
    color: rgba(153, 153, 153, 1);
  }
}
</style>
