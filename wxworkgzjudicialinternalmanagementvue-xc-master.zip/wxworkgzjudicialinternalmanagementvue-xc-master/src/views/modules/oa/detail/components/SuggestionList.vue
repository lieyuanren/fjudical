<!--
 * @Author: tangzhicheng
 * @Date: 2021-03-25 10:19:14
 * @LastEditors: tangzhicheng
 * @LastEditTime: 2021-03-25 14:16:30
 * @Description: file content
-->

<template>
  <div class="suggestion-list">
    <van-collapse v-model="activeNames">
      <van-collapse-item name="1">
        <template #title>
          <div class="title">
            <span>{{ title }}</span>
            <span>{{ status }}</span>
          </div>
        </template>
        <div class="item"
             v-for="n in 2"
             :key="n">
          <p class="head">
            <span class="name">叶小华</span>
            <span class="line">|</span>
            <span class="org">广州司法局</span>
            <span class="time">2019-12-2 8:30</span>
          </p>
          <p class="content">
            关于推动司法行政工作创新发展方面关于推动司法行政 工作创新发展方面
          </p>
        </div>
      </van-collapse-item>
    </van-collapse>
  </div>
</template>

<script lang='ts'>
import { Component, Prop, Vue } from 'vue-property-decorator';

@Component
export default class SuggestionList extends Vue {
  @Prop() private title: string;
  @Prop() private status: string;
  private activeNames = [];
}
</script>

<style lang='less' scoped>
.suggestion-list {
  margin: 20px 0;

  .title {
    font-size: 32px;
    span {
      padding-right: 10px;
    }
  }

  .item {
    font-size: 28px;
    margin-bottom: 30px;

    &:nth-last-child(1) {
      margin-bottom: 0;
    }

    .head {
      overflow: hidden;
      .name {
        color: #666666;
      }

      .line {
        color: #eaeaea;
        padding: 0 10px;
      }

      .org {
        color: #999999;
      }

      .time {
        float: right;
        color: #999999;
      }
    }

    .content {
      margin-top: 20px;
      color: #333333;
    }
  }
}
</style>

