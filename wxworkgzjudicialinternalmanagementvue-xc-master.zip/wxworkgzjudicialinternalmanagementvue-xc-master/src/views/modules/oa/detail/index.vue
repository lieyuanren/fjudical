<!--
 * @Author: tangzhicheng
 * @Date: 2021-03-25 09:30:43
 * @LastEditors: tangzhicheng
 * @LastEditTime: 2021-03-25 15:56:25
 * @Description: file content
-->

<template>
  <div class="detail">
    <header>
      <div class="head">
        <p>局科技信息化工作领导小组会议通知</p>
        <van-tag plain
                 type="primary">标签</van-tag>
      </div>
      <div class="content">
        <p>
          <span class="label">流程名称</span>
          <span class="text">收文流程</span>
        </p>
        <p>
          <span class="label">流程名称</span>
          <span class="text">收文流程</span>
        </p>
        <p>
          <span class="label">流程名称</span>
          <span class="text">收文流程</span>
        </p>
        <p>
          <span class="label">流程名称</span>
          <span class="text">收文流程</span>
        </p>
      </div>
    </header>
    <main>
      <SuggestionList title="拟办意见"
                      status="已同意" />
      <div class="steps">
        <van-steps direction="vertical"
                   :active="1">
          <van-step>
            <h3>【城市】物流状态1</h3>
            <p>2016-07-12 12:40</p>
          </van-step>
          <van-step>
            <h3>【城市】物流状态2</h3>
            <p>2016-07-11 10:00</p>
          </van-step>
          <van-step>
            <h3>快件已发货</h3>
            <p>2016-07-10 09:30</p>
          </van-step>
        </van-steps>
        <div class="btn-group">
          <van-button type="info"
                      plain>取消</van-button>
          <van-button type="info"
                      @click="navigate">确认</van-button>
        </div>
      </div>
    </main>
  </div>
</template>

<script lang='ts'>
import { Component, Vue } from 'vue-property-decorator';
import SuggestionList from './components/SuggestionList.vue';

@Component({
  components: {
    SuggestionList
  }
})
export default class Detail extends Vue {
  private message = '';

  private navigate() {
    this.$router.push({
      path: 'received'
    });
  }
}
</script>

<style lang='less' scoped>
.detail {
  header {
    padding: 30px;
    padding-bottom: 50px;
    background-color: #ffffff;

    .head {
      p {
        font-size: 36px;
        color: #333333;
        padding-bottom: 4px;
      }
      padding-bottom: 20px;
      border-bottom: 1px solid #eeeeee;
    }

    .content {
      p {
        width: 100%;
        margin: 24px 0;
        font-size: 28px;
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
        &:nth-last-child(1) {
          margin-bottom: 0;
        }

        span {
          display: inline-block;
        }

        .label {
          width: 200px;
          color: #666666;
        }

        .text {
          color: #333333;
        }
      }
    }
  }

  main {
    .btn-group {
      padding: 20px 0;
      display: flex;
      justify-content: space-around;
      background-color: #ffffff;
    }
  }
}
</style>

<style lang="less">
.detail {
  .btn-group {
    .van-button {
      width: 310px;
      border-radius: 12px;
    }
  }

  .van-step__title {
    h3,
    p {
      font-size: 28px;
    }
  }

  .van-step--finish {
    color: #07c160;
  }
}
</style>

