<!--
 * @Author: tangzhicheng
 * @Date: 2021-03-24 14:16:12
 * @LastEditors: tangzhicheng
 * @LastEditTime: 2021-03-24 16:47:56
 * @Description: file content
-->

<template>
  <div class="received-card"
       @click="$emit('click')">
    <p>{{ title }}</p>
    <slot></slot>
  </div>
</template>

<script lang='ts'>
import { Component, Prop, Vue } from 'vue-property-decorator';

@Component
export default class ReceivedCard extends Vue {
  @Prop({ default: '' }) private title: string;
}
</script>

<style lang='less' scoped>
.received-card {
  padding: 40px 30px;
  background-color: #ffffff;
  margin-bottom: 20px;
  position: relative;

  p:nth-child(1) {
    font-size: 36px;
    color: #333333;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
    width: 100%;
  }
}
</style>

