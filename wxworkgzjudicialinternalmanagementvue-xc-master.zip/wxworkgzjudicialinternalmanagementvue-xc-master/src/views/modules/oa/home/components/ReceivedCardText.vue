<!--
 * @Author: tangzhicheng
 * @Date: 2021-03-24 14:23:21
 * @LastEditors: tangzhicheng
 * @LastEditTime: 2021-03-24 14:36:04
 * @Description: file content
-->


<template>
  <p class="received-card-text">
    <span class="label">{{ label }}：</span>
    <span class="value">{{ value }}</span>
  </p>
</template>

<script lang='ts'>
import { Component, Prop, Vue } from 'vue-property-decorator';

@Component
export default class ReceivedCardText extends Vue {
  @Prop() private label: string;
  @Prop() private value: string;
}
</script>

<style lang='less' scoped>
.received-card-text {
  width: 100%;
  font-size: 28px;
  color: #999999;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
  margin: 22px 0;
  &:nth-last-child(1) {
    margin-bottom: 0;
  }
}
</style>

