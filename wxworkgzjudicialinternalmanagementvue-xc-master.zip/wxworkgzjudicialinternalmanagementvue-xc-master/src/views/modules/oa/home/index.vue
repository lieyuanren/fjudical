<!--
 * @Author: tangzhicheng
 * @Date: 2021-03-24 13:59:40
 * @LastEditors: tangzhicheng
 * @LastEditTime: 2021-03-26 09:09:14
 * @Description: file content
-->

<template>
  <div class="home">
    <header>
      <van-tabs v-model="activeName"
                color="#0063FF"
                title-active-color="#0063FF">
        <van-tab title="我的待办(10)"
                 name="a"></van-tab>
        <van-tab title="我的待阅(10)"
                 name="b"></van-tab>
        <van-tab title="我的已办"
                 name="c"></van-tab>
      </van-tabs>
      <van-search v-model="keywords"
                  placeholder="请输入搜索关键词" />
      <van-dropdown-menu active-color="#0063FF">
        <van-dropdown-item v-model="value1"
                           :options="option" />
        <van-dropdown-item v-model="value2"
                           :options="option" />
      </van-dropdown-menu>

    </header>
    <div class="tips">
      共3条，满足当前条件3条
    </div>
    <main>
      <VSkeleton :loading="listData.length === 0"
                 :count="3" />
      <van-pull-refresh v-model="refreshing"
                        @refresh="onRefresh">
        <van-list v-model="loading"
                  :finished="finished"
                  finished-text="没有更多了"
                  @load="onLoad"
                  :offset="offset">
          <ReceivedCard title="局科技信息化工作领导小组会议通知"
                        v-for="(n, index) in listData"
                        :key="index"
                        @click="navigate">
            <ReceivedCardText label="申请时间"
                              value="2019-07-30  15:28:12 " />
            <ReceivedCardText label="申请时间"
                              value="2019-07-30  15:28:12 " />
            <ReceivedCardText label="申请时间"
                              value="2019-07-30  15:28:12 " />
          </ReceivedCard>
        </van-list>
      </van-pull-refresh>

    </main>
  </div>
</template>

<script lang='ts'>
import { Component, Vue } from 'vue-property-decorator';
import ReceivedCard from './components/ReceivedCard.vue';
import ReceivedCardText from './components/ReceivedCardText.vue';
import VSkeleton from '@/components/common/v-skeleton/index.vue';

@Component({
  components: {
    ReceivedCard,
    ReceivedCardText,
    VSkeleton
  }
})
export default class Home extends Vue {
  private activeName = '';
  private keywords: string = '';
  private value1 = '0';
  private value2 = '0';
  private listData: any = [];
  private loading = false;
  private finished = false;
  private refreshing = false;
  private offset: number = 200;

  private option = [
    { text: '全部商品', value: '0' },
    { text: '新款商品', value: '1' },
    { text: '活动商品', value: '2' }
  ];

  private created() {
    this.getData();
  }

  private navigate() {
    this.$router.push({
      path: 'detail',
      query: {
        id: '1'
      }
    });
  }

  private async onLoad() {
    await this.getData();

    this.loading = false;
    this.refreshing = false;

    if (this.listData.length > 30) {
      this.finished = true;
    }
  }

  private onRefresh() {
    // 清空列表数据
    this.listData = [];
    this.finished = false;

    // 重新加载数据
    // 将 loading 设置为 true，表示处于加载状态
    this.loading = true;
    this.onLoad();
  }

  private getData() {
    return new Promise((resolve) => {
      setTimeout(() => {
        // @ts-ignore
        this.listData.push(...[1, 2, 3]);
        resolve(1);
      }, 2000);
    });
  }
}
</script>

<style lang='less' scoped>
.home {
  padding-bottom: 60px;
  padding-top: 290px;

  header {
    top: 0;
    position: fixed;
    width: 100%;
    z-index: 999;
  }
  .tips {
    font-size: 24px;
    color: #666666;
    padding: 30px 15px;
  }
}
</style>

