<!--
 * @Author: tangzhicheng
 * @Date: 2021-03-24 10:25:54
 * @LastEditors: tangzhicheng
 * @LastEditTime: 2021-03-24 13:58:28
 * @Description: file content
-->

<template>
  <div class="OA">
    <router-view />
  </div>
</template>

<script lang='ts'>
import { Component, Vue } from 'vue-property-decorator';

@Component
export default class OA extends Vue {}
</script>

<style lang='less' scoped>
.OA {
  width: 100%;
  height: 100%;
}
</style>
