<!--
 * @Author: tangzhicheng
 * @Date: 2021-03-25 15:28:50
 * @LastEditors: tangzhicheng
 * @LastEditTime: 2021-03-31 09:10:19
 * @Description: 内部行文提交页面
-->

<template>
  <div class="post">
    <div class="org-select"
         v-show="!others">
      <div :class="['org-item', (selectDepartments.includes(dp.name)) && 'active']"
           v-for="dp in departmentList"
           :key="dp.id"
           @click="selectHandle(dp.name)">
        <span>{{ dp.name }}</span>
        <img src="../../../../assets/images/modules/mediation/cleck.png">
      </div>
    </div>

    <van-cell title="转他人办理">
      <template #right-icon>
        <van-checkbox v-model="others">是</van-checkbox>
      </template>
    </van-cell>

    <PersonSelectWrapper title="抄送" />

    <PersonSelectWrapper :title="item"
                         v-for="item in  selectDepartments"
                         :key="item" />

    <van-cell title="短信通知">
      <template #right-icon>
        <van-checkbox v-model="isMessage">是</van-checkbox>
      </template>
    </van-cell>

    <div class="opinions">
      <div class="head">办理意见</div>
      <div class="tips"
           @click="selectShow = true">
        <span>选择常用处理意见</span>
        <van-icon name="arrow-down" />
      </div>
      <div class="content">
        <van-field v-model="value"
                   rows="2"
                   autosize
                   type="textarea"
                   maxlength="300"
                   placeholder="请输入意见"
                   show-word-limit />
      </div>
    </div>
    <div class="btn-group">
      <van-button type="info">办理完成</van-button>
      <van-button type="info">一键同意</van-button>
      <van-button type="info"
                  plain>重置</van-button>
    </div>

    <van-popup v-model="selectShow"
               position="bottom"
               round>
      <van-picker title="标题"
                  show-toolbar
                  :columns="columns" />
    </van-popup>
  </div>
</template>

<script lang='ts'>
import { Component, Vue } from 'vue-property-decorator';
import PersonSelectWrapper from '@/components/common/v-person-select-wrapper/index.vue';

@Component({
  components: {
    PersonSelectWrapper
  }
})
export default class Post extends Vue {
  private isMessage = false;
  private selectShow = false;
  private others = false;
  private departmentList: any[] = [
    {
      id: 1,
      name: '广州政法大厅'
    },
    {
      id: 2,
      name: '哈撒给'
    },
    {
      id: 3,
      name: '所累可通'
    }
  ];
  private selectDepartments: string[] = [];
  private value = '';
  private columns = [
    '杭州',
    '宁波',
    '温州',
    '绍兴',
    '湖州',
    '嘉兴',
    '金华',
    '衢州'
  ];

  private selectHandle(name: string) {
    let index;
    if ((index = this.selectDepartments.indexOf(name)) !== -1) {
      this.selectDepartments.splice(index, 1);
      return;
    }
    this.selectDepartments.push(name);
  }
}
</script>

<style lang='less' scoped>
.post {
  .org-select {
    padding: 30px;
    background-color: #ffffff;
    display: flex;
    flex-wrap: wrap;
    margin-bottom: 20px;

    .org-item {
      position: relative;
      padding: 20px 30px;
      border: 1px solid #d6d6d6;
      border-radius: 6px;
      flex-shrink: 1;
      margin-right: 20px;
      margin-bottom: 20px;
      font-size: 28px;
      color: #666666;
      img {
        width: 44px;
        height: 44px;
        position: absolute;
        right: 0;
        bottom: 0;
        opacity: 0;
      }
    }

    .active {
      border-color: #2077ff;
      color: #2077ff;
      img {
        opacity: 1;
      }
    }
  }

  .opinions {
    padding: 30px;
    background-color: #ffffff;
    margin-top: 20px;

    .head {
      padding-bottom: 20px;
      border-bottom: 1px solid #eeeeee;
      font-size: 32px;
    }

    .tips {
      font-size: 28px;
      padding: 36px 0;
      color: #666666;

      span {
        padding-right: 15px;
      }
    }
    .content {
      border: 1px solid #e6e6e6;
      border-radius: 10px;
      overflow: hidden;
    }
  }

  .btn-group {
    padding: 20px;
    background-color: #ffffff;
    display: flex;
    justify-content: space-around;
  }
}
</style>

<style lang="less">
.btn-group {
  display: flex;
  .van-button {
    max-width: 310px;
    min-width: 190px;
    height: 98px;
    border-radius: 12px;
  }
}
</style>

