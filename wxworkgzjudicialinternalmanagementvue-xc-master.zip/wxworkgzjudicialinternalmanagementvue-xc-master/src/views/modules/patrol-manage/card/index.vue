<!--
 * @Author: lilili
 * @Date:2020-07-17 16:15:00
 * @LastEditors: lilili
 * @LastEditTime: 2020-07-17 16:15:00
 * @Description: file content
 -->
 <template>
  <div class="attendance-manage">
    <div class="appraiser-head">
      <van-search @input="handleInput"
                  placeholder="搜索"
                  v-model="keyword" />
      <div class="attendance-manage-select">
        <!-- 选择部门 -->
        <div class="van-cell__value"
             style="overflow:inherit;">
          <div class="van-field__body">
            <van-dropdown-menu>
              <van-dropdown-item v-model="type" :options="typeOptions" @change="typeSelect" />
            </van-dropdown-menu>
          </div>
        </div>
      </div>
    </div>
    <!-- 数据列表 -->
    <van-pull-refresh v-model="refreshing" @refresh="onRefresh">
    <van-list
        v-model="loading"
        :finished="finished"
        finished-text="没有更多了"
        :immediate-check="false"
        :offset="10"
        @load="onLoad">
      <DataCard :item="item" :key="index" v-for="(item,index) in cardList" />
    </van-list>
    </van-pull-refresh>
  </div>
</template>

<script lang='ts'>
import { Component, Vue } from 'vue-property-decorator';
import DataCard from '@/components/modules/patrol-manage/data-card/index.vue';

@Component({
  components: {
    DataCard
  }
})
export default class AttendanceData extends Vue {
  private type: any = null;
  private typeOptions: any[] = [
    { text: '请选择卡类型', value: null },
    { text: '人员卡', value: 1 },
    { text: '地址卡', value: 2 },
    { text: '事件卡', value: 3 }
  ];
  private keyword: string = '';
  // 数据列表
  private cardList: any[] = [];
  // 刷新
  private currentPage: number = 1;
  private pageSize: number = 10;
  private loading: boolean = false;
  private finished: boolean = false;
  private refreshing: boolean = false;

  private handleInput(): void {
    this.currentPage = 1;
    this.cardList = [];
    this.getData();
  }

  private onRefresh(): void {
    this.finished = false;
    this.onLoad();
  }

  private async onLoad(): Promise<void> {
    this.currentPage++;
    await this.getData();
  }

  private async created(): Promise<void> {
    await this.getData();
  }

  /**
   * 获取数据
   */
  private async getData(): Promise<void> {
    const body = {
      current: this.currentPage,
      size: this.pageSize,
      type: this.type,
      keyword: this.keyword
    };
    const res = await this.$api.xHttp.post(
      this.$interface.patrolManage.attendance.cardList,
      body
    );
    this.refreshing = false;
    this.loading = false;
    if (res.code === 0) {
      const records = res.data.records;
      if (records === null || records.length === 0) {
        this.finished = true;
        return;
      }
      if (records.length < this.pageSize) {
        this.finished = true;
      }
      if (this.currentPage === 1) {
        this.cardList = records;
      } else {
        this.cardList.push(...records);
      }
    } else {
      this.$toast(res.msg);
    }
  }

  /**
   * 卡类型切换
   */
  private async typeSelect(val: any): Promise<void> {
    this.type = val;
    this.currentPage = 1;
    this.cardList = [];
    await this.getData();
  }
}
</script>

<style lang='less' scoped>
.attendance-manage {
  &-head {
    background-color: #ffffff;
  }
  .tips {
    font-size: 24px;
    color: rgba(153, 153, 153, 1);
    padding: 30px;
  }
  &-select {
    display: flex;
    justify-content: space-between;
    background: #fff;
    padding: 0 0.4rem 0.2rem;
    font-size: 0.37333rem;
    .show-btn {
      color: #666666;
      span,
      i {
        vertical-align: middle;
      }

      span {
        margin-right: 8px;
      }
    }
    .department-name {
      height: 0.88rem;
      line-height: 0.88rem;
    }
  }
  .time-select {
    width: 260px;
    height: 66px;
    border-radius: 8px;
    border: 1px solid #ffffff;
    margin-left: 60px;
    display: flex;
    align-items: center;
    justify-content: flex-end;
    &:nth-child(3) {
      margin-left: 28px;
    }

    span {
      padding-right: 8px;
    }
    span,
    i {
      vertical-align: middle;
    }
  }
}

.van-hairline--top-bottom::after,
.van-hairline-unset--top-bottom::after {
  border: none;
}

.van-search {
  padding: 30px;
}
</style>
