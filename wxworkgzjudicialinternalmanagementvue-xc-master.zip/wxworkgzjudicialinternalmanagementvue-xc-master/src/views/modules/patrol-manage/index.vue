<!--
 * @Author: lilili
 * @Date:2020-07-17 16:15:00
 * @LastEditors: lilili
 * @LastEditTime: 2020-07-17 16:15:00
 * @Description: file content
 -->
<template>
  <div class="patrol-manage">
    <div class="patrol-manage-body">
      <transition name="outIn"
                  mode="out-in">
        <component :is="componentId[active]"></component>
      </transition>
    </div>
    <div class="patrol-manage-menu">
      <van-tabbar v-model="active">
        <van-tabbar-item>
          <span>卡号管理</span>
          <img :src="props.active ? menuIcon.homeActive : menuIcon.homeInactive"
               class="patrol-manage-menu-icon"
               slot="icon"
               slot-scope="props" />
        </van-tabbar-item>
        <van-tabbar-item>
          <span>巡更情况</span>
          <img :src="props.active ? menuIcon.recordActive : menuIcon.recordInactive"
               class="patrol-manage-menu-icon"
               slot="icon"
               slot-scope="props" />
        </van-tabbar-item>
      </van-tabbar>
    </div>
  </div>
</template>

<script lang='ts'>
import { Component, Vue } from 'vue-property-decorator';
import Card from './card/index.vue';
import Record from './record/index.vue';

@Component({
  components: {
    Card,
    Record
  }
})
export default class InternalControl extends Vue {
  // 底部菜单图标
  private menuIcon: any = {
    homeActive: require('../../../assets/images/modules/patrol-manage/tabs/card-sel.png'),
    homeInactive: require('../../../assets/images/modules/patrol-manage/tabs/card.png'),
    recordActive: require('../../../assets/images/modules/patrol-manage/tabs/condition-sel.png'),
    recordInactive: require('../../../assets/images/modules/patrol-manage/tabs/condition.png')
  };

  private active: number = 0;

  // 组件名
  private componentId: string[] = ['Card', 'Record'];
}
</script>

<style lang='less' scoped>
.patrol-manage {
  height: 100%;

  &-menu {
    height: 92px;
    &-icon {
      height: 44px;
      width: 44px;
    }
  }
}

.outIn-enter,
.outIn-leave-to {
  opacity: 0;
}

.outIn-enter-active,
.outIn-leave-active {
  transition: opacity 0.3s;
}
</style>

