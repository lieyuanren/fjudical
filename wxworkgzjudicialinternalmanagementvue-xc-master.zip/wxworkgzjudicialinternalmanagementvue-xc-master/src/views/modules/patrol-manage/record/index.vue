<!--
 * @Author: lilili
 * @Date:2020-07-17 16:15:00
 * @LastEditors: lilili
 * @LastEditTime: 2020-07-17 16:15:00
 * @Description: file content
 -->
 <template>
  <div class="attendance-manage">
    <div class="attendance-manage-head">
      <div class="attendance-manage-time">
        <div class="attendance-manage-time-item"
             @click="beginTimeHandle">{{ beginTime === null ? '开始时间' : beginTime }}
        </div>
        <div>-</div>
        <div class="attendance-manage-time-item"
             @click="endTimeHandle">{{ endTime === null ? '结束时间' : endTime }}</div>
      </div>
      <div class="attendance-manage-select">
        <van-dropdown-menu>
          <van-dropdown-item v-model="road" :options="roadOptions" @change="menuChange"/>
          <van-dropdown-item v-model="locate" :options="locateOptions" @change="menuChange"/>
          <van-dropdown-item v-model="person" :options="personOptions" @change="menuChange"/>
          <van-dropdown-item v-model="result" :options="resultOptions" @change="menuChange"/>
        </van-dropdown-menu>
      </div>
    </div>
    <!-- 记录列表 -->
    <van-pull-refresh v-model="refreshing"
                      @refresh="onRefresh">
      <van-list v-model="loading"
                :finished="finished"
                finished-text="没有更多了"
                @load="onLoad">
        <RecordCard v-for="(item,index) in cardList"
                    :item="item"
                    :key="index"
                    class="record-card" />
      </van-list>
    </van-pull-refresh>

    <van-popup :style="{ height: '50%' }"
               position="bottom"
               v-model="beginTimeShow">
      <van-datetime-picker @cancel="onCancel(1)"
                           :value="currentDate"
                           @confirm="onConfirmBeginDate"
                           type="datetime"/>
    </van-popup>

    <van-popup :style="{ height: '50%' }"
               position="bottom"
               v-model="endTimeShow">
      <van-datetime-picker @cancel="onCancel(2)"
                           :value="currentDate"
                           @confirm="onConfirmEndDate"
                           type="datetime"/>
    </van-popup>
  </div>
</template>

<script lang='ts'>
import { Component, Vue } from 'vue-property-decorator';
import RecordCard from '../../../../components/modules/patrol-manage/record-card/index.vue';
// @ts-ignore
import Common from '@/utils/common/common';

@Component({
  components: {
    RecordCard
  }
})
export default class AttendanceRecord extends Vue {
  // 下拉筛选
  private road: any = null;
  private roadOptions: any[] = [];
  private locate: any = null;
  private locateOptions: any[] = [];
  private person: any = null;
  private personOptions: any[] = [];
  private result: any = null;
  private resultOptions: any[] = [
    { text: '巡捡结果', value: null },
    { text: '合格', value: 1 },
    { text: '漏检', value: 2 },
    { text: '误点', value: 3 }
  ];
  // 数据列表
  private cardList: any = [];
  // 刷新
  private currentPage: number = 1;
  private pageSize: number = 10;
  private loading: boolean = false;
  private finished: boolean = false;
  private refreshing: boolean = false;
  // 时间
  private beginTime: any = null;
  private endTime: any = null;

  private beginTimeShow: boolean = false;
  private endTimeShow: boolean = false;

  private currentDate: Date = new Date();

  private created(): void {
    this.getInspectionRoutes();
    this.getAddressList();
    this.getPersonList();
    this.getDataList();
  }
  /**
   * 上拉刷新
   */
  private async onLoad(): Promise<void> {
    this.currentPage++;
    await this.getDataList();
  }

  private onRefresh() {
    this.finished = false;
    this.onLoad();
  }

  private onCancel(type: number) {
    if (type === 1) {
      this.beginTime = null;
      this.beginTimeShow = false;
    } else {
      this.endTime = null;
      this.endTimeShow = false;
    }
    this.currentPage = 1;
    this.getDataList();
  }

  private onConfirmBeginDate($event: any) {
    const year = $event.getFullYear();
    const month = $event.getMonth() + 1;
    const date = $event.getDate();
    const hour = $event.getHours();
    const minute = $event.getMinutes();

    this.beginTime = `${year}-${this.add0(month)}-${this.add0(date)} ${this.add0(hour)}:${this.add0(minute)}`;
    if (this.endTime !== null && new Date(this.beginTime) > new Date(this.endTime)) {
      this.$toast('开始时间应小于结束时间');
      return;
    }

    this.beginTimeShow = false;
    this.cardList = [];
    this.currentPage = 1;
    this.getDataList();
  }

  private onConfirmEndDate($event: any) {
    const year = $event.getFullYear();
    const month = $event.getMonth() + 1;
    const date = $event.getDate();
    const hour = $event.getHours();
    const minute = $event.getMinutes();

    this.endTime = `${year}-${this.add0(month)}-${this.add0(date)} ${this.add0(hour)}:${this.add0(minute)}`;
    if (new Date(this.beginTime) > new Date(this.endTime)) {
      this.$toast('结束时间应大于等于开始时间');
      return;
    }

    this.endTimeShow = false;
    this.cardList = [];
    this.currentPage = 1;
    this.getDataList();
  }

  private add0(num: number) {
    if (num < 10) {
      return `0${num}`;
    } else {
      return `${num}`;
    }
  }

  private beginTimeHandle() {
    this.beginTimeShow = true;
  }

  private endTimeHandle() {
    this.endTimeShow = true;
  }

  /**
   * 获取所有线路
   */
  private async getInspectionRoutes(): Promise<void> {
    const firstObj = { text: '线路', value: null };
    this.roadOptions = await this.getMenuData(this.$interface.patrolManage.record.inspectionRoutes, firstObj);
  }
  /**
   * 获取所有地点
   */
  private async getAddressList(): Promise<void> {
    const firstObj = { text: '地点', value: null };
    this.locateOptions = await this.getMenuData(this.$interface.patrolManage.record.inspectionAddress, firstObj);
  }
  /**
   * 获取所有地点
   */
  private async getPersonList(): Promise<void> {
    const firstObj = { text: '人员', value: null };
    this.personOptions = await this.getMenuData(this.$interface.patrolManage.record.inspectionPerson, firstObj);
  }
  /**
   * 获取菜单数据
   */
  private async getMenuData(uri: string, firstObj: any): Promise<any[]> {
    const arr = [];
    arr.push(firstObj);
    const res = await this.$api.xHttp.post(uri, {});
    if (res.code === 0) {
      res.data.forEach((item: any) => {
        arr.push({ text: item.name, value: item.value });
      });
    } else {
      this.$toast(res.msg);
    }
    return arr;
  }

  /**
   * 获取列表数据
   */
  private async getDataList(): Promise<void> {
    const body = {
      startTime: this.beginTime,
      endTime: this.endTime,
      routeId: this.road,
      addressId: this.locate,
      personId: this.person,
      result: this.result,
      current: this.currentPage,
      size: this.pageSize
    };
    const res = await this.$api.xHttp.post(this.$interface.patrolManage.record.inspectionDetail, body);
    this.refreshing = false;
    this.loading = false;
    if (res.code === 0) {
      const records = res.data.records;
      if (records === null || records.length === 0) {
        this.finished = true;
        return;
      }
      if (records.length < this.pageSize) {
        this.finished = true;
      }
      records.map((item: any) => {
        item.startTime = Common.dateFmt(null, new Date(item.startTime));
        item.endTime = Common.dateFmt(null, new Date(item.endTime));
        item.time = Common.dateFmt(null, new Date(item.time));
      });
      if (this.currentPage === 1) {
        this.cardList = records;
      } else {
        this.cardList.push(...records);
      }
    } else {
      this.$toast(res.msg);
    }
  }

  private menuChange(): void {
    this.currentPage = 1;
    this.cardList = [];
    this.getDataList();
  }

}
</script>

<style lang='less' scoped>
.attendance-manage {
  &-head {
    background-color: #ffffff;
    margin-bottom: 20px;
    height: 220px;
  }
  &-time {
    height: 80px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    text-align: center;
    padding: 30px 8% 15px 8%;
    box-sizing: border-box;
    &-item {
      background-color: #F7F7FA;
      line-height: 70px;
      height: 70px;
      width: 48%;
      font-size: 28px;
    }
  }
  .tips {
    font-size: 24px;
    color: rgba(153, 153, 153, 1);
    padding: 30px;
  }
  &-select {
    padding: 0.5rem 0.4rem 0.1rem;
  }
  .time-select {
    width: 260px;
    height: 66px;
    border-radius: 8px;
    border: 1px solid #ffffff;
    margin-left: 60px;
    display: flex;
    align-items: center;
    justify-content: flex-end;
    &:nth-child(3) {
      margin-left: 28px;
    }

    span {
      padding-right: 8px;
    }
    span,
    i {
      vertical-align: middle;
    }
  }
}

.van-hairline--top-bottom::after,
.van-hairline-unset--top-bottom::after {
  border: none;
}

.van-search {
  padding: 30px;
}
</style>
