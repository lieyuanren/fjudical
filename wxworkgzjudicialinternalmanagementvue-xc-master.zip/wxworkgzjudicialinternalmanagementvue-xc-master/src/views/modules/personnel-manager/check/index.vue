<template>
  <div class="check">
    <div class="check-head">
      <div class="row">
        <div @click="switchShow"
             class="timer-select">
          <span class="label">{{ sureTime }}</span>
          <van-icon name="arrow-down" />
        </div>
        <div class="search-box">
          <van-search @input="handleSearch"
                      background="#f2f2f2"
                      placeholder="搜索统一案号或者委托人姓名"
                      v-model="searchKey"></van-search>
        </div>
      </div>
      <van-dropdown-menu v-if="sureTime === '平时考核'">
        <van-dropdown-item :options="yearOptions" v-model="year" @change="onYearChange"/>
        <van-dropdown-item :options="quarterOptions" v-model="quarter" @change="onQuarterChange"/>
        <van-dropdown-item :options="resultOptions" v-model="result" @change="onResultChange"/>
      </van-dropdown-menu>

      <van-dropdown-menu v-else>
        <van-dropdown-item :options="yearOptions" v-model="year" @change="onYearChange"/>
        <van-dropdown-item :options="resultOptions" v-model="result" @change="onResultChange"/>
      </van-dropdown-menu>
    </div>
    <div class="check-content">
      <van-pull-refresh v-model="loading" @refresh="onRefresh">
        <van-list v-model="loading"
                  finished-text="没有更多了"
                  :finished="finished"
                  :immediate-check="false"
                  :offset="10"
                  direction="down"
                  @load="onLoad">
          <CheckCard :item="item"
                    :key="index"
                    v-for="(item,index) in checkList" />
        </van-list>
      </van-pull-refresh>
    </div>
    <van-popup @click-overlay="switchShow"
               position="bottom"
               v-model="isShow">
      <van-picker :columns="styles"
                  @cancel="isShow = false"
                  @confirm="onConfirm"
                  show-toolbar />
    </van-popup>
  </div>
</template>

<script lang='ts'>
import { Component, Vue, Watch } from 'vue-property-decorator';
import CheckCard from '@/components/modules/personnel-manager/check/v-check-card/index.vue';
import CheckCardModel from '@/model/modules/personnel-manager/check/CheckCardModel';

// 案件
@Component({
  components: {
    CheckCard
  }
})
export default class Check extends Vue {
  private year: any = null;
  private yearOptions: any = [
    { text: '全部', value: null },
    { text: '2021', value: 2021 },
    { text: '2020', value: 2020 },
    { text: '2019', value: 2019 }
  ];

  private quarter: any = null;
  private quarterOptions: any = [
    { text: '全部', value: null },
    { text: '第一季度', value: 1 },
    { text: '第二季度', value: 2 },
    { text: '第三季度', value: 3 },
    { text: '第四季度', value: 4 }
  ];

  private result: any = null;
  private resultOptions: any = [
    { text: '全部', value: null },
    { text: '优秀', value: 1 },
    { text: '称职', value: 2 },
    { text: '基本称职', value: 3 },
    { text: '不称职', value: 4 },
    { text: '合格', value: 5 },
    { text: '基本合格', value: 6 },
    { text: '不合格', value: 7 },
    { text: '不定等次', value: 8 },
    { text: '不进行考核', value: 9 }
  ];

  // 时间
  private sureTime: string = '平时考核';
  // 搜索关键字
  private searchKey: string = '';
  // 是否显示
  private isShow: boolean = false;
  // 年份项
  private styles: string[] = ['平时考核', '年度考核'];
  // 案件数据
  private checkList: CheckCardModel[] = [];
  private timerLimit: any = null;

  // 满足条件案件数
  private conformCount: number = 0;
  private finished: boolean = false;
  private loading: boolean = false;
  private currentPage: number = 1;
  private pageSize: number = 10;

  private async created(): Promise<void> {
    // 获取案件列表
    this.checkList = [];
    await this.getCaseList(this.searchKey);
  }

  private onRefresh() {
    this.currentPage = 0;
    // 清空列表数据
    this.finished = false;
    // 重新加载数据
    // 将 loading 设置为 true，表示处于加载状态
    this.loading = true;
    this.checkList = [];
    this.getCaseList(this.searchKey);
  }

  private onYearChange(e) {
    this.year = e;
    this.currentPage = 0;
    // 清空列表数据
    this.loading = true;
    this.checkList = [];
    this.getCaseList(this.searchKey);
  }

  private onQuarterChange(e) {
    console.log(e);
    this.quarter = e;
    this.currentPage = 0;
    // 清空列表数据
    this.loading = true;
    this.checkList = [];
    this.getCaseList(this.searchKey);
  }

  private onResultChange(e) {
    console.log(e);
    this.result = e;
    this.currentPage = 0;
    // 清空列表数据
    this.loading = true;
    this.checkList = [];
    this.getCaseList(this.searchKey);
  }

  /**
   * 请求数据
   * @data :请求回来的数据
   * @res :处理过的数据
   * @params :传参对象，{ sureTime, searchKey}
   */
  private async getCaseList(searchKey: string): Promise<any> {
    // 封裝季度
    let jd: any = null;
    switch (this.quarter) {
     case 1: {
       jd = '第一季度';
       break;
     }
     case 2: {
       jd = '第二季度';
       break;
     }
     case 3: {
       jd = '第三季度';
       break;
     }
     case 4: {
       jd = '第四季度';
       break;
     }
    }

    if (this.sureTime === '年度考核') {
      // console.log("我是年度考核("+"yearOptions:"+yearOptions+"resultOptions:"+resultOptions+")")
      /** 年度考核的访问发起 */
      const that = this;
      let param = {
        year: this.year,
        name: searchKey,
        result: this.result,
        currentPage: that.currentPage ++,
        pageSize: that.pageSize
      };
      let res = await that.$api.xHttp.post(
          that.$interface.personalManager.checks.annual,
          param
      );
      if (res.code === 0) {
        const length = res.data.list.length;
        that.conformCount = res.data.total;
        let caseArr: CheckCardModel[] = [];
        if (length) {
          for (let i = 0; i < length; i++) {
            let caseCardModel = new CheckCardModel();
            const caseVO = res.data.list[i];
            caseCardModel.name = caseVO.name;
            caseCardModel.id = caseVO.id;
            caseCardModel.birthday = caseVO.birthday;
            caseCardModel.PriorWorkUnit = caseVO.PriorWorkUnit;
            caseCardModel.workTime = caseVO.workTime;
            caseCardModel.year = caseVO.annualAssessMent.year;
            // caseCardModel.quarter = caseVO.checkASordinarytimevo.quarter;
            caseCardModel.constructionName = caseVO.annualAssessMent.constructionName;
            // caseCardModel.performance = caseVO.annualAssessMent.performance;
            caseCardModel.photo = caseVO.photo;
            caseCardModel.registrationform = caseVO.annualAssessMent.registrationform;
            caseArr.push(caseCardModel);
          }
          that.finished = that.conformCount < that.currentPage * that.pageSize;
        } else {
          that.finished = true;
        }
        that.loading = false;
        this.checkList.push(...caseArr);
      } else {
        that.$toast(res.msg);
      }
    } else {
      /** 平时考核的访问发起 */
      const that = this;
      let param = {
        year: this.year,
        name: searchKey,
        result: this.result,
        quarter: jd,
        currentPage: that.currentPage ++,
        pageSize: that.pageSize
      };
      let res = await this.$api.xHttp.post(
          that.$interface.personalManager.checks.ordinary,
          param
      );
      if (res.code === 0) {
        const length = res.data.list.length;
        that.conformCount = res.data.total;
        let caseArr: CheckCardModel[] = [];
        if (length) {
          for (let i = 0; i < length; i++) {
            let caseCardModel = new CheckCardModel();
            const caseVO = res.data.list[i];
            caseCardModel.name = caseVO.name;
            caseCardModel.id = caseVO.id;
            caseCardModel.birthday = caseVO.birthday;
            caseCardModel.PriorWorkUnit = caseVO.PriorWorkUnit;
            caseCardModel.workTime = caseVO.workTime;
            caseCardModel.year = caseVO.checkASordinarytimevo.year;
            caseCardModel.quarter = caseVO.checkASordinarytimevo.quarter;
            caseCardModel.constructionName = caseVO.checkASordinarytimevo.constructionName;
            caseCardModel.performance = caseVO.checkASordinarytimevo.performance;
            caseCardModel.photo = caseVO.photo;
            caseCardModel.registrationform = caseVO.checkASordinarytimevo.registrationform;
            caseArr.push(caseCardModel);
          }
          that.finished = that.conformCount < that.currentPage * that.pageSize;
        } else {
          that.finished = true;
        }
        that.loading = false;
        this.checkList.push(...caseArr);
      } else {
        that.$toast(res.msg);
      }
    }
  }

  // 年份更改触发搜索
  @Watch('sureTime')
  private async watchSureTime(): Promise<void> {
    this.checkList = [];
    this.currentPage = 1; // 监听sure一改变就把页数变为1
    await this.getCaseList(this.searchKey);
  }

  // 时间选择显示控制
  private switchShow(): void {
    this.isShow = !this.isShow;
  }

  // 输入完触发搜索
  private handleSearch(): void {
    // 防抖节流
    clearTimeout(this.timerLimit);
    this.timerLimit = setTimeout(async () => {
      this.checkList = [];
      this.currentPage = 0;
      await this.getCaseList(this.searchKey);
    }, 1000);
  }

  // onConfirm
  private onConfirm(value: string): void {
    this.sureTime = value;
    this.isShow = false;
  }

  /**
   * 下拉加载
   */
  private onLoad() {
    this.getCaseList(this.searchKey);
  }
}
</script>

<style lang='less' scoped>
.check {
  &-head {
    padding: 30px;
    background-color: rgb(255, 255, 255);
    margin-bottom: 26px;
    height: 140px;

    .row {
      display: flex;
      border: 0;
      line-height: 72px;
      height: 72px;
      border-radius: 6px;
      overflow: hidden;
      .timer-select {
        width: 186px;
        text-align: center;
        font-size: 28px;
        font-weight: 500;
        height: 100%;
        background-color: #f2f2f2;
        i {
          vertical-align: middle;
        }

        .label {
          color: #333333;
          padding-right: 8px;
          vertical-align: middle;
        }
      }
      .search-box {
        display: flex;
        flex: 1;
        background-color: #f2f2f2;
      }
    }
  }

  &-content {
    .tips {
      padding: 30px 40px;
      font-size: 24px;
      color: rgba(153, 153, 153, 1);
    }
    margin-bottom: 17%;
  }

  // 重置vant组件样式
  .van-search__content {
    background-color: #f2f2f2;
  }

  .van-cell {
    padding: 0;
    box-sizing: border-box;
  }

  .van-search {
    width: 100%;
    padding: 0;
  }

  [class*="van-hairline"]::after {
    border: none;
  }
}
@dropdown-menu-title-padding: 6px;
</style>
