<template>
  <div class="home">
    <HomeCard :item="item" :key="index" v-for="(item,index) in cardList"/>
  </div>
</template>

<script lang='ts'>
import { Component, Vue } from 'vue-property-decorator';
import HomeCard from '../../../components/modules/personnel-manager/home/v-home-card/index.vue';
import HomeCardModel from '../../../model/modules/personnel-manager/home/HomeCardModel';

// 首页
@Component({
  components: {
    HomeCard
  }
})
export default class Home extends Vue {
  // 展示卡数据
  private cardList: HomeCardModel[] = [];

  private async created(): Promise<void> {
    this.cardList = [{
      data: '编内人员管理',
      prop: '展示管理编内人员信息',
      imgUrl: require('../../../assets/images/modules/personnel-manager/home-1.png'),
      route: '/personnelManager/person/list?state=0',
      query: {state: 1}
    }, {
      data: '编外人员管理',
      prop: '展示管理编外人员信息',
      imgUrl: require('../../../assets/images/modules/personnel-manager/home-2.png'),
      route: '/personnelManager/person/list?state=1'
    }, {
      data: '考核管理',
      prop: '展示平时和年度考核备案信息',
      imgUrl: require('../../../assets/images/modules/personnel-manager/home-3.png'),
      route: '/personnelManager/check'
    }, {
      data: '工会群团',
      prop: '管理工会群团事务',
      imgUrl: require('../../../assets/images/modules/personnel-manager/home-4.png'),
      route: '/personnelManager/union'
    }, {
      data: '培训管理',
      prop: '查看和维护培训信息',
      imgUrl: require('../../../assets/images/modules/personnel-manager/home-5.png'),
      route: '/personnelManager/train'
    }, {
      data: '统计报表',
      prop: '查看统计信息',
      imgUrl: require('../../../assets/images/modules/personnel-manager/home-6.png'),
      route: '/personnelManager/statistical'
    }] as HomeCardModel[];
  }
}
</script>

<style lang='less' scoped>
.home {
  position: absolute;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  background-color: #ffffff;
  padding: 30px;
  height: 1250px;
  &-title {
    font-size: 48px;
    font-weight: bold;
    margin-top: 30px;
    margin-bottom: 60px;
  }
}
</style>
