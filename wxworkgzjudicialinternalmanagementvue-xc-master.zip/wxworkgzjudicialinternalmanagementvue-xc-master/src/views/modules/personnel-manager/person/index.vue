<template>
  <div class="person">
    <div class="person-head">
      <!-- 选择部门 -->
      <div class="van-cell__value"
           style="overflow:inherit; margin-left: 18px;">
        <div class="van-field__body">
          <div @click="switchShow"
               class="show-btn department-name">
            <span>{{ selectDepartment }}</span>
            <van-icon name="arrow-down" />
          </div>
        </div>
      </div>
      <div class="person-head-search">
        <van-search @input="handleInput" placeholder="请输入搜索关键词" v-model="searchkey"/>
      </div>
      <div class="person-select">
        <ul>
          <li :class="optionIndex === 0 ? 'active' : ''" @click="optionIndex = 0">所有</li>
          <li :class="optionIndex === 1 ? 'active' : ''" @click="optionIndex = 1">本级及下级</li>
          <li :class="optionIndex === 2 ? 'active' : ''" @click="optionIndex = 2">离职</li>
          <li :class="optionIndex === 3 ? 'active' : ''" @click="optionIndex = 3">原任</li>
        </ul>
      </div>
    </div>
    <div style="margin-bottom: 60px;">
      <van-pull-refresh v-model="refreshing" @refresh="onRefresh">
        <van-list
          v-model="loading"
          :finished="finished"
          finished-text="没有更多了"
          @load="onLoad"
        >
          <PersonCard :item="item" :key="index" v-for="(item,index) in cardList"/>
        </van-list>
      </van-pull-refresh>
    </div>
    <!-- 所有部门 -->
    <van-popup v-model="show"
               @click-overlay="switchShow"
               close-icon="close"
               closeable
               :lazy-render="false"
               :style="{ height: '60%' }"
               position="bottom">
      <!-- <Tree></Tree> -->
      <DepartmentTree :data="departmentTreeData"
                      :isShow.sync="show"
                      @bindSend="propMsg" />
    </van-popup>
  </div>
</template>

<script lang='ts'>
import { Component, Vue, Watch } from 'vue-property-decorator';
import PersonCardModel from '@/model/modules/personnel-manager/person/PersonCardModel';
import PersonCard from '@/components/modules/personnel-manager/person/v-person-card/index.vue';
import DepartmentTree from '@/components/modules/attendance-manage/department-tree/index.vue';

@Component({
  components: {
    PersonCard,
    DepartmentTree
  }
})
export default class Person extends Vue {
  private searchkey: string = '';

  // 数据列表
  private cardList: PersonCardModel[] = [];

  private props: number = 0;
  private currentPage: number = 1;
  private pageSize: number = 10;

  private loading: boolean = false;
  private finished: boolean = false;
  private refreshing: boolean = false;

  /** 机构选择 */
  private show: boolean = false;
  private selectDepartmentSub: any = ''; // 辅助存储当前选中部门name
  private selectDepartmentId: any = null;
  private selectDepartmentIdSub: any = null; // 辅助存储当前选中部门id
  private departmentTreeData: any[] = [];
  private selectDepartment: string = '所有部门';
  private optionIndex: number = 0;
  /** 组织 */
  private organization: any = null;

  /** 测试数组 */
  private test: PersonCardModel[] = [];

  private stiffest: string;

  /** 一进来触发一次 */
  private async created(): Promise<void> {
    // this.search();
    // this.stiffest = this.$route.query.state;
    this.stiffest = this.$route.params.state;
    // console.log("我是stiffest"+this.stiffest)
    // this.cardList = [];
    // this.search();
  }

  private handleInput(): void {
    this.cardList = [];
    this.onRefresh();
  }

  @Watch('optionIndex')
  private watchOptionIndex(): void {
    this.cardList = [];
    this.currentPage = 1;
    this.search();
  }

  @Watch('searchkey')
  private watchSearch(): void {
    this.search();
  }

  @Watch('stiffest')
  private watchStiffest(): void {
    this.cardList = [];
    this.currentPage = 1;
    this.search();
  }

  // 切换部门
  private propMsg(id: any, name: string, show: boolean): void {
    this.show = show;
    this.selectDepartmentSub = name;
    this.selectDepartmentIdSub = id;
  }

  /**
   * 所有部门选择
   */

  // 切换显示
  private switchShow(): void {
    this.show = !this.show;
    this.listOrgs();

    this.$forceUpdate();

    // 部门列表
    this.show && this.search();
  }

  /**
   * 获取部门数据
   */
  private async listOrgs(): Promise<void> {
    const data = await this.$api.xHttp.get(this.$interface.personalManager.person.listOrgs);
    this.departmentTreeData = [data.data];
  }

  /**
   * 请求数据
   * @data : 请求回来的数据
   * @res :处理后的数据
   * @params :传参对象
   * @return ：返回的res满足PersonCardModel类型
   */
  private async search(): Promise<void> {

    // 本来的值

    let params = {
      name: this.searchkey,
      currentPage: this.currentPage,
      pageSize: this.pageSize,
      stiffest: this.$route.query.state,
      state: this.optionIndex,
      organization: this.selectDepartmentSub
    };
    const res = await this.$api.xHttp.post(
      this.$interface.personalManager.person.listStaff,
      params
    );
    if (res.code === 0) {
      // let list = res.data.list;
      // this.cardList = res.data.list
      this.props = res.data.total;
      let arr: PersonCardModel[] = res.data.list;
      // let arr: PersonCardModel[] = this.cardList;
      // this.test = res.data.list

      this.cardList.push(...arr);
      // this.cardList = this.test
      this.loading = false;
      this.currentPage++; // 取出可以出现
      this.finished = res.data.pageNum >= res.data.pages;
    } else {
      this.$toast(res.msg);
    }
  }

  /**
   * 上拉刷新
   */
  private async onLoad(): Promise<void> {
    if (this.refreshing) {
      this.cardList = [];
      this.refreshing = false;
      this.search();
    }
    if (this.cardList.length !== 0) {
      this.search();
    }

  }

  private onRefresh() {
    this.currentPage = 1;
    // 清空列表数据
    this.finished = false;
    // 重新加载数据
    // 将 loading 设置为 true，表示处于加载状态
    this.loading = true;
    // this.cardList = [];
    // debugger
    this.onLoad();
  }

  private activated() {
    // 清除已选部门缓存
    window.sessionStorage.removeItem('selectedDepartment');
    this.selectDepartment = '所有部门';
    this.selectDepartmentId = null;
    this.departmentTreeData = [];
    this.organization = null;
    this.selectDepartmentSub = null;
    // if (this.cardList == []){
    this.currentPage = 1;
    this.search();
    // }
    this.cardList = [];

    // this.search();
    // this.search();

    // 删除一进来的搜索
    this.searchkey = '';
  }

  // 监听部门弹窗关闭时获取最新部门id以及数据
  @Watch('show')
  private async watchDepartmentShow(): Promise<void> {
    if (!this.show) {
      this.selectDepartmentSub &&
      (this.selectDepartment = this.selectDepartmentSub);
      this.selectDepartmentIdSub &&
      (this.selectDepartmentId = this.selectDepartmentIdSub);
      this.refreshing = true;
      this.onRefresh();
    }
  }
}
</script>

<style lang='less' scoped>
  .person {
    &-head {
      background-color: #ffffff;
      height: 280px;
      margin-bottom: 26px;
      &-search {
        padding: 0 18px;
      }
    }
    &-select {
      height: 46px;
      line-height: 46px;
    }
    ul {
      display: flex;
      justify-content: center;
    }
    li {
      height: 80px;
      line-height: 80px;
      font-size: 28px;
      color: #666666;
      display: inline-block;
      min-width: 120px;
      margin: 0 24px;
      text-align: center;
    }
    .active {
      color: #0D61FE;
      border-bottom: 6px solid #0D61FE;
    }
  }

  .van-hairline--top-bottom::after,
  .van-hairline-unset--top-bottom::after {
    border: none;
  }

  /deep/ .van-dropdown-menu {
    height: 0.9rem;
  }

  .van-search {
    padding: 15px;
  }
  .van-field__body{
    font-size: 32px;
    font-family: PingFang SC;
    font-weight: 500;
    color: #333333;
  }
</style>
