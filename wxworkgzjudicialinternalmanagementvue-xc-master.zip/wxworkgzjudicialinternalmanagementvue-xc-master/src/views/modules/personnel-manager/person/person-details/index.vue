<template>
  <div class="appraiser-details">
    <div class="appraiser-details-base">
      <div class="title">
        <span class="text1">{{ personDetail.name }}</span>
        <!--        <span class="text1">{{ personDetail.name }}</span>-->
      </div>
      <p class="text4">出生年月：{{ personDetail.birthday }}</p>
      <p class="text4">籍贯：{{ personDetail.nativePlace }}</p>
      <p class="text4">所在单位：{{ personDetail.units }}</p>
      <p class="text4">政治面貌：{{ personDetail.politicsStatusName}}</p>
      <p class="text4">参加工作时间：{{ personDetail.workTime }}</p>
      <p class="text4">身份证号码：{{ personDetail.idCar }}</p>
      <p class="text4">专业技术职务：{{ personDetail.post }}</p>
      <p class="text4">现工作单位及职务简称：{{ personDetail.PriorWorkUnit }}</p>
      <p class="text4">毕业学校：{{ personDetail.schoolOfGraduation }}</p>
      <p class="text4">所学专业：{{ personDetail.major }}</p>
      <p class="text4">毕业时间：{{ personDetail.Graduation }}</p>
      <p class="text4">最高学历：{{ personDetail.officialAcademicCredentials }}</p>
      <div class="img-box">
        <img :src="personDetail.photo" />
      </div>
    </div>
    <div class="appraiser-details-credit">
      <div class="appraiser-details-credit-panel">
        <div class="appraiser-details-credit-panel-head">
          <!--          <span class="text2">考核状况</span>-->
          <!--          <span class="text2">奖罚状况</span>-->
          <!--          <span class="text2">家庭成员</span>-->

          <!--              <p class="text2">考核状况</p>-->
          <!--              <p>你好</p>-->
          <!--              <p>世界</p>-->

          <!--  白色  -->
          <div style="background-color:#FFFFFF">
            <div class="person-select">
              <ul>
                <li :class="optionIndex === 0 ? 'active' : ''"
                    @click="optionIndex = 0">平时考核</li>
                <li :class="optionIndex === 1 ? 'active' : ''"
                    @click="optionIndex = 1">年度考核</li>
              </ul>
              <ul>
                <li class="test02">考核年度</li>
                <li class="test02"
                    v-if="this.optionIndex == 0">考核季度</li>
                <li class="test02"
                    v-if="this.optionIndex == 0">考核分数</li>
                <li class="test02">考核结果</li>
              </ul>
              <!--     平时考核年度考核的渲染       -->
              <div>
                <div v-for="item in checklist"
                     :key="item.checklist">
                  <ul>
                    <li class="test02">{{item.year}}</li>
                    <li class="test02"
                        v-if="item.quarter!=null">{{item.quarter}}</li>
                    <li class="test02"
                        v-if="item.performance!=null">{{item.performance}}</li>
                    <li class="test02">{{item.constructionName}}</li>
                  </ul>
                </div>
              </div>
              <!--   渲染结束         -->
            </div>
            <p class="text2">奖罚状况</p>
            <div class="test03"
                 v-for="item in RqList"
                 :key="item.RqList">
              <div class="test01">
                <p class="text6">奖惩名称: {{item.name}}</p>
                <p class="text6">批准机关名称: {{item.officeName}}</p>
                <p class="text6">批准日期: {{item.approvalTime}}</p>
                <p class="text6">撤销日期: {{item.endTime}}</p>
              </div>
            </div>

            <p class="text2">家庭成员</p>
            <div class="test03"
                 v-for="item in familyList"
                 :key="item.familyList">
              <div class="test01">
                <p class="text6">姓名: {{item.name}}</p>
                <p class="text6">称谓: {{item.title}}</p>
                <p class="text6">政治面貌: {{item.politicsStatusName}}</p>
                <p class="text6">出生日期: {{item.birthday}}</p>
                <p class="text6">工作单位及职务: {{item.units}}</p>
              </div>
            </div>
          </div>
          <!--   结束    -->
        </div>
        <div class="appraiser-details-credit-panel-list">

        </div>
      </div>
    </div>
  </div>
</template>

<script lang='ts'>
import RewardAndPunish from '@/model/modules/personnel-manager/person/RewardAndPunish';
import { Component, Vue, Watch } from 'vue-property-decorator';
import CreditInfo from '@/components/modules/judicial-expertise/appraisal-institution/v-credit-info/index.vue';
import AppraiserDetailsModel from '@/model/modules/judicial-expertise/appraiser/AppraiserDetailsModel';
import Family from '@/model/modules/personnel-manager/person/Family';
import CheckCardModel from '@/model/modules/personnel-manager/check/CheckCardModel';

@Component({
  components: {
    CreditInfo
  }
})
export default class AppraiserDetails extends Vue {
  // 年份
  private year: number = 0;
  // 年份数组
  private yearArr: number[] = [];
  // id
  private id: string = '';
  private state: string = 'primary';
  // 鉴定人详情数据
  private personDetail: AppraiserDetailsModel = new AppraiserDetailsModel();
  // 家庭详信息
  private familyList: Family[] = [];
  // 奖罚详细信息
  private RqList: RewardAndPunish[] = [];
  // 定义点击变量
  private optionIndex: number = 0;
  // 考核年度的数组
  private checklist: CheckCardModel[] = [];

  @Watch('optionIndex')
  private watchOptionIndex(): void {
    this.checklist = [];
    this.checks();
  }

  private async activated(): Promise<void> {
    await this.getID();
    await this.getAppraiser();
    await this.setState();
    await this.getFamily();
    await this.getRq();
    await this.checks();
  }

  private getID() {
    this.id = this.$route.query.id as string;
  }

  private getYear(): void {
    if (this.yearArr.length !== 0) {
      return;
    }
    const curYear = new Date().getFullYear();
    this.year = curYear;
    for (let i = 0; i < 5; i++) {
      this.yearArr.push(curYear - i);
    }
  }

  private setState(): void {
    if (this.personDetail.state === '暂停') {
      this.state = 'warning';
    } else if (this.personDetail.state === '注销') {
      this.state = 'danger';
    }
  }

  /**
   * 获取数据
   * @data :请求数据
   * @res :处理之后数据
   * @params :id
   */
  private async getAppraiser(): Promise<void> {
    const id = this.$route.query.id;
    const data = await this.$api.xHttp.get(
      this.$interface.personalManager.person.listPeople,
      { id }
    );
    const res = new AppraiserDetailsModel();
    const object = data.data;
    res.name = object.name;
    res.sex = object.sex;
    res.birthday = object.birthday;
    res.nativePlace = object.nativePlace;
    res.units = object.units;
    res.politicsStatusName = object.politicsStatusName;
    res.workTime = object.workTime;
    res.idCar = object.idCar;
    res.post = object.post;
    res.PriorWorkUnit = object.PriorWorkUnit;
    res.schoolOfGraduation = object.schoolOfGraduation;
    res.major = object.major;
    res.Graduation = object.Graduation;
    res.officialAcademicCredentials = object.officialAcademicCredentials;
    res.photo = object.photo;
    res.creditList = [0, 0, 0, 1, 0, 1, 0];

    this.personDetail = res;
  }

  /** 平时考核和年度考核的请求 */
  private async checks(): Promise<void> {
    const id = this.$route.query.id;

    if (this.optionIndex === 0) {
      // 如果是平时考核
      const res = await this.$api.xHttp.get(
        this.$interface.personalManager.checks.OrdinaryTimeById,
        { id }
      );
      this.checklist = res.data;
    } else if (this.optionIndex === 1) {
      // 年度考核
      const res = await this.$api.xHttp.get(
        this.$interface.personalManager.checks.AnnualById,
        { id }
      );
      this.checklist = res.data;
    }
  }

  /** 家庭成员的请求 */
  private async getFamily(): Promise<void> {
    const id = this.$route.query.id;
    const res = await this.$api.xHttp.get(
      this.$interface.personalManager.person.listFamily,
      { id }
    );
    if (res.code === 0) {
      this.familyList = res.data;
    }
  }

  /** 奖罚情况请求 */
  private async getRq(): Promise<void> {
    const id = this.$route.query.id;
    const res = await this.$api.xHttp.get(
      this.$interface.personalManager.person.listRp,
      { id }
    );
    if (res.code === 0) {
      this.RqList = res.data;
    }
  }

  /**
   * 获取信用数据
   * @data :请求数据
   * @res :处理数据
   * @params :year,id
   */
  private async getCreditList(year: number): Promise<void> {
    // const data = this.$api
    const res = [0, 23, 4, 4, 4, 10, 0] as number[];
    this.personDetail.creditList = res;
    console.log('执行了');
  }
}
</script>

<style lang='less' scoped>
.appraiser-details {
  .text1 {
    font-size: 36px !important;
    color: rgba(51, 51, 51, 1) !important;
  }
  &-base {
    padding: 48px 30px;
    background-color: #ffffff;
    position: relative;

    .title {
      display: flex;
      align-items: center;
      margin: 20px 0;
      span {
        margin-right: 12px;
      }
    }

    .img-box {
      position: absolute;
      width: 190px;
      height: 190px;
      background-color: #666666;
      top: 68px;
      right: 30px;
    }
  }

  &-credit {
    &-panel {
      background-color: #ffffff;
      margin-top: 20px;

      &-head {
        //padding: 0 30px;
        height: 102px;
        border-bottom: 1px solid #eeeeee;
        //display: flex;
        justify-content: space-between;
        align-items: center;
        //margin: 0 0 0 0px;
        i {
          font-size: 34px;
        }
      }

      &-list {
        padding: 30px;
        overflow: hidden;

        .more-btn {
          padding: 20px 0;
          display: flex;
          justify-content: flex-end;
          .btn {
            width: 154px;
            height: 56px;
            box-sizing: border-box;
            border: 1px solid #0a5ffe;
            border-radius: 6px;
            font-size: 28px;
            color: #0a5ffe;
            text-align: center;
            line-height: 56px;
          }
        }

        .certificate {
          margin-top: 24px;
          .title {
            display: flex;
            align-items: center;
            font-size: 32px;
            .blue {
              width: 10px;
              height: 32px;
              margin-right: 24px;
              background: rgba(10, 95, 254, 1);
              border-radius: 5px;
            }
          }
        }

        .credit-list {
          display: flex;
          padding: 0 30px;
          justify-content: space-between;
          font-size: 28px;
          color: #333333;
          margin: 30px 0;

          span {
            color: #999999;
          }

          .red {
            color: #f84242;
          }
        }
      }
    }
  }
}

.timer-select {
  .timer {
    width: 184px;
    height: 56px;
    background: rgba(247, 247, 247, 1);
    border: 1px solid rgba(230, 230, 230, 1);
    border-radius: 28px;
    text-align: center;
    line-height: 56px;
    font-size: 24px;
    color: #666666;

    .year {
      padding-right: 12px;
    }

    span {
      vertical-align: middle;
    }
  }
}
.text1:last-child {
  margin-left: 12px;
  padding-left: 12px;
  font-size: 28px;
  color: #666;
  line-height: 32px;
  height: 32px;
  border-left: 1px solid #eee;
}
.text7 {
  width: 250px;
  height: 26px;
  font-size: 28px;
  font-family: PingFang SC;
  font-weight: 500;
  color: #666666;
}
.text6 {
  width: 800px;
  height: 40px;
  font-size: 28px;
  font-family: PingFang SC;
  font-weight: 500;
  color: #666666;
}
//.person-select{
//  height: 46px;
//  line-height: 46px;
//}
ul {
  display: flex;
  //justify-content: center;
  padding: 0 0 0 0px;
}
li {
  height: 80px;
  line-height: 80px;
  font-size: 32px;
  font-weight: bold;
  color: #333333;
  display: inline-block;
  width: 200px;
  margin: 0 10px;
  text-align: center;
}
.active {
  color: #0d61fe;
  border-bottom: 6px solid #0d61fe;
  width: 200px;
  height: -20px;
  font-size: 32px;
  font-family: PingFang SC;
  font-weight: bold;
  color: #333333;
  //text-align:left;
}
.test01 {
  margin: 35px 0px 35px 0px;
}
.test02 {
  width: 200px;
  height: 100px;
  font-size: 28px;
  font-family: PingFang SC;
  font-weight: 500;
  color: #666666;
}
.test03 {
  margin: 0 0 0 30px;
  padding-bottom: 60px;
}
.text2 {
  margin: 0 0 0 30px;
}
</style>
