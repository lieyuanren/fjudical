<template>
  <div>
    <div class="statistical-analysis-show"
         v-if="!isArr">
      <div class="statistical-analysis-show-title">
        <h3>{{ obj.title }}</h3>
      </div>
      <div class="statistical-analysis-show-content"
           v-for="(item, idx) in obj.arr" :key="idx">
        <div class="statistical-analysis-show-item"
             v-for="(it, itIdx) in item"
             :key="itIdx">
          <div class="statistical-analysis-show-item-title">{{ it.title }}</div>
          <div class="statistical-analysis-show-item-num">{{ it.num }}</div>
        </div>
      </div>
    </div>
    <div class="statistical-analysis-show"
         v-else>
      <div style="display: flex;">
        <div :class="index === idx ? 'statistical-analysis-show-title active' : 'statistical-analysis-show-title'"
             v-for="(title, idx) in obj.titles"
             :key="idx"
             @click="index = idx">
          <h3>{{ title }}</h3>
        </div>
      </div>
      <div class="statistical-analysis-show-content bot-content"
           v-for="(item, idx) in obj.datas[index]" :key="idx">
        <div class="statistical-analysis-show-item bot-item"
             v-for="(it, itIdx) in item"
             :key="itIdx">
          <div class="statistical-analysis-show-item-title">{{ it.title }}</div>
          <div class="statistical-analysis-show-item-num">{{ it.num }}</div>
        </div>
      </div>
    </div>
  </div>
</template>

<script lang='ts'>
import {Component, Prop, Vue} from 'vue-property-decorator';

@Component({})
export default class Appraiser extends Vue {
  @Prop({
    type: Object,
    default: () => {
      return {};
    }
  })
  private readonly obj!: any;

  @Prop({
    type: Boolean,
    default: () => false
  })
  private readonly isArr: boolean;

  /** 选中索引 */
  private index: number = 0;
}
</script>

<style lang='less' scoped>
  .statistical-analysis-show {
    min-height: 200px;
    width: 94%;
    background: #ffffff;
    margin: 60px auto 0 auto;
    border-radius: 12px;
    padding: 25px 30px;
    box-sizing: border-box;
    &-title {
      margin-top: 12px;
      margin-right: 56px;
    }
    &-content {
      display: flex;
      justify-content: center;
      flex-wrap: wrap;
    }
    &-item {
      //width: 33.333%;
      flex: 1;
      text-align: center;
      //flex-shrink: 1;
      margin: 20px 0;
      &-title {
        height: 46px;
        line-height: 46px;
        font-size: 26px;
        font-weight: 500;
        color: #999999;
      }
      &-num {
        font-size: 36px;
        font-weight: bold;
        color: #333333;
      }
    }
    &-item:not(:first-child) {
      border-left: 1px solid #EEEEEE;
    }
  }
  .statistical-analysis-show:last-child {
    margin-bottom: 60px;
  }
  .active {
    padding-bottom: 12px;
    border-bottom: 5px solid #0D61FE;
  }

  .bot-item {
    width: 32.3%;
    flex: none;
  }

  .bot-content {
    justify-content: flex-start;
  }
</style>
