<template>
  <div class="statistical-analysis">
    <div class="statistical-analysis-head">
      <div :class="{'statistical-analysis-head-btn' : true, 'active' : activeIndex === 0}"
           @click="clickBtn(0)">编内人员
      </div>
      <div :class="{'statistical-analysis-head-btn' : true, 'active' : activeIndex === 1}"
           @click="clickBtn(1)">编外人员
      </div>
    </div>
    <div class="statistical-analysis-person">
      <div class="statistical-analysis-person-top">
        <h3>基层法律工作人员概况</h3>
      </div>
      <div class="statistical-analysis-person-bottom">
        <canvas id="myChart1"
                style="width:100%;height:200px;"></canvas>
      </div>
    </div>

    <!-- 年龄分布 -->
    <show :obj="ageStatic"></show>

    <!-- 学历情况 -->
    <show :obj="studyStatic"></show>

    <!-- 政治面貌 -->
    <show :obj="proxyStatic"></show>

    <!-- 现职务层次、现职级、现任警衔 -->
    <show :obj="threeStatic" :isArr="true"></show>
  </div>
</template>

<script lang='ts'>
import PieType from '@/model/common/f2/PieType';
import pieInfo from '@/plugins/antv-f2/pieInFo';
import Show from './components/v-show/index.vue';
import {Component, Vue, Watch} from 'vue-property-decorator';

@Component({
  components: {
    Show
  }
})
export default class StatisticalAnalysis extends Vue {
  private activeIndex: number = 0;
  private personData: any[] = [];
  private one: number = 0;

  /** 年龄分布 */
  private ageStatic: any = {
    title: '年龄分布',
    arr: [
      [{
        title: '65岁以上',
        num: 2
      }, {
        title: '50到64岁',
        num: 249
      }],
      [{
        title: '30到49岁',
        num: 249
      }, {
        title: '29岁以下',
        num: 249
      }]
    ]
  };

  /** 学历情况 */
  private studyStatic: any = {
    title: '学历情况',
    arr: [
      [{
        title: '研究生教育',
        num: 1
      }, {
        title: '本专科教育',
        num: 2
      }, {
        title: '中等职业学校',
        num: 3
      }],
      [{
        title: '高中',
        num: 4
      }, {
        title: '高中以下',
        num: 5
      }, {
        title: '',
        num: ''
      }]
    ]
  };

  /** 政治面貌 */
  private proxyStatic: any = {
    title: '政治面貌',
    arr: [
      [{
        title: '中共党员',
        num: 249
      }, {
        title: '非中共党员',
        num: 249
      }]
    ]
  };

  /** 现职务层次、现职级、现任警衔 */
  private threeStatic: any = {
    titles: [
      '现职务层次',
      '现职级',
      '现任警衔'
    ],
    datas: [
      [
        [{
          title: '国家级正职',
          num: 1
        }, {
          title: '国家副级',
          num: 249
        }, {
          title: '省部级正职',
          num: 249
        }, {
          title: '省部级副职',
          num: 249
        }, {
            title: '厅局级正职',
            num: 1
        }, {title: '厅局级副职', num: 1},
          {title: '县处级正职', num: 1 },
          {title: '县处级副职', num: 1},
          {title: '乡科级正职', num: 1},
          {title: '乡科级副级', num: 1},
          {title: '科员', num: 1},
          {title: '办事员', num: 1},
          {title: '试用期人员', num: 1},
          {title: '其他(公务员)', num: 1}
          ]
      ],
      // 这里是另外一个数组
      [
        [{
          title: '一级巡视员',
          num: 249
        }, {
          title: '二级巡视员',
          num: 249
        }, {
          title: '一级调研员',
          num: 249
        }, {
          title: '二级调研员',
          num: 249
        }, {
          title: '三级调研员',
          num: 249
        }, {
          title: '四级调研员',
          num: 249
        }, {
          title: '一级主任科员',
          num: 249
        }, {
          title: '二级主任科员',
          num: 249
        }, {
          title: '三级主任科员',
          num: 249
        }, {
          title: '四级主任科员',
          num: 249
        }, {
          title: '一级科员',
          num: 249
        }, {
          title: '二级科员',
          num: 249
        }]
      ],
      // 这里是另外一个数组
      [
        [{
          title: '一级警监',
          num: 249
        }, {
          title: '二级警监',
          num: 249
        }, {
          title: '三级警监',
          num: 249
        }, {
          title: '一级警督',
          num: 249
        }, {
          title: '二级警督',
          num: 249
        }, {
          title: '三级警督',
          num: 249
        }, {
          title: '一级警司',
          num: 249
        }, {
          title: '二级警司',
          num: 249
        }, {
          title: '三级警司',
          num: 249
        }, {
          title: '一级警员',
          num: 249
        }, {
          title: '二级警员',
          num: 249
        }]
      ]
    ]
  };

  public mounted(): void {
    this.initSexData();
  }

  private async initSexData() {
    const res = await this.$api.xHttp.get(
        this.$interface.personalManager.statistical.list, {staff: this.activeIndex}
    );
    console.log(this.studyStatic.arr[0][0].num);
    // 年龄分布
    this.ageStatic.arr[0][0].num = res.data.getSixtyFive;
    this.ageStatic.arr[0][1].num = res.data.fiftyToSixtyFour;
    this.ageStatic.arr[1][0].num = res.data.thirtyNineToFortyNine;
    this.ageStatic.arr[1][1].num = res.data.underTwentyNine;
    // 学历情况数据
    this.studyStatic.arr[0][0].num = res.data.background.yjbackground;
    this.studyStatic.arr[0][1].num = res.data.background.bzbackground;
    this.studyStatic.arr[0][2].num = res.data.background.zdbackground;
    this.studyStatic.arr[1][0].num = res.data.background.gzbackground;
    this.studyStatic.arr[1][1].num = res.data.background.gzyxbackground;
    // 政治面貌数据
    this.proxyStatic.arr[0][0].num = res.data.politicsStatus.partymember;
    this.proxyStatic.arr[0][1].num = res.data.politicsStatus.notpartymember;
    // 现职务层次
    this.threeStatic.datas[0][0][0].num = res.data.currentPositionLevelVo.nationalLevelJob;
    this.threeStatic.datas[0][0][1].num = res.data.currentPositionLevelVo.deputyNationalLevel;
    this.threeStatic.datas[0][0][2].num = res.data.currentPositionLevelVo.provincialAndMinisterialPosts;
    this.threeStatic.datas[0][0][3].num = res.data.currentPositionLevelVo.deputyProvincialAndMinisterialPosts;
    this.threeStatic.datas[0][0][4].num = res.data.currentPositionLevelVo.departmentBureauLevel;
    this.threeStatic.datas[0][0][5].num = res.data.currentPositionLevelVo.departmentBureauLevelDeputyPost;
    this.threeStatic.datas[0][0][6].num = res.data.currentPositionLevelVo.countyLevelOfficialPost;
    this.threeStatic.datas[0][0][7].num = res.data.currentPositionLevelVo.countyLevelDeputyPost;
    this.threeStatic.datas[0][0][8].num = res.data.currentPositionLevelVo.mainpostAtTownshipLevel;
    this.threeStatic.datas[0][0][9].num = res.data.currentPositionLevelVo.deputyLevelOfTownshipSection;
    this.threeStatic.datas[0][0][10].num = res.data.currentPositionLevelVo.sectionMember;
    this.threeStatic.datas[0][0][11].num = res.data.currentPositionLevelVo.officeclerk;
    this.threeStatic.datas[0][0][12].num = res.data.currentPositionLevelVo.personnelOnProbation;
    this.threeStatic.datas[0][0][13].num = res.data.currentPositionLevelVo.rests;
    // 现职级
    this.threeStatic.datas[1][0][0].num = res.data.currentLevelVo.inspectorI;
    this.threeStatic.datas[1][0][1].num = res.data.currentLevelVo.inspectorII;
    this.threeStatic.datas[1][0][2].num = res.data.currentLevelVo.researcherI;
    this.threeStatic.datas[1][0][3].num = res.data.currentLevelVo.researcherII;
    this.threeStatic.datas[1][0][4].num = res.data.currentLevelVo.researcherIII;
    this.threeStatic.datas[1][0][5].num = res.data.currentLevelVo.researcherIV;
    this.threeStatic.datas[1][0][6].num = res.data.currentLevelVo.classIChiefSectionMember;
    this.threeStatic.datas[1][0][7].num = res.data.currentLevelVo.classIIChiefSectionMember;
    this.threeStatic.datas[1][0][8].num = res.data.currentLevelVo.classIIIChiefSectionMember;
    this.threeStatic.datas[1][0][9].num = res.data.currentLevelVo.classIVChiefSectionMember;
    this.threeStatic.datas[1][0][10].num = res.data.currentLevelVo.clerkI;
    this.threeStatic.datas[1][0][11].num = res.data.currentLevelVo.clerkII;
    // 现任警绗
    this.threeStatic.datas[2][0][0].num = res.data.theCurrentTitleVo.commissionerI;
    this.threeStatic.datas[2][0][1].num = res.data.theCurrentTitleVo.commissionerII;
    this.threeStatic.datas[2][0][2].num = res.data.theCurrentTitleVo.commissionerIII;
    this.threeStatic.datas[2][0][3].num = res.data.theCurrentTitleVo.policesupervisorI;
    this.threeStatic.datas[2][0][4].num = res.data.theCurrentTitleVo.policesupervisorII;
    this.threeStatic.datas[2][0][5].num = res.data.theCurrentTitleVo.policesupervisorIII;
    this.threeStatic.datas[2][0][6].num = res.data.theCurrentTitleVo.superintendentI;
    this.threeStatic.datas[2][0][7].num = res.data.theCurrentTitleVo.superintendentII;
    this.threeStatic.datas[2][0][8].num = res.data.theCurrentTitleVo.superintendentIII;
    this.threeStatic.datas[2][0][9].num = res.data.theCurrentTitleVo.policeconstableI;
    this.threeStatic.datas[2][0][10].num = res.data.theCurrentTitleVo.policeconstableII;

    // console.log(this.ageStatic.arr[0][0].num)
    let womanSum = res.data.woman;
    let manSum = res.data.man;
    let personSum = res.data.headcount;
    const p = new PieType();
    p.type = '女性';
    p.precent = parseFloat(
      ((womanSum / personSum) * 100).toFixed(1));
    p.num = womanSum;
    const p1 = new PieType();
    p1.type = '男性';
    p1.precent = parseFloat(((manSum / personSum) * 100).toFixed(1));
    p1.num = manSum;
    this.personData = [];
    this.personData.push(p1);
    this.personData.push(p);
    // 调用antv/f2组件
    pieInfo('myChart1', this.personData, ['#1F80F1', '#E55857'], '人');
  }

  private clickBtn(index: number): void {
    this.activeIndex = index;
  }

  @Watch('activeIndex')
  private watchActiveIndex(): void {
    // todo
    this.initSexData();
  }
}
</script>

<style lang='less' scoped>
  .statistical-analysis {
    &-head {
      height: 238px;
      padding: 30px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      background: url(../../../../assets/images/modules/notarization/index/bg@2x.png) no-repeat;
      background-size: 132%;

      &-btn {
        width: 320px;
        height: 90px;
        background-color: #ffffff;
        border-radius: 8px;
        font-size: 32px;
        color: #666666;
        text-align: center;
        line-height: 90px;
      }

      .active {
        background-color: #0a5ffe;
        color: #ffffff;
      }
    }

    .timer-box {
      margin: 34px 30px;

      &-select {
        width: 184px;
        height: 56px;
        background: rgba(255, 255, 255, 1);
        border: 1px solid rgba(230, 230, 230, 1);
        border-radius: 28px;
        text-align: center;
        font-size: 24px;
        color: #666666;
        line-height: 56px;

        span {
          padding-right: 12px;
        }

        span,
        i {
          vertical-align: middle;
        }
      }
    }
    &-person {
      min-height: 200px;
      width: 94%;
      background: #ffffff;
      margin: 0 auto;
      margin-top: 60px;
      border-radius: 12px;

      &-top {
        padding-left: 30px;
        position: relative;
        top: 25px;
      }

      &-bottom {
        min-height: 200px;
        padding: 0 30px 30px 30px;
      }
    }
    &-content {
      display: flex;

    }
    &-show {
      min-height: 200px;
      width: 94%;
      background: #ffffff;
      margin: 60px auto 0 auto;
      border-radius: 12px;
      padding: 25px 30px;
      box-sizing: border-box;
      &-content {
        display: flex;
        justify-content: center;
      }
      &-item {
        flex: 1;
        text-align: center;

        margin: 20px 0;
        &-title {
          height: 46px;
          line-height: 46px;
          font-size: 26px;
          font-weight: 500;
          color: #999999;
        }
        &-num {
          font-size: 36px;
          font-weight: bold;
          color: #333333;
        }
      }
      &-item:not(:first-child) {
        border-left: 1px solid #EEEEEE;
      }
    }
    &-show:last-child {
      margin-bottom: 60px;
    }
  }
</style>
