<template>
  <div class="person">
    <div class="person-head">
      <div class="person-head-search">
        <van-search @input="handleInput" placeholder="请输入搜索关键词" v-model="searchkey"/>
      </div>
      <div class="person-select">
        <ul>
          <li :class="optionIndex === 1 ? 'active' : ''" @click="optionIndex = 1">工会</li>
          <li :class="optionIndex === 2 ? 'active' : ''" @click="optionIndex = 2">妇委会</li>
          <li :class="optionIndex === 3 ? 'active' : ''" @click="optionIndex = 3">共青团</li>
        </ul>
      </div>
    </div>
    <div style="margin-bottom: 60px;">
      <van-pull-refresh v-model="refreshing" @refresh="onRefresh">
        <van-list
          v-model="loading"
          :finished="finished"
          finished-text="没有更多了"
          @load="onLoad"
        >
          <PersonCard :item="item" :key="index" v-for="(item,index) in cardList"/>
        </van-list>
      </van-pull-refresh>
    </div>
  </div>
</template>

<script lang='ts'>
import TrainCardModel from '@/model/modules/personnel-manager/train/TrainCardModel';
import { Component, Vue, Watch } from 'vue-property-decorator';
import PersonCardModel from '@/model/modules/personnel-manager/person/PersonCardModel';
import PersonCard from '@/components/modules/personnel-manager/person/v-person-card/index.vue';

@Component({
  components: {
    PersonCard
  }
})
export default class Person extends Vue {
  private searchkey: string = '';

  // 数据列表
  private cardList: PersonCardModel[] = [];

  private props: number = 0;
  private currentPage: number = 1;
  private pageSize: number = 10;

  private loading: boolean = false;
  private finished: boolean = false;
  private refreshing: boolean = false;

  private optionIndex: number = 1;

  private async created(): Promise<void> {
    // this.search();
  }

  private handleInput(): void {
    this.cardList = [];
    this.onRefresh();
  }

  @Watch('optionIndex')
  private watchOptionIndex(): void {
    this.cardList = [];
    this.currentPage = 1;
    this.search();
  }

  /**
   * 请求数据
   * @data : 请求回来的数据
   * @res :处理后的数据
   * @params :传参对象
   * @return ：返回的res满足PersonCardModel类型
   */
  private async search(): Promise<void> {
    // let arr: PersonCardModel[] = [];
    // arr.push({
    //   name: '张晓明',
    //   position: '主任',
    //   birthDate: '1998-03-02',
    //   imgUrl: 'https://wework.qpic.cn/wwhead/nMl9ssowtibVGyrmvBiaibzDjb2icgTBhjkjrv8FRKDtM6CEHlp75AV4Spr4VWewWXGMMlnibLxZJoEY/0'
    // } as PersonCardModel, {
    //   name: '张晓明',
    //   position: '主任',
    //   birthDate: '1998-03-02',
    //   imgUrl: 'https://wework.qpic.cn/wwhead/nMl9ssowtibVGyrmvBiaibzDjb2icgTBhjkjrv8FRKDtM6CEHlp75AV4Spr4VWewWXGMMlnibLxZJoEY/0'
    // } as PersonCardModel);
    // this.cardList.push(...arr);
    // this.loading = false;

    let params = {
      name: this.searchkey,
      currentPage: this.currentPage,
      pageSize: this.pageSize,
      state: this.optionIndex
    };
    const res = await this.$api.xHttp.post(
      this.$interface.personalManager.union.listunion,
      params
    );
    if (res.code === 0) {
      let list = res.data.list;
      this.props = res.data.total;
      // let arr: TrainCardModel[] = list;
      let arr: TrainCardModel[] = list;


      this.cardList.push(...arr);
      this.loading = false;
      this.currentPage++;
      this.finished = res.data.pageNum >= res.data.pages;
    } else {
      this.$toast(res.msg);
    }
  }

  /**
   * 上拉刷新
   */
  private async onLoad(): Promise<void> {
    if (this.refreshing) {
      this.cardList = [];
      this.refreshing = false;
    }
    await this.search();
  }

  private onRefresh() {
    this.currentPage = 1;
    // 清空列表数据
    this.finished = false;
    // 重新加载数据
    // 将 loading 设置为 true，表示处于加载状态
    this.loading = true;
    this.onLoad();
  }
}
</script>

<style lang='less' scoped>
  .person {
    &-head {
      background-color: #ffffff;
      height: 180px;
      margin-bottom: 26px;
      &-search {
        padding: 0 18px;
      }
    }
    &-select {
      height: 46px;
      line-height: 46px;
    }
    ul {
      display: flex;
      justify-content: center;
    }
    li {
      height: 80px;
      line-height: 80px;
      font-size: 28px;
      color: #666666;
      display: inline-block;
      width: 100px;
      margin: 0 72px;
      text-align: center;
    }
    .active {
      color: #0D61FE;
      border-bottom: 6px solid #0D61FE;
    }
  }

  .van-hairline--top-bottom::after,
  .van-hairline-unset--top-bottom::after {
    border: none;
  }

  /deep/ .van-dropdown-menu {
    height: 0.9rem;
  }

  .van-search {
    padding: 15px;
  }
</style>
