<template>
  <div class="car-detail">
    <div id="map"></div>
    <div class="fix-info">
      <h3>{{carData.carNumber}}</h3>
      <van-row>
        <van-col span="12">车辆类型：{{carData.carType}}</van-col>
        <van-col span="12">车辆状态：{{carData.useStatus}}</van-col>
      </van-row>
      <van-row>
        <van-col span="12">持证人：{{carData.name}}</van-col>
        <van-col span="12">终端号码：{{carData.equipmentNumber}} </van-col>
      </van-row>
      <van-row class="line">
        <van-col span="24">本次累计里程：{{carData.mileage}}公里</van-col>
      </van-row>
      <van-row>
        <van-col span="24">车辆累计里程：{{carData.accumulatedMileage}}公里</van-col>
      </van-row>
    </div>
  </div>
</template>
<script lang='ts'>
import { Component, Vue } from 'vue-property-decorator';
@Component
export default class AttendanceDetail extends Vue {
  private carData: any = {};
  private carNumber: any = null;
  private map: any = null;
  private marker: any = null;
  private mapContext: any = null;
  private position: any = {};

  /**
   * 定位获得当前位置信息
   */
  private getMyLocation() {
      let geolocation = new qq.maps.Geolocation('JLCBZ-2GQKJ-7CZFO-FW752-AEIYZ-67FWN', 'key');
      geolocation.getLocation(this.showPosition, this.showErr);
  }

  private showPosition(position: any) {
      console.log(position);
      this.setMapData();
  }

  // 定位失败再请求定位，测试使用
  private showErr() {
      console.log('定位失败，请重试！');
      this.getMyLocation();
  }
​
  /**
   * 位置信息在地图上展示
   */
  private setMapData() {
      let myLatlng = new qq.maps.LatLng(this.position.latitude, this.position.longitude);
      let myOptions = {
          zoom: 16,
          center: myLatlng,
          mapTypeId: qq.maps.MapTypeId.ROADMAP
      };
      // 获取dom元素添加地图信息
      const myMapContainer = document.getElementById('map');
      if (myMapContainer) {
        this.map = new qq.maps.Map(myMapContainer, myOptions);
  ​
        // 给定位的位置添加图片标注
        this.marker = new qq.maps.Marker({
            position: myLatlng,
            map: this.map,
            draggable: true // 允许鼠标拖动
        });
      }
  }

  private async getCarDetail(): Promise<void> {
    const res = await this.$api.xHttp.get(
      this.$interface.policeCar.carUseDetail + this.carNumber
    );
    if (res.code === 0) {
      this.position.longitude = res.data.beginLon;
      this.position.latitude = res.data.beginLat;
      this.position = {
        latitude: res.data.beginLat,
        longitude: res.data.beginLon
      };
      this.carData = res.data;
      this.getMyLocation();
    }
  }

  private mounted() {
    this.$nextTick(() => {
      this.carNumber = this.$route.params.carNumber;
      this.getCarDetail();
    });
  }
}
</script>
<style lang="less" scoped>
#map {
  width: 100%;
  height: 100%;
}
.car-detail {
  height: 100%;
}
.fix-info {
  // height: 45%;
  position: fixed;
  bottom: 0;
  left: 0;
  right: 0;
  padding: 0.5rem;
  box-sizing: border-box;
  background: #fff;
  border-top-left-radius: 0.39rem;
  border-top-right-radius: 0.39rem;
  h3 {
    color: #2158ed;
    font-size: 0.5rem;
  }
  .van-row {
    font-size: 0.39rem;
    padding: 0.25rem 0;
  }
  .line {
    margin-top: 0.25rem;
    border-top: 1px solid #eeeeee;
  }
}
</style>
