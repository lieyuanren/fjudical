<!--
 * @Author: lilili
 * @Date:2020-07-17 16:15:00
 * @LastEditors: lilili
 * @LastEditTime: 2020-07-17 16:15:00
 * @Description: file content
 -->
<template>
  <div class="internal-control">
    <div class="internal-control-body">
      <transition name="outIn"
                  mode="out-in">
        <component :is="componentId[active]"></component>
      </transition>
    </div>
    <div class="internal-control-menu">
      <van-tabbar v-model="active">
        <van-tabbar-item>
          <span>首页</span>
          <img :src="props.active ? menuIcon.homeActive : menuIcon.homeInactive"
               class="internal-control-menu-icon"
               slot="icon"
               slot-scope="props" />
        </van-tabbar-item>
        <van-tabbar-item>
          <span>信息管理</span>
          <img :src="props.active ? menuIcon.infoActive : menuIcon.infoInactive"
               class="internal-control-menu-icon"
               slot="icon"
               slot-scope="props" />
        </van-tabbar-item>
      </van-tabbar>
    </div>
  </div>
</template>

<script lang='ts'>
import { Component, Vue } from 'vue-property-decorator';
import Data from './data/index.vue';
import Info from './info/index.vue';

@Component({
  components: {
    Data,
    Info
  }
})
export default class InternalControl extends Vue {
  // 底部菜单图标
  private menuIcon: any = {
    homeActive: require('../../../assets/images/modules/police-car/tabs/home01.png'),
    homeInactive: require('../../../assets/images/modules/police-car/tabs/home02.png'),
    infoActive: require('../../../assets/images/modules/police-car/tabs/info01.png'),
    infoInactive: require('../../../assets/images/modules/police-car/tabs/info02.png')
  };

  private active: number = 0;

  // 组件名
  private componentId: string[] = ['Data', 'Info'];
}
</script>

<style lang='less' scoped>
.internal-control {
  height: 100%;

  &-menu {
    height: 92px;
    &-icon {
      height: 44px;
      width: 44px;
    }
  }
}

.outIn-enter,
.outIn-leave-to {
  opacity: 0;
}

.outIn-enter-active,
.outIn-leave-active {
  transition: opacity 0.3s;
}
</style>
 
