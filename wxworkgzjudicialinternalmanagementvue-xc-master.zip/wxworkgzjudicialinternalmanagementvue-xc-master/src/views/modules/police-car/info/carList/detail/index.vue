<template>
  <div class="car-detail">
    <h3>{{details.carNumber}}</h3>
    <div class="fix-info">
      <van-row v-for="(item, index) in data"
               :key="index"
               :class="{'marginTop': item.isMarginTop}">
        <van-col span="8">{{item.label}}：</van-col>
        <van-col span="16">{{details[item.value]}}</van-col>
      </van-row>
    </div>
  </div>
</template>
<script lang='ts'>
import { Component, Prop, Vue } from 'vue-property-decorator';
@Component
export default class AttendanceDetail extends Vue {
  private carId: any = null;
  private details: any = {};
  private detail1: any = {};
  private detail2: any = {};
  private data: any = [{
    label: '所属单位',
    value: 'orgName'
  }, {
    label: '车辆类型',
    value: 'carType'
  }, {
    label: '驾驶员',
    value: 'driverName'
  }, {
    label: '行驶公里数',
    value: 'accumulatedMileage'
  }, {
    label: '品牌型号',
    value: 'carBrand',
    isMarginTop: true
  }, {
    label: '车辆识别代号',
    value: 'carIdentificationNumber'
  }, {
    label: '发动机号码',
    value: 'engineNumber'
  }, {
    label: '排量',
    value: 'displacement'
  }, {
    label: '注册日期',
    value: 'loginDate',
    isMarginTop: true
  }, {
    label: '发证日期',
    value: 'certificationDate'
  }, {
    label: '出厂日期',
    value: 'deliveryDate'
  }, {
    label: '车辆来源',
    value: 'source'
  }, {
    label: '购车日期',
    value: 'buyDate'
  }, {
    label: '车身颜色',
    value: 'carColour',
    isMarginTop: true
  }, {
    label: '车身尺寸',
    value: 'carSize'
  }, {
    label: '终端号码',
    value: 'equipmentNumber',
    isMarginTop: true
  }, {
    label: '终端安装日期',
    value: 'equipmentInstallDate'
  }, {
    label: '终端型号',
    value: 'equipmentType'
  }, {
    label: '备注',
    value: 'remark',
    isMarginTop: true
  }];

  private mounted() {
    this.$nextTick(() => {
      this.carId = this.$route.params.carId;
      this.getCarDetails();
    });
  }

  private async getCarDetails(): Promise<void> {
    const res = await this.$api.xHttp.get(
      this.$interface.policeCar.carDetails + this.carId
    );
    if (res.code === 0) {
      this.detail1 = res.data;
      this.getCarDetail();
    }
  }

  private async getCarDetail(): Promise<void> {
    const res = await this.$api.xHttp.get(
      this.$interface.policeCar.carDetail + this.carId
    );
    if (res.code === 0) {
      this.detail2 = res.data;
      this.details = Object.assign(this.detail1, this.detail2);
      console.log(this.details);
    }
  }
}
</script>
<style lang="less" scoped>
.car-detail {
  height: 100%;
  h3 {
    color: #fff;
    font-size: 0.59rem;
    padding: 0.75rem 0.8rem 2rem;
    background: url("../../../../../../assets/images/modules/police-car/infoBg2.png")
      no-repeat top center;
    background-size: contain;
  }
}
.fix-info {
  // height: 45%;
  position: fixed;
  bottom: 0;
  top: 2.4rem;
  left: 0;
  right: 0;
  padding: 0.39rem 0.5rem;
  box-sizing: border-box;
  background: #fff;
  border-top-left-radius: 0.39rem;
  border-top-right-radius: 0.39rem;
  overflow-y: auto;
  .van-row {
    font-size: 0.39rem;
    padding: 0.15rem 0;
    color: #363740;
  }
  .marginTop {
    margin-top: 0.68rem;
  }
  .line {
    margin-top: 0.25rem;
    border-top: 1px solid #eeeeee;
  }
  .van-col--8 {
    color: #959ba6;
  }
}
</style>
