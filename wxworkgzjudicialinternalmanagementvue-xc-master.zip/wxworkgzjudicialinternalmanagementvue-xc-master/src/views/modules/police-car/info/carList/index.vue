<!--
 * @Author: lilili
 * @Date:2020-07-17 16:15:00
 * @LastEditors: lilili
 * @LastEditTime: 2020-07-17 16:15:00
 * @Description: file content
 -->
 <template>
  <div class="attendance-manage">
    <div class="appraiser-head">
      <van-search @input="handleInput"
                  placeholder="搜索"
                  show-action
                  @search="onSearch"
                  @cancel="onCancel"
                  v-model="keyword" />
      <van-row>
        <van-col span="12">
          <van-button class="showPop"
                      @click="showPop"
                      type="default">{{treeDefault}}
            <van-icon name="play"
                      color="#323233"
                      size="2" />
          </van-button>
        </van-col>
        <van-col span="12">
          <van-dropdown-menu>
            <van-dropdown-item v-model="value2"
                               placeholder="请选择车辆状态"
                               :options="option2">
            </van-dropdown-item>
          </van-dropdown-menu>
        </van-col>
      </van-row>
    </div>
    <!-- 数据列表 -->
    <van-pull-refresh v-model="refreshing"
                      @refresh="onRefresh">
      <van-list v-model="loading"
                :finished="finished"
                finished-text="没有更多了"
                @load="downLoad">
        <div class='listCardBox'>
          <div class='listCard'
               v-for="(item,index) in cardList"
               :item="item"
               :key="index"
               @click="openDetail(item)">
            <van-tag :type="item.useStatus === '行驶' ? 'primary': 'danger'">{{item.useStatus}}</van-tag>
            <h3>{{item.carNumber}}</h3>
            <div class="info">
              <p>
                <van-image width="16"
                           height="16"
                           :src="require('@/assets/images/modules/police-car/org.png')" />{{item.orgName}}
              </p>
              <p>
                <van-image width="16"
                           height="16"
                           :src="require('@/assets/images/modules/police-car/carType.png')" />{{item.accumulatedMileage}}
              </p>
            </div>
          </div>
        </div>
      </van-list>
    </van-pull-refresh>
    <!-- 选择单位-弹出层 -->
    <van-popup v-model="isShowPop1"
               round
               closeable
               position="bottom"
               :style="{ height: '45%' }">
      <div>
        <h4 style="position:absolute;left: 20px;top: 15px" @click="returnLevel()">返回</h4>
        <h3 style="text-align:center ">{{treeDefault}}</h3>
      </div>
      <van-tree-select name="myTree"
                       :items="items"
                       :active-id.sync="activeId"
                       @click-item="clickTreeItem"
                       @click-nav="indexChange"
                       :main-active-index.sync="activeIndex" />
    </van-popup>
  </div>
</template>

<script lang='ts'>
import { Component, Vue, Watch } from 'vue-property-decorator';
import DataCard from '@/components/modules/attendance-manage/data-card/index.vue';
// @ts-ignore
import Common from '@/utils/common/common';
import { TreeSelect } from 'vant';

@Component({
  components: {
    DataCard,
    VanTreeSelect: TreeSelect
  }
})
export default class AttendanceData extends Vue {
  private keyword: string = '';
  private pageIndex: number = 1;
  private treeDefault: string = '选择单位';
  private value1: number = 0;
  private option1: any = [
        { text: '选择单位', value: 0 },
        { text: '新款商品', value: 1 },
        { text: '活动商品', value: 2 }
  ];
  private value2: any = null;
  private option2: any = [
        { text: '全部车辆状态', value: null },
        { text: '行驶', value: '行驶' },
        { text: '停驶', value: '停驶' }
  ];
  private timerLimit: any = null;
  // 数据列表
  private cardList: any = [];
  // 刷新
  private currentPage: number = 1;
  private pageSize: number = 10;
  private loading: boolean = false;
  private finished: boolean = false;
  private refreshing: boolean = false;
  private isShowPop1: boolean = false;
  private activeId: number = 1;
  private activeIndex: number = 0;
  private items: any = [];
  private orgTree: any = [];
  private orgNames: string[];

  // 鉴定人总数
  private count: number = 0;

   private async getListData(): Promise<void> {
    const res = await this.$api.xHttp.post(
      this.$interface.policeCar.carList,
      {
        keyword: this.keyword,
        current: this.currentPage,
        size: 10,
        useStatus: this.value2,
        orgNames: this.orgNames
      }
    );

    if (res.code === 0) {
      this.loading = false;
      const records = res.data.records;
      if (records === null || records.length === 0) {
        if (this.currentPage === 1) {
          this.cardList = [];
        }
        this.finished = true;
        return;
      }
      if (records.length < this.pageSize) {
        this.finished = true;
      }
      if (this.currentPage === 1) {
        this.cardList = records;
      } else {
        this.cardList.push(...records);
      }
      if (!this.finished) {
        this.currentPage++;
      }
    }
  }

  private mounted() {
    this.getListData();
    this.getOrgList();
  }

  private openDetail(item: any) {
    this.$router.push({
      path: `/car-info/${item.carId}`
    });
  }

  private showPop() {
    this.isShowPop1 = true;
  }

  /**
   * 上拉刷新
   */
  private onLoad() {
    if (this.refreshing) {
      this.refreshing = false;
      this.cardList = [];
    }
  }

  private downLoad() {
    console.log(this.currentPage, 'downLoad');
    this.getListData();
  }

  private onSearch(val: any) {
    console.log(val);
  }
  private onCancel() {
    console.log('onCancel');
  }

  private onRefresh() {
    this.currentPage = 1;
    // 清空列表数据
    this.finished = false;
    // 重新加载数据
    // 将 loading 设置为 true，表示处于加载状态
    this.loading = true;
    this.getListData();
    this.onLoad();
  }

  // 关键字搜索
  private handleInput(): void {
    clearTimeout(this.timerLimit);
    this.timerLimit = setTimeout(async () => {
      this.onRefresh();
    }, 1000);
  }
  private async getOrgList(): Promise<void> {
    const res = await this.$api.xHttp.get(
      this.$interface.policeCar.getOrgList
    );
    if (res.code === 0) {
      let dataStr = JSON.stringify(res.data);
      dataStr = dataStr.replace(/name/g, 'text');
      dataStr = dataStr.replace(/childrenList/g, 'children');
      dataStr = dataStr.replace(/organizationId/g, 'id');
      this.items = [JSON.parse(dataStr)];
      this.orgTree = [JSON.parse(dataStr)];
    }
  }

  private clickTreeItem(data: any) {
    if (data.children.length !== 0) {
      this.items = data.children;
    }
    this.currentPage = 1;
    console.log('clickTreeItem', data.text);
    this.orgNames = [];
    this.orgNames.push(data.text);
    this.getListData();
    this.treeDefault = data.text;
    this.isShowPop1 = false;
  }

  private indexChange(index: any) {
    console.log(this.items[index], 'aaaa');
    if (this.items[index].children.length === 0) {
      this.orgNames = [];
      this.orgNames.push(this.items[index].text);
      this.getListData();
      this.treeDefault = this.items[index].text;
      this.isShowPop1 = false;
    }
  }

  private returnLevel() {
    this.items = this.orgTree;
    this.treeDefault = '选择单位';
    this.isShowPop1 = true;
  }
}
</script>

<style lang='less' scoped>
.attendance-manage {
  .appraiser-head {
    background-color: #ffffff;
  }
  .tips {
    font-size: 24px;
    color: rgba(153, 153, 153, 1);
    padding: 30px;
  }
}
.listCardBox {
  padding: 20px;
  .listCard {
    border-radius: 8px;
    background: #fff;
    padding: 20px;
    position: relative;
    line-height: 2;
    .van-tag {
      position: absolute;
      right: 20px;
      top: 20px;
      padding-left: 15px;
      padding-right: 15px;
      border-top-left-radius: 8px;
      border-bottom-left-radius: 0;
      border-bottom-right-radius: 8px;
      border-top-right-radius: 0;
    }
    .van-tag--primary {
      background-color: #3770eb;
    }
    .van-tag--danger {
      background-color: #ff5b60;
    }
    h3 {
      font-size: 0.39rem;
      color: #363740;
    }
    .info {
      display: flex;
      font-size: 0.39rem;
      p {
        width: 40%;
        color: #b4b8be;
        display: flex;
        align-items: center;
        .van-image {
          margin-right: 10px;
        }
      }
    }
    .address {
      color: #b4b8be;
      font-size: 0.39rem;
    }
  }
  .listCard + .listCard {
    margin-top: 20px;
  }
}

.van-hairline--top-bottom::after,
.van-hairline-unset--top-bottom::after {
  border: none;
}

.van-search {
  padding: 30px;
}
.showPop.van-button--default {
  border: none;
  width: 100%;
  height: 1.28rem;
  z-index: 99;
  .van-icon-play {
    transform: rotate(90deg);
  }
}
.van-popup {
  overflow: hidden;
  h3 {
    font-size: 0.39rem;
    text-align: center;
    padding: 25px 0;
    color: #363740;
    border-bottom: 1px solid #eee;
  }
}
.van-tree-select {
  height: calc(100% - 1.25rem) !important;
}
.van-button__content {
  justify-content: flex-start;
}

.van-button {
  text-align: left;
}
/deep/.van-dropdown-menu__item {
  justify-content: flex-start;
  .van-dropdown-menu__title {
    font-size: 0.37rem;
  }
}
</style>
