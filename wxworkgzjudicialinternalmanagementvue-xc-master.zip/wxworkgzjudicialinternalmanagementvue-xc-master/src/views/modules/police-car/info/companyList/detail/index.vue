<template>
  <div class="car-detail">
    <h3>{{orgData.name}}</h3>
    <div class="fix-info">
      <van-row>
        <van-col span="6">上级单位：</van-col>
        <van-col span="18">{{orgData.parentName}}</van-col>
      </van-row>
      <van-row>
        <van-col span="6">单位：</van-col>
        <van-col span="18">{{orgData.name}}</van-col>
      </van-row>
      <van-row>
        <van-col span="6">联系人：</van-col>
        <van-col span="18">{{orgData.contactsName}}</van-col>
      </van-row>
      <van-row>
        <van-col span="6">联系电话：</van-col>
        <van-col span="18">{{orgData.contactsMobile}}</van-col>
      </van-row>
      <van-row>
        <van-col span="6">地址：</van-col>
        <van-col span="18">{{orgData.address}}</van-col>
      </van-row>
    </div>
  </div>
</template>
<script lang='ts'>
import { Component, Prop, Vue } from 'vue-property-decorator';
@Component
export default class AttendanceDetail extends Vue {
  private orgId: any = null;
  private orgData: any = {};

  private mounted() {
    this.$nextTick(() => {
      this.orgId = this.$route.params.organizationId;
      this.getOrgDetail();
    });
  }

   private async getOrgDetail(): Promise<void> {
    const res = await this.$api.xHttp.get(
      this.$interface.policeCar.orgDetail + this.orgId
    );
    if (res.code === 0) {
      this.orgData = res.data;
    }
  }
}
</script>
<style lang="less" scoped>
.car-detail {
  height: 100%;
  h3 {
    color: #fff;
    font-size: 0.59rem;
    padding: 0.75rem 0.8rem 2rem;
    background: url("../../../../../../assets/images/modules/police-car/infoBg.png")
      no-repeat top center;
    background-size: contain;
  }
}
.fix-info {
  // height: 45%;
  position: fixed;
  bottom: 0;
  top: 2.4rem;
  left: 0;
  right: 0;
  padding: 0.39rem 0.5rem;
  box-sizing: border-box;
  background: #fff;
  border-top-left-radius: 0.39rem;
  border-top-right-radius: 0.39rem;
  .van-row {
    font-size: 0.39rem;
    padding: 0.15rem 0;
    color: #363740;
  }
  .line {
    margin-top: 0.25rem;
    border-top: 1px solid #eeeeee;
  }
  .van-col--6 {
    color: #959ba6;
  }
}
</style>
