<template>
  <div class="car-detail">
    <h3>{{driverData.name}}</h3>
    <div class="fix-info">
      <van-row v-for="(item, index) in data"
               :key="index"
               :class="{'marginTop': item.isMarginTop}">
        <van-col span="8">{{item.label}}：</van-col>
        <van-col span="16">{{driverData[item.value]}}</van-col>
      </van-row>
    </div>
  </div>
</template>
<script lang='ts'>
import { Component, Prop, Vue } from 'vue-property-decorator';
@Component
export default class AttendanceDetail extends Vue {
  private driverId: any = null;
  private driverData: any = {};
  private driverData1: any = {};
  private driverData2: any = {};
  private data: any = [{
    label: '车牌号',
    value: 'carNumber'
  }, {
    label: '所属单位',
    value: 'orgName'
  }, {
    label: '电话号码',
    value: 'telephone'
  }, {
    label: '手机号码',
    value: 'phone',
    isMarginTop: true
  }, {
    label: '身份证号码',
    value: 'idCardNumber'
  }, {
    label: '驾驶证号',
    value: 'driverLicenseNumber',
    isMarginTop: true
  }, {
    label: '发证机关',
    value: 'issuingAuthority'
  }, {
    label: '证件有效期',
    value: 'termValidity'
  }, {
    label: '驾驶证类型',
    value: 'driverType'
  }];

   private mounted() {
    this.$nextTick(() => {
      this.driverId = this.$route.params.driverId;
      this.getDriverDetails();
    });
  }

   private async getDriverDetails(): Promise<void> {
    const res = await this.$api.xHttp.get(
      this.$interface.policeCar.driverDetails + this.driverId
    );
    if (res.code === 0) {
      this.driverData1 = res.data;
      this.getDriverDetail();
    }
  }

   private async getDriverDetail(): Promise<void> {
    const res = await this.$api.xHttp.get(
      this.$interface.policeCar.driverDetail + this.driverId
    );
    if (res.code === 0) {
      this.driverData2 = res.data;
      this.driverData = Object.assign(this.driverData1, this.driverData2);
    }
  }
}
</script>
<style lang="less" scoped>
.car-detail {
  height: 100%;
  h3 {
    color: #fff;
    font-size: 0.59rem;
    padding: 0.75rem 0.8rem 2rem;
    background: url("../../../../../../assets/images/modules/police-car/infoBg3.png")
      no-repeat top center;
    background-size: contain;
  }
}
.fix-info {
  // height: 45%;
  position: fixed;
  bottom: 0;
  top: 2.4rem;
  left: 0;
  right: 0;
  padding: 0.39rem 0.5rem;
  box-sizing: border-box;
  background: #fff;
  border-top-left-radius: 0.39rem;
  border-top-right-radius: 0.39rem;
  overflow-y: auto;
  .van-row {
    font-size: 0.39rem;
    padding: 0.15rem 0;
    color: #363740;
  }
  .marginTop {
    margin-top: 0.68rem;
  }
  .line {
    margin-top: 0.25rem;
    border-top: 1px solid #eeeeee;
  }
  .van-col--8 {
    color: #959ba6;
  }
}
</style>
