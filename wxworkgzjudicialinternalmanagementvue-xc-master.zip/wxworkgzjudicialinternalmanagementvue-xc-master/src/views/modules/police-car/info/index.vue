 <template>
  <div class="info-manage">
    <div class="info-manage-card"
         v-for="(item, index) in cards"
         @click="goTo(item.link)"
         :key="index">
      <div class="flexCenter">
        <van-image width="1rem"
                   height="1rem"
                   :src="item.icon" />
        {{item.title}}
      </div>
      <van-icon name="arrow"
                color="#B4B8BE"
                size="0.5rem" />
    </div>
  </div>
</template>

<script lang='ts'>
import { Component, Vue, Watch } from 'vue-property-decorator';
// @ts-ignore
import Common from '@/utils/common/common';

@Component({
  components: {
  }
})
export default class AttendanceRecord extends Vue {
  private cards: any = [{
    title: '单位信息管理',
    link: '/company-list',
    icon: require('@/assets/images/modules/police-car/companyInfo.png')
  }, {
    title: '车辆信息管理',
    link: '/car-list',
    icon: require('@/assets/images/modules/police-car/carInfo.png')
  }, {
    title: '驾驶员信息管理',
    link: '/driver-list',
    icon: require('@/assets/images/modules/police-car/driverInfo.png')
  }];

  private goTo(link: any) {
    this.$router.push({
      path: link
    });
  }
}
</script>

<style lang='less' scoped>
.info-manage {
  padding: 0.39rem;
  &-card {
    border-radius: 0.2rem;
    background: #fff;
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 0.39rem;
    font-size: 0.39rem;
    font-weight: 600;
    .van-image {
      margin-right: 0.24rem;
    }
    & + .info-manage-card {
      margin-top: 0.39rem;
    }
  }
}
.flexCenter {
  display: flex;
  justify-content: center;
  align-items: center;
}
</style>
