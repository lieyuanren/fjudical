<template>
  <div class="copy-give">
    <v-jstree :data="children"
              loading-text="loading"
              drag-over-background-color="white"
              size="large"
              show-checkbox
              multiple
              allow-batch
              whole-row
              @item-click="itemClick"></v-jstree>
  </div>
</template>

<script lang='ts'>
import { Component, Vue, Prop } from 'vue-property-decorator';
import { Getter, Mutation } from 'vuex-class';
import ListTreeType from '@/model/modules/t_manager/ListTreeType';
import TreeList from '@/components/modules/tmanager/create-tasks/v-tree-list/index.vue';
import NameCardType from '@/model/modules/t_manager/NameCardType';
// @ts-ignore
import VJstree from 'vue-jstree';

@Component({
  components: {
    TreeList,
    VJstree
  }
})
export default class CopyGive extends Vue {
  @Getter('companyList') private companyList: NameCardType[];
  @Getter('leaderList') private leaderList: NameCardType[];
  @Getter('personnelList') private personnelList: NameCardType[];
  @Getter('messageList') private messageList: NameCardType[];
  @Mutation('addAll') private addAll: any;
  @Mutation('delAll') private delAll: any;
  private propName: string = '';

  private children: ListTreeType[] = [];

  // 选择列表
  private dataList: ListTreeType[] = [
    // // 测试数据
    // {
    //   id: '1ds31',
    //   name: '中央军委',
    //   children: [
    //     {
    //       id: '123',
    //       name: '中央军委',
    //       children: [
    //         {
    //           id: '123444',
    //           name: '中央军委',
    //           children: [
    //             { id: '1', name: '张忠文1' },
    //             { id: '2', name: '张忠文2' },
    //             { id: '3', name: '张忠文3' }
    //           ]
    //         },
    //         {
    //           id: '1233',
    //           name: '中央军委',
    //           children: [
    //             { id: '4', name: '张忠文4' },
    //             { id: '8', name: '张忠文5' },
    //             { id: '9', name: '张忠文6' }
    //           ]
    //         }
    //       ]
    //     },
    //     {
    //       name: '中央军委',
    //       children: [
    //         { id: '7', name: '张忠文7' },
    //         { id: '6', name: '张忠文8' },
    //         { id: '11', name: '张忠文9' }
    //       ]
    //     }
    //   ] as ListTreeType[]
    // }
  ];

  public async activated(): Promise<void> {
    await this.getPropName();
    await this.getData();
    await this.initChildren();
  }

  private getListIds(item: ListTreeType) {
    const childs = item.children;
    if (childs && childs.length > 0) {
      for (let i of childs) {
        this.getListIds(i);
      }
    } else {
      if (item.selected) {
        // 添加
        this.addAll({
          propName: this.propName,
          arr: [
            {
              id: item.id,
              name: item.name,
              label: item.name,
              text: item.name
            }
          ]
        });
      } else {
        // 删除
        this.delAll({
          propName: this.propName,
          arr: [
            {
              id: item.id,
              name: item.name,
              label: item.name,
              text: item.name
            }
          ]
        });
      }
    }
  }

  private getPropName(): void {
    this.propName = this.$route.query.propName as string;
  }

  /**
   * 根据不同的typeIndex请求不同的数据
   * @params propName
   */
  private async getData() {
    let url = this.$interface.tManager.task.department;
    if (this.propName !== 'companyList') {
      url = this.$interface.tManager.task.deptAndUser;
    }
    const res = await this.$api.xHttp.get(url);
    if (res.code === 0) {
      this.dataList = res.data;
    }
  }

  private initChildren(): void {
    console.log('1123', this.children);
    for (const item of this.dataList) {
      this.setItem(item);
    }
    // 深拷贝整个数组
    this.children = JSON.parse(JSON.stringify(this.dataList));
    this.dataList = [];
  }

  private itemClick(node: any, item: any, other: any) {
    this.getListIds(item);
  }

  // 递归处理每一个项
  private setItem(item: ListTreeType): void {
    // 判断状态
    item.isChecked = false;
    item.text = item.name;
    item.opened = false;
    item.selected = false;
    item.selected = this.judegeState(item);
    item.icon = 'custom icon';
    if (item.children) {
      item.isOpen = true;
      for (const obj of item.children) {
        this.setItem(obj);
      }
    } else {
      return;
    }
  }

  // 判断状态
  private judegeState(item: ListTreeType): boolean {
    // @ts-ignore
    const isTrue = this[this.propName].some((obj: NameCardType): boolean => {
      if (item.id === obj.id) {
        return true;
      } else {
        return false;
      }
    });
    return isTrue;
  }
}
</script>

<style lang='less' scoped>
.copy-give {
  min-height: 100%;
  width: 100%;
  background: white;
  padding-top: 20px;
}
</style>
