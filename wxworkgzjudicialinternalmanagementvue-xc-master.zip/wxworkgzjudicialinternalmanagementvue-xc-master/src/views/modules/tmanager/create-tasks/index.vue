<template>
  <div class="create-tasks">
    <div class="create-tasks-info">
      <van-field v-model="taskName"
                 label="计划任务"
                 input-align="right"
                 placeholder="请输入任务名称"
                 required />
      <van-cell title="任务来源"
                is-link
                required
                :value="taskSource"
                @click="showPopup(0)"
                v-if="index==='3'||index==='2'" />
      <van-field v-model="sketch"
                 label="来源简述"
                 input-align="right"
                 placeholder="请输入来源简述"
                 v-if="index==='3'||index==='2'" />
      <van-cell title="开始时间"
                is-link
                required
                :value="startTime"
                @click="showPopup(1)" />
      <van-cell title="结束时间"
                is-link
                required
                :value="endTime"
                @click="showPopup(2)" />
      <van-cell title="任务级别"
                is-link
                :value="level"
                @click="showPopup(3)" />
    </div>
    <div class="create-tasks-add"
         v-if="index==='3'">
      <div class="create-tasks-add-cell"
           @click="goRoute('companyList')">
        <span class="create-tasks-add-cell-span">承办单位</span>
        <van-icon name="add-o" />
      </div>
      <div class="create-tasks-add-list"
           v-if="companyList.length>0? true : false">
        <transition-group name="fade"
                          mode="out-in"
                          tag="div">
          <NameCard v-for="item in companyList"
                    :key="item.id"
                    :item="item"
                    :propName="'companyList'" />
        </transition-group>
      </div>
    </div>
    <div class="create-tasks-add"
         v-if="index==='3'||index==='2'">
      <div class="create-tasks-add-cell"
           @click="goRoute('leaderList')">
        <span class="create-tasks-add-cell-span">分管领导</span>
        <van-icon name="add-o" />
      </div>
      <div class="create-tasks-add-list"
           v-if="leaderList.length>0? true : false">
        <transition-group name="fade"
                          mode="out-in"
                          tag="div">
          <NameCard v-for="item in leaderList"
                    :key="item.id"
                    :item="item"
                    :propName="'leaderList'" />
        </transition-group>

      </div>
    </div>
    <div class="create-tasks-add"
         v-if="index==='3'||index==='2'">
      <div class="create-tasks-add-cell"
           @click="goRoute('personnelList')">
        <span class="create-tasks-add-cell-span">承办人员</span>
        <van-icon name="add-o" />
      </div>
      <div class="create-tasks-add-list"
           v-if="personnelList.length>0? true : false">
        <transition-group name="fade"
                          mode="out-in"
                          tag="div">
          <NameCard v-for="item in personnelList"
                    :key="item.id"
                    :item="item"
                    :propName="'personnelList'" />
        </transition-group>

      </div>
    </div>
    <div class="create-tasks-add"
         v-if="index==='3'">
      <div class="create-tasks-add-cell"
           @click="goRoute('messageList')">
        <span class="create-tasks-add-cell-span">接受消息人员</span>
        <van-icon name="add-o" />
      </div>
      <div class="create-tasks-add-list"
           v-if="messageList.length>0? true : false">
        <transition-group name="fade"
                          mode="out-in"
                          tag="div">
          <NameCard v-for="item in messageList"
                    :key="item.id"
                    :item="item"
                    :propName="'messageList'" />
        </transition-group>
      </div>
    </div>
    <div class="create-tasks-add"
         v-if="index==='3'">
      <div class="create-tasks-add-cell">
        <span>距离任务结束前自动提醒</span>
        <van-icon name="add-o"
                  @click="show1 = true" />
      </div>
      <div class="create-tasks-add-list"
           v-if="jobList.length>0? true : false">
        <NameCard v-for="item in jobList"
                  :key="item.id"
                  :item="item"
                  :propName="'jobList'" />
      </div>
    </div>
    <div class="create-tasks-describe">
      <div class="tips">任务描述</div>
      <van-field v-model="describe"
                 class="borderArea"
                 placeholder="请输入"
                 type="textarea" />
    </div>
    <div class="create-tasks-btn">
      <div class="btn_2"
           @click="onOver">取消
      </div>
      <div class="btn_1"
           @click="onSubmit">保存
      </div>
    </div>
    <van-popup v-model="show"
               position="bottom">
      <van-picker :columns="columns1"
                  @confirm="onConfirm"
                  @cancel="onCancel"
                  show-toolbar
                  v-if="showIndex === 0" />
      <van-datetime-picker v-model="currentDate"
                           type="date"
                           show-toolbar
                           @confirm="timeConfirm"
                           @cancel="onCancel"
                           v-else-if="showIndex===1||showIndex===2" />
      <van-picker :columns="columns2"
                  @confirm="onConfirm"
                  @cancel="onCancel"
                  show-toolbar
                  v-else />
    </van-popup>
    <!-- 时间选择 -->
    <van-popup v-model="show1"
               position="bottom">
      <van-picker show-toolbar
                  @cancel="show1=false"
                  @confirm="onConfirmTime"
                  title="距离任务结束前"
                  :columns="columns5" />
    </van-popup>
  </div>
</template>

<script lang='ts'>
import { Component, Vue } from 'vue-property-decorator';
import { Getter, Mutation } from 'vuex-class';
import NameCard from '@/components/modules/tmanager/create-tasks/v-name-card/index.vue';
import NameCardType from '@/model/modules/t_manager/NameCardType';
import Task from '@/model/modules/t_manager/Task';
import BaseUser from '@/model/common/wxwork/BaseUser';
import LocalStorage from '@/utils/common/local-storage';

@Component({
  components: {
    NameCard
  }
})
export default class CreateTasks extends Vue {
  public show1: boolean = false;
  public columns: any[] = [];
  public columns5: any[] = [];
  public user: BaseUser = LocalStorage.get('USER');
  @Getter('companyList') private companyList: NameCardType[];
  @Getter('leaderList') private leaderList: NameCardType[];
  @Getter('personnelList') private personnelList: NameCardType[];
  @Getter('messageList') private messageList: NameCardType[];
  @Getter('jobList') private jobList: NameCardType[];
  @Mutation('clearStore') private clearStore: any;
  @Mutation('addAll') private addAll: any;
  // 任务名称
  private taskName: string = '';
  // 任务来源
  private taskSource: string = '请选择任务来源';
  // 来源简述
  private sketch: string = '';
  private currentDate: Date = new Date();
  private describe: string = '';
  private show: boolean = false;
  private showIndex: number = 0;
  private columns1: string[] = [];
  private columns2: string[] = ['低', '中', '高', '急'];
  private startTime: string = '';
  private endTime: string = '';
  private level: string = '低';
  // 用于区别当 任务类型
  // 1 个人
  // 2 部门
  // 3 督办
  private index: string = '1';
  private startDate: number;
  private endDate: number;

  public async activated(): Promise<void> {
    this.index = this.$route.query.index as string;
    const create = this.$route.query.create as string;
    if (create === 'true') {
      this.clearInfo();
      this.$router.replace({
        path: '/tmanager/createTasks',
        query: {
          index: this.index
        }
      });
    }
    await this.initAutoTime();
    await this.getTaskFrom();
    // 当承办单位有值的时候，联动显示承办人员
    if (this.companyList.length > 0) {
      this.showPersonnelList();
    }
  }

  public onConfirmTime(value: string[], index: number[]) {
    let job = new NameCardType();
    let day = index[0] + 1;
    let hour = index[1] + 1;
    job.name = job.name = day + '天' + hour + '小时';
    job.id = day * 24 + hour + '';
    let flag = true;
    for (const item of this.jobList) {
      if (item.id === job.id) {
        flag = false;
      }
    }
    if (flag) {
      this.addAll({
        propName: 'jobList',
        arr: [job]
      });
    }
    this.show1 = false;
  }

  /**
   * 联动显示承办人员
   * @resList : 后台请求回来的list
   */
  private async showPersonnelList(): Promise<void> {
    let resList: any[] = [];
    const newList: NameCardType[] = [];
    const deptId: string[] = [];
    this.companyList.forEach((item: NameCardType) => {
      deptId.push(item.id);
    });
    if (deptId.length > 0) {
      const res = await this.$api.xHttp.get(
        this.$interface.tManager.task.deptUser +
          '?deptId=' +
          this.parserArray(deptId),
        null,
        null
      );
      if (res.code === 0) {
        resList = res.data;
      }
      resList.forEach((item): void => {
        newList.push({
          id: item.userId,
          name: item.role
        });
      });
      this.addAll({
        propName: 'personnelList',
        arr: newList
      });
    }
  }

  private onConfirm(str: string): void {
    this.show = false;
    if (this.showIndex === 0) {
      this.taskSource = str;
    } else {
      this.level = str;
    }
  }

  private timeConfirm(date: Date): void {
    const time = new Date(date).getTime();
    console.log(date);
    this.show = false;
    if (this.showIndex === 1) {
      this.startTime = this.$utils.Common.dateFmt('yyyy-MM-dd', date);
      this.startDate = date.getTime();
      if (this.endTime) {
        const end = new Date(this.endTime).getTime();
        if (time > end) {
          this.$toast.fail('开始时间不能大于结束时间');
          return;
        }
      }
    } else if (this.showIndex === 2) {
      this.endTime = this.$utils.Common.dateFmt('yyyy-MM-dd', date);
      this.endDate = date.getTime();
      if (this.startTime) {
        const start = new Date(this.startTime).getTime();
        if (start > time) {
          this.$toast.fail('开始时间不能大于结束时间');
          return;
        }
      }
    }
  }

  private onOver(): void {
    this.clearInfo();
    this.$router.go(-1);
  }

  /**
   * 提交数据
   * 根据当前任务类型提交
   */
  private async onSubmit(): Promise<void> {
    this.addTask();
  }

  // 清楚信息
  private clearInfo(): void {
    this.taskName = '';
    this.taskSource = '请选择任务来源';
    this.sketch = '';
    this.describe = '';
    this.showIndex = 0;
    this.startTime = '';
    this.endTime = '';
    this.level = '低';
    this.clearStore();
  }

  private onCancel(): void {
    this.show = false;
  }

  private showPopup(index: number): void {
    this.show = true;
    this.showIndex = index;
    console.log(this.showIndex);
    
  }

  private goRoute(propName: string): void {
    this.$router.push({
      path: '/tmanager/copyGive',
      query: {
        propName
      }
    });
  }

  private addTask(): void {
    if (this.index === '1') {
      // 个人任务
      this.addPrivateTask();
    } else if (this.index === '2') {
      // 部门任务
      this.addDepartmentTask();
    } else {
      // 监督任务
      this.addSuperviseTask();
    }
  }

  private addPrivateTask(): void {
    const val = this.checkTask();
    if (this.notBlankStr(val)) {
      this.$toast(val);
      return;
    }
    const task = this.getBaseTask();
    task.taskFrom = '个人计划';
    this.doAddTask(task);
  }

  private addDepartmentTask(): void {
    const task = this.getBaseTask();
    task.taskFrom = this.taskSource;
    const val = this.checkTask();
    if (this.notBlankStr(val)) {
      this.$toast(val);
      return;
    }
    // 领导
    task.leaderIds = this.leaderList.map((item) => {
      return item.id;
    });
    // 承办
    task.undertakePersons = this.personnelList.map((item) => {
      return item.id;
    });
    if (this.checkTaskPerson()) {
      this.$toast('人员选择不能重复、为空(创建人，承办人员，分管领导重复)');
      return;
    }
    this.doAddTask(task);
  }

  private checkTaskPerson(): boolean {
    const personIds: string[] = [];
    this.personnelList.map((item) => {
      personIds.push(item.id);
    });
    if (this.personnelList.length === 0) {
      return true;
    }
    this.leaderList.map((item) => {
      personIds.push(item.id);
    });
    if (this.leaderList.length === 0) {
      return true;
    }
    this.messageList.map((item) => {
      personIds.push(item.id);
    });
    return this.isRepeat(personIds);
  }

  private isRepeat(arr: string[]): boolean {
    let hash = {};
    for (const item of arr) {
      // @ts-ignore
      if (hash[item]) {
        return true;
      }
      // 不存在该元素，则赋值为true，可以赋任意值，相应的修改if判断条件即可
      // @ts-ignore
      hash[item] = true;
    }
    return false;
  }

  private addSuperviseTask(): void {
    const val = this.checkTask();
    if (this.notBlankStr(val)) {
      this.$toast(val);
      return;
    }
    const task = this.getBaseTask();
    task.taskFrom = this.taskSource;
    // 领导
    task.leaderIds = this.leaderList.map((item) => {
      return item.id;
    });
    // 承办
    task.undertakePersons = this.personnelList.map((item) => {
      return item.id;
    });
    // 接受消息人员
    task.acceptPersons = this.messageList.map((item) => {
      return item.id;
    });
    if (this.companyList.length > 0) {
      let org = '';
      for (const item of this.companyList) {
        org += item.name;
        org += ',';
      }
      task.orginizer = org.substr(0, org.length - 1);
    }
    if (this.jobList.length !== 0) {
      task.jobs = [];
      for (const item of this.jobList) {
        task.jobs.push({
          status: 0,
          type: 1,
          sendTime: item.id,
          createTime: new Date()
        });
      }
    }
    if (this.checkTaskPerson()) {
      this.$toast(
        '人员选择不能重复、为空(创建人，承办人员，分管领导重复,接受消息人员)'
      );
      return;
    }
    this.doAddTask(task);
  }

  /**
   * 获取基础task
   */
  private getBaseTask(): Task {
    const task = new Task();
    // 时间
    task.beginDate = this.startDate;
    task.endDate = this.endDate;
    task.taskTitle = this.taskName;
    task.taskDesc = this.describe;
    task.createTime = new Date().getTime();
    task.taskType = this.index + '';
    if (this.level === '低') {
      task.taskLevel = '1';
    }
    if (this.level === '中') {
      task.taskLevel = '2';
    }
    if (this.level === '高') {
      task.taskLevel = '3';
    }
    if (this.level === '急') {
      task.taskLevel = '4';
    }
    return task;
  }

  /**
   * 添加任务
   * @param task
   */
  private async doAddTask(task: Task) {
    const res = await this.$api.xHttp.post(
      this.$interface.tManager.task.addTask,
      task,
      null
    );
    if (res.code === 0) {
      this.clearInfo();
      this.onOver();
    }
  }

  private async getTaskFrom() {
    const res = await this.$api.xHttp.get(
      this.$interface.tManager.task.taskFrom
    );
    if (res.code === 0) {
      this.columns1 = res.data;
    }
  }

  private parserArray(ids: string[]) {
    let id = '';
    for (const item of ids) {
      id += item;
      id += ',';
    }
    return id.substr(0, id.length - 1);
  }

  private async initAutoTime() {
    const v1: string[] = [];
    const v2: string[] = [];
    const hObject: any = { values: v1, defaultIndex: 5 };
    const dObject: any = { values: v2, defaultIndex: 12 };
    let hours: string[] = [];
    for (let i = 1; i < 24; i++) {
      hours.push(i + '小时');
    }
    let days: string[] = [];
    for (let i = 1; i < 30; i++) {
      days.push(i + '天');
    }
    hObject.values = hours;
    dObject.values = days;
    this.columns5 = [];
    this.columns5.push(dObject);
    this.columns5.push(hObject);
  }

  private notBlankStr(str: string): boolean {
    if (str) {
      if (str.length > 0) {
        return true;
      }
    }
    return false;
  }

  private checkTask(): string {
    let msg = '';
    if (!this.notBlankStr(this.taskName)) {
      msg = '任务名称不能为空';
    }
    if (this.taskSource === '请选择任务来源') {
      this.taskSource = '';
    }
    if (!this.notBlankStr(this.startTime)) {
      msg = '任务开始时间不能为空';
    }
    if (!this.notBlankStr(this.endTime)) {
      msg = '任务结束时间不能为空';
    }
    if (new Date(this.startTime).getTime() > new Date(this.endTime).getTime()) {
      msg = '开始时间不能大于结束时间';
    }
    return msg;
  }
}
</script>

<style lang='less' scoped>

  .borderArea {
    border-bottom: 1px solid rgba(235, 237, 240, 0.60);
    box-sizing: border-box;
    left: 15px
  }

.create-tasks {
  height: 100%;
  overflow-y: auto;

  &-info {
    margin-top: 30px;
    overflow: hidden;
  }

  &-add {
    padding: 30px;
    background-color: #ffffff;
    margin: 20px 0;

    &-cell {
      font-size: 28px;
      display: flex;
      justify-content: space-between;
      align-items: center;

      i {
        font-size: 42px;
        color: #0a5ffe;
      }
    }

    &-list {
      margin-top: 15px;
      border-top: 1px solid #eeeeee;
    }
  }

  &-describe {
    background-color: #ffffff;

    .tips {
      font-size: 28px;
      padding: 30px 30px 0 30px;
    }
  }

  &-btn {
    padding: 42px;
    background: #ffffff;
    display: flex;
    justify-content: space-between;

    .btn_1 {
      width: 310px;
      height: 98px;
      background-color: #0a5ffe;
      color: #ffffff;
      font-size: 36px;
      border-radius: 12px;
      text-align: center;
      line-height: 98px;
    }

    .btn_2 {
      width: 310px;
      height: 98px;
      background-color: #edf3ff;
      border: 1px solid #0a5ffe;
      border-radius: 12px;
      box-sizing: border-box;
      color: #0a5ffe;
      text-align: center;
      line-height: 98px;
      font-size: 36px;
    }
  }
}
.create-tasks-add-cell-span::before {
  color: #ee0a24;
  font-size: 0.37333rem;
  content: "*";
}

/deep/ .van-cell__value {
  color: #666666 !important;
}

/deep/ .van-field__control{
  color: #666666 !important;
}
</style>
