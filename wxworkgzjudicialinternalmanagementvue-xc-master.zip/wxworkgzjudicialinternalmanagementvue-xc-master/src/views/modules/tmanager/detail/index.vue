<template>
  <div>
    <div class="tmanager-detail">
      <div class="tmanager-detail-title">
        <div>{{taskInfo.taskName}}</div>
        <div :class="taskInfo.finish==='已完成'?'tmanager-detail-title-status1':'tmanager-detail-title-status'">
          {{taskInfo.finish}}
        </div>
      </div>
      <div class="tmanager-detail-content">
        <div class="tmanager-detail-content-item">
          <div class="tmanager-detail-content-item-left">任务级别</div>
          <div class="tmanager-detail-content-item-right">{{taskInfo.taskLevel}}</div>
        </div>
        <div class="tmanager-detail-content-item">
          <div class="tmanager-detail-content-item-left">类型</div>
          <div class="tmanager-detail-content-item-right">{{taskInfo.taskType}}</div>
        </div>
        <div class="tmanager-detail-content-item">
          <div class="tmanager-detail-content-item-left">创建人</div>
          <div class="tmanager-detail-content-item-right">{{taskInfo.taskCreator}}</div>
        </div>
        <div class="tmanager-detail-content-item">
          <div class="tmanager-detail-content-item-left">创建时间</div>
          <div class="tmanager-detail-content-item-right">{{taskInfo.createTime}}</div>
        </div>
        <div class="tmanager-detail-content-item">
          <div class="tmanager-detail-content-item-left">计划开始时间</div>
          <div class="tmanager-detail-content-item-right">{{taskInfo.startTime}}</div>
        </div>
        <div class="tmanager-detail-content-item">
          <div class="tmanager-detail-content-item-left">计划结束时间</div>
          <div class="tmanager-detail-content-item-right">{{taskInfo.endTime}}</div>
        </div>
        <div class="tmanager-detail-content-item">
          <div class="tmanager-detail-content-item-left">剩余(天)</div>
          <div class="tmanager-detail-content-item-right">{{taskInfo.surplus}}</div>
        </div>
      </div>
      <div class="tmanager-detail-subtitle">
        <div>任务描述</div>
      </div>
      <div class="tmanager-detail-subcontent">
        {{taskInfo.taskDesc}}
      </div>
    </div>
    <van-collapse style="margin-top: 10px"
                  v-if="taskInfo.taskType !=='个人任务'"
                  v-model="activeNames">
      <van-collapse-item class="tmanager-condition-subtitle"
                         name="1"
                         size="large"
                         title="领导意见">
        <div :class="index == (taskInfo.advise.length-1) ? '':'message-bom'"
             :key="index"
             v-for="(item,index) in taskInfo.advise">
          <span class="person">
            <div class="person-left">{{item.user}}</div>
            <div class="person-right">{{item.createTime}}</div>
          </span>
          <span class="tmanager-condition-subcontent">
            {{item.taskRecordContent}}
          </span>
        </div>
      </van-collapse-item>
    </van-collapse>

    <van-collapse style="margin-top: 10px"
                  v-if="taskInfo.taskType !=='个人任务'"
                  v-model="activeNames1">
      <van-collapse-item class="tmanager-condition-subtitle"
                         name="1"
                         size="large"
                         title="工作进度">
        <div :class="index == (taskInfo.progress.length-1) ? '':'message-bom'"
             :key="index"
             v-for="(item,index) in taskInfo.progress">
          <span class="person">
            <div class="person-left">{{item.user}}</div>
            <div class="admin/api/wechat/loginByAccount person-right">{{item.createTime}}</div>
          </span>
          <span class="tmanager-condition-subcontent">
            {{item.taskRecordContent}}
          </span>
        </div>
      </van-collapse-item>
    </van-collapse>

    <!-- 时间选择 -->
    <van-popup :style="{ height: '30%' }"
               position="bottom"
               v-model="show">
      <van-picker :columns="columns"
                  @cancel="show=false"
                  @confirm="onConfirm"
                  show-toolbar
                  title="距离任务结束前" />
    </van-popup>

    <!-- 创建人审核 -->
    <div class="tmanager-condition"
         style="margin-top: 10px"
         v-if="isCreator && roleType !==3 && taskInfo.finish !== '已完成'">
      <div class="tmanager-condition-subtitle1">
        <div class="wenzi">
          <div style="float: left;">距离任务结束前自动提醒</div>
          <img @click="show=true"
               v-if="isAdd"
               class="add"
               src="@/assets/images/modules/tmanager/add.png" />
        </div>
        <div class="tmanager-condition-subcontent1"
             style="width: 100%">
          <div :key="index"
               class="item"
               v-for="(item,index) in taskInfo.jobs">
            <div class="item-left">{{item.title}}</div>
            <img @click="closeJob(item.id,index)"
                 class="item-right"
                 src="@/assets/images/modules/tmanager/close@2x.png">
          </div>
        </div>
      </div>
      <div class="tmanager-condition-btns"
           style="padding-top: 20px;border-top: 1px solid #eeeeee;"
           v-if="applyNumber === 0 ||applyNumber === 3">
        <div @click="applyFinish"
             class="tmanager-condition-btns-save">办结
        </div>
        <div @click="saveTime"
             :class="isAdd ? 'tmanager-condition-btns-over' : 'tmanager-condition-btns-over2'">
          保存
        </div>
      </div>
      <div class="tmanager-condition-btns"
           style="padding-top: 20px;border-top: 1px solid #eeeeee;"
           v-if="applyNumber === 1">
        <div @click="apply(2)"
             class="tmanager-condition-btns-save">确认办结
        </div>
        <div @click="apply(3)"
             class="tmanager-condition-btns-over">拒绝
        </div>
      </div>
      <div class="tmanager-condition-btns"
           style="padding-top: 20px;border-top: 1px solid #eeeeee;"
           v-if="applyNumber === 2 || taskInfo.taskType === '已完成'">
        <div @click="saveToList"
             class="tmanager-condition-btns-save">返回
        </div>
        <div class="tmanager-condition-btns-over2">保存</div>
      </div>
    </div>

    <div class="tmanager-condition"
         style="margin-top: 10px"
         v-if="!isCreator && roleType !==3 && taskInfo.finish !== '已完成'">

      <div class="tmanager-condition-subtitle"
           v-if="taskInfo.taskType !=='个人任务'&& roleType !==3  ">
        <div>{{roleType===1?'领导意见':'任务办理情况'}}</div>
        <div class="tmanager-condition-subcontent"
             style="width: 100%">
          <textarea placeholder="内容描述"
                    style="width: 100%;height: 60px;border:none"
                    v-model="message">
          </textarea>
        </div>
      </div>

      <!--个人任务 -->
      <div class="tmanager-condition-btns"
           v-if="taskInfo.taskType === '个人任务'">
        <div class="tmanager-condition-btns-over1"
             v-if="taskInfo.finish === '已完成'">
          <div @click="saveToList">返回</div>
        </div>
        <div @click="saveToList"
             class="tmanager-condition-btns-save"
             v-if="taskInfo.finish !== '已完成'">返回
        </div>
        <div @click="applyFinish"
             class="tmanager-condition-btns-over"
             v-if="taskInfo.finish !== '已完成'">办结
        </div>
      </div>

      <!-- 非个人任务 -->
      <div class="tmanager-condition-btns"
           v-if="taskInfo.taskType !== '个人任务'">
        <!-- 未完成 ，并且没有申请办结.或者申请被拒绝-->
        <div @click="saveProgress"
             class="tmanager-condition-btns-save"
             v-if="taskInfo.taskType !== '未完成' && ( applyNumber ===0 || applyNumber ===3)">保存
        </div>
        <!-- 承办人员 -->
        <div @click="applyFinish"
             class="tmanager-condition-btns-over"
             v-if="taskInfo.taskType !== '未完成' && (applyNumber ===0 || applyNumber ===3) && roleType === 2">申请办结
        </div>
        <!-- 领导 -->
        <div @click="saveToList"
             class="tmanager-condition-btns-over"
             v-if="taskInfo.taskType !== '未完成' && (applyNumber ===0 || applyNumber ===3) && roleType === 1">返回
        </div>

        <!-- 未完成，正在申请 -->
        <div @click="saveProgress"
             class="tmanager-condition-btns-save"
             v-if="taskInfo.taskType !== '未完成' && ( applyNumber ===1)">保存
        </div>
        <div @click="saveToList"
             class="tmanager-condition-btns-over"
             v-if="taskInfo.taskType !== '未完成' && (applyNumber ===1)">返回
        </div>
        <!-- 已完成 -->
        <div @click="saveToList"
             class="tmanager-condition-btns-over1"
             v-if="taskInfo.taskType !== '已完成' && applyNumber ===2">返回
        </div>
      </div>

    </div>

    <div class="tmanager-condition"
         style="margin-top: 10px"
         v-if="roleType ===3 && taskInfo.finish !== '已完成'" >
      <div class="tmanager-condition-btns">
        <div @click="saveToList"
             class="tmanager-condition-btns-over1">返回
        </div>
      </div>
    </div>

  </div>
</template>

<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';
import TaskInfo from '@/model/modules/t_manager/TaskInfo';
import TaskProgress from '@/model/modules/t_manager/TaskProgress';
import LocalStorage from '@/utils/common/local-storage';
import BaseUser from '@/model/common/wxwork/BaseUser';
import Job from '@/model/modules/t_manager/Job';

@Component({})
export default class TManagerDetail extends Vue {
  public columns: any[] = [];
  public user: BaseUser = LocalStorage.get('USER');
  public activeNames = ['0'];
  public activeNames1 = ['0'];
  public message: string = '';
  public isGR = false;
  public show: boolean = false;
  public isAdd: boolean = true;
  public taskInfo: TaskInfo = new TaskInfo();
  public taskId: string = '';
  public roleType: number = 1;
  public isCreator: boolean = false;
  public applyNumber: number = 0;

  public activated() {
    let query = this.$route.query as any;
    this.columns = [];
    this.isAdd = true;
    console.log(query);
    const hObject = {};
    const dObject = {};
    let hours: any[] = [];
    for (let i = 1; i < 24; i++) {
      hours.push(i + '小时');
    }
    let days: any[] = [];
    for (let i = 0; i < 30; i++) {
      days.push(i + '天');
    }
    // @ts-ignore
    hObject.values = hours;
    // @ts-ignore
    dObject.values = days;
    this.columns.push(dObject);
    this.columns.push(hObject);
    const id = query.id;
    this.taskId = id;
    this.getTask(id);
    this.message = '';
  }

  public async apply(item: number) {
    const url = `?taskId=${this.taskId}&type=${item}`;
    const res = await this.$api.xHttp.get(
      this.$interface.tManager.task.applyTask + url,
      null,
      null
    );
    console.log('办结', res);
    this.saveToList();
  }

  public saveToList() {
    console.log('跳转');
    // this.$router.push({
    //   path: '/tmanager/todo'
    // });
    this.$router.go(-1);
  }

  public async saveTime() {
    if (!this.isAdd) {
      return;
    }
    const jobs = this.taskInfo.jobs;
    let applyJobs = [];
    applyJobs.push({
      taskId: this.taskId
    });

    if (jobs.length !== 0) {
      applyJobs = [];
    }
    for (const item of jobs) {
      applyJobs.push({
        taskId: this.taskId,
        status: 0,
        type: 1,
        sendTime: item.time,
        createId: this.user.externalUser.otherId,
        createTime: new Date()
      });
    }
    const res = await this.$api.xHttp.post(
      this.$interface.tManager.task.saveTimes,
      applyJobs,
      null
    );
    console.log('添加自动提醒', res);
    this.saveToList();
  }

  public onConfirm(value: string[], index: number[]) {
    let job = new Job();
    let day = index[0] + 1;
    let hour = index[1] + 1;
    job.title = job.title = day + '天' + hour + '小时';
    job.time = day * 24 + hour;
    let flag = true;
    for (const item of this.taskInfo.jobs) {
      if (item.time === job.time) {
        flag = false;
      }
    }
    if (flag) {
      this.taskInfo.jobs.push(job);
      this.taskInfo.jobs.sort((a, b) => a.time - b.time);
    }
    this.show = false;
  }

  public async closeJob(jobId: number, index: number) {
    this.taskInfo.jobs.splice(index, 1);
  }

  public async applyFinish() {
    const res = await this.$api.xHttp.get(
      this.$interface.tManager.task.apply + '?taskId=' + this.taskId,
      null,
      null
    );
    console.log('res', res);
    this.saveToList();
  }

  // 保存进度
  public async saveProgress() {
    if (this.message.length === 0) {
      alert('内容描述不能为空');
      return;
    }
    const progress = new TaskProgress();
    progress.content = this.message;
    progress.taskId = this.taskId;
    progress.type = this.roleType;
    if (this.roleType === 2) {
      progress.type = 1;
    }
    if (this.roleType === 1) {
      progress.type = 2;
    }
    const res = await this.$api.xHttp.post(
      this.$interface.tManager.task.progress,
      progress,
      null
    );
    console.log('res', res);
    this.saveToList();
  }

  public async getTask(task: string) {
    this.isAdd = true;
    const res = await this.$api.xHttp.get(
      this.$interface.tManager.task.detail + '?taskId=' + task,
      null,
      null
    );
    if (res.code === 0) {
      const data = res.data as any;
      const info = new TaskInfo();
      info.taskName = data.taskTitle;
      info.taskDesc = data.taskDesc;
      if (data.taskState === '2') {
        info.finish = '已完成';
      } else if (data.taskState === '3') {
        info.finish = '待验收';
      } else {
        info.finish = '未完成';
      }
      if (data.taskLevel === '1') {
        info.taskLevel = '低';
      } else if (data.taskLevel === '2') {
        info.taskLevel = '中';
      } else if (data.taskLevel === '3') {
        info.taskLevel = '高';
      } else {
        info.taskLevel = '急';
      }
      if (data.taskType === '1') {
        this.isGR = true;
        info.taskType = '个人任务';
      } else if (data.taskType === '2') {
        info.taskType = '部门任务';
      } else {
        info.taskType = '督办任务';
      }
      info.taskCreator = data.user;
      info.createTime = this.getDateFormat(data.createTime);
      info.startTime = this.getDateFormat(data.beginDate);
      info.endTime = this.getDateFormat(data.endDate);
      if (info.finish === '已完成') {
        this.isAdd = false;
        info.surplus = '0';
      } else {
        let now = new Date().getTime();
        let day = data.endDate - now;
        let d = day / 1000 / 60 / 60 / 24;
        info.surplus = parseInt(d + '', 10).toString();
        if (d < 0) {
          this.isAdd = false;
          info.surplus =
            '已逾期' +
            parseInt(d + '', 10)
              .toString()
              .replace('-', '') +
            '天';
        }
      }
      if (data.role) {
        for (const item of data.role) {
          if (item.role === '0') {
            this.roleType = 1;
          }
          if (item.role === '1') {
            this.roleType = 2;
          }
          if (item.role === '2') {
            this.roleType = 3;
            break;
          }
        }
      }
      info.advise = data.leaderAdviceList;
      info.progress = data.taskCaseList;
      const jobs = [];
      if (data.messageJobs) {
        for (const item of data.messageJobs) {
          let job = new Job();
          job.id = item.id;
          job.time = item.sendTime;
          if (job.time === 24) {
            job.title = '1天0小时';
          }
          if (job.time < 24) {
            job.title = '0天' + job.time + '小时';
          }
          if (job.time > 24) {
            const hour = job.time % 24;
            const day = parseInt(job.time / 24 + '', 10);
            job.title = day + '天' + hour + '小时';
          }
          jobs.push(job);
        }
      }
      info.jobs = jobs;
      this.taskInfo = info;
      this.applyNumber = data.applyNumber;
      if (data.createId === this.user.externalUser.otherId) {
        this.isCreator = true;
        this.roleType = 0;
      }
    }
  }

  public getDateFormat(l: string) {
    const date = new Date(parseInt(l, 10));
    let year = date.getFullYear();
    let month = date.getMonth() + 1;
    let day = date.getDate();
    let day1 = '';
    if (day < 10) {
      day1 = '0' + day;
    } else {
      day1 = day + '';
    }
    return `${year}-${month}-${day1}`;
  }
}
</script>

<style lang="less" scoped>
.add {
  width: 50px;
  height: 50px;
  margin-left: 648px;
  margin-top: -100px;
}

.item {
  float: left;
  margin-bottom: 40px;
  margin-right: 68px;
  padding: 2px;
  height: 70px;
  margin-left: 10px;
  background: rgba(250, 250, 250, 1);
  border: 1px solid rgba(228, 228, 228, 1);
  width: 150px;
  border-radius: 8px;
  line-height: 70px; /*让黄色div中的文字内容垂直居中*/
  text-align: center; /*让文字水平居中*/
  color: #333333;

  &-left {
    font-weight: 400;
  }

  &-right {
    position: relative;
    height: 40px;
    width: 40px;
    margin-top: -210px;
    margin-left: 140px;
  }
}

.wenzi {
  height: 69px;
  margin-bottom: 40px;
  border-bottom: 1px solid #eeeeee;
}

.message-bom {
  margin-bottom: 20px;
  padding-bottom: 20px;
  border-bottom: 1px solid rgb(238, 238, 238);
}

.person {
  display: flex;
  margin-top: -10px;
  margin-bottom: 3px;
  justify-content: space-between;

  &-left {
    font-size: 30px;
    color: #666666;
  }

  &-right {
    color: #999999;
    font-weight: 400;
  }
}

.tmanager-detail {
  width: 100%;
  min-height: 780px;
  padding: 30px 30px;
  background: white;

  &-title {
    width: 690px;
    font-size: 36px;
    font-weight: bold;
    color: rgba(0, 0, 0, 1);
    padding-bottom: 25px;
    margin-bottom: 20px;
    border-bottom: 1px solid rgb(238, 238, 238);

    &-status {
      margin-top: 18px;
      width: 83px;
      height: 36px;
      line-height: 36px;
      border: 1px solid rgba(249, 90, 102, 1);
      border-radius: 4px;
      font-size: 22px;
      font-weight: 400;
      color: rgba(249, 90, 102, 1);
      text-align: center;
    }

    &-status1 {
      margin-top: 18px;
      width: 83px;
      height: 36px;
      line-height: 36px;
      border: 1px solid rgba(0, 204, 0, 1);
      border-radius: 4px;
      font-size: 22px;
      font-weight: 400;
      color: rgba(0, 204, 0, 1);
      text-align: center;
    }
  }

  &-content {
    width: 690px;
    margin-bottom: 42px;

    &-item {
      margin-bottom: 32px;
      width: 100%;
      display: flex;
      flex-direction: row;
      height: 28px;
      line-height: 28px;
      font-size: 28px;

      &-left {
        width: 200px;
        font-weight: 400;
        color: rgba(153, 153, 153, 1);
      }

      &-right {
        width: 490px;
        font-weight: 400;
        color: rgba(51, 51, 51, 1);
      }
    }
  }

  &-subtitle {
    width: 690px;
    font-size: 32px;
    font-weight: bold;
    color: rgba(0, 0, 0, 1);
    padding-bottom: 25px;
    margin-bottom: 20px;
    border-bottom: 1px solid rgb(238, 238, 238);
  }

  &-subcontent {
    width: 690px;
    min-height: 73px;
    font-size: 28px;
    font-weight: 400;
    color: rgba(51, 51, 51, 1);
    line-height: 48px;
  }
}

.tmanager-comment {
  background: white;
  width: 100%;
  height: 100%;
  padding: 30px 30px;
  margin-top: 30px;

  &-title {
    width: 690px;
    display: flex;
    flex-direction: row;

    &-left {
      font-size: 32px;
      color: rgba(51, 51, 51, 1);
    }

    &-right {
      width: 490px;
      font-size: 32px;
      text-align: right;
    }
  }
}

.tmanager-condition {
  background: white;
  width: 100%;
  height: 100%;
  padding: 30px 30px;

  &-subtitle {
    font-size: 32px;
    font-weight: bold;
    color: rgba(0, 0, 0, 1);
    border-bottom: 1px solid rgb(238, 238, 238);
  }

  &-subtitle1 {
    font-size: 32px;
    font-weight: bold;
    color: rgba(0, 0, 0, 1);
  }

  &-subcontent {
    margin-top: 20px;
    min-height: 173px;
    font-size: 28px;
    font-weight: 400;
    color: rgba(51, 51, 51, 1);
    line-height: 48px;
  }

  &-subcontent1 {
    font-size: 28px;
    font-weight: 400;
    color: rgba(51, 51, 51, 1);
    line-height: 48px;
    margin-bottom: 159px;
  }

  &-btns {
    display: flex;
    flex-direction: row;
    width: 750px;
    text-align: center;
    font-size: 36px;
    font-weight: 400;
    margin: 45px 0;

    &-save {
      margin-left: 11px;
      width: 310px;
      height: 98px;
      line-height: 98px;
      background: rgba(237, 242, 255, 1);
      border: 2px solid rgba(8, 96, 253, 1);
      border-radius: 12px;
      color: rgba(8, 95, 255, 1);
    }

    &-over {
      margin-left: 41px;
      width: 310px;
      height: 98px;
      line-height: 98px;
      background: rgba(8, 95, 255, 1);
      border: 2px solid rgba(8, 96, 253, 1);
      border-radius: 12px;
      color: rgba(255, 255, 255, 1);
    }

    &-over2 {
      margin-left: 41px;
      width: 310px;
      height: 98px;
      line-height: 98px;
      background: #878a91;
      border: 2px solid #65686c;
      border-radius: 12px;
      color: rgba(255, 255, 255, 1);
    }

    &-over1 {
      margin-left: 41px;
      width: 80%;
      height: 98px;
      line-height: 98px;
      background: rgba(8, 95, 255, 1);
      border: 2px solid rgba(8, 96, 253, 1);
      border-radius: 12px;
      color: rgba(255, 255, 255, 1);
    }
  }
}
</style>
