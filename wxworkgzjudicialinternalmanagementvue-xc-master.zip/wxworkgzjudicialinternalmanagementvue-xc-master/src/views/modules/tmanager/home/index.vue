<!--
 * @Author: tangzhicheng
 * @Date: 2020-04-29 11:47:15
 * @LastEditors: tangzhicheng
 * @LastEditTime: 2020-04-29 14:32:56
 * @Description: file content
 -->

 <template>
  <div class="home">
    <div class="home-banner">
      <img src="@/assets/images/modules/tmanager/banner.png"
           width="100%" />
    </div>
    <div @click="msgClick()"
         class="home-msg">
      <div class="home-msg-icon">
        <div class="home-msg-icon-item">
          <img class="home-msg-icon-img"
               src="@/assets/images/modules/tmanager/icon@2x.png" />
        </div>
      </div>
      <div class="home-msg-title">
        {{ content }}
      </div>
      <div class="home-msg-rIcon">
        <van-icon name="arrow" />
      </div>
    </div>
    <div class="home-title">
      <div class="home-title-label">我的待办</div>
      <div @click="moreClick()"
           class="home-title-more">
        查看更多
        <van-icon name="arrow"
                  style="margin-left: 2px; vertical-align: middle;" />
      </div>
    </div>
    <div></div>
    <div class="home-cards">
      <div :key="index"
           @click="manageClick(item.taskId)"
           class="home-cards-card"
           v-for="(item, index) in toDoTaskList">
        <div class="home-cards-card-title">
          <span>{{ item.title | lengthLimit }}</span>
          <van-tag plain
                   type="danger">{{ item.status }}</van-tag>
        </div>

        <div class="home-cards-card-item">
          <span>剩余(天)&nbsp;:&nbsp;</span>
          <span>{{ item.surplusDays }}天</span>
        </div>
        <div class="home-cards-card-item">
          <span>类型&nbsp;:&nbsp;</span>
          <span>{{ item.type }}</span>
        </div>
        <div class="home-cards-card-item">
          <span>级别&nbsp;:&nbsp;</span>
          <span>{{ item.level }}</span>
        </div>
        <div class="home-cards-card-item">
          <span>计划完成时间&nbsp;:&nbsp;</span>
          <span>{{ item.finishTime }}</span>
        </div>
      </div>
      <nodata v-if="toDoTaskList.length === 0"></nodata>
    </div>
  </div>
</template>

 <script lang='ts'>
import { Component, Vue } from 'vue-property-decorator';
import Nodata from '@/components/common/v-nodata/index.vue';

@Component({
  components: {
    Nodata
  },
  filters: {
    lengthLimit(val: string): string {
      if (val.length >= 15) {
        return val.substring(0, 14) + '...';
      }
      return val;
    }
  }
})
export default class Home extends Vue {
  private content = '';
  // 未完成任务
  private toDoTaskList = [];

  public created() {
    this.getToDOTaskList();
    this.getMessageList();
  }

  /**
   * 获取我的待办任务
   */
  public async getToDOTaskList(): Promise<void> {
    const res = await this.$api.xHttp.post(
      this.$interface.tManager.task.taskList,
      {},
      null
    );
    if (res.code === 0) {
      this.toDoTaskList = res.data.filter(
        (item: any) => item.status !== '已完成'
      );
    }
  }

  public msgClick(): void {
    this.$router.push({
      path: '/tmanager/message_list'
    });
  }

  public moreClick(): void {
    (this.$router as any).push({
      path: '/tmanager/todo',
      query: {
        index: 0
      }
    });
  }

  /**
   * 任务点击
   */
  public manageClick(id: string): void {
    console.log('任务点击');
    this.$router.push({
      path: '/tmanager/detail',
      query: {
        id
      }
    });
  }

  /**
   * 获取消息
   */
  public async getMessageList(): Promise<void> {
    const res = await this.$api.xHttp.get(
      this.$interface.tManager.message.list,
      null,
      null
    );
    if (res.code === 0) {
      if (res.data.length) {
        this.content = res.data.filter(
          (it: any) => it.status === '0'
        )[0].content;
      }
    }
  }
}
</script>

 <style lang='less' scoped>
.home {
  &-msg {
    width: 100%;
    height: 80px;
    line-height: 80px;
    display: flex;
    flex-direction: row;
    background: white;

    &-icon {
      width: 95px;

      &-item {
        width: 50px;
        position: relative;
      }

      &-img {
        position: absolute;
        top: 15px;
        right: -32px;
      }
    }

    &-title {
      width: 540px;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      font-size: 26px;
      font-weight: 400;
      color: rgba(102, 102, 102, 1);
    }

    &-rIcon {
      text-align: right;
      width: 90px;
      font-size: 32px;
      padding-top: 3px;
    }
  }

  &-title {
    display: flex;
    flex-direction: row;
    width: 690px;
    margin: 30px;
    justify-content: space-between;

    &-label {
      font-size: 36px;
      font-weight: 400;
      color: rgba(51, 51, 51, 1);
      text-align: left;
      width: 500px;
    }

    &-more {
      font-size: 26px;
      font-weight: 400;
      color: rgba(153, 153, 153, 1);
      text-align: right;
      vertical-align: middle;
      width: 160px;
    }
  }

  &-cards {
    padding: 0 30px;
    height: 680px;
    overflow-y: scroll;

    &-card {
      position: relative;
      width: 660px;
      height: 302px;
      background: rgba(255, 255, 255, 1);
      box-shadow: 0 4px 21px 0 rgba(221, 221, 221, 0.48);
      border-radius: 12px;
      padding-top: 30px;
      padding-left: 30px;
      margin-top: 30px;

      &-title {
        font-size: 32px;
        font-weight: 400;
        padding-right: 30px;
        line-height: 32px;
        color: rgba(51, 51, 51, 1);
        display: flex;
        justify-content: space-between;
        align-items: center;
      }

      &-item {
        margin-top: 10px;
        font-size: 28px;
        font-weight: 400;
        color: rgba(102, 102, 102, 1);
      }

      &-status {
        position: absolute;
        top: 30px;
        left: 577px;
        width: 83px;
        height: 36px;
        line-height: 36px;
        border: 1px solid rgba(53, 127, 250, 1);
        border-radius: 4px;
        text-align: center;
        font-size: 22px;
        font-weight: 400;
        color: rgba(53, 127, 250, 1);
      }
    }

    &-card:first-child {
      margin-top: 0;
    }
  }
}
</style>

