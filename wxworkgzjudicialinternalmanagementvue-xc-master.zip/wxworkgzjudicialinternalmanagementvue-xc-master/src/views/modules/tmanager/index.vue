<!--
 * @Author: tangzhicheng
 * @Date: 2020-04-29 11:38:36
 * @LastEditors: tangzhicheng
 * @LastEditTime: 2020-05-06 16:32:16
 * @Description: file content
 -->

<template>
  <div class="tmanager">
    <transition name="component-fade"
                mode="out-in">
      <component :is="componentIds[active]"></component>
    </transition>
    <div class="tmanager-menu">
      <van-tabbar v-model="active">
        <van-tabbar-item>
          <span>我的待办</span>
          <img :src="active === 0 ? menuIcon.homeActive : menuIcon.homeInactive"
               class="tmanager-menu-icon"
               slot="icon" />
        </van-tabbar-item>
        <van-tabbar-item>
          <span>任务管理</span>
          <img :src="active === 1 ? menuIcon.recordActive : menuIcon.recordInactive"
               class="tmanager-menu-icon"
               slot="icon" />
        </van-tabbar-item>
      </van-tabbar>
    </div>
    <div @click="show=true"
         class="tmanager-add">
      <img src="@/assets/images/modules/tmanager/add-01@2x.png" />
    </div>

    <van-popup :style="{ height : '35%' }"
               position="bottom"
               v-model="show">
      <div class="popup-contain">
        <div class="popup-contain-top">
          <div :key="index"
               @click="toCreate(index + 1)"
               class="popup-contain-top-item"
               v-for="(item, index) in cartoonIcons">
            <img :src="item.icon"
                 class="popup-contain-top-item-image">
            <div>{{ item.name }}</div>
          </div>
        </div>
        <div class="popup-contain-bottom">
          <img :src="require('../../../assets/images/modules/tmanager/index-close.png')"
               @click="show = false"
               class="popup-contain-bottom-image">
        </div>
      </div>
    </van-popup>
  </div>
</template>
 
 <script lang='ts'>
import { Component, Vue } from 'vue-property-decorator';
import Home from './home/index.vue';
import TaskManager from './task-manager/index.vue';

@Component({
  components: {
    Home,
    TaskManager
  }
})
export default class TManager extends Vue {
  // 底部菜单图标
  private menuIcon: any = {
    homeActive: require('../../../assets/images/modules/tmanager/home-active.png'),
    homeInactive: require('../../../assets/images/modules/tmanager/home-inactive.png'),
    recordActive: require('../../../assets/images/modules/tmanager/record-active.png'),
    recordInactive: require('../../../assets/images/modules/tmanager/record-inactive.png')
  };

  private cartoonIcons = [
    {
      name: '创建个人任务',
      path: 'person',
      icon: require('../../../assets/images/modules/tmanager/index-person.png')
    },
    {
      name: '创建部门任务',
      path: 'dept',
      icon: require('../../../assets/images/modules/tmanager/index-dept.png')
    },
    {
      name: '创建督办任务',
      path: 'supervise',
      icon: require('../../../assets/images/modules/tmanager/index-supervise.png')
    }
  ];
  private active: number = 0;

  private show: boolean = false;

  private componentIds: string[] = ['Home', 'TaskManager'];

  private toCreate(index: number): void {
    this.$router.push({
      path: '/tmanager/createTasks',
      query: {
        index: index + ''
      }
    });
  }
}
</script>
 
 <style lang='less' scoped>
.tmanager {
  width: 100%;
  height: 100%;

  &-menu {
    height: 92px;

    &-icon {
      height: 44px;
      width: 44px;
    }
  }

  &-add {
    width: 100px;
    height: 100px;
    position: fixed;
    bottom: 30px;
    z-index: 999;
    left: 330px;
  }
}

.popup-contain {
  margin: 85px 61px 0 61px;
  display: flex;
  flex-direction: column;

  &-top {
    display: flex;
    justify-content: space-between;

    &-item {
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;

      &-image {
        height: 110px;
        width: 110px;
      }
    }
  }

  &-bottom {
    display: flex;
    margin: 75px 0 0 0;
    align-items: center;
    justify-content: center;

    &-image {
      height: 84px;
      width: 84px;
    }
  }
}
</style>
 
