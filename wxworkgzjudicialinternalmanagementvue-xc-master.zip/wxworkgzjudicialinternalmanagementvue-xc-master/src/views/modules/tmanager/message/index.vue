<template>
  <div class="message-container">
    <div :key="index"
         class="message-container-list"
         v-for="(item, index) in messageList">
      <van-swipe-cell>
        <div class="message-container-list-item">
          <div class="message-container-list-item-title">
            <div :class="item.status === '0' ? 'message-container-list-item-title-icon' : ''"></div>
            <span>{{ item.sendUser }}给你发送了一条消息</span>
          </div>
          <span class="message-container-list-item-time">{{ timeStampToDateStr(item.sendTime) }}</span>
        </div>
        <div class="message-container-list-item-content">{{ item.content }}</div>
        <template slot="right">
          <div>
            <van-button @click="readed(item)"
                        color="#999999"
                        square
                        text="标为已读" />
            <van-button @click="deleted(item)"
                        square
                        text="删除"
                        type="danger" />
          </div>
        </template>
      </van-swipe-cell>
    </div>
    <nodata v-if="messageList.length === 0"></nodata>
  </div>
</template>

<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';
// @ts-ignore
import Nodata from '@/components/common/v-nodata';
import { SwipeCell } from 'vant';

Vue.use(SwipeCell);
@Component({
  components: {
    Nodata
  }
})
export default class Message extends Vue {
  public messageList = [];

  public activated () {
    this.getMessageList();
  }

  public async getMessageList() {
    const res = await this.$api.xHttp.get(
      this.$interface.tManager.message.list,
      null,
      null
    );
    if (res.code === 0) {
      this.messageList = res.data;
    }
  }

  /**
   * 时间戳转日期
   */
  public timeStampToDateStr(timeStamp: string) {
    let time = new Date(parseInt(timeStamp, 10));
    let year = time.getFullYear();
    let month = time.getMonth() + 1;
    let day = time.getDate();
    return year + '-' + this.add0(month) + '-' + this.add0(day);
  }

  /**
   * 增加0
   */
  public add0(m: number) {
    return m < 10 ? '0' + m : m;
  }

  /**
   * 已读
   */
  public async readed(item: any) {
    const body = {
      messageId: item.messageId
    };
    const res = await this.$api.xHttp.get(
      this.$interface.tManager.message.read,
      body,
      null
    );
    if (res.code === 0) {
      this.getMessageList();
    } else {
      this.$toast(res.msg);
    }
  }

  /**
   * 删除
   */
  public async deleted(item: any) {
    const body = {
      messageId: item.messageId
    };
    const res = await this.$api.xHttp.get(
      this.$interface.tManager.message.delete,
      body,
      null
    );
    if (res.code === 0) {
      this.getMessageList();
    } else {
      this.$toast(res.msg);
    }
  }
}
</script>

<style lang="less">
.message-container {
  height: 100%;
  background: rgba(255, 255, 255, 1);
  overflow-y: auto;
  &-list {
    display: flex;
    flex-direction: column;
    margin: 0 28px;
    padding: 36px 0;
    border-bottom: 2px solid #eeeeee;

    &-item {
      display: flex;
      justify-content: space-between;
      margin-bottom: 23px;

      &-title {
        font-size: 32px;
        font-weight: 400;
        color: #333333;
        display: flex;
        align-items: center;

        &-icon {
          width: 20px;
          height: 20px;
          background: red;
          border-radius: 20px;
          margin: 0 10px 0 0;
        }
      }

      &-time {
        font-size: 24px;
        font-weight: 400;
        color: #999999;
      }

      &-content {
        font-size: 28px;
        font-weight: 400;
        color: #999999;
        line-height: 42px;
      }
    }
  }
}

.van-swipe-cell__left,
.van-swipe-cell__right {
  position: absolute;
  top: 35%;
  height: 100%;
}
</style>
