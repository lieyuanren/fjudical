<template>
  <div class="report-container">

    <van-search @input="getTaskList"
                placeholder="搜索任务名称"
                v-model="taskName" />

    <van-dropdown-menu>
      <van-dropdown-item :options="typeList"
                         @change="typeChange"
                         v-model="type" />
      <van-dropdown-item :options="progressList"
                         @change="progressChange"
                         v-model="progress" />
    </van-dropdown-menu>
    <div class="report-container-row"></div>
    <div style="background: #FFFFFF;">
      <div :key="index"
           @click="TaskDetail(item)"
           class="report-container-item"
           v-for="(item, index) in taskList">
        <div class="report-container-item-one"
             v-if="item.type === '个人'">
          <img :src="require('../../../../assets/images/modules/tmanager/person.png')"
               class="report-container-item-one-image" />
          <div class="report-container-item-one-bottom">
            <div class="report-container-item-one-bottom-title">
              <span class="report-container-item-one-bottom-title-span">{{ item.title }}</span>
              <div :class="[progress === '2' ? 'status' : 'status1']">
                {{ item.status }}
              </div>
            </div>
            <div class="report-container-item-one-bottom-other">级别：{{ item.level }}</div>
            <div class="report-container-item-one-bottom-other">计划完成时间：{{ item.finishTime }}</div>
          </div>
        </div>
        <div class="report-container-item-two"
             v-else>
          <img class="report-container-item-one-image"
               :src="item.type === '部门' ? require('../../../../assets/images/modules/tmanager/dept.png') :
                    require('../../../../assets/images/modules/tmanager/supervide.png')"/>
		   <div class="report-container-item-one-bottom">
            <div class="report-container-item-one-bottom-title">
              <span class="report-container-item-one-bottom-title-span">{{ item.title }}</span>
              <div :class="progress === '2' ? 'status' : 'status1'">
                {{ item.status }}
              </div>
            </div>
            <div class="report-container-item-one-bottom-other">级别：{{ item.level }}</div>
            <div class="report-container-item-one-bottom-other">来源：{{ item.taskFrom }}</div>
            <div class="report-container-item-one-bottom-other">分区领导：{{ item.leader.toString() }}</div>
          </div>
        </div>
      </div>
    </div>
    <nodata v-if="taskList.length === 0"></nodata>

    <!-- <div class="report-container-menu">
      <van-tabbar v-model="active">
        <van-tabbar-item @click="tabClick(0)">
          <span>人员统计</span>
          <img :src="menuIcon.person"
               class="report-container-menu-icon"
               slot="icon" />
        </van-tabbar-item>
        <van-tabbar-item @click="tabClick(1)">
          <span>部门统计</span>
          <img :src="menuIcon.dept"
               class="report-container-menu-icon"
               slot="icon" />
        </van-tabbar-item>
        <van-tabbar-item @click="tabClick(2)">
          <span>督办统计</span>
          <img :src="menuIcon.supervise"
               class="report-container-menu-icon"
               slot="icon" />
        </van-tabbar-item>
      </van-tabbar>
    </div> -->
  </div>
</template>

<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';
import Nodata from '@/components/common/v-nodata/index.vue';

@Component({
  components: {
    Nodata
  }
})
export default class Report extends Vue {
  public taskName: string = '';

  public type: string = '';

  public progress: string = '';

  // public active: number = 0;

  public typeList = [
    { text: '全部', value: '' },
    { text: '个人', value: '1' },
    { text: '部门', value: '2' },
    { text: '督办', value: '3' }
  ];

  public progressList = [
    { text: '全部', value: '' },
    { text: '已逾期', value: '0' },
    { text: '未完成', value: '1' },
    { text: '已完成', value: '2' }
  ];

  // public menuIcon: any = {
  //   person: require('../../../../assets/images/modules/tmanager/report-person.png'),
  //   dept: require('../../../../assets/images/modules/tmanager/report-dept.png'),
  //   supervise: require('../../../../assets/images/modules/tmanager/report-supervise.png')
  // };

  public taskList = [];

  public activated () {
    this.getTaskList();
  }

  /**
   * 获取任务
   */
  public async getTaskList() {
    const body = {
      taskName: this.taskName,
      taskType: this.type,
      taskStatus: this.progress
    };
    const res = await this.$api.xHttp.post(
      this.$interface.tManager.task.taskList,
      body,
      null
    );
    if (res.code === 0) {
      this.taskList = res.data;
    }
  }

  /**
   * 选择任务类型
   */
  public typeChange(value: string) {
    this.type = value;
    this.getTaskList();
  }

  /**
   * 选择进度
   */
  public progressChange(value: string) {
    this.progress = value;
    this.getTaskList();
  }

  /**
   * tab点击
   */
  // public tabClick(e: number): void {
  //   this.active = e;
  //   this.$forceUpdate();
  //   console.log(this.active);
  //   this.$router.push({
  //     path: '/tmanager/static',
  //     query: {
  //       type: (this.active + 1).toString()
  //     }
  //   });
  // }

  /**
   * 跳转任务详情
   */
  public TaskDetail(item: any) {
    this.$router.push({
      path: '/tmanager/detail',
      query: {
        id: item.taskId
      }
    });
  }
}
</script>

<style lang="less" scoped>
.report-container {
  width: 100%;
  height: 100%;
  font-family: Microsoft YaHei;
  margin-bottom: 31px;
  &-row {
    height: 30px;
    background: #f2f2f2;
  }
  &-item {
    background: #ffffff;
    &-one {
      height: 204px;
      border-bottom: 1px solid #eeeeee;
      padding-bottom: 38px;
      &-image {
        height: 46px;
        width: 46px;
      }
      &-bottom {
        margin: 0 31px 0 60px;
        &-title {
          display: flex;
          justify-content: space-between;
          font-size: 32px;
          font-family: Microsoft YaHei;
          font-weight: 400;
          color: rgba(51, 51, 51, 1);
          margin-bottom: 10px;
          &-span {
            width: 80%;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
          }
        }
        &-other {
          font-size: 28px;
          font-family: Microsoft YaHei;
          font-weight: 400;
          color: rgba(102, 102, 102, 1);
          margin-bottom: 10px;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }
      }
    }
    &-two {
      height: 260px;
      border-bottom: 1px solid #eeeeee;
      padding-bottom: 38px;
    }
  }
  &-menu {
    height: 92px;
    &-icon {
      height: 44px;
      width: 44px;
    }
  }
}
.status1 {
  width: 83px;
  height: 36px;
  line-height: 36px;
  border: 1px solid rgba(249, 90, 102, 1);
  border-radius: 4px;
  font-size: 22px;
  font-weight: 400;
  color: rgba(249, 90, 102, 1);
  text-align: center;
}

.status {
  width: 83px;
  height: 36px;
  line-height: 36px;
  border: 1px solid rgba(0, 204, 0, 1);
  border-radius: 4px;
  font-size: 22px;
  font-weight: 400;
  color: rgba(0, 204, 0, 1);
  text-align: center;
}

/deep/ .van-search {
  -webkit-box-align: center;
  -webkit-align-items: center;
  align-items: center;
  box-sizing: border-box;
  padding: 21px 45px 0 45px;
}

/deep/ .van-tabbar {
  background: #f2f2f2;
}

/deep/ .van-tabbar-item--active {
  color: #7d7e80 !important;
}

/deep/ .van-tabbar-item--active .van-tabbar-item__text {
  color: #7d7e80 !important;
}

/deep/ .van-search .van-cell {
  -webkit-box-flex: 1;
  -webkit-flex: 1;
  flex: 1;
  padding: 0.13333rem 0.21333rem 0.13333rem 0;
  background-color: transparent;
  height: 72px;
}

/deep/ .van-search__content {
  -webkit-box-flex: 1;
  -webkit-flex: 1;
  flex: 1;
  padding-left: 0.21333rem;
  background-color: #f2f2f2;
  border-radius: 2px;
}



/deep/ .van-dropdown-menu {
  height: 94px;
  background-color: #fff;
  -webkit-user-select: none;
  user-select: none;
}

/deep/ .van-dropdown-menu__title {
  position: relative;
  box-sizing: border-box;
  max-width: 100%;
  padding: 0 0.21333rem;
  color: #666666;
  font-size: 28px;
  font-family: Microsoft YaHei;
  font-weight: 400;
  line-height: 0.48rem;
}
</style>
