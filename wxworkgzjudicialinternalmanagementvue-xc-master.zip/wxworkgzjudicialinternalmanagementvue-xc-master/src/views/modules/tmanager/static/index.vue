<template>
  <div class="home">
    <div class="head-tabs">
      <div :class="activeIndex === i?'head-tab tab-active':'head-tab'"
           :key="i"
           @click="setActiveIndex(i)"
           v-for="(text,i) in tabs">{{ text }}
      </div>
    </div>
    <div class="unit">
      <span>时间：{{ lastMonth | changeTime }}</span>
      <span>(单位：{{unit[activeIndex]}})</span>
    </div>
    <!-- 首页的三个模块 -->
    <transition mode="out-in"
                name="van-pop-in">
      <component :is="componentIds[activeIndex]"
                 :notarizationArr="notarizationArr"></component>
    </transition>

    <div class="report-container-menu">
      <van-tabbar v-model="active">
        <van-tabbar-item @click="tabClick(0)">
          <span>人员统计</span>
          <img :src="menuIcon.person"
               class="report-container-menu-icon"
               slot="icon" />
        </van-tabbar-item>
        <van-tabbar-item @click="tabClick(1)">
          <span>部门统计</span>
          <img :src="menuIcon.dept"
               class="report-container-menu-icon"
               slot="icon" />
        </van-tabbar-item>
        <van-tabbar-item @click="tabClick(2)">
          <span>督办统计</span>
          <img :src="menuIcon.supervise"
               class="report-container-menu-icon"
               slot="icon" />
        </van-tabbar-item>
      </van-tabbar>
    </div>
  </div>
</template>

<script lang="ts">
// @ts-ignore
import Notaries from './v-notaries';
// @ts-ignore
import NotarizationDetails from './v-tmanager-details';
// @ts-ignore
import NotariesModel from '@/model/modules/notarization/home/Notaries';
// @ts-ignore
import { Component, Vue } from 'vue-property-decorator';

@Component({
  components: {
    NotarizationDetails,
    Notaries
  },
  filters: {
    changeTime(value: string) {
      return `${value.substring(0, 4)}-${value.substring(4)}`;
    }
  }
})
export default class Home extends Vue {
  // tabs数组
  public tabs: string[] = ['当月周统计', '时间段统计'];
  // 当前tab索引
  public activeIndex: number = 0;
  // 单位
  public unit: string[] = ['次', '次', '人'];
  // 首页三模块组件名
  public componentIds: string[] = [
    'notarizationDetails',
    'notaries',
    'notaries'
  ];
  public number: string[] = ['一', '二', '三', '四', '五'];
  public notarizationArr: any[] = [];

  public lastMonth: string = '';

  public active: number = 0;

  public type: number = 0;
  
  public menuIcon: any = {
    person: require('../../../../assets/images/modules/tmanager/report-person.png'),
    dept: require('../../../../assets/images/modules/tmanager/report-dept.png'),
    supervise: require('../../../../assets/images/modules/tmanager/report-supervise.png')
  };


  // 这里执行三个报表数据请求
  public async created(): Promise<void> {
    this.type = 1;
    this.lastMonth = this.getMonth();
    this.notarizationArr = await this.getTaskStatic(this.type);
  }

  public async getTaskStatic(type: number): Promise<any[]> {
    let notarizationArr: any[] = [];
    const res = await this.$api.xHttp.get(
      this.$interface.tManager.task.staticTask + '?taskType=' + type,
      null
    );
    if (res.code === 0) {
      // day: {total: 0, finish: 0, doing: 0, noOver: 0}
      // month: {total: 0, finish: 0, doing: 0, noOver: 0}
      // week: {total: 0, finish: 0, doing: 0, noOver: 0}
      const month = res.data.month;
      const week = res.data.week;
      const day = res.data.day;
      console.log(res.data);
      notarizationArr = [
        {
          notarizationType: '当月报表',
          total: month.total,
          finish: month.finish,
          doing: month.doing,
          noOver: month.noOver
        },
        {
          notarizationType: '当周报表',
          total: week.total,
          finish: week.finish,
          doing: week.doing,
          noOver: week.noOver
        },
        {
          notarizationType: '当日报表',
          total: day.total,
          finish: day.finish,
          doing: day.doing,
          noOver: day.noOver
        }
      ];
    } else {
      this.$toast(res.msg);
    }
    return notarizationArr;
  }

  // 获取公证员数据
  public async getNotaries(): Promise<NotariesModel> {
    const param = {
      month: this.getMonth()
    };
    const res = await this.$api.xHttp.post(
      this.$interface.notarization.index.notaryCase,
      param
    );
    const notariesModel = new NotariesModel();
    if (res.code === 0) {
      let notaryArr = res.data.notary.split(',');
      notariesModel.inEditing = notaryArr[1];
      notariesModel.nonEditing = notaryArr[2];
      notariesModel.subtotal = notaryArr[3];
      let level = res.data.notaryLevel.split(',');
      for (let i = 1; i < level.length; i++) {
        let obj = {
          const: '',
          type: '',
          num: 0
        };
        obj.const = 'const';
        obj.type = this.number[i - 1];
        obj.num = level[i] * 1;
        notariesModel.viewData.push(obj);
      }
    } else {
      this.$toast(res.msg);
    }
    return notariesModel;
  }

  public setActiveIndex(index: number): void {
    this.activeIndex = index;
  }

  public getMonth(): any {
    const nowDate = new Date();
    let year = nowDate.getFullYear();
    let month = nowDate.getMonth() + 1;
    if (month === 0) {
      month = 12;
      year = year - 1;
    }
    let monthStr = month.toString();
    if (monthStr.length < 2) {
      monthStr = '0' + month;
    }
    return year + monthStr;
  }

  /**
   * tab点击
   */
  public async tabClick(e: number): Promise<void> {
    this.active = e;
    this.type = e + 1;
    this.lastMonth = this.getMonth();
    this.notarizationArr = await this.getTaskStatic(this.type);
    this.$forceUpdate();
  }
}
</script>
<style lang="less" scoped>
.home {
  .head-tabs {
    width: 100%;
    height: 238px;
    display: flex;
    justify-content: space-around;
    background-image: url("../../../../assets/images/modules/notarization/index/bg@2x.png");
    background-position: center center;
    background-repeat: no-repeat;
    background-size: cover;
    overflow: hidden;

    .head-tab {
      width: 214px;
      height: 90px;
      background: rgba(255, 255, 255, 1);
      border-radius: 8px;
      align-self: center;
      font-size: 32px;
      color: rgba(102, 102, 102, 1);
      text-align: center;
      line-height: 90px;
    }

    .tab-active {
      background: rgba(10, 95, 254, 1);
      color: rgba(255, 255, 255, 1);
    }
  }

  .unit {
    text-align: right;
    margin-top: 42px;
    padding: 0 40px;
    display: flex;
    font-size: 24px;
    justify-content: space-between;
  }

  .report-container-menu-icon {
    width: 36px;
    height: 36px;
  }
}
</style>
