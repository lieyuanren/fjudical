<!--
 * @Author: tangzhicheng
 * @Date: 2021-03-23 10:44:30
 * @LastEditors: tangzhicheng
 * @LastEditTime: 2021-05-27 14:26:04
 * @Description: file content
-->
<template>
  <div class="details-card">
    <h2 class="text2">
      <img :src="urlArr[iconIndex]" />
      <span>{{ item.notarizationType }}</span>
    </h2>
    <div class="content">
      <div class="sameMonth">
        <p class="text5">创建任务总数</p>
        <p class="text1">{{ item.total }}</p>
        <p class="text5">未完成任务数</p>
        <p class="text1">{{ item.doing }}</p>
      </div>
      <div class="cumulative">
        <p class="text5">逾期任务数</p>
        <p class="text1">{{ item.noOver }}</p>
        <p class="text5">已完成任务数</p>
        <p class="text1">{{ item.finish }}</p>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator';
// @ts-ignore
import NotarizationData from '../../../../../model/modules/notarization/home/Notarization';

@Component
export default class DetailsCard extends Vue {
  @Prop(Object) public item!: NotarizationData;

  // 图标数组
  public urlArr: string[] = [
    require('../../../../../assets/images/modules/notarization/index/icon-09@2x.png'),
    require('../../../../../assets/images/modules/notarization/index/icon-09@2x.png'),
    require('../../../../../assets/images/modules/notarization/index/icon-09@2x.png'),
    require('../../../../../assets/images/modules/notarization/index/icon-09@2x.png'),
    require('../../../../../assets/images/modules/notarization/index/icon-09@2x.png'),
    require('../../../../../assets/images/modules/notarization/index/icon-09@2x.png')
  ];

  public iconIndex: number = 0;

  public created(): void {
    this.iconIndex = 0;
  }
}
</script>

<style lang="less" scoped>
.details-card {
  margin: 30px;
  padding: 30px;
  background: rgba(255, 255, 255, 1);
  border: 1px solid rgba(224, 224, 224, 0.2);
  border-radius: 12px;

  h2 {
    img {
      width: 48px;
      height: 48px;
      vertical-align: middle;
    }
    span {
      vertical-align: middle;
      padding-left: 20px;
    }
  }

  .content {
    width: 100%;
    display: flex;
    margin-top: 22px;
    flex-wrap: wrap;

    .sameMonth,
    .cumulative {
      width: 50%;
      padding-left: 70px;
      box-sizing: border-box;
      flex-shrink: 0;
      box-sizing: border-box;
    }

    div:nth-child(2n) {
      border-left: 1px solid rgba(238, 238, 238, 1);
    }
  }
}
</style>
