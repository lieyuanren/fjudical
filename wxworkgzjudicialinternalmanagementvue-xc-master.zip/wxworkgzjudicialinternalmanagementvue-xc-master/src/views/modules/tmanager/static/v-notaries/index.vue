<template>
  <div class="notaries">
    <van-popup position="bottom"
               v-model="show">
      <van-picker @cancel="onCancel"
                  @confirm="timeConfirm"
                  show-toolbar
                  v-if="showIndex === 0" />
      <van-datetime-picker @cancel="onCancel"
                           @confirm="timeConfirm"
                           show-toolbar
                           type="datetime"
                           v-else-if="showIndex===1||showIndex===2"
                           v-model="currentDate" />
      <van-picker @cancel="onCancel"
                  @confirm="timeConfirm"
                  show-toolbar
                  v-else />
    </van-popup>
    <h2 class="text2">
      <img :src="iconUrl" />
      <span>时间段统计</span>
    </h2>
    <div>
      <br />
      <br />
      <van-cell :value="startTime"
                @click="showPopup(1)"
                is-link
                title="开始时间" />
      <br />
      <van-cell :value="endTime"
                @click="showPopup(2)"
                is-link
                title="结束时间" />
      <br />
    </div>
    <div class="flex-box">
      <div class="inEditing">
        <p class="text5">创建总数</p>
        <p class="text1">{{total}}</p>
      </div>
      <div class="nonEditing">
        <p class="text5">未完成</p>
        <p class="text1">{{doing}}</p>
      </div>
      <div class="subtotal">
        <p class="text5">已完成</p>
        <p class="text1">{{finish}}</p>
      </div>
      <div class="subtotal">
        <p class="text5">逾期</p>
        <p class="text1">{{noOver}}</p>
      </div>
    </div>
  </div>
</template>
<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';
// @ts-ignore
import NotariesModel from '@/model/modules/notarization/home/Notaries';
import DetailsCard from '@/views/modules/tmanager/static/v-details-card/index.vue';

@Component({
  components: {
    DetailsCard
  }
})
export default class Notaries extends Vue {
  public iconUrl: string = require('@/assets/images/modules/notarization/index/icon-15@2x.png');
  private startTime: string = '';
  private endTime: string = '';
  private currentDate: Date = new Date();
  private notariesData!: NotariesModel;

  private show: boolean = false;
  private showIndex: number = 0;

  private startDate: number;
  private endDate: number;

  private total: number = 0;
  private finish: number = 0;
  private doing: number = 0;
  private noOver: number = 0;

  public async activated() {
    this.startTime = '';
    this.endTime = '';
  }

  private timeConfirm(date: Date): void {
    this.show = false;
    if (this.showIndex === 1) {
      this.startTime = this.$utils.Common.dateFmt('yyyy-MM-dd hh:mm', date);
      this.startDate = date.getTime();
    } else {
      this.endTime = this.$utils.Common.dateFmt('yyyy-MM-dd hh:mm', date);
      this.endDate = date.getTime();
      this.getDate();
    }
  }

  private onCancel(): void {
    this.show = false;
  }

  private showPopup(index: number): void {
    this.show = true;
    this.showIndex = index;
  }

  private async getDate() {
    if (
      this.startDate &&
      this.startDate > 0 &&
      this.endDate &&
      this.endDate > 0
    ) {
      let url =
        '?start=' + this.startDate + '&&end=' + this.endDate + '&type=' + 1;
      const body = {
        start: this.startDate,
        end: this.endDate,
        type: this.$route.query.type
      };
      const res = await this.$api.xHttp.get(
        this.$interface.tManager.task.infoByTime + url,
        null,
        null
      );
      if (res.code === 0) {
        const data = res.data;
        this.total = data.total; // 总数
        this.finish = data.finish; // 完成
        this.doing = data.doing; // 未完成
        this.noOver = data.noOver; // 逾期
      }
    }
  }
}
</script>

<style lang="less" scoped>
.notaries {
  padding: 30px;
  margin: 30px;
  background: rgba(255, 255, 255, 1);
  border: 1px solid rgba(224, 224, 224, 0.2);
  border-radius: 12px;

  h2 {
    img {
      width: 48px;
      height: 48px;
      vertical-align: middle;
    }

    span {
      vertical-align: middle;
      padding-left: 20px;
    }
  }

  h3 {
    padding: 0 34px;
    margin-top: 90px;
  }

  .flex-box {
    display: flex;
    margin: 0 -20px;

    margin-top: 52px;

    div {
      flex: 1;
      text-align: center;
    }
  }
}
</style>
