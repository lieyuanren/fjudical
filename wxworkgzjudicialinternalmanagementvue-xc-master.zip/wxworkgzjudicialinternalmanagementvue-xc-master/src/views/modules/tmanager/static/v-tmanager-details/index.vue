<template>
  <div class="notarization-details">
    <DetailsCard :item="item"
                 :key="i"
                 v-for="(item,i) in notarizationArr" />
  </div>
</template>
<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator';
// @ts-ignore
import DetailsCard from '../v-details-card';
// @ts-ignore
import NotarizationModel from '@model/modules/notarization/home/Notarization';

@Component({
  components: {
    DetailsCard
  }
})
export default class NotarizationDetails extends Vue {
  @Prop({
    type: Array,
    default: []
  })
  public notarizationArr!: NotarizationModel[];
}
</script>
