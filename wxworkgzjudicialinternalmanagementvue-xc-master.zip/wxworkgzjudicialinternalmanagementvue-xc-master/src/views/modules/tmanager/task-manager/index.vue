<template>
  <div class="manager-container">
    <div class="manager-container-row"></div>
    <div style="background: #FFFFFF;">
      <div :key="index"
           @click="menuClick(item,index)"
           class="manager-container-line"
           v-for="(item, index) in menuList">
        <div class="manager-container-line-left">
          <img :src="item.icon"
               class="manager-container-line-left-image">
          <span class="manager-container-line-left-title">{{ item.name }}</span>
        </div>
        <div class="manager-container-line-right">
          <img :src="require('../../../../assets/images/modules/tmanager/arrows.png')"
               class="manager-container-line-right-image">
        </div>
      </div>
    </div>

    <!-- <div class="manager-container-menu">
      <van-tabbar v-model="active">
        <van-tabbar-item @click="tabClick(0)">
          <span>我的待办</span>
          <img :src="active === 0 ? menuIcon.homeActive : menuIcon.homeInactive"
               class="manager-container-menu-icon"
               slot="icon" />
        </van-tabbar-item>
        <van-tabbar-item>
          <span>任务管理</span>
          <img :src="menuIcon.recordActive"
               class="manager-container-menu-icon"
               slot="icon" />
        </van-tabbar-item>
      </van-tabbar>
    </div>
    <div class="manager-container-add">
      <img @click="addPopup"
           src="@/assets/images/modules/tmanager/add-01@2x.png" />
    </div> -->

    <!-- 弹出动画窗口 -->
    <!-- <van-popup :style="{ height: '35%' }"
               position="bottom"
               v-model="show">
      <div class="popup-contain">
        <div class="popup-contain-top">
          <div :key="index"
               @click="toCreate(index+1)"
               class="popup-contain-top-item"
               v-for="(item, index) in cartoonIcons">
            <img :src="item.icon"
                 class="popup-contain-top-item-image">
            <div>{{ item.name }}</div>
          </div>
        </div>
        <div class="popup-contain-bottom">
          <img :src="require('../../../../assets/images/modules/tmanager/index-close.png')"
               @click="closePopup"
               class="popup-contain-bottom-image">
        </div>
      </div>
    </van-popup> -->
  </div>
</template>

<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';

@Component({
  components: {}
})
export default class TaskManager extends Vue {
  // public active: number = 1;

  // 底部菜单图标
  // public menuIcon: any = {
  //   homeActive: require('../../../../assets/images/modules/tmanager/home-active.png'),
  //   homeInactive: require('../../../../assets/images/modules/tmanager/home-inactive.png'),
  //   recordActive: require('../../../../assets/images/modules/tmanager/record-active.png'),
  //   recordInactive: require('../../../../assets/images/modules/tmanager/record-inactive.png')
  // };

  // 菜单跳转选项
  public menuList = [
    {
      path: '/tmanager/todo',
      name: '我的待办',
      icon: require('../../../../assets/images/modules/tmanager/my-todo.png')
    },
    {
      path: '/tmanager/tasksList',
      name: '个人任务管理',
      icon: require('../../../../assets/images/modules/tmanager/person-task-manager.png')
    },
    {
      path: '/tmanager/tasksList',
      name: '部门任务管理',
      icon: require('../../../../assets/images/modules/tmanager/dept-task-manager.png')
    },
    {
      path: '/tmanager/tasksList',
      name: '督办任务管理',
      icon: require('../../../../assets/images/modules/tmanager/supervise-task-manager.png')
    },
    {
      path: '/tmanager/static',
      name: '统计报表',
      icon: require('../../../../assets/images/modules/tmanager/report.png')
    }
  ];

  // 弹出动画窗口标志
  public show = false;

  // 动画图标
  // public cartoonIcons = [
  //   {
  //     name: '创建个人任务',
  //     path: 'person',
  //     icon: require('../../../../assets/images/modules/tmanager/index-person.png')
  //   },
  //   {
  //     name: '创建部门任务',
  //     path: 'dept',
  //     icon: require('../../../../assets/images/modules/tmanager/index-dept.png')
  //   },
  //   {
  //     name: '创建督办任务',
  //     path: 'supervise',
  //     icon: require('../../../../assets/images/modules/tmanager/index-supervise.png')
  //   }
  // ];

  /**
   * tab点击
   */
  // public tabClick(e: number): void {
  //   this.active = e;
  //   this.$forceUpdate();
  //   console.log(this.active);
  //   if (this.active === 0) {
  //     this.$router.push({
  //       path: '/tmanager'
  //     });
  //   }
  // }

  // public activated() {
  //   this.active = 1;
  // }

  public menuClick(item: any, index: number) {
    console.log(index);
    
    if (index === 4) {
      this.$router.push({
        path: item.path
      });
    } else {
      this.$router.push({
        path: item.path,
        query: {
          index: index + ''
        }
      });
    }
  }

  /**
   * 弹出动画窗口
   */
  // public addPopup() {
  //   this.show = true;
  // }

  /**
   * 关闭动画窗口
   */
  // public closePopup() {
  //   this.show = false;
  // }

  // private toCreate(index: number): void {
  //   this.$router.push({
  //     path: '/tmanager/tasksList',
  //     query: {
  //       index: index + ''
  //     }
  //   });
  // }
}
</script>

<style lang="less" scoped>
.manager-container {
  width: 100%;
  height: 100%;
  &-row {
    height: 31px;
  }
  &-line {
    height: 120px;
    display: flex;
    align-items: center;
    margin: 0 32px 0 30px;
    background: #ffffff;
    justify-content: space-between;
    border-bottom: 1px solid #eeeeee;
    &-left {
      display: flex;
      align-items: center;
      &-image {
        width: 64px;
        height: 64px;
        margin-right: 33px;
      }
      &-title {
        font-size: 36px;
        font-family: Microsoft YaHei;
        font-weight: 400;
        color: rgba(51, 51, 51, 1);
      }
    }

    &-right {
      &-image {
        height: 26px;
        width: 16px;
      }
    }
  }
  &-menu {
    height: 92px;
    &-icon {
      height: 44px;
      width: 44px;
    }
  }
  &-add {
    width: 100px;
    height: 100px;
    position: fixed;
    bottom: 30px;
    z-index: 999;
    left: 330px;
  }
}

.popup-contain {
  margin: 85px 61px 0 61px;
  display: flex;
  flex-direction: column;
  &-top {
    display: flex;
    justify-content: space-between;
    &-item {
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      &-image {
        height: 110px;
        width: 110px;
      }
    }
  }
  &-bottom {
    display: flex;
    margin: 75px 0 0 0;
    align-items: center;
    justify-content: center;
    &-image {
      height: 84px;
      width: 84px;
    }
  }
}
</style>
