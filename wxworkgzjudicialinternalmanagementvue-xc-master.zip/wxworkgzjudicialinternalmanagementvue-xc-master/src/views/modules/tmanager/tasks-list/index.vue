<template>
  <div class="tasks-list">
    <div class="tasks-list-head">
      <van-search placeholder="请输入搜索关键词"
                  v-model="searchKey"/>
      <van-dropdown-menu>
        <van-dropdown-item :options="option"
                           @change="onChange"
                           v-model="index"/>
      </van-dropdown-menu>
    </div>
    <div @click="toAddTask"
         class="tasks-list-add">
      <img class="tasks-list-add-image"
           src="../../../../assets/images/modules/tmanager/task-add.png">
    </div>
    <div class="tasks-list-body">
      <TaskCard :item="item"
                :key="index"
                v-for="(item, index) in currentList"/>
    </div>
    <nodata v-if="currentList.length === 0"></nodata>
  </div>
</template>

<script lang='ts'>
import {Component, Vue, Watch} from 'vue-property-decorator';
import TaskCard from '@/components/modules/tmanager/tasks-list/v-task-card/index.vue';
import TaskCardType from '@/model/modules/t_manager/TaskCardType';
import Nodata from '@/components/common/v-nodata/index.vue';

@Component({
  components: {
    TaskCard,
    Nodata
  },
  beforeRouteEnter (to, from, next) {
    if (to.query.index) {
      next();
    } else {
      next('/tmanager');
    }
  }
})
export default class TasksList extends Vue {
  private searchKey: string = '';
  private index: string = '';
  private option: any[] = [
    {text: '全部', value: ''},
    {text: '已逾期', value: '0'},
    {text: '未完成', value: '1'},
    {text: '已完成', value: '2'}
  ];
  // 任务类型索引
  private typeIndex: string = '1';
  private currentList: TaskCardType[] = [];
  private timeLimit: any = null;

  public async activated () {
    console.log('created');
    await this.getTypeIndex();
    await this.getDateList();
  }

  /**
   * 跳转任务创建页面
   */
  public toAddTask () {
    this.$router.push({
      path: '/tmanager/createTasks',
      query: {
        index: this.typeIndex,
        create: 'true'
      }
    });
  }

  @Watch('searchKey')
  private watchSearchKey (): void {
    clearTimeout(this.timeLimit);
    this.timeLimit = setTimeout(() => {
      this.getDateList();
    }, 700);
  }

  private onChange (): void {
    this.getDateList();
  }

  /**
   * 请求数据
   * --所需参数--
   * @typeIndex :用于判断请求什么任务类型的数据 1 2 3
   * @searchKey :搜索索引 默认空
   * @index 转台类型索引
   */
  private async getDateList (): Promise<void> {
    this.currentList = [];
    const body = {
      taskName: this.searchKey,
      taskStatus: this.index,
      taskType: this.typeIndex
    };
    const res = await this.$api.xHttp.post(
      this.$interface.tManager.task.taskList,
      body,
      null
    );
    const that = this;
    if (res.code === 0) {
      if (res.data.length) {
        let taskCardType = null;
        res.data.forEach((item: any) => {
          taskCardType = new TaskCardType();
          taskCardType.title = item.title;
          taskCardType.state = item.status;
          taskCardType.taskId = item.taskId;
          const obj1 = {label: '级别', value: item.level};
          taskCardType.list.push(obj1);
          if (that.typeIndex === '1') {
            // 个人任务
            const obj2 = {label: '计划完成时间', value: item.finishTime};
            taskCardType.list.push(obj2);
          } else {
            // 部门任务
            const obj2 = {label: '来源', value: item.taskFrom};
            taskCardType.list.push(obj2);
            const obj3 = {label: '分管领导', value: item.leader.toString()};
            taskCardType.list.push(obj3);
          }
          this.currentList.push(taskCardType);
        });
      }
    }
  }

  // 获取任务类型
  private async getTypeIndex (): Promise<void> {
    this.typeIndex = this.$route.query.index as string;
    if (this.typeIndex === '1') {
      this.$utils.Common.setTitle('个人任务');
    }
    if (this.typeIndex === '2') {
      this.$utils.Common.setTitle('部门任务');
    }
    if (this.typeIndex === '3') {
      this.$utils.Common.setTitle('督办任务');
    }
  }
}
</script>

<style lang='less' scoped>
.tasks-list {
  position: relative;
  height: 100%;

  &-body {
    margin-top: 20px;
  }

  &-add {
    bottom: 15px;
    right: 15px;
    position: fixed;
    z-index: 999;

    &-image {
      height: 126px;
      width: 126px;
    }
  }
}
</style>
