<template>
  <div class="todo-container">
    <van-search v-model="taskName"
                placeholder="搜索任务名称"
                @input="getTaskList"/>

    <van-tabs v-model="active"
              color="#0D61FE"
              line-height="6px"
              title-active-color="#0D61FE"
              title-inactive-color="#333333"
              :border="false"
              @click="getTaskList">
      <van-tab name="1"
               title="未完成">
        <div class="row-class"></div>
        <div v-for="(item, index) in unFinishTaskList"
             class="todo-container-item"
             :key="index"
             @click="manageClick(item.taskId)">
          <div class="todo-container-item-title">
            <span class="title-span">{{ item.title }}</span>
            <div class="status1">
              {{ item.status }}
            </div>
          </div>
          <div class="todo-container-item-other">剩余（天）：{{ item.surplusDays }}<span>天</span></div>
          <div class="todo-container-item-other">类型：{{ item.type }}</div>
          <div class="todo-container-item-other">级别：{{ item.level }}</div>
          <div class="todo-container-item-time">计划完成时间：{{ item.finishTime }}</div>
        </div>
      </van-tab>
      <van-tab name="2"
               title="已完成">
        <div class="row-class"></div>
        <div v-for="(item, index) in finishTaskList"
             class="todo-container-item"
             :key="index"
             @click="manageClick(item.taskId)">
          <div class="todo-container-item-title">
            <span class="title-span">{{ item.title }}</span>
            <div class="status">
              {{ item.status }}
            </div>
          </div>
          <div class="todo-container-item-other">剩余（天）：{{ item.surplusDays }}<span>天</span></div>
          <div class="todo-container-item-other">类型：{{ item.type }}</div>
          <div class="todo-container-item-other">级别：{{ item.level }}</div>
          <div class="todo-container-item-time">计划完成时间：{{ item.finishTime }}</div>
        </div>
      </van-tab>
    </van-tabs>
  </div>
</template>

<script lang="ts">
  import {Tab, Tabs} from 'vant';
  import {Component, Vue} from 'vue-property-decorator';

  Vue.use(Tabs).use(Tab);
  @Component
  export default class Message extends Vue {
    public taskName: string = '';

    public active: number = 1;

    public unFinishTaskList = [];

    public finishTaskList = [];

    public activated () {
      this.getTaskList();
    }

    /**
     * 任务点击
     */
    public manageClick(id: string): void {
      console.log('任务点击');
      this.$router.push({
        path: '/tmanager/detail',
        query: {
          id
        }
      });
    }

    /**
     * 获取任务
     */
    public async getTaskList() {
      let body = {};
      body = {
        taskName: this.taskName
      };
      const res = await this.$api.xHttp.post(
        this.$interface.tManager.task.taskList,
        body,
        null
      );
      if (res.code === 0) {
        this.unFinishTaskList = res.data.filter((it: any) => {
          return it.status === '未完成' || it.status === '已逾期';
        });
        this.finishTaskList = res.data.filter((it: any) => {
          return it.status === '已完成';
        });
      }
    }
  }
</script>

<style lang="less" scoped>
  .todo-container {
    height: 100%;
    background: rgba(255, 255, 255, 1);
    overflow-y: auto;

    &-item {
      height: 288px;
      margin: 30px 30px 37px 30px;
      border-bottom: #eeeeee solid 2px;

      &-title {
        display: flex;
        justify-content: space-between;
        font-size: 32px;
        font-weight: 400;
        color: rgba(51, 51, 51, 1);
        margin-bottom: 5px;
      }

      &-other {
        font-size: 28px;
        font-weight: 400;
        color: #666666;
        margin-bottom: 5px;
      }

      &-time {
        font-size: 28px;
        font-weight: 400;
        color: #666666;
      }
    }
  }

  .row-class {
    height: 30px;
    background: #f2f2f2;
  }

  /deep/ .van-ellipsis {
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
    font-size: 28px;
  }

  /deep/ .van-tabs--line .van-tabs__wrap {
    height: 100px;
  }

  /deep/ .van-search {
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    box-sizing: border-box;
    padding: 21px 30px 0 30px;
  }

  /deep/ .van-search .van-cell {
    -webkit-box-flex: 1;
    -webkit-flex: 1;
    flex: 1;
    padding: 0.13333rem 0.21333rem 0.13333rem 0;
    background-color: transparent;
    height: 72px;
  }

  .status1 {
    width: 83px;
    height: 36px;
    line-height: 36px;
    border: 1px solid rgba(249, 90, 102, 1);
    border-radius: 4px;
    font-size: 22px;
    font-weight: 400;
    color: rgba(249, 90, 102, 1);
    text-align: center;
  }

  .status {
    width: 83px;
    height: 36px;
    line-height: 36px;
    border: 1px solid rgba(0, 204, 0, 1);
    border-radius: 4px;
    font-size: 22px;
    font-weight: 400;
    color: rgba(0, 204, 0, 1);
    text-align: center;
  }

  .title-span {
    width: 80%;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
</style>
