/**
 * @Author : ChangJun
 * @Date : 2019-06-18
 * @Version : 1.0
 * @Content : 项目配置文件
 */
const CompressionWebpackPlugin = require('compression-webpack-plugin');
const productionGzipExtensions = ['js', 'css'];
// 非开发环境
const isBuild = process.env.VUE_APP_CURRENTMODE !== 'development';
// 公共项目配置
const project_config = require('./src/config/index');
// 全局环境变量
const ENV = process.env.VUE_APP_CURRENTMODE;
// cdn
const cdn = {
  css: ['//cdn.jsdelivr.net/npm/vant@2.2.12/lib/index.css'],
  js: [
    '//cdn.jsdelivr.net/npm/vue@2.6.10/dist/vue.min.js',
    '//cdn.jsdelivr.net/npm/vuex@3.0.1/dist/vuex.min.js',
    '//cdn.jsdelivr.net/npm/vue-router@3.0.3/dist/vue-router.min.js',
    '//cdn.jsdelivr.net/npm/vant@2.2.12/lib/vant.min.js',
    '//cdn.jsdelivr.net/npm/moment@2.24.0/moment.min.js'
  ]
};
// proxy接口代理对象
let proxyObj = {};
project_config.proxy.dev.forEach(v => {
  proxyObj[v] = {
    target: project_config.proxy.domain[v][ENV],
    changeOrigin: true,
    secure: false,
    pathRewrite: {
      [`/${v}`]: ''
    }
  };
});
module.exports = {
  publicPath: '/',
  assetsDir: 'static',
  productionSourceMap: false,
  chainWebpack: config => {
    if (isBuild) {
      config.plugin('html')
        .tap(args => {
          args[0].cdn = cdn;
          return args;
        });
    }
  },
  configureWebpack: config => {
    if (isBuild) {
      config.externals = {
        'vue': 'Vue',
        'vuex': 'Vuex',
        'vue-router': 'VueRouter',
        'vant': 'vant',
        'moment': 'moment'
      };
    }
    config.performance = {
      hints: 'warning',
      //入口起点的最大体积 整数类型（以字节为单位）
      maxEntrypointSize: 50000000,
      //生成文件的最大体积 整数类型（以字节为单位 300k）
      maxAssetSize: 30000000,
      //只给出 js 文件的性能提示
      assetFilter: function (assetFilename) {
        return assetFilename.endsWith('.js');
      }
    };
    config.plugins.push(new CompressionWebpackPlugin({
      algorithm: 'gzip',
      test: new RegExp('\\.(' + productionGzipExtensions.join('|') + ')$'),
      threshold: 10240,
      minRatio: 0.8
    }));
  },
  // webPack-dev-server的所有选项
  devServer: {
    host: '',
    port: 80,
    https: false,
    open: false, // 自动启动浏览器
    proxy: proxyObj,
    historyApiFallback: true,
    disableHostCheck: true
  }
};
